"""합성 발신 연구소 — 제품 HubIndex 위에 발화 키 보증·철회를 admit하고, 편지와 판 보기를 만든다.

- 보증·철회 선언은 r3 모양(좌표 없는 선언 + grant)으로 `message.posted` 본문에 실려 admit된다.
- 인라인 보증 사본은 발화 키 r2 모양(hub 좌표·valid_from_seq·lab_sig)에 grant를 더한 것이다.
- 판 보기의 행은 원장 1..T를 재생해 만든다. 보증 seq n → valid_from_seq n+1, 철회 seq n →
  revoked_at_seq n+1(동결판 §5의 통일 규칙).
- 결정론: 고정 seed · 고정 시각 · BIP-340 aux 0 · provenance.platform 고정.
"""

from __future__ import annotations

import copy
import hashlib
import json
import sys
from pathlib import Path

_ROOT = Path(__file__).resolve().parents[2]
for _p in (_ROOT / "src", _ROOT / "experiments" / "identity-v0"):
    if str(_p) not in sys.path:
        sys.path.insert(0, str(_p))
from organum import hub_envelope as he  # noqa: E402
from organum import hub_log as hl  # noqa: E402
from organum import hub_ops as ho  # noqa: E402
from organum import schnorr_pure as sp  # noqa: E402
import voice  # noqa: E402

CLAIMS = {"claims": {"core:artifact.frozen": {
    "act_class": "self_attesting", "subject_types": ["artifact"],
    "ordering_levels": ["emission"], "capture_required": False,
    "revocation_authority": "same_signer"}}}
PLATFORM = "linux"


def seed_of(label: str) -> bytes:
    return hashlib.sha256(b"organum-credential-v0-fixture/" + label.encode()).digest()


def pub_of(seed: bytes) -> str:
    return sp.public_key(seed).hex()


def _cfg(lab: str) -> dict:
    return {"machine_id": "m-" + hashlib.sha256(lab.encode()).hexdigest()[:16]}


def _envelope_message(lab, *, to_lab, to_id, to_epoch, body: bytes, locator, at, media):
    env = ho.build_message_envelope(_cfg(lab), signer=lab, key_id="k1", epoch=1,
                                    to_lab=to_lab, to_id=to_id, to_epoch=to_epoch,
                                    body=body, body_locator=locator, media_type=media,
                                    created_at=at)
    env["provenance"]["platform"] = PLATFORM
    return env


def sign_env(env: dict, seed: bytes) -> str:
    return sp.sign(hashlib.sha256(he.canonical_bytes(env)).digest(), seed).hex()


class SenderLab:
    """발신 연구소 원장. 선언은 제품 admit 경로로만 들어간다."""

    def __init__(self, lab: str, seed: bytes):
        self.lab, self.seed = lab, seed
        keys = he.KeyRegistry()
        keys.register(pub_of(seed), signer_id=lab, key_id="k1", key_epoch=1)
        self.hub = he.HubIndex(
            key_registry=keys,
            claim_registry=he.ClaimRegistry(CLAIMS, expected_sha256=he.canonical_sha(CLAIMS)),
            log=hl.TransparencyLog(), source_domain=f"{lab}/hub")
        self.decls = []            # (seq, event_id, 선언)

    @property
    def T(self) -> int:
        return self.hub.log.tree_size

    def _admit(self, body: bytes, locator: str, at: str) -> tuple:
        env = _envelope_message(self.lab, to_lab=self.lab, to_id="registrar", to_epoch=1,
                                body=body, locator=locator, at=at, media="application/json")
        raw = he.canonical_bytes(env)
        r = self.hub.admit(raw, sign_env(env, self.seed), pub_of(self.seed))
        if not (r["admitted"] and not r["duplicate"]):
            raise AssertionError(f"합성 원장 admit 실패: {r.get('problems')}")
        return r["accepted_seq"], r["event_id"]

    def attest(self, subject: dict, voice_seed: bytes, *, grant=None, at: str) -> dict:
        decl = {"kind": "voice.attested", "lab": self.lab, "subject": subject,
                "voice_pubkey": pub_of(voice_seed), "at": at}
        if grant is not None:
            decl["grant"] = grant
        seq, eid = self._admit(voice._canon(decl), f"file://attest-{self.T + 1}.json", at)
        self.decls.append((seq, eid, decl))
        return self.inline_attestation(decl, seq, eid)

    def revoke(self, subject: dict, voice_seed: bytes, *, at: str) -> int:
        decl = {"kind": "voice.revoked", "lab": self.lab, "subject": subject,
                "voice_pubkey": pub_of(voice_seed), "at": at}
        seq, eid = self._admit(voice._canon(decl), f"file://revoke-{self.T + 1}.json", at)
        self.decls.append((seq, eid, decl))
        return seq

    def heartbeat(self, *, at: str) -> int:
        seq, _ = self._admit(voice._canon({"kind": "heartbeat", "at": at}),
                             f"file://hb-{self.T + 1}.json", at)
        return seq

    def inline_attestation(self, decl: dict, seq: int, event_id: str, *, seed=None) -> dict:
        body = {"kind": "voice.attested", "lab": decl["lab"], "subject": decl["subject"],
                "voice_pubkey": decl["voice_pubkey"],
                "hub": {"event_id": event_id, "accepted_seq": seq},
                "valid_from_seq": seq + 1, "at": decl["at"]}
        if "grant" in decl:
            body["grant"] = decl["grant"]
        sig = sp.sign(voice._digest(voice._canon(body)), seed or self.seed).hex()
        return {"body": body, "lab_sig": sig}

    def rows(self, T: int) -> list:
        """원장 1..T 재생 → 발화 결속 행(동결판 §9 스케치). 철회 끝 = n+1."""
        rows = []
        for seq, _, d in self.decls:
            if seq > T:
                continue
            if d["kind"] == "voice.attested":
                rows.append({"subject": d["subject"], "voice_pubkey": d["voice_pubkey"],
                             "grant": d.get("grant"), "valid_from_seq": seq + 1,
                             "revoked_at_seq": None,
                             "origin": {"kind": "voice.attested", "seq": seq}})
            else:
                for r in rows:
                    if (r["subject"] == d["subject"] and r["voice_pubkey"] == d["voice_pubkey"]
                            and r["revoked_at_seq"] is None):
                        r["revoked_at_seq"] = seq + 1
        return rows

    def view(self, T: int, *, usable: bool = True, drop_subject=None) -> dict:
        rows = [r for r in self.rows(T) if r["subject"] != drop_subject]
        sid = he.canonical_sha({"T": T, "rows": rows})
        return {"snapshot_id": sid, "T": T, "usable": usable, "voice_bindings": rows}


def letter(*, env_lab: str, env_seed: bytes, author: dict, to: dict, text: str, at: str,
           voice_seed=None, attestation=None, voice_sign_seed=None, envelope_to=None,
           drop_keys=(), voice_override=None, body_after=None, env_at=None, wire_ascii=False) -> dict:
    """크리처 편지 한 통(봉투·서명·본문). 합성 결함은 인자로 만든다.
    wire_ascii: 본문을 비ASCII `\\u` 이스케이프 JSON으로 싣는다(파이썬 json 기본값 — 다른 링이 이렇게 보낼 수 있다)."""
    body = {"kind": "creature.letter", "author": author, "to": to, "at": at, "text": text}
    for k in drop_keys:
        body.pop(k, None)
    if voice_override is not None:
        body["voice"] = voice_override
    elif voice_seed is not None:
        sig = voice.sign_speech(voice_sign_seed or voice_seed, voice.speech_bytes_of(body))
        body["voice"] = {"sig": sig, "attestation": attestation}
    body_bytes = (json.dumps(body, ensure_ascii=True, sort_keys=True, separators=(",", ":")).encode()
                  if wire_ascii else voice._canon(body))
    tgt = envelope_to or to
    env = _envelope_message(env_lab, to_lab=tgt["lab_id"], to_id=tgt["to_id"],
                            to_epoch=tgt["to_epoch"], body=body_bytes,
                            locator="letters://creature", at=env_at or at, media="application/json")
    out = {"envelope": env, "sig": sign_env(env, env_seed), "body_utf8": body_bytes.decode("utf-8")}
    if body_after is not None:                 # 봉투를 만든 뒤 본문을 바꾼다(digest 불일치)
        out["body_utf8"] = body_after
    return out


def resign_attestation(att: dict, seed: bytes) -> dict:
    out = copy.deepcopy(att)
    out["lab_sig"] = sp.sign(voice._digest(voice._canon(out["body"])), seed).hex()
    return out
