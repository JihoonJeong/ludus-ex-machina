"""크리처 자격 증명 C2 벡터 시험 — delta v0.3 동결판(dev acacdb5). r1·r2는 v0.2 동결판(dev 73472e5).

    python3 -m pytest experiments/credential-v0 -q
"""

import json
import sys
import unicodedata
from pathlib import Path

import pytest

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import credential as cr  # noqa: E402
import make_credential_vectors as make_vectors  # noqa: E402

VEC_DIR = HERE / "vectors"
VECS = {p.stem: json.loads(p.read_text(encoding="utf-8"))
        for p in sorted(VEC_DIR.glob("*.json")) if p.name != "INDEX.json"}
CASES = [(name, i) for name, v in VECS.items() for i in range(len(v["cases"]))]


def subset(want, got) -> bool:
    if isinstance(want, dict):
        return isinstance(got, dict) and all(k in got and subset(v, got[k]) for k, v in want.items())
    return want == got


def _verify(vec, cs, letter_name):
    L = vec["letters"][letter_name]
    view = vec["views"][cs["view"]] if cs["view"] else None
    return cr.verify_letter(L["envelope"], L["sig"], L["body_utf8"].encode("utf-8"),
                            envelope_keys=vec["envelope_keys"][cs["envelope_keys"]],
                            pinned=vec["pinned"][cs["pinned"]], view=view, now=cs["now"],
                            clock_trusted=cs["clock_trusted"])


def run_case(vec, cs):
    op = cs["op"]
    if op == "letter":
        r = _verify(vec, cs, cs["letter"])
        return dict(r, display=cr.display(r))
    if op == "aggregate":
        names = {cr.envelope_event_id(vec["letters"][n]["envelope"]): n for n in cs["letters"]}
        copies = [(cr.envelope_event_id(vec["letters"][n]["envelope"]), _verify(vec, cs, n))
                  for n in cs["letters"]]
        a = cr.aggregate(copies)
        return {"representative": names.get(a["representative"]),
                "representative_grade": a["representative_grade"],
                "copy_grades": [c["authorship"] for c in a["copies"]], "_raw": a, "_copies": copies}
    if op == "policy_check":
        return {"valid": not cr.contact_policy_problems(cs["policy"],
                                                        known_channels=vec["known_channels"])}
    if op == "policy_admits":
        ok, why = cr.policy_admits(cs["profile"], cs["letter_body"], cs["surface"],
                                   known_channels=vec["known_channels"])
        return {"admit": ok, "reason": why}
    if op == "projection":
        return {"profile_keys": sorted(cr.public_projection(cs["row"])["profile"])}
    if op == "projection_problems":
        return {"problem_count": len(cr.projection_problems(cs["projected"]))}
    if op == "rate":
        return {"exceeded": cr.rate_exceeded(cs["prior"], cs["now"], cs["rate"])}
    if op == "dedup":
        keys = [cr.dedup_key(json.loads(vec["letters"][n]["body_utf8"])) for n in cs["letters"]]
        return {"same": keys[0] == keys[1]}
    raise ValueError(op)


@pytest.mark.parametrize("name,i", CASES, ids=[f"{n}#{i}" for n, i in CASES])
def test_벡터(name, i):
    vec = VECS[name]
    cs = vec["cases"][i]
    got = run_case(vec, cs)
    assert subset(cs["expect"], got), {"case": cs["name"], "want": cs["expect"], "got": got}


def test_벡터는_결정론으로_재생성된다(tmp_path):
    idx = make_vectors.emit(tmp_path)
    for p in sorted(VEC_DIR.iterdir()):
        assert (tmp_path / p.name).read_bytes() == p.read_bytes(), p.name
    assert sorted(x.name for x in tmp_path.iterdir()) == sorted(x.name for x in VEC_DIR.iterdir())
    assert idx["digest"] == json.loads((VEC_DIR / "INDEX.json").read_text())["digest"]


def test_기대값은_검증기와_독립이다():
    import re
    src = (HERE / "make_credential_vectors.py").read_text(encoding="utf-8")
    assert not re.search(r"^\s*(import\s+credential\b(?!_)|from\s+credential\s+import)", src, re.M)
    assert not re.search(r"^\s*(import\s+credential\b(?!_)|from\s+credential\s+import)",
                         (HERE / "credential_issuer.py").read_text(encoding="utf-8"), re.M)


def test_상세_reason이_모두_벡터에_있다():
    seen = set()
    for v in VECS.values():
        for cs in v["cases"]:
            r = cs["expect"].get("reason")
            if r:
                seen.add(r)
    assert set(cr.ADDRESS_NAME) <= seen, sorted(set(cr.ADDRESS_NAME) - seen)


def test_네_등급과_범위_판정이_모두_벡터에_있다():
    grades, verdicts = set(), set()
    for v in VECS.values():
        for cs in v["cases"]:
            e = cs["expect"]
            if "authorship" in e:
                grades.add(e["authorship"])
            if isinstance(e.get("scope"), dict):
                verdicts.add(e["scope"]["verdict"])
    assert {"claimed", "unverifiable", "rejected", "verified", None} <= grades
    assert {"in_scope", "out_of_scope:surface", "out_of_scope:recipient", "out_of_scope:expired",
            "no_grant"} <= verdicts


def test_참고_판정은_어떤_경우에도_전달_후보가_아니다():
    """이음 160: inline_advisory나 unchecked가 있는 결과는 '전달 허용'으로 올라가지 않는다."""
    for name, i in CASES:
        vec, cs = VECS[name], VECS[name]["cases"][i]
        if cs["op"] != "letter":
            continue
        got = run_case(vec, cs)
        sc = got.get("scope") or {}
        if sc.get("basis") == "inline_advisory" or sc.get("unchecked"):
            assert got["delivery_candidate"] is False, cs["name"]
        if got["delivery_candidate"]:
            assert got["authorship"] == "verified" and sc["verdict"] == "in_scope"


def test_검증기는_공개_입력에_예외를_내지_않는다():
    vec = VECS["00-letter-structure"]
    for env, body in ((None, b"{}"), ({}, b"{}"), ({"event_kind": "message.posted"}, b"x"),
                      (vec["letters"]["claimed"]["envelope"], b"\xff\xfe")):
        r = cr.verify_letter(env, "zz", body, envelope_keys={}, pinned={}, view=None,
                             now=make_vectors.NOW)
        assert r["authorship"] in (None, "rejected")
    for pol in (None, [], {"accepts": "x", "from": 3}, {"accepts": [1], "from": [None]}):
        assert cr.contact_policy_problems(pol, known_channels=[])


def test_A_미확인은_어떤_편지도_claimed나_전달_후보로_만들지_않는다():
    """Orin 048: 봉투 발신 키(A)를 모르면 봉투가 연구소의 서명 진술인지 모른다."""
    vec = VECS["04-q10-cross"]
    for name in vec["letters"]:
        cs = {"view": None, "envelope_keys": "no_sender", "pinned": "all", "now": make_vectors.NOW,
              "clock_trusted": True}
        r = _verify(vec, cs, name)
        if r["reason"] not in ("body_digest_mismatch", "envelope_malformed"):
            assert r["authorship"] is None and r["envelope"] == "unverified", name
        assert r["delivery_candidate"] is False


def test_집계는_사본을_버리지_않고_전달_판정을_섞지_않는다():
    """C2-1(이음 162·Orin 048): 사본 전부 보존 · 대표는 표시일 뿐 · 사본별 전달 판정 그대로."""
    vec = VECS["08-aggregate"]
    for cs in vec["cases"]:
        got = run_case(vec, cs)
        a, copies = got["_raw"], got["_copies"]
        assert len(a["copies"]) == len(cs["letters"])
        assert "delivery_candidate" not in a and "scope" not in a
        for kept, (_, r) in zip(a["copies"], copies):
            assert kept["delivery_candidate"] == r["delivery_candidate"]


def test_text_경계_편지는_정말_경계에_있다():
    """r3(이음 164): 경계 벡터가 적힌 길이 그대로인지 — 검증기를 부르지 않고 본문을 풀어 센다."""
    vec = VECS["09-text-cap"]
    text = {n: json.loads(L["body_utf8"])["text"] for n, L in vec["letters"].items()}
    assert {n: len(t) for n, t in text.items() if n in (
        "text_cap_han", "text_over_han", "text_cap_emoji", "text_over_combining", "text_escaped_emoji",
        "text_over_ascii", "text_cap_voice")} == {
        "text_cap_han": 16000, "text_over_han": 16001, "text_cap_emoji": 16000,
        "text_over_combining": 16002, "text_escaped_emoji": 2000, "text_over_ascii": 16001,
        "text_cap_voice": 16000}
    assert len(text["text_cap_emoji"].encode("utf-16-le")) // 2 == 32000
    assert len(unicodedata.normalize("NFC", text["text_over_combining"])) == 8001
    raw = vec["letters"]["text_escaped_emoji"]["body_utf8"]
    assert raw.isascii() and raw.count("\\ud83c\\udf31") == 2000


def test_발견_제품_public_projection은_contact_policy를_모른다():
    """C2 발견(보고서): v0.3 채택 전 제품 경로. 지금은 화이트리스트가 contact_policy를 거부해서
    새지 않지만, 화이트리스트만 넓히면 제품 투영이 contact_policy를 그대로 내보낸다.
    제품이 고쳐지면 이 시험은 실패한다 — 그때 이 기록을 갱신한다."""
    sys.path.insert(0, str(HERE.parents[1] / "src"))
    from organum import bbs
    assert "contact_policy" not in bbs.PROFILE_FIELDS
    row = {"subject": {"lab": "lab:recv", "id": "Moss", "epoch": 1},
           "profile": {"display_name": "Moss", "contact_policy": {"accepts": ["letters"]}},
           "announced_at": "2026-10-01T00:00:00Z", "profile_event_last_seen": "2026-10-01T00:00:00Z"}
    out = bbs.public_projection([row])
    assert "contact_policy" in out[0]["profile"]
