# 크리처 자격 증명 C2 — 참조 기계와 합성 벡터

계약: 크리처 자격 증명 delta **v0.3 동결판**(dev `acacdb5`,
[docs/creature-credential-delta-v0.md](../../docs/creature-credential-delta-v0.md)). r1·r2는 v0.2 동결판(dev `73472e5`)
기준이었다. 결과와 발견은
[docs/creature-credential-c2-report.md](../../docs/creature-credential-c2-report.md).

**제품이 아니다.** 동결판 문구가 스스로 모순 없이 판정하는지 합성 벡터로 보는 실험이다. 실제 서비스·드롭·시계·
주민 편지는 여기서 검증하지 않는다.

**r2(Orin 048).** 신뢰근을 둘로 가른다. **A**는 바깥 봉투의 발신 연구소 키(`envelope_keys`, 받는 쪽 hub registry)다. **B**는
발화 보증·판의 신뢰근(`pinned`, trust snapshot 발급자 고정)이다. A를 모르면 저자성은 판정 전(null)이고 사유는
`envelope_signer_unverified`다. r1은 이 경우를 claimed로 판정했다(Orin 047 교차 사례의 오독). C2-1 집계(`aggregate`)도 r2에서 더했다.

**r3(v0.3 §3.2, 이음 164·Orin 050).** `text` 상한 16,000 유니코드 코드 포인트를 넘으면 `letter_malformed`다. 길이는 JSON을 푼 문자열의
코드 포인트를 서명된 그대로 센다. 정규화하지 않고, UTF-8 바이트·UTF-16 단위·자소 묶음·이스케이프 길이가 아니다(C2 D14). 편지 구조
단계의 검사라 봉투 층이 먼저 이기고 target·voice보다 먼저 온다. 경계 벡터는 `09-text-cap`이다.

## 파일

| 파일 | 역할 |
|---|---|
| `credential.py` | 참조 검증기. 편지 판정(봉투 층·A 게이트·구조와 `text` 상한·저자성 네 등급·상세 reason, Q10 순서) · 범위 판정 · 사본 집계(C2-1) · 연락 정책 · public projection · 빈도 관측 · 중복 키 |
| `credential_issuer.py` | 합성 발신 연구소. 제품 `HubIndex`에 보증·철회 선언을 admit하고, 편지와 판 보기를 만든다 |
| `make_credential_vectors.py` | 벡터 생성기. **기대값은 동결판 문구에서 손으로 적는다**(검증기를 부르지 않음) |
| `vectors/` | 벡터 10개(사례 117) + `INDEX.json` |
| `test_credential_vectors.py` | 전 사례 실행 · 결정론 재생성 · 독립성 · 포괄성 · 참고 판정의 비권한성 · 제품 발견 기록 |
| `mutation_check.py` | 검증기 판정을 하나씩 망가뜨려 벡터가 잡는지 확인 |

발화 키 r3의 철회 좌표 n+1 통일과 그 회귀 벡터는 `experiments/identity-v0/`(`voice_r3.py`,
`test_voice_r3_n1.py`)에 있다.

## 돌리기

```bash
python3 -m pytest experiments/credential-v0 -q
```

```bash
python3 experiments/credential-v0/mutation_check.py
```

```bash
python3 experiments/credential-v0/make_credential_vectors.py
```

마지막 명령은 `vectors/`를 다시 쓴다. 코드가 같으면 bytes도 같다.

## 경로 S의 입력 — 합성 모양

trust snapshot 주민 층(C4)이 정해지기 전이라, 받는 쪽이 가진 발신 연구소 판은 다음 합성 모양으로 준다.

```json
{"snapshot_id": "<64 hex>", "T": 13, "usable": true,
 "voice_bindings": [{"subject": {"lab": "…", "id": "…", "epoch": 1}, "voice_pubkey": "<64 hex>",
                     "grant": {…} | null, "valid_from_seq": 2, "revoked_at_seq": null,
                     "origin": {"kind": "voice.attested", "seq": 1}}]}
```

`usable`은 trust snapshot v0.5 상태 규칙(만료·유실 등)의 결과를 받는 자리다. 여기서 다시 판정하지 않는다. 판이
없으면 `null`이다. 행은 발신 연구소 원장 1..T를 재생해 만든다. 보증 seq n은 `valid_from_seq = n+1`, 철회 seq n은
`revoked_at_seq = n+1`이다.

## 벡터 형식

```json
{"vector": "02-letter-snapshot", "contract": "…", "refs": ["§3.3"], "purpose": "…",
 "envelope_keys": {"all": {"lab:sender": "<64 hex>"}, "no_sender": {…}},
 "pinned": {"all": {"lab:sender": "<64 hex>"}, "no_sender": {…}},
 "known_channels": ["letters", "hub-ops", "bbs-plaza"],
 "views": {"T13": {…}}, "letters": {"spark": {"envelope": {…}, "sig": "<128 hex>", "body_utf8": "…"}},
 "cases": [{"name": "…", "op": "letter", "letter": "spark", "envelope_keys": "all", "pinned": "all", "view": "T13",
            "now": "2026-10-01T00:00:00Z", "clock_trusted": true, "expect": {…}}]}
```

| op | 입력 | 기대값 키 |
|---|---|---|
| `letter` | 편지 이름·봉투 키 묶음(A)·신뢰근 묶음(B)·판 보기(없으면 null)·받는 쪽 시각(= 수거 시각)·시계 신뢰 | `envelope`(ok·unverified·invalid·null) · `authorship`(claimed·unverifiable·rejected·verified·null=판정 전) · `reason` · `scope`(verdict·basis·unchecked) · `basis`(판 id·T·판정 좌표) · `observations` · `delivery_candidate` · `display`(address_name·reason·ko·en) |
| `aggregate` | 같은 중복 키의 편지들(도착 순서)·A·B·판 보기 | `representative`(편지 이름)·`representative_grade`·`copy_grades` |
| `policy_check` | 연락 정책 | `valid` |
| `policy_admits` | 받는 이 프로필 행·편지 본문·표면 | `admit`·`reason` |
| `projection` · `projection_problems` | 프로필 행 · 투영 산출물 | `profile_keys` · `problem_count` |
| `rate` | 이전 편지 시각들·지금·rate | `exceeded` |
| `dedup` | 편지 둘 | `same` |

기대값은 부분 일치다. 적힌 키만 본다. 목록은 통째로 같아야 한다. 모든 서명은 결정론 seed로 만들었다.
