"""변이 검사 — 벡터가 참조 검증기의 판정을 실제로 붙잡는지(공허한 시험이 아닌지) 본다.

credential.py의 판정 한 곳을 일부러 망가뜨린 사본을 임시 디렉터리에 만들고 시험을 돌린다. 모든 변이가
**시험 실패**로 끝나야 한다. 수집 오류는 잡힘이 아니다(trust-v0에서 겪은 공허).

    python3 experiments/credential-v0/mutation_check.py

종료코드 0 = 기준선 통과 + 모든 변이가 시험 실패로 잡힘.
"""
import os
import pathlib
import shutil
import subprocess
import sys
import tempfile

HERE = pathlib.Path(__file__).resolve().parent
ROOT = HERE.parents[1]
env = dict(os.environ, PYTHONPATH=os.pathsep.join([str(ROOT / "src"),
                                                   str(ROOT / "experiments" / "identity-v0")]))

M = {
 "baseline (no mutation)": ("", ""),
 "voice 부재가 claimed 아님": ('return _result(env_state, "claimed", None)',
                           'return _result(env_state, "unverifiable", "no_trust_root")'),
 "digest 미검사": ('if hashlib.sha256(body_bytes).hexdigest() != envelope["payload"]["body_sha256"]:',
                'if False:'),
 "봉투 서명 미검사": ('        return _result("invalid", None, "envelope_sig_invalid")',
                   '        env_state = "ok"'),
 "target 미검사": ('if envelope["payload"]["target"] != body["to"]:', 'if False:'),
 "author lab 미검사": ('if envelope["signer"]["id"] != author["lab"]:', 'if False:'),
 "보증 subject 미검사": ('if att_body["lab"] != author["lab"] or att_body["subject"] != author:', 'if False:'),
 "보증 서명 미검사": ('    if not sp.verify(bytes.fromhex(v["attestation"]["lab_sig"]),',
                   '    if False and sp.verify(bytes.fromhex(v["attestation"]["lab_sig"]),'),
 "발화 서명 미검사": ('    if not sp.verify(bytes.fromhex(v["sig"]),', '    if False and sp.verify(bytes.fromhex(v["sig"]),'),
 "판 만료 무시": ('if view is None or not view.get("usable"):', 'if view is None:'),
 "보증 좌표 = T를 기다림으로": ('        if admit_seq > T:', '        if admit_seq >= T:'),
 "철회 무시": ('active = [r for r in rows if r["revoked_at_seq"] is None]', 'active = rows'),
 "범위를 인라인 grant로": ('sc = scope_of(row.get("grant"),', 'sc = scope_of(inline_grant,'),
 "not_after 경계 >": ('elif now >= parse_time(grant["not_after"]) and verdict == "in_scope":',
                      'elif now > parse_time(grant["not_after"]) and verdict == "in_scope":'),
 "until_seq 경계 >": ('elif coord >= grant["until_seq"] and verdict == "in_scope":',
                      'elif coord > grant["until_seq"] and verdict == "in_scope":'),
 "시계 미신뢰 무시": ('    if not clock_trusted:\n        unchecked.append("not_after")\n    elif',
                   '    if False:\n        unchecked.append("not_after")\n    elif'),
 "전달 후보가 근거·미검사 무시": ('out["delivery_candidate"] = (sc["verdict"] == "in_scope" and sc["basis"] == "snapshot"',
                          'out["delivery_candidate"] = (sc["verdict"] == "in_scope" or sc["basis"] == "snapshot"'),
 "무효 grant 무시": ('if "until_seq" in grant and grant["until_seq"] <= admit_seq:', 'if False:'),
 "패턴 epoch 무시": ('and ("epoch" not in p or p["epoch"] == epoch))', ')'),
 "와일드카드 연구소 허용": ('    if not (isinstance(p["lab"], str) and he._LAB_ID.fullmatch(p["lab"])):',
                       '    if not isinstance(p["lab"], str):'),
 "정책 부재 = 허가": ('return False, "no_policy"', 'return True, None'),
 "받는 이 epoch 무시": ('if subj["epoch"] != to["to_epoch"]:', 'if False:'),
 "note 상한 +1": ('if len(n) > _NOTE_MAX:', 'if len(n) > _NOTE_MAX + 1:'),
 "note 연락 수단 무시": ('            if _has_contact_means(n):', '            if False:'),
 "전화번호 숫자 하한 제거": ('_PHONE_MIN_DIGITS = 9 ', '_PHONE_MIN_DIGITS = 1 '),
 "모르는 채널 허용": ('elif ch not in known_channels:', 'elif False:'),
 "빈도 창 닫힌 구간": ('< rate["per_seconds"])', '<= rate["per_seconds"])'),
 "중복 키에 voice 포함": ('    return voice.speech_bytes_of(body)', '    return voice._canon(body)'),
 "A 게이트 제거(A 미확인을 claimed로)": ('        return _result("unverified", None, "envelope_signer_unverified")',
                                     '        return _result("unverified", "claimed", None)'),
 "A와 B 혼동(B로 봉투 검증)": ('    lab_key = envelope_keys.get(envelope["signer"]["id"])',
                              '    lab_key = pinned.get(envelope["signer"]["id"])'),
 "집계 대표 = 첫 도착 사본": ('    best = min(ranked, key=lambda c: (-_RANK[c["authorship"]], c["event_id"]))',
                           '    best = ranked[0]'),
 "집계에 rejected 포함": ('_RANK = {"verified": 3, "unverifiable": 2, "claimed": 1}',
                       '_RANK = {"rejected": 4, "verified": 3, "unverifiable": 2, "claimed": 1}'),
 "집계 동률 규칙 역전": ('(-_RANK[c["authorship"]], c["event_id"]))',
                      '(-_RANK[c["authorship"]], "".join(chr(255 - ord(x)) for x in c["event_id"])))'),
 "npub 체크섬 무시": ('    if any(_is_nostr_key(m.group()) for m in _NOSTR_KEY.finditer(note)):',
                    '    if any(True for m in _NOSTR_KEY.finditer(note)):'),
 "npub 규칙 없음": ('    if any(_is_nostr_key(m.group()) for m in _NOSTR_KEY.finditer(note)):',
                  '    if False:'),
 "결속 부재 표시를 unverified로": ('"binding_absent": "signer_unbound",', '"binding_absent": "signer_unverified",'),
 # r3 — text 상한(v0.3 §3.2, C2 D14)
 "text 상한 없음": ('_TEXT_MAX = 16_000 ', '_TEXT_MAX = 10**9 '),
 "text 상한 경계 <": ('_text_len(body["text"]) <= _TEXT_MAX', '_text_len(body["text"]) < _TEXT_MAX'),
 "text 길이 = UTF-8 바이트": ('    return len(s)\n', '    return len(s.encode("utf-8", "surrogatepass"))\n'),
 "text 길이 = UTF-16 단위": ('    return len(s)\n', '    return len(s.encode("utf-16-le", "surrogatepass")) // 2\n'),
 "text 길이 = NFC 뒤": ('    return len(s)\n', '    return len(__import__("unicodedata").normalize("NFC", s))\n'),
 "text 검사를 A 게이트 앞으로": ('    lab_key = envelope_keys.get(envelope["signer"]["id"])\n',
                              '    try:\n        _t = json.loads(body_bytes.decode("utf-8")).get("text")\n'
                              '    except Exception:\n        _t = None\n'
                              '    if isinstance(_t, str) and _text_len(_t) > _TEXT_MAX:\n'
                              '        return _result(None, "rejected", "letter_malformed")\n'
                              '    lab_key = envelope_keys.get(envelope["signer"]["id"])\n'),
 "text 검사를 주소 결속 뒤로": (
     '            and isinstance(body["text"], str) and _text_len(body["text"]) <= _TEXT_MAX\n'
     '            and (body.get("in_reply_to") is None or isinstance(body["in_reply_to"], str))):\n'
     '        return _result(env_state, "rejected", "letter_malformed")\n'
     '    if envelope["payload"]["target"] != body["to"]:\n'
     '        return _result(env_state, "rejected", "target_mismatch")\n'
     '    author = body["author"]\n'
     '    if envelope["signer"]["id"] != author["lab"]:\n'
     '        return _result(env_state, "rejected", "author_lab_mismatch")\n',
     '            and isinstance(body["text"], str)\n'
     '            and (body.get("in_reply_to") is None or isinstance(body["in_reply_to"], str))):\n'
     '        return _result(env_state, "rejected", "letter_malformed")\n'
     '    if envelope["payload"]["target"] != body["to"]:\n'
     '        return _result(env_state, "rejected", "target_mismatch")\n'
     '    author = body["author"]\n'
     '    if envelope["signer"]["id"] != author["lab"]:\n'
     '        return _result(env_state, "rejected", "author_lab_mismatch")\n'
     '    if _text_len(body["text"]) > _TEXT_MAX:\n'
     '        return _result(env_state, "rejected", "letter_malformed")\n'),
}

bad = 0
tmp = tempfile.mkdtemp(prefix="cred-mut-")
for name, (a, b) in M.items():
    d = pathlib.Path(tmp) / "mut"
    shutil.rmtree(d, ignore_errors=True)
    shutil.copytree(HERE, d, ignore=shutil.ignore_patterns("__pycache__"))
    src = (d / "credential.py").read_text(encoding="utf-8")
    if a and src.count(a) != 1:
        print(f"ANCHOR MISSING: {name}")
        bad += 1
        continue
    if a:
        (d / "credential.py").write_text(src.replace(a, b), encoding="utf-8")
    r = subprocess.run([sys.executable, "-m", "pytest", str(d), "-q", "-p", "no:cacheprovider"],
                       capture_output=True, text=True, env=env)
    tail = [l for l in r.stdout.splitlines() if " passed" in l or " failed" in l or " error" in l]
    summ = tail[-1] if tail else "NO SUMMARY"
    coll_err = "error" in summ and "failed" not in summ and "passed" not in summ
    if not a:
        verdict = "BASELINE-OK" if r.returncode == 0 else "BASELINE-FAIL"
        bad += r.returncode != 0
    else:
        verdict = "COLLECTION-ERROR" if coll_err else ("CAUGHT" if r.returncode else "MISSED")
        bad += verdict != "CAUGHT"
    print(f"{verdict:16} {name} :: {summ}")
shutil.rmtree(tmp, ignore_errors=True)
sys.exit(1 if bad else 0)
