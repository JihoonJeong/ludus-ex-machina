"""크리처 자격 증명 C2 합성 벡터 생성기 — delta v0.3 동결판(dev acacdb5). r1·r2는 v0.2 동결판(dev 73472e5).

입력(편지·보증·판 보기)은 합성 발신 연구소가 제품 원장 코드로 만든다(credential_issuer.py). **기대값은 이 파일에
동결판 문구에서 손으로 적는다.** 참조 검증기(credential.py)를 부르지 않는다.

    python3 experiments/credential-v0/make_credential_vectors.py [출력 디렉터리]
"""

from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from credential_issuer import SenderLab, letter, pub_of, resign_attestation, seed_of  # noqa: E402

CONTRACT = ("크리처 자격 증명 delta v0.3 동결판(dev acacdb5) — C2 참조 기계 r3(r2 A/B 분리·C2-1 집계 + "
            "text 상한 경계, 이음 164·Orin 050)")
SENDER, OTHER, RECV = "lab:sender", "lab:other", "lab:recv"
S_SENDER, S_OTHER, S_MALLORY = seed_of("sender"), seed_of("other"), seed_of("mallory")
V = {k: seed_of("voice-" + k) for k in ("spark", "bramble", "flint", "wisp", "echo", "ash",
                                        "rune", "late", "void")}
NA = "2026-10-10T00:00:00Z"
NOW = "2026-10-01T00:00:00Z"
LAT = "2026-09-30T12:00:00Z"
GS = "organum-voice/grant/v0"

G_STD = {"schema": GS, "letters": {"to": [{"lab": SENDER}, {"lab": RECV, "id": "Moss", "epoch": 1}]},
         "boards": ["bbs-plaza"], "rate": {"max": 5, "per_seconds": 86400}, "not_after": NA}
G_UNTIL12 = dict(G_STD, until_seq=12)
G_NOLET = {"schema": GS, "boards": ["bbs-plaza"], "not_after": NA}
G_SELF = {"schema": GS, "letters": {"to": [{"lab": SENDER}]}, "not_after": NA}
G_VOID = dict(G_STD, until_seq=15)

MOSS = {"lab_id": RECV, "to_id": "Moss", "to_epoch": 1}
MOSS2 = {"lab_id": RECV, "to_id": "Moss", "to_epoch": 2}
FERN = {"lab_id": RECV, "to_id": "Fern", "to_epoch": 1}
PIP = {"lab_id": SENDER, "to_id": "Pip", "to_epoch": 1}
# A = 봉투 발신 키(받는 쪽 hub registry), B = 보증·판 신뢰근(trust snapshot 발급자 고정) — r2(Orin 048)
ENVELOPE_KEYS = {"all": {SENDER: pub_of(S_SENDER), OTHER: pub_of(S_OTHER)},
                 "no_sender": {OTHER: pub_of(S_OTHER)}}
PINNED = {"all": {SENDER: pub_of(S_SENDER), OTHER: pub_of(S_OTHER)},
          "no_sender": {OTHER: pub_of(S_OTHER)}}

_B32 = "qpzry9x8gf2tvdw0s3jn54khce6mua7l"


def bech32_encode(hrp: str, data8: bytes) -> str:
    """생성기 쪽 독립 구현(BIP-173 bech32, NIP-19) — 검증기 코드를 쓰지 않는다."""
    acc, bits, data5 = 0, 0, []
    for b in data8:
        acc = (acc << 8) | b
        bits += 8
        while bits >= 5:
            bits -= 5
            data5.append((acc >> bits) & 31)
    if bits:
        data5.append((acc << (5 - bits)) & 31)
    gen = [0x3b6a57b2, 0x26508e6d, 0x1ea119fa, 0x3d4233dd, 0x2a1462b3]

    def polymod(vals):
        chk = 1
        for v in vals:
            top = chk >> 25
            chk = ((chk & 0x1ffffff) << 5) ^ v
            for i in range(5):
                if (top >> i) & 1:
                    chk ^= gen[i]
        return chk
    hx = [ord(x) >> 5 for x in hrp] + [0] + [ord(x) & 31 for x in hrp]
    pm = polymod(hx + data5 + [0] * 6) ^ 1
    check = [(pm >> 5 * (5 - i)) & 31 for i in range(6)]
    return hrp + "1" + "".join(_B32[d] for d in data5 + check)
KNOWN_CHANNELS = ["letters", "hub-ops", "bbs-plaza"]


def c(id_, epoch=1):
    return {"lab": SENDER, "id": id_, "epoch": epoch}


def t(n):
    return f"2026-09-30T00:{n:02d}:00Z"


def build():
    S = SenderLab(SENDER, S_SENDER)
    A = {}
    A["spark"] = S.attest(c("Spark"), V["spark"], grant=G_STD, at=t(1))          # 1
    A["bramble"] = S.attest(c("Bramble"), V["bramble"], at=t(2))                  # 2 grant 없음
    A["flint"] = S.attest(c("Flint"), V["flint"], grant=G_NOLET, at=t(3))         # 3
    S.heartbeat(at=t(4))                                                          # 4
    A["wisp_old"] = S.attest(c("Wisp"), V["wisp"], grant=G_STD, at=t(5))          # 5
    S.revoke(c("Wisp"), V["wisp"], at=t(6))                                       # 6
    A["wisp_new"] = S.attest(c("Wisp"), V["wisp"], grant=G_SELF, at=t(7))         # 7 같은 키 재보증
    A["echo"] = S.attest(c("Echo"), V["echo"], grant=G_UNTIL12, at=t(8))          # 8
    A["ash"] = S.attest(c("Ash"), V["ash"], grant=G_STD, at=t(9))                 # 9
    S.revoke(c("Ash"), V["ash"], at=t(10))                                        # 10
    S.heartbeat(at=t(11))                                                         # 11
    A["rune"] = S.attest(c("Rune"), V["rune"], grant=G_STD, at=t(12))             # 12
    S.heartbeat(at=t(13))                                                         # 13
    A["late"] = S.attest(c("Late"), V["late"], grant=G_STD, at=t(14))             # 14
    A["void"] = S.attest(c("Void"), V["void"], grant=G_VOID, at=t(15))            # 15
    S.heartbeat(at=t(16))                                                         # 16
    assert S.T == 16 and [d[0] for d in S.decls] == [1, 2, 3, 5, 6, 7, 8, 9, 10, 12, 14, 15]

    views = {"T9": S.view(9), "T10": S.view(10), "T11": S.view(11), "T12": S.view(12),
             "T13": S.view(13), "T13_unusable": S.view(13, usable=False),
             "T13_denied": S.view(13, drop_subject=c("Spark")), "T16": S.view(16),
             "T12_denied": S.view(12, drop_subject=c("Rune"))}

    def L(author, voice_key=None, att=None, to=MOSS, text=None, **kw):
        return letter(env_lab=SENDER, env_seed=S_SENDER, author=c(author), to=to,
                      text=f"{author}의 편지" if text is None else text, at=LAT,
                      voice_seed=V.get(voice_key), attestation=att, **kw)

    # r3 text 상한(v0.3 §3.2) — 16,000 유니코드 코드 포인트. 길이는 손으로 확인한다.
    han_cap, han_over = "가" * 16000, "가" * 16001
    emoji_cap = "\U0001F331" * 16000              # UTF-16 단위로는 32,000
    comb_over = "e\u0301" * 8001                  # 코드 포인트 16,002 · NFC 뒤 8,001 · 자소 8,001
    esc = "\U0001F331" * 2000                     # \u 이스케이프로 실으면 24,000자
    asc_cap, asc_over = "a" * 16000, "a" * 16001
    assert (len(han_cap), len(han_over), len(emoji_cap), len(comb_over), len(esc)) == (
        16000, 16001, 16000, 16002, 2000)
    over = L("Spark", text=asc_over)
    over_changed = over["body_utf8"].replace('"text":"a', '"text":"b', 1)
    assert over_changed != over["body_utf8"]

    claimed = L("Spark")
    changed = claimed["body_utf8"].replace("Spark의 편지", "바꾼 편지")
    assert changed != claimed["body_utf8"]
    lets = {
        "claimed": claimed,
        "claimed_resend": L("Spark", env_at="2026-09-30T13:00:00Z"),
        "spark_resend": L("Spark", "spark", A["spark"], env_at="2026-09-30T13:00:00Z"),
        "ash_claimed": L("Ash"),
        "digest": dict(claimed, body_utf8=changed),
        "env_malformed": dict(claimed, envelope={k: v for k, v in claimed["envelope"].items()
                                                 if k != "created_at"}),
        "envsig": letter(env_lab=SENDER, env_seed=S_MALLORY, author=c("Spark"), to=MOSS,
                         text="Spark의 편지", at=LAT),
        "target": L("Spark", "spark", A["spark"], envelope_to=FERN),
        "authorlab": letter(env_lab=OTHER, env_seed=S_OTHER, author=c("Spark"), to=MOSS,
                            text="Spark의 편지", at=LAT, voice_seed=V["spark"],
                            attestation=A["spark"]),
        "malformed": L("Spark", drop_keys=("to",)),
        "voice_half": L("Spark", voice_override={"sig": "ab" * 64}),
        "att_mismatch": L("Spark", "spark", A["bramble"]),
        "att_sig": L("Spark", "spark", resign_attestation(A["spark"], S_MALLORY)),
        "voice_sig": L("Spark", "spark", A["spark"], voice_sign_seed=V["bramble"]),
        "spark": L("Spark", "spark", A["spark"]),
        "spark_fern": L("Spark", "spark", A["spark"], to=FERN),
        "spark_pip": L("Spark", "spark", A["spark"], to=PIP),
        "spark_moss2": L("Spark", "spark", A["spark"], to=MOSS2),
        "bramble": L("Bramble", "bramble", A["bramble"]),
        "flint": L("Flint", "flint", A["flint"]),
        "wisp_old": L("Wisp", "wisp", A["wisp_old"]),
        "echo": L("Echo", "echo", A["echo"]),
        "ash": L("Ash", "ash", A["ash"]),
        "ash_badsig": L("Ash", "ash", A["ash"], voice_sign_seed=V["spark"]),
        "rune": L("Rune", "rune", A["rune"]),
        "late": L("Late", "late", A["late"]),
        "void": L("Void", "void", A["void"]),
        "digest_target": dict(L("Spark", envelope_to=FERN),
                              body_utf8=changed),
        "target_badvoice": L("Spark", "spark", A["spark"], envelope_to=FERN,
                             voice_sign_seed=V["bramble"]),
        "text_cap_han": L("Spark", text=han_cap),
        "text_over_han": L("Spark", text=han_over),
        "text_cap_emoji": L("Spark", text=emoji_cap),
        "text_over_combining": L("Spark", text=comb_over),
        "text_escaped_emoji": L("Spark", text=esc, wire_ascii=True),
        "text_over_ascii": over,
        "text_over_envsig": letter(env_lab=SENDER, env_seed=S_MALLORY, author=c("Spark"), to=MOSS,
                                   text=asc_over, at=LAT),
        "text_over_digest": dict(over, body_utf8=over_changed),
        "text_over_target": L("Spark", "spark", A["spark"], envelope_to=FERN, text=asc_over),
        "text_over_voice": L("Spark", "spark", A["spark"], text=asc_over),
        "text_over_voice_half": L("Spark", voice_override={"sig": "ab" * 64}, text=asc_over),
        "text_cap_voice": L("Spark", "spark", A["spark"], text=asc_cap),
    }
    return S, views, lets


# ── 기대값 모양 ──────────────────────────────────────────────────────────────

def disp(address_name=None, reason=None, ko=None, en=None):
    return {"address_name": address_name, "reason": reason, "ko": ko, "en": en}


INV = "invalid_signature_or_digest"
UNV = "signer_unverified"
UNB = "signer_unbound"


def case(name, letter_name, expect, *, envelope_keys="all", pinned="all", view="T13", now=NOW,
         clock_trusted=True):
    return {"name": name, "op": "letter", "letter": letter_name, "envelope_keys": envelope_keys,
            "pinned": pinned, "view": view, "now": now, "clock_trusted": clock_trusted,
            "expect": expect}


def scope(verdict, basis, unchecked=()):
    return {"verdict": verdict, "basis": basis, "unchecked": list(unchecked)}


def vectors(views, lets):
    sid = {k: v["snapshot_id"] for k, v in views.items()}
    out = []

    out.append(("00-letter-structure", ["§3.2", "§4.4 Q10 1단계"],
                "봉투 층(digest·봉투 서명)과 편지 구조·주소 결속. 구조 단계에서 voice가 없으면 claimed로 끝난다.", [
        case("voice 없음 → claimed", "claimed",
             {"envelope": "ok", "authorship": "claimed", "reason": None, "scope": None,
              "delivery_candidate": False, "display": disp()}),
        case("본문 digest 불일치 → 판정 전", "digest",
             {"envelope": None, "authorship": None, "reason": "body_digest_mismatch",
              "display": disp(INV, "body_digest_mismatch")}),
        case("봉투 모양이 깨짐(created_at 없음) → 판정 전", "env_malformed",
             {"envelope": None, "authorship": None, "reason": "envelope_malformed",
              "display": disp(INV, "envelope_malformed")}),
        case("봉투 서명이 고정 키로 서지 않음 → 판정 전", "envsig",
             {"envelope": "invalid", "authorship": None, "reason": "envelope_sig_invalid",
              "display": disp(INV, "envelope_sig_invalid")}),
        case("봉투 target ≠ 본문 to", "target",
             {"envelope": "ok", "authorship": "rejected", "reason": "target_mismatch",
              "display": disp(None, "target_mismatch", "받는 주소 불일치", "Recipient address mismatch")}),
        case("봉투 서명 연구소 ≠ author.lab", "authorlab",
             {"envelope": "ok", "authorship": "rejected", "reason": "author_lab_mismatch",
              "display": disp(None, "author_lab_mismatch", "발신 연구소와 저자 소속 불일치",
                              "Sender lab and author lab mismatch")}),
        case("본문에 to 없음", "malformed",
             {"envelope": "ok", "authorship": "rejected", "reason": "letter_malformed",
              "display": disp(None, "letter_malformed")}),
        case("voice 반쪽 → voice_incomplete", "voice_half",
             {"envelope": "ok", "authorship": "rejected", "reason": "voice_incomplete",
              "display": disp(None, "voice_incomplete")}),
        case("남의 보증(subject ≠ author)", "att_mismatch",
             {"envelope": "ok", "authorship": "rejected", "reason": "attestation_mismatch"}),
    ]))

    out.append(("01-letter-chain", ["§4.1", "§4.4 Q10 3단계"],
                "완전한 사슬: 신뢰근 → 보증 서명 → 발화 서명.", [
        case("B(보증·판 신뢰근) 없음 · A 검증됨 → unverifiable, 범위는 참고", "spark",
             {"envelope": "ok", "authorship": "unverifiable", "reason": "no_trust_root",
              "scope": scope("in_scope", "inline_advisory"), "delivery_candidate": False,
              "display": disp(UNV, "no_trust_root")}, pinned="no_sender"),
        case("A(봉투 발신 키) 없음 → 판정 전", "spark",
             {"envelope": "unverified", "authorship": None, "reason": "envelope_signer_unverified",
              "scope": None, "delivery_candidate": False,
              "display": disp(UNV, "envelope_signer_unverified")}, envelope_keys="no_sender"),
        case("보증 서명 불일치", "att_sig",
             {"envelope": "ok", "authorship": "rejected", "reason": "attestation_sig_invalid",
              "scope": None, "display": disp(INV, "attestation_sig_invalid")}),
        case("발화 서명 불일치", "voice_sig",
             {"envelope": "ok", "authorship": "rejected", "reason": "voice_sig_invalid",
              "display": disp(INV, "voice_sig_invalid")}),
    ]))

    out.append(("02-letter-snapshot", ["§3.3", "§4.1", "§5", "§9"],
                "경로 S: 받는 쪽이 채택한 판 T에서 판정 좌표 T+1. 도입·철회가 T에서 일어난 경계, 판이 없거나 "
                "만료, 판이 보증보다 오래됨, 표가 결속을 부정함.", [
        case("verified · 범위 안 · 전달 후보", "spark",
             {"envelope": "ok", "authorship": "verified", "reason": None,
              "scope": scope("in_scope", "snapshot"),
              "basis": {"snapshot_id": sid["T13"], "T": 13, "coordinate": 14},
              "observations": [], "delivery_candidate": True, "display": disp()}),
        case("쓸 판 없음 → unverifiable", "spark",
             {"authorship": "unverifiable", "reason": "no_valid_snapshot",
              "scope": scope("in_scope", "inline_advisory"), "delivery_candidate": False,
              "display": disp(UNV, "no_valid_snapshot")}, view=None),
        case("판 만료(usable=false) → unverifiable", "spark",
             {"authorship": "unverifiable", "reason": "no_valid_snapshot",
              "delivery_candidate": False}, view="T13_unusable"),
        case("표가 결속을 부정 → binding_absent", "spark",
             {"authorship": "rejected", "reason": "binding_absent",
              "basis": {"snapshot_id": sid["T13_denied"], "T": 13, "coordinate": 14},
              "display": disp(UNB, "binding_absent")}, view="T13_denied"),
        case("판이 보증보다 오래됨(보증 14 > T 13)", "late",
             {"authorship": "unverifiable", "reason": "snapshot_behind_attestation",
              "scope": scope("in_scope", "inline_advisory"),
              "display": disp(UNV, "snapshot_behind_attestation")}),
        case("같은 보증이 새 판에서는 verified", "late",
             {"authorship": "verified", "delivery_candidate": True}, view="T16"),
        case("철회 전 판(T 9) → verified", "ash",
             {"authorship": "verified", "basis": {"T": 9, "coordinate": 10}}, view="T9"),
        case("철회가 T(10)에서 일어남 → revoked_at 11 = T+1 → binding_revoked", "ash",
             {"authorship": "rejected", "reason": "binding_revoked",
              "basis": {"snapshot_id": sid["T10"], "T": 10, "coordinate": 11},
              "display": disp(None, "binding_revoked", "서명 키 보증 철회",
                              "Signing-key attestation revoked")}, view="T10"),
        case("철회 뒤 판(T 13)도 binding_revoked", "ash",
             {"authorship": "rejected", "reason": "binding_revoked"}),
        case("보증이 T(12)에서 일어남 → valid_from 13 = T+1 → verified", "rune",
             {"authorship": "verified", "basis": {"T": 12, "coordinate": 13}}, view="T12"),
        case("보증 좌표 12 = T 12인데 표에 없음 → binding_absent(기다리지 않는다)", "rune",
             {"authorship": "rejected", "reason": "binding_absent",
              "basis": {"snapshot_id": sid["T12_denied"], "T": 12, "coordinate": 13}},
             view="T12_denied"),
        case("보증 12 > T 11 → snapshot_behind_attestation", "rune",
             {"authorship": "unverifiable", "reason": "snapshot_behind_attestation"}, view="T11"),
        case("같은 키 재보증 — 옛 인라인 사본(넓음), 판 행(좁음)이 이긴다", "wisp_old",
             {"authorship": "verified", "scope": scope("out_of_scope:recipient", "snapshot"),
              "observations": ["inline_grant_differs"], "delivery_candidate": False}),
    ]))

    out.append(("03-scope", ["§3.1", "§4.2", "§5"],
                "범위 판정: grant 없음·표면·받는 이 패턴·not_after(받는 쪽 시계)·until_seq(판정 좌표)·시계 미신뢰·무효 grant.", [
        case("grant 없음", "bramble",
             {"authorship": "verified", "scope": scope("no_grant", "snapshot"),
              "delivery_candidate": False}),
        case("letters 표면 없음", "flint",
             {"authorship": "verified", "scope": scope("out_of_scope:surface", "snapshot")}),
        case("받는 이 불일치(Fern)", "spark_fern",
             {"scope": scope("out_of_scope:recipient", "snapshot"), "delivery_candidate": False}),
        case("lab만 적은 패턴은 그 연구소 누구든(Pip)", "spark_pip",
             {"scope": scope("in_scope", "snapshot"), "delivery_candidate": True}),
        case("패턴 epoch 1 ≠ 받는 이 epoch 2", "spark_moss2",
             {"scope": scope("out_of_scope:recipient", "snapshot")}),
        case("not_after 1초 전 → 범위 안", "spark",
             {"scope": scope("in_scope", "snapshot"), "delivery_candidate": True},
             now="2026-10-09T23:59:59Z"),
        case("not_after 도달 → expired", "spark",
             {"scope": scope("out_of_scope:expired", "snapshot"), "delivery_candidate": False},
             now=NA),
        case("받는 쪽 시계 미신뢰 → not_after 검사 못 함", "spark",
             {"scope": scope("in_scope", "snapshot", ["not_after"]), "delivery_candidate": False},
             clock_trusted=False),
        case("until_seq 12, 판정 좌표 11 → 범위 안", "echo",
             {"scope": scope("in_scope", "snapshot"), "delivery_candidate": True}, view="T10"),
        case("until_seq 12, 판정 좌표 12 → expired", "echo",
             {"scope": scope("out_of_scope:expired", "snapshot")}, view="T11"),
        case("until_seq 12, 판정 좌표 14 → expired", "echo",
             {"scope": scope("out_of_scope:expired", "snapshot")}),
        case("판 없음 → until_seq 검사 못 함(참고)", "echo",
             {"authorship": "unverifiable", "scope": scope("in_scope", "inline_advisory", ["until_seq"]),
              "delivery_candidate": False}, view=None),
        case("push는 기한 전이지만 수거가 기한 뒤 → 받는 쪽(수거) 시각으로 expired(LxM 110)", "spark",
             {"scope": scope("out_of_scope:expired", "snapshot"), "delivery_candidate": False},
             now="2026-10-10T06:00:00Z"),
        case("B 없음 → until_seq 검사 못 함(참고)", "echo",
             {"authorship": "unverifiable", "reason": "no_trust_root",
              "scope": scope("in_scope", "inline_advisory", ["until_seq"])}, pinned="no_sender"),
        case("until_seq ≤ 보증 좌표 → grant 무효 = grant 없음", "void",
             {"authorship": "verified",
              "scope": {"verdict": "no_grant", "basis": "snapshot",
                        "observation": "grant_void_until_seq"},
              "delivery_candidate": False}, view="T16"),
    ]))

    out.append(("04-q10-cross", ["§4.4 Q10", "Orin 047·048"],
                "Q10 교차 사례 — 신뢰근을 A(봉투 발신 키)와 B(보증·판)로 가른다(Orin 048). A가 없으면 판정 전이다. "
                "A가 검증된 뒤에는 B·판 상태가 voice 부재·반쪽·서명 불일치를 가리지 않는다.", [
        case("(A 검증, voice 없음, B 없음) → claimed", "claimed",
             {"envelope": "ok", "authorship": "claimed", "reason": None},
             pinned="no_sender", view=None),
        case("(A 없음, voice 없음) → 판정 전(claimed 아님)", "claimed",
             {"envelope": "unverified", "authorship": None, "reason": "envelope_signer_unverified",
              "delivery_candidate": False}, envelope_keys="no_sender", view=None),
        case("(A 검증, voice 반쪽, B 없음) → rejected", "voice_half",
             {"envelope": "ok", "authorship": "rejected", "reason": "voice_incomplete"},
             pinned="no_sender", view=None),
        case("(A 없음, voice 반쪽) → 판정 전", "voice_half",
             {"envelope": "unverified", "authorship": None, "reason": "envelope_signer_unverified"},
             envelope_keys="no_sender", view=None),
        case("(A 검증, 완전·서명 불일치, B 있음·쓸 판 없음) → rejected", "voice_sig",
             {"authorship": "rejected", "reason": "voice_sig_invalid"}, view=None),
        case("(A 검증, 완전·서명 정상, 쓸 판 없음) → unverifiable", "spark",
             {"authorship": "unverifiable", "reason": "no_valid_snapshot"}, view=None),
        case("(A 검증, 완전, B 없음) → unverifiable", "spark",
             {"authorship": "unverifiable", "reason": "no_trust_root"}, pinned="no_sender", view=None),
        case("(A 없음, 완전·서명 정상) → 판정 전", "spark",
             {"authorship": None, "reason": "envelope_signer_unverified"},
             envelope_keys="no_sender", view=None),
    ]))

    out.append(("05-reason-priority", ["§4.4 Q10"],
                "오류가 겹칠 때 앞 단계의 사유가 이긴다.", [
        case("digest 불일치 + target 불일치 → digest", "digest_target",
             {"authorship": None, "reason": "body_digest_mismatch"}),
        case("target 불일치 + 발화 서명 불일치 → target", "target_badvoice",
             {"authorship": "rejected", "reason": "target_mismatch"}),
        case("보증 서명 불일치 + 판 없음 → 보증 서명", "att_sig",
             {"authorship": "rejected", "reason": "attestation_sig_invalid"}, view=None),
        case("발화 서명 불일치 + 결속 철회 → 발화 서명", "ash_badsig",
             {"authorship": "rejected", "reason": "voice_sig_invalid"}),
        case("voice 반쪽 + 판 있음 → voice_incomplete", "voice_half",
             {"authorship": "rejected", "reason": "voice_incomplete"}),
        case("A 없음 + target 불일치 → A 게이트가 먼저", "target",
             {"authorship": None, "reason": "envelope_signer_unverified"}, envelope_keys="no_sender"),
        case("digest 불일치 + A 없음 → digest가 먼저", "digest",
             {"authorship": None, "reason": "body_digest_mismatch"}, envelope_keys="no_sender"),
    ]))

    agg = lambda name, letters, expect, *, envelope_keys="all", pinned="all", view="T13": {  # noqa: E731
        "name": name, "op": "aggregate", "letters": letters, "envelope_keys": envelope_keys,
        "pinned": pinned, "view": view, "now": NOW, "clock_trusted": True, "expect": expect}
    first_spark = min(("spark", "spark_resend"), key=lambda n: event_id(lets[n]["envelope"]))
    out.append(("08-aggregate", ["C2-1", "이음 162", "Orin 048"],
                "같은 중복 키의 사본 집계: 사본을 버리지 않고, 지금 판정한 가장 높은 등급(rejected·판정 전 제외)을 대표로 "
                "보인다. 도착 순서와 무관하고, 판이 바뀌면 다시 판정한다. 같은 등급이면 봉투 event_id가 작은 사본.", [
        agg("무서명 → 서명 순서", ["claimed", "spark"],
            {"representative": "spark", "representative_grade": "verified",
             "copy_grades": ["claimed", "verified"]}),
        agg("서명 → 무서명 순서(대표 같음)", ["spark", "claimed"],
            {"representative": "spark", "representative_grade": "verified",
             "copy_grades": ["verified", "claimed"]}),
        agg("거부 사본이 먼저 와도 정상 사본을 막지 않는다", ["voice_sig", "claimed"],
            {"representative": "claimed", "representative_grade": "claimed",
             "copy_grades": ["rejected", "claimed"]}),
        agg("철회 전 판(T 9) → 서명 사본이 대표", ["ash_claimed", "ash"],
            {"representative": "ash", "representative_grade": "verified"}, view="T9"),
        agg("철회 뒤 판(T 13)으로 다시 판정 → 대표가 무서명 사본으로(과거 verified를 고정하지 않음)",
            ["ash_claimed", "ash"],
            {"representative": "ash_claimed", "representative_grade": "claimed",
             "copy_grades": ["claimed", "rejected"]}),
        agg("B 없음 → unverifiable이 claimed보다 위", ["claimed", "spark"],
            {"representative": "spark", "representative_grade": "unverifiable"}, view=None),
        agg("A 없음 → 모두 판정 전, 대표 없음", ["claimed", "spark"],
            {"representative": None, "representative_grade": None, "copy_grades": [None, None]},
            envelope_keys="no_sender"),
        agg("같은 등급 둘 → event_id가 작은 사본", ["spark", "spark_resend"],
            {"representative": first_spark, "representative_grade": "verified"}),
        agg("같은 등급 둘, 순서 반대 → 같은 대표", ["spark_resend", "spark"],
            {"representative": first_spark, "representative_grade": "verified"}),
    ]))

    MAL = {"envelope": "ok", "authorship": "rejected", "reason": "letter_malformed", "scope": None,
           "delivery_candidate": False, "display": disp(None, "letter_malformed")}
    CLM = {"envelope": "ok", "authorship": "claimed", "reason": None}
    out.append(("09-text-cap", ["§3.2 v0.3", "§4.4 Q10 1단계", "이음 164", "Orin 050"],
                "text 상한 16,000 유니코드 코드 포인트(v0.3 §3.2). JSON을 푼 문자열을 서명된 그대로 센다 — 정규화하지 "
                "않고, UTF-8 바이트·UTF-16 단위·자소 묶음·이스케이프 길이가 아니다(C2 D14). 상한 초과는 편지 구조 결함이라 "
                "봉투 층(digest·A 게이트·봉투 서명)이 먼저 이기고, target·voice보다 먼저 온다.", [
        case("한글 16,000 코드 포인트 → 상한 안(claimed)", "text_cap_han", CLM),
        case("한글 16,001 코드 포인트 → letter_malformed", "text_over_han", MAL),
        case("ASCII 16,001 → letter_malformed", "text_over_ascii", MAL),
        case("이모지 16,000(UTF-16 단위 32,000) → 코드 포인트로 세어 상한 안", "text_cap_emoji", CLM),
        case("e+결합 부호 ×8,001 = 코드 포인트 16,002(NFC·자소 8,001) → 정규화하지 않는다, letter_malformed",
             "text_over_combining", MAL),
        case("비ASCII를 \\u 이스케이프로 실은 본문(이모지 2,000 = 24,000자) → JSON을 푼 뒤 세어 상한 안",
             "text_escaped_emoji", CLM),
        case("상한 초과 + A 없음 → A 게이트가 먼저(판정 전)", "text_over_ascii",
             {"envelope": "unverified", "authorship": None, "reason": "envelope_signer_unverified",
              "delivery_candidate": False}, envelope_keys="no_sender"),
        case("상한 초과 + 봉투 서명 불일치 → 봉투 서명이 먼저", "text_over_envsig",
             {"envelope": "invalid", "authorship": None, "reason": "envelope_sig_invalid"}),
        case("상한 초과 + digest 불일치 → digest가 먼저", "text_over_digest",
             {"envelope": None, "authorship": None, "reason": "body_digest_mismatch"}),
        case("상한 초과 + target 불일치 → 편지 구조가 먼저(letter_malformed)", "text_over_target", MAL),
        case("상한 초과 + 완전·정상 voice → verified가 아니라 letter_malformed", "text_over_voice", MAL),
        case("상한 초과 + voice 반쪽 → voice_incomplete보다 letter_malformed가 먼저", "text_over_voice_half", MAL),
        case("16,000 + 완전·정상 voice → verified · 범위 안 · 전달 후보", "text_cap_voice",
             {"envelope": "ok", "authorship": "verified", "reason": None,
              "scope": scope("in_scope", "snapshot"), "delivery_candidate": True}),
    ]))
    return out


NPUB = bech32_encode("npub", bytes.fromhex(pub_of(S_SENDER)))
NPROFILE = bech32_encode("nprofile", bytes([0, 32]) + bytes.fromhex(pub_of(S_OTHER)))
NPUB_BAD = NPUB[:-1] + ("q" if NPUB[-1] != "q" else "p")


def event_id(envelope: dict) -> str:
    """봉투 event_id(= sha256(정규화 봉투)) — 제품 hub_envelope 규칙 그대로(검증기 아님)."""
    from organum import hub_envelope as he
    return he.event_id_of(he.canonical_bytes(envelope))


def policy_vectors(lets):
    P_OK = {"accepts": ["letters"], "from": [{"lab": SENDER}], "channel": "letters",
            "note": "편지는 천천히 읽습니다"}
    P_SPARK1 = {"accepts": ["letters"], "from": [{"lab": SENDER, "id": "Spark", "epoch": 1}]}

    def prof(policy, epoch=1):
        p = {"display_name": "Moss", "kind": "creature"}
        if policy is not None:
            p["contact_policy"] = policy
        return {"subject": {"lab": RECV, "id": "Moss", "epoch": epoch}, "profile": p}

    def body(author_epoch=1, to=MOSS):
        return {"kind": "creature.letter", "author": c("Spark", author_epoch), "to": to,
                "at": LAT, "text": "Spark의 편지"}

    chk = lambda name, pol, valid: {"name": name, "op": "policy_check", "policy": pol,  # noqa: E731
                                     "expect": {"valid": valid}}
    adm = lambda name, profile, b, surface, admit, reason: {  # noqa: E731
        "name": name, "op": "policy_admits", "profile": profile, "letter_body": b,
        "surface": surface, "expect": {"admit": admit, "reason": reason}}
    cases = [
        chk("정상 정책", P_OK, True),
        chk("accepts 누락", {"from": [{"lab": SENDER}]}, False),
        chk("accepts가 목록 아님", dict(P_OK, accepts="letters"), False),
        chk("모르는 표면(fax)", dict(P_OK, accepts=["fax"]), False),
        chk("게시판 표면", dict(P_OK, accepts=["letters", "board:bbs-plaza"]), True),
        chk("모르는 채널", dict(P_OK, channel="hub-ops2"), False),
        chk("연구소 와일드카드", dict(P_OK, **{"from": [{"lab": "*"}]}), False),
        chk("빈 목록도 유효한 모양", {"accepts": [], "from": []}, True),
        chk("note 200 코드 포인트", dict(P_OK, note="가" * 200), True),
        chk("note 201 코드 포인트", dict(P_OK, note="가" * 201), False),
        chk("note에 URL", dict(P_OK, note="자세한 건 https://example.org 참고"), False),
        chk("note에 전자우편", dict(P_OK, note="moss@example.org 로"), False),
        chk("note에 연구소 좌표", dict(P_OK, note="lab:recv 로 보내 주세요"), False),
        chk("note에 전화번호", dict(P_OK, note="+82 10-1234-5678"), False),
        chk("평범한 note", dict(P_OK, note="주말에는 늦게 읽어요"), True),
        chk("note의 날짜는 전화번호가 아니다", dict(P_OK, note="2026-10-01부터 읽어요"), True),
        chk("note에 Nostr npub 키(체크섬 맞음)", dict(P_OK, note=f"여기로: {NPUB}"), False),
        chk("note에 Nostr nprofile(체크섬 맞음)", dict(P_OK, note=f"{NPROFILE} 로 찾아요"), False),
        chk("npub 모양이지만 체크섬 틀림 → 기계 규칙은 통과(사람 검토 몫)",
            dict(P_OK, note=f"{NPUB_BAD} 이건 오타"), True),
        chk("짧은 접두어만(npub1abc) → 기계 규칙은 통과", dict(P_OK, note="npub1abc 라는 별명"), True),
        adm("정책 없음 → 허가 아님", prof(None), body(), "letters", False, "no_policy"),
        adm("정상 정책 · 편지 표면", prof(P_OK), body(), "letters", True, None),
        adm("표면 불일치(게시판)", prof(P_OK), body(), "board:bbs-plaza", False, "surface_not_accepted"),
        adm("from 빈 목록 → 허용 발신자 없음", prof(dict(P_OK, **{"from": []})), body(), "letters",
            False, "sender_not_accepted"),
        adm("accepts 빈 목록 → 수락 표면 없음", prof(dict(P_OK, accepts=[])), body(), "letters",
            False, "surface_not_accepted"),
        adm("발신 epoch 1 명시 · 발신자 epoch 1", prof(P_SPARK1), body(1), "letters", True, None),
        adm("발신 epoch 1 명시 · 발신자 epoch 2로 바뀜", prof(P_SPARK1), body(2), "letters",
            False, "sender_not_accepted"),
        adm("받는 이 epoch가 바뀜(편지는 epoch 2로)", prof(P_OK), body(1, MOSS2), "letters",
            False, "policy_epoch_mismatch"),
        adm("다른 주체 앞 편지", prof(P_OK), body(1, FERN), "letters", False, "policy_subject_mismatch"),
        adm("형식이 틀린 정책 → 허가 아님", prof(dict(P_OK, channel="nowhere")), body(), "letters",
            False, "policy_invalid"),
    ]
    return ("06-contact-policy", ["§8", "이음 159·160", "나루 235"],
            "연락 정책(전화번호부 v0.3 제안): 부재·빈 목록·오형식은 허가가 아니다, epoch는 넘어가지 않는다.", cases)


def misc_vectors(lets):
    row = {"subject": {"lab": RECV, "id": "Moss", "epoch": 1},
           "profile": {"display_name": "Moss", "kind": "creature",
                       "contact": {"lab_id": RECV, "to_id": "Moss", "to_epoch": 1},
                       "contact_policy": {"accepts": ["letters"], "from": [{"lab": SENDER}]}}}
    cases = [
        {"name": "public projection은 contact·contact_policy를 뺀다", "op": "projection", "row": row,
         "expect": {"profile_keys": ["display_name", "kind"]}},
        {"name": "투영 산출물에 contact_policy가 남으면 문제", "op": "projection_problems",
         "projected": {"subject": row["subject"],
                       "profile": {"display_name": "Moss", "contact_policy": {"accepts": []}}},
         "expect": {"problem_count": 1}},
        {"name": "창 안 이전 편지 5통 → 초과 관측", "op": "rate",
         "prior": ["2026-09-30T01:00:00Z", "2026-09-30T05:00:00Z", "2026-09-30T09:00:00Z",
                   "2026-09-30T13:00:00Z", "2026-09-30T17:00:00Z"],
         "now": NOW, "rate": {"max": 5, "per_seconds": 86400}, "expect": {"exceeded": True}},
        {"name": "창 안 4통 → 초과 아님", "op": "rate",
         "prior": ["2026-09-30T05:00:00Z", "2026-09-30T09:00:00Z", "2026-09-30T13:00:00Z",
                   "2026-09-30T17:00:00Z"],
         "now": NOW, "rate": {"max": 5, "per_seconds": 86400}, "expect": {"exceeded": False}},
        {"name": "창 밖(25시간 전) 1통은 세지 않는다", "op": "rate",
         "prior": ["2026-09-29T23:00:00Z", "2026-09-30T05:00:00Z", "2026-09-30T09:00:00Z",
                   "2026-09-30T13:00:00Z", "2026-09-30T17:00:00Z"],
         "now": NOW, "rate": {"max": 5, "per_seconds": 86400}, "expect": {"exceeded": False}},
        {"name": "딱 24시간 전 편지는 창 밖(반열림) → 초과 아님", "op": "rate",
         "prior": ["2026-09-30T00:00:00Z", "2026-09-30T05:00:00Z", "2026-09-30T09:00:00Z",
                   "2026-09-30T13:00:00Z", "2026-09-30T17:00:00Z"],
         "now": NOW, "rate": {"max": 5, "per_seconds": 86400}, "expect": {"exceeded": False}},
        {"name": "같은 편지를 새 봉투로 → 같은 중복 키", "op": "dedup",
         "letters": ["claimed", "claimed_resend"], "expect": {"same": True}},
        {"name": "받는 이가 다른 편지 → 다른 중복 키", "op": "dedup",
         "letters": ["claimed", "spark_fern"], "expect": {"same": False}},
        {"name": "무서명판과 서명판의 같은 내용 → 같은 중복 키(동결판 정의 그대로 — 발견 C2-1)",
         "op": "dedup", "letters": ["claimed", "spark"], "expect": {"same": True}},
    ]
    return ("07-projection-rate-dedup", ["§8", "§4.3", "§3.2"],
            "public projection 제거 규칙 · 빈도 관측 · 중복 키.", cases)


def emit(out_dir: Path) -> dict:
    S, views, lets = build()
    groups = vectors(views, lets) + [policy_vectors(lets), misc_vectors(lets)]
    out_dir.mkdir(parents=True, exist_ok=True)
    index = []
    for name, refs, purpose, cases in groups:
        used_letters = sorted({cs["letter"] for cs in cases if cs.get("letter")}
                              | {n for cs in cases for n in cs.get("letters", [])})
        used_views = sorted({cs["view"] for cs in cases if cs.get("view")})
        doc = {"vector": name, "contract": CONTRACT, "refs": refs, "purpose": purpose,
               "envelope_keys": ENVELOPE_KEYS, "pinned": PINNED, "known_channels": KNOWN_CHANNELS,
               "views": {k: views[k] for k in used_views},
               "letters": {k: lets[k] for k in used_letters}, "cases": cases}
        data = (json.dumps(doc, ensure_ascii=False, indent=1, sort_keys=True) + "\n").encode()
        (out_dir / f"{name}.json").write_bytes(data)
        index.append({"file": f"{name}.json", "cases": len(cases),
                      "sha256": hashlib.sha256(data).hexdigest()})
    digest = hashlib.sha256("".join(f"{e['sha256']}  {e['file']}\n" for e in index)
                            .encode()).hexdigest()
    idx = {"contract": CONTRACT, "vectors": index, "digest": digest,
           "digest_rule": "sha256(각 줄 '<sha256>  <file>\\n'을 파일명 순으로 이은 bytes)"}
    (out_dir / "INDEX.json").write_bytes((json.dumps(idx, ensure_ascii=False, indent=1) + "\n").encode())
    return idx


if __name__ == "__main__":
    target = Path(sys.argv[1]) if len(sys.argv) > 1 else HERE / "vectors"
    idx = emit(target)
    print(json.dumps({"vectors": len(idx["vectors"]),
                      "cases": sum(v["cases"] for v in idx["vectors"]),
                      "digest": idx["digest"], "out": str(target)}, ensure_ascii=False))
