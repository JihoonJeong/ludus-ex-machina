"""크리처 자격 증명 C2 참조 기계 — delta v0.3 동결판(dev acacdb5)을 코드로 옮긴 것(r1·r2는 v0.2 동결판 73472e5).

제품이 아니다(experiments/). 동결판 문구가 스스로 모순 없이 판정하는지 합성 벡터로 본다.
기대값은 벡터 생성기가 동결판 문구에서 손으로 적고, 이 모듈을 부르지 않는다.

담는 것:
- 크리처 편지(`creature.letter`) 판정 — 봉투 층 · 구조 · 저자성 네 등급 · 상세 reason(§4.1·§4.4, Q10 순서)
- 범위 판정(§4.2) — `scope_basis`·`unchecked`, 전달 후보는 판 근거·미검사 없음일 때만
- 연락 정책(§8, 전화번호부 v0.3 제안) — 검증·수용 판정·public projection
- 빈도 관측(§4.3)과 중복 키(§3.2)

경로 S의 입력(발신 연구소 판 보기)은 trust snapshot 주민 층이 정해지기 전(C4)이라 합성 모양이다:
`view = {"snapshot_id", "T", "usable", "voice_bindings": [동결판 §9 스케치 행]}` 또는 None.
`usable`은 trust snapshot v0.5 상태 규칙(만료·유실 등)의 결과를 받는 자리다 — 여기서 다시 판정하지 않는다.

C2가 정한 것(동결판이 C2에 맡긴 항목)은 README와 보고서에 적는다. 로컬 진단 이름은 이 delta 안의
이름이다(Orin 046) — 전역 enum이 아니다.

r2(Orin 048): 신뢰근을 둘로 가른다.
- **A — 바깥 봉투의 발신 연구소 키**(`envelope_keys`, 받는 쪽 hub registry의 결속). A를 모르면 봉투가 연구소의
  서명 진술인지부터 확인할 수 없다. 저자성은 판정 전(null), 사유 `envelope_signer_unverified`.
- **B — 발화 보증·판의 신뢰근**(`pinned`, trust snapshot 발급자 고정). A가 검증된 뒤 Q10 3단계에서만 본다.
C2-1(이음 162·Orin 048): 같은 중복 키의 사본은 버리지 않고 하나로 집계하며, 지금 판정한 가장 높은 등급을 대표로 보인다.
r3(v0.3 §3.2, 이음 164·Orin 050): `text`가 16,000 코드 포인트를 넘으면 편지 구조 결함(`letter_malformed`)이다.
구조 단계에 있으므로 봉투 층(A 게이트·봉투 서명·digest)이 먼저 이기고, target·voice보다 먼저 온다.
"""

from __future__ import annotations

import hashlib
import json
import re
import sys
from datetime import datetime, timezone
from pathlib import Path

_ROOT = Path(__file__).resolve().parents[2]
for _p in (_ROOT / "src", _ROOT / "experiments" / "identity-v0"):
    if str(_p) not in sys.path:
        sys.path.insert(0, str(_p))
from organum import hub_envelope as he  # noqa: E402
from organum import schnorr_pure as sp  # noqa: E402
import voice  # noqa: E402  (발화 키 r2: DOMAIN·정규화·서명)

LETTER_KIND = "creature.letter"
GRANT_SCHEMA = "organum-voice/grant/v0"
ATTEST_KIND = "voice.attested"

# 상세 reason → 주소 계약 쪽 표시(§4.4). None이면 주소 계약 이름이 없어 reason을 보존한다.
ADDRESS_NAME = {
    "envelope_malformed": "invalid_signature_or_digest",
    "envelope_signer_unverified": "signer_unverified",
    "envelope_sig_invalid": "invalid_signature_or_digest",
    "body_digest_mismatch": "invalid_signature_or_digest",
    "voice_sig_invalid": "invalid_signature_or_digest",
    "attestation_sig_invalid": "invalid_signature_or_digest",
    "no_trust_root": "signer_unverified",
    "no_valid_snapshot": "signer_unverified",
    "snapshot_behind_attestation": "signer_unverified",
    "binding_absent": "signer_unbound",
    "target_mismatch": None,
    "author_lab_mismatch": None,
    "binding_revoked": None,
    "letter_malformed": None,
    "voice_incomplete": None,
    "attestation_mismatch": None,
}
# 여울 표시층 제안(이음 160, 동결판 §4.4) — 주소 계약 이름이 없는 셋
DISPLAY = {
    "target_mismatch": ("받는 주소 불일치", "Recipient address mismatch"),
    "author_lab_mismatch": ("발신 연구소와 저자 소속 불일치", "Sender lab and author lab mismatch"),
    "binding_revoked": ("서명 키 보증 철회", "Signing-key attestation revoked"),
}

_HEX = set("0123456789abcdef")
_LETTER_KEYS = {"kind", "author", "to", "at", "text"}
_LETTER_OPT = {"in_reply_to", "voice"}
_ATT_KEYS = {"kind", "lab", "subject", "voice_pubkey", "hub", "valid_from_seq", "at"}
_GRANT_KEYS = {"schema", "letters", "boards", "rate", "not_after", "until_seq"}
_BOARD_ID = re.compile(r"[a-z0-9][a-z0-9-]{0,63}\Z")
_CHANNEL = re.compile(r"[a-z0-9][a-z0-9-]{0,63}\Z")      # 드롭 채널 이름 규칙(LxM 104)
_NOTE_MAX = 200                                          # 유니코드 코드 포인트(나루 235)
_TEXT_MAX = 16_000                                       # 유니코드 코드 포인트(v0.3 §3.2)
# note의 연락 수단 탐지 — C2가 정한 보수적 규칙. 완전하지 않다(보고서의 한계).
_CONTACT_MEANS = [
    re.compile(r"[a-z][a-z0-9+.-]*://", re.I),           # URL 스킴
    re.compile(r"\bwww\.", re.I),
    re.compile(r"[^\s@]+@[^\s@]+\.[^\s@]+"),             # 전자우편
    re.compile(r"\blab:[a-z0-9]", re.I),                 # organum 연구소 좌표
    re.compile(r"/v0/"),                                 # 드롭 경로
]
_PHONE = re.compile(r"\+?\d[\d\s().-]{6,}\d")                # 전화번호 모양 — 숫자 9개 이상일 때만
_PHONE_MIN_DIGITS = 9                                    # 날짜(YYYY-MM-DD, 숫자 8개)를 오인하지 않게


_B32 = "qpzry9x8gf2tvdw0s3jn54khce6mua7l"
_NOSTR_KEY = re.compile(r"(npub1|nprofile1)[" + _B32 + r"]{6,}", re.I)   # 나루 243·이음 162


def _bech32_polymod(values) -> int:
    gen = (0x3b6a57b2, 0x26508e6d, 0x1ea119fa, 0x3d4233dd, 0x2a1462b3)
    chk = 1
    for v in values:
        top = chk >> 25
        chk = (chk & 0x1ffffff) << 5 ^ v
        for i in range(5):
            chk ^= gen[i] if (top >> i) & 1 else 0
    return chk


def _bech32_data(s: str):
    """BIP-173 bech32(NIP-19) 체크섬이 맞으면 (hrp, 5비트 데이터), 아니면 None."""
    s = s.lower()
    pos = s.rfind("1")
    if pos < 1 or len(s) - pos < 7:
        return None
    hrp, tail = s[:pos], s[pos + 1:]
    data = [_B32.find(ch) for ch in tail]
    if -1 in data:
        return None
    expand = [ord(x) >> 5 for x in hrp] + [0] + [ord(x) & 31 for x in hrp]
    if _bech32_polymod(expand + data) != 1:
        return None
    return hrp, data[:-6]


def _is_nostr_key(token: str) -> bool:
    """실제 키 형태만 — 접두어가 아니라 체크섬, npub은 32바이트까지 본다."""
    dec = _bech32_data(token)
    if dec is None:
        return False
    hrp, data = dec
    if hrp == "npub":
        return len(data) * 5 // 8 == 32
    return hrp == "nprofile"


def _has_contact_means(note: str) -> bool:
    if any(rx.search(note) for rx in _CONTACT_MEANS):
        return True
    if any(_is_nostr_key(m.group()) for m in _NOSTR_KEY.finditer(note)):
        return True
    return any(sum(ch.isdigit() for ch in m.group()) >= _PHONE_MIN_DIGITS
               for m in _PHONE.finditer(note))


# ── 작은 도구 ────────────────────────────────────────────────────────────────

def _text_len(s: str) -> int:
    """`text`의 길이 = JSON을 푼 문자열의 유니코드 코드 포인트 수, 서명된 그대로(C2 D14).
    정규화(NFC 등)하지 않는다. UTF-8 바이트·UTF-16 단위·자소 묶음·JSON 이스케이프 길이가 아니다."""
    return len(s)


def _is_hex(v, n) -> bool:
    return isinstance(v, str) and len(v) == 2 * n and set(v) <= _HEX


def _is_int(v, lo=0) -> bool:
    return type(v) is int and v >= lo


def parse_time(v):
    if not he._is_rfc3339_z(v):
        return None
    body = v[:-1]
    fmt = "%Y-%m-%dT%H:%M:%S.%f" if "." in body else "%Y-%m-%dT%H:%M:%S"
    return datetime.strptime(body, fmt).replace(tzinfo=timezone.utc)


def _coord_ok(c) -> bool:
    return (isinstance(c, dict) and set(c) == {"lab", "id", "epoch"}
            and isinstance(c["lab"], str) and he._LAB_ID.fullmatch(c["lab"]) is not None
            and isinstance(c["id"], str) and bool(c["id"]) and _is_int(c["epoch"], 1))


def _addr_ok(a) -> bool:
    return (isinstance(a, dict) and set(a) == {"lab_id", "to_id", "to_epoch"}
            and isinstance(a["lab_id"], str) and he._LAB_ID.fullmatch(a["lab_id"]) is not None
            and isinstance(a["to_id"], str) and bool(a["to_id"]) and _is_int(a["to_epoch"], 1))


def speech_bytes(body: dict) -> bytes:
    """서명 대상 = 본문에서 voice를 뺀 정규화 bytes(발화 키 r2 speech_bytes_of)."""
    return voice.speech_bytes_of(body)


def dedup_key(body: dict) -> tuple:
    """(author, 서명 대상 bytes의 sha256) — 같은 편지는 봉투가 달라도 하나다(§3.2)."""
    a = body["author"]
    return (a["lab"], a["id"], a["epoch"], hashlib.sha256(speech_bytes(body)).hexdigest())


# ── 패턴·grant ──────────────────────────────────────────────────────────────

def pattern_problems(p) -> list:
    """받는 이·보내는 이 패턴 {lab[, id][, epoch]} — 연구소 와일드카드 없음."""
    if not (isinstance(p, dict) and "lab" in p and set(p) <= {"lab", "id", "epoch"}):
        return ["패턴은 {lab[, id][, epoch]}"]
    out = []
    if not (isinstance(p["lab"], str) and he._LAB_ID.fullmatch(p["lab"])):
        out.append("패턴 lab이 lab: 문법 밖(와일드카드 없음)")
    if "id" in p and not (isinstance(p["id"], str) and p["id"]):
        out.append("패턴 id는 비어 있지 않은 문자열")
    if "epoch" in p and not _is_int(p["epoch"], 1):
        out.append("패턴 epoch는 양의 정수")
    return out


def pattern_matches(p: dict, lab: str, id_: str, epoch: int) -> bool:
    return (p["lab"] == lab and ("id" not in p or p["id"] == id_)
            and ("epoch" not in p or p["epoch"] == epoch))


def grant_problems(g) -> list:
    if not (isinstance(g, dict) and set(g) <= _GRANT_KEYS and "schema" in g
            and "not_after" in g):
        return ["grant 키 집합(schema·not_after 필수)"]
    out = []
    if g["schema"] != GRANT_SCHEMA:
        out.append("grant schema")
    if parse_time(g["not_after"]) is None:
        out.append("not_after 형식(RFC3339 Z)")
    if "letters" in g:
        L = g["letters"]
        if not (isinstance(L, dict) and set(L) == {"to"} and isinstance(L["to"], list)):
            out.append("letters는 {to: [패턴]}")
        else:
            for p in L["to"]:
                out += pattern_problems(p)
    if "boards" in g and not (isinstance(g["boards"], list)
                              and all(isinstance(b, str) and _BOARD_ID.fullmatch(b)
                                      for b in g["boards"])):
        out.append("boards는 게시판 좌표 목록")
    if "rate" in g and not (isinstance(g["rate"], dict) and set(g["rate"]) == {"max", "per_seconds"}
                            and _is_int(g["rate"]["max"], 1)
                            and _is_int(g["rate"]["per_seconds"], 1)):
        out.append("rate는 {max, per_seconds} 양의 정수")
    if "until_seq" in g and not _is_int(g["until_seq"], 1):
        out.append("until_seq는 양의 정수")
    return out


def scope_of(grant, to: dict, *, now, clock_trusted: bool, coord, basis: str,
             admit_seq: int) -> dict:
    """§4.2 범위 판정. coord = 판정 좌표(경로 S의 T+1) 또는 None(참고 판정)."""
    unchecked = []
    if grant is None:
        return {"verdict": "no_grant", "basis": basis, "unchecked": unchecked}
    if "until_seq" in grant and grant["until_seq"] <= admit_seq:
        # §3.1: until_seq는 보증의 admit 좌표보다 커야 한다. 아니면 grant는 무효 → grant 없음(C2)
        return {"verdict": "no_grant", "basis": basis, "unchecked": unchecked,
                "observation": "grant_void_until_seq"}
    if "letters" not in grant:
        verdict = "out_of_scope:surface"
    elif not any(pattern_matches(p, to["lab_id"], to["to_id"], to["to_epoch"])
                 for p in grant["letters"]["to"]):
        verdict = "out_of_scope:recipient"
    else:
        verdict = "in_scope"
    if not clock_trusted:
        unchecked.append("not_after")
    elif now >= parse_time(grant["not_after"]) and verdict == "in_scope":
        verdict = "out_of_scope:expired"
    if "until_seq" in grant:
        if coord is None:
            unchecked.append("until_seq")
        elif coord >= grant["until_seq"] and verdict == "in_scope":
            verdict = "out_of_scope:expired"
    return {"verdict": verdict, "basis": basis, "unchecked": unchecked}


# ── 편지 판정 ────────────────────────────────────────────────────────────────

def _result(envelope, authorship, reason, **extra) -> dict:
    out = {"envelope": envelope, "authorship": authorship, "reason": reason,
           "scope": None, "basis": None, "observations": [], "delivery_candidate": False}
    out.update(extra)
    return out


def _voice_shape_problems(v, author) -> list:
    """voice 블록의 구조 — 키 없이 볼 수 있는 것 전부. 실패는 voice_incomplete."""
    if not (isinstance(v, dict) and set(v) == {"sig", "attestation"}):
        return ["voice는 {sig, attestation}"]
    out = []
    if not _is_hex(v["sig"], 64):
        out.append("voice.sig hex128 아님")
    att = v["attestation"]
    if not (isinstance(att, dict) and set(att) == {"body", "lab_sig"}):
        return out + ["attestation은 {body, lab_sig}"]
    if not _is_hex(att["lab_sig"], 64):
        out.append("attestation.lab_sig hex128 아님")
    b = att["body"]
    if not (isinstance(b, dict) and _ATT_KEYS <= set(b) <= _ATT_KEYS | {"grant"}):
        return out + ["attestation.body 키 집합"]
    if b["kind"] != ATTEST_KIND:
        out.append("attestation kind")
    if not _coord_ok(b["subject"]) or not isinstance(b["lab"], str):
        out.append("attestation subject·lab 모양")
    if not _is_hex(b["voice_pubkey"], 32):
        out.append("voice_pubkey hex64 아님")
    hub = b["hub"]
    if not (isinstance(hub, dict) and set(hub) == {"event_id", "accepted_seq"}
            and _is_hex(hub["event_id"], 32) and _is_int(hub["accepted_seq"], 1)):
        out.append("attestation hub 좌표")
    elif b["valid_from_seq"] != hub["accepted_seq"] + 1:
        out.append("valid_from_seq ≠ accepted_seq + 1")
    if parse_time(b["at"]) is None:
        out.append("attestation at 형식")
    if "grant" in b:
        out += grant_problems(b["grant"])
    return out


def verify_letter(envelope, env_sig, body_bytes: bytes, *, envelope_keys: dict, pinned: dict,
                  view, now: str, clock_trusted: bool = True) -> dict:
    """크리처 편지 판정. Q10 순서(동결판 §4.4, r2 A/B 분리):
    1 봉투 모양·digest → A(봉투 발신 키) 게이트 → 봉투 서명 → 편지 구조·주소 결속 →
    2 voice 부재=claimed / 반쪽·형식=rejected →
    3 완전한 사슬만: B(보증·판 신뢰근) → 암호 사슬 → 판 상태 → 결속 → 범위.

    envelope_keys = A(받는 쪽 hub registry의 연구소 서명 키), pinned = B(trust snapshot 발급자 고정 키)."""
    now_dt = parse_time(now)
    # ── 1. 봉투 층 ──
    try:
        if not isinstance(envelope, dict) or envelope.get("event_kind") != "message.posted":
            raise ValueError("message.posted 봉투가 아님")
        raw = he.canonical_bytes(envelope)
        probs = he.validate_envelope(envelope)
    except (he.HubEnvelopeError, TypeError, ValueError, KeyError, AttributeError) as e:
        return _result(None, None, "envelope_malformed", problems=[str(e)])
    if probs:
        return _result(None, None, "envelope_malformed", problems=probs)
    if hashlib.sha256(body_bytes).hexdigest() != envelope["payload"]["body_sha256"]:
        return _result(None, None, "body_digest_mismatch")
    lab_key = envelope_keys.get(envelope["signer"]["id"])
    if lab_key is None:
        # A 미확인(Orin 048): 봉투가 연구소의 서명 진술인지 모른다 — claimed로 쓰지 않는다
        return _result("unverified", None, "envelope_signer_unverified")
    if not (_is_hex(env_sig, 64) and sp.verify(bytes.fromhex(env_sig),
                                                hashlib.sha256(raw).digest(),
                                                bytes.fromhex(lab_key))):
        return _result("invalid", None, "envelope_sig_invalid")
    env_state = "ok"
    # ── 1. 편지 구조·주소 결속 ──
    try:
        body = json.loads(body_bytes.decode("utf-8"))
    except (UnicodeDecodeError, ValueError):
        body = None
    if not (isinstance(body, dict) and _LETTER_KEYS <= set(body) <= _LETTER_KEYS | _LETTER_OPT
            and body["kind"] == LETTER_KIND and _coord_ok(body["author"])
            and _addr_ok(body["to"]) and parse_time(body["at"]) is not None
            and isinstance(body["text"], str) and _text_len(body["text"]) <= _TEXT_MAX
            and (body.get("in_reply_to") is None or isinstance(body["in_reply_to"], str))):
        return _result(env_state, "rejected", "letter_malformed")
    if envelope["payload"]["target"] != body["to"]:
        return _result(env_state, "rejected", "target_mismatch")
    author = body["author"]
    if envelope["signer"]["id"] != author["lab"]:
        return _result(env_state, "rejected", "author_lab_mismatch")
    # ── 2. voice 부재·반쪽 ──
    if "voice" not in body:
        return _result(env_state, "claimed", None)
    v = body["voice"]
    shape = _voice_shape_problems(v, author)
    if shape:
        return _result(env_state, "rejected", "voice_incomplete", problems=shape)
    att_body = v["attestation"]["body"]
    if att_body["lab"] != author["lab"] or att_body["subject"] != author:
        return _result(env_state, "rejected", "attestation_mismatch")
    admit_seq = att_body["hub"]["accepted_seq"]
    inline_grant = att_body.get("grant")

    def advisory(authorship, reason):
        sc = scope_of(inline_grant, body["to"], now=now_dt, clock_trusted=clock_trusted,
                      coord=None, basis="inline_advisory", admit_seq=admit_seq)
        return _result(env_state, authorship, reason, scope=sc)

    # ── 3. 완전한 사슬 ──
    trust_key = pinned.get(author["lab"])
    if trust_key is None:
        return advisory("unverifiable", "no_trust_root")
    if not sp.verify(bytes.fromhex(v["attestation"]["lab_sig"]),
                     voice._digest(voice._canon(att_body)), bytes.fromhex(trust_key)):
        return _result(env_state, "rejected", "attestation_sig_invalid")
    if not sp.verify(bytes.fromhex(v["sig"]),
                     hashlib.sha256(voice.DOMAIN + speech_bytes(body)).digest(),
                     bytes.fromhex(att_body["voice_pubkey"])):
        return _result(env_state, "rejected", "voice_sig_invalid")
    if view is None or not view.get("usable"):
        return advisory("unverifiable", "no_valid_snapshot")
    T = view["T"]
    coord = T + 1
    basis = {"snapshot_id": view["snapshot_id"], "T": T, "coordinate": coord}
    rows = [r for r in view["voice_bindings"]
            if r["subject"] == author and r["voice_pubkey"] == att_body["voice_pubkey"]]
    if not rows:
        if admit_seq > T:
            return advisory("unverifiable", "snapshot_behind_attestation")
        return _result(env_state, "rejected", "binding_absent", basis=basis)
    active = [r for r in rows if r["revoked_at_seq"] is None]
    if not active:
        return _result(env_state, "rejected", "binding_revoked", basis=basis)
    row = max(active, key=lambda r: r["valid_from_seq"])
    sc = scope_of(row.get("grant"), body["to"], now=now_dt, clock_trusted=clock_trusted,
                  coord=coord, basis="snapshot", admit_seq=row["origin"]["seq"])
    out = _result(env_state, "verified", None, scope=sc, basis=basis)
    if he.canonical_bytes({"g": inline_grant}) != he.canonical_bytes({"g": row.get("grant")}):
        out["observations"].append("inline_grant_differs")
    out["delivery_candidate"] = (sc["verdict"] == "in_scope" and sc["basis"] == "snapshot"
                                 and not sc["unchecked"])
    return out


_RANK = {"verified": 3, "unverifiable": 2, "claimed": 1}


def envelope_event_id(envelope: dict) -> str:
    return he.event_id_of(he.canonical_bytes(envelope))


def aggregate(copies: list) -> dict:
    """C2-1(이음 162·Orin 048): 같은 중복 키의 사본을 하나의 편지로 집계한다.

    copies = [(봉투 event_id, verify_letter 결과), …] 도착 순서. 사본은 하나도 버리지 않는다. 대표는 지금 판정한
    결과 가운데 rejected·판정 전을 뺀 가장 높은 등급이고, 같으면 event_id가 가장 작은 사본이다(도착 순서와 무관).
    대표는 표시일 뿐이다 — 전달 판정을 새로 만들지 않고, 사본 사이에 범위·정책·전달 판정을 섞지 않는다."""
    kept = [{"event_id": eid, "authorship": r["authorship"], "reason": r["reason"],
             "delivery_candidate": r["delivery_candidate"]} for eid, r in copies]
    ranked = [c for c in kept if c["authorship"] in _RANK]
    if not ranked:
        return {"copies": kept, "representative": None, "representative_grade": None}
    best = min(ranked, key=lambda c: (-_RANK[c["authorship"]], c["event_id"]))
    return {"copies": kept, "representative": best["event_id"],
            "representative_grade": best["authorship"]}


def display(result: dict) -> dict:
    """주민 표시(§4.4) — 주소 계약 이름이 있으면 그것, 없으면 reason 보존 + 여울 표시 문자열."""
    reason = result.get("reason")
    if reason is None:
        return {"address_name": None, "reason": None, "ko": None, "en": None}
    ko, en = DISPLAY.get(reason, (None, None))
    return {"address_name": ADDRESS_NAME[reason], "reason": reason, "ko": ko, "en": en}


# ── 연락 정책(§8, 전화번호부 v0.3 제안) ──────────────────────────────────────

def contact_policy_problems(policy, *, known_channels) -> list:
    """C2가 정한 모양: accepts·from 필수, channel·note 선택(보고서 C2 결정)."""
    if not (isinstance(policy, dict) and {"accepts", "from"} <= set(policy)
            <= {"accepts", "from", "channel", "note"}):
        return ["contact_policy 키 집합(accepts·from 필수, channel·note 선택)"]
    out = []
    acc = policy["accepts"]
    if not isinstance(acc, list):
        out.append("accepts는 목록")
    else:
        for a in acc:
            if not (a == "letters" or (isinstance(a, str) and a.startswith("board:")
                                       and _BOARD_ID.fullmatch(a[len("board:"):]))):
                out.append(f"모르는 표면: {a!r}")
    if not isinstance(policy["from"], list):
        out.append("from은 목록")
    else:
        for p in policy["from"]:
            out += pattern_problems(p)
    if "channel" in policy:
        ch = policy["channel"]
        if not (isinstance(ch, str) and _CHANNEL.fullmatch(ch)):
            out.append("channel 이름 규칙")
        elif ch not in known_channels:
            out.append(f"모르는 채널: {ch!r}")
    if "note" in policy:
        n = policy["note"]
        if not isinstance(n, str):
            out.append("note는 문자열")
        else:
            if len(n) > _NOTE_MAX:
                out.append(f"note가 {_NOTE_MAX} 코드 포인트를 넘는다")
            if _has_contact_means(n):
                out.append("note에 연락 수단(주소·링크·연락처)")
    return out


def policy_admits(profile: dict, letter_body: dict, surface: str, *, known_channels) -> tuple:
    """받는 이 프로필의 정책이 이 편지를 받나. (허용, 사유) — 부재·빈 목록·오형식은 허가가 아니다."""
    subj, to = profile["subject"], letter_body["to"]
    if (subj["lab"], subj["id"]) != (to["lab_id"], to["to_id"]):
        return False, "policy_subject_mismatch"
    if subj["epoch"] != to["to_epoch"]:
        return False, "policy_epoch_mismatch"
    pol = profile.get("profile", {}).get("contact_policy")
    if pol is None:
        return False, "no_policy"
    if contact_policy_problems(pol, known_channels=known_channels):
        return False, "policy_invalid"
    if surface not in pol["accepts"]:
        return False, "surface_not_accepted"
    a = letter_body["author"]
    if not any(pattern_matches(p, a["lab"], a["id"], a["epoch"]) for p in pol["from"]):
        return False, "sender_not_accepted"
    return True, None


def public_projection(row: dict) -> dict:
    """contact와 contact_policy를 항상 제거한다. 남으면 예외(fail-closed)."""
    prof = {k: v for k, v in row["profile"].items() if k not in ("contact", "contact_policy")}
    out = {"subject": row["subject"], "profile": prof}
    if projection_problems(out):
        raise AssertionError("public projection에 연락 필드가 남았다")
    return out


def projection_problems(projected: dict) -> list:
    return [f"{k}가 남았다" for k in ("contact", "contact_policy")
            if k in projected.get("profile", {})]


# ── 빈도 관측(§4.3) ──────────────────────────────────────────────────────────

def rate_exceeded(prior_times: list, now: str, rate: dict) -> bool:
    """받는 쪽 시계로 (now - per_seconds, now] 창 안의 이전 편지 수가 max 이상이면 초과 관측.
    관측일 뿐 저자성 등급을 바꾸지 않는다."""
    now_dt = parse_time(now)
    n = sum(1 for t in prior_times
            if 0 <= (now_dt - parse_time(t)).total_seconds() < rate["per_seconds"])
    return n >= rate["max"]
