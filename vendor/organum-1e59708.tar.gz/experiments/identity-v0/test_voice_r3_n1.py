"""발화 키 r3 철회 끝 좌표 n → n+1 회귀 벡터 (크리처 자격 증명 delta v0.2 동결판 §5, Orin 045·046).

바꾼 것: `VoiceRegistry`가 seq n의 `voice.revoked`를 `revoked_at = n+1`로 저장한다(제품 C2와 같다).
주장은 좁다(Orin 046). **실제로 admit된 발화의 이력 등급**은 바뀌지 않는다 — 한 좌표에 사건이 하나라
발화는 자기 키를 철회하는 사건과 같은 좌표를 가질 수 없기 때문이다. `valid_at(…, n)`처럼 철회 좌표
자체를 묻는 질의는 달라진다. 이 파일은 두 규칙(새 n+1, 옛 n)을 **같은 원장**에 대조한다.
"""

import hashlib
import random
import sys
from pathlib import Path

import pytest

SRC = Path(__file__).resolve().parents[2] / "src"
sys.path.insert(0, str(SRC))
sys.path.insert(0, str(Path(__file__).parent))
from organum import hub_envelope as he  # noqa: E402
from organum import hub_log as hl  # noqa: E402
from organum import schnorr_pure as sp  # noqa: E402
import voice  # noqa: E402
import voice_r3 as r3  # noqa: E402

LAB_SEED = hashlib.sha256(b"r3n1-lab").digest()
HUB_SEED = hashlib.sha256(b"r3n1-hub-receipt").digest()
LAB_PUB = sp.public_key(LAB_SEED).hex()
CODY = {"lab": "lab:organum", "id": "Cody", "epoch": 1}
SIGNER = {"id": "lab:organum", "key_id": "k1", "key_epoch": 1}
CFG = {"machine": "m-r3n1", "target": {"lab_id": "lab:organum", "to_id": "Cody",
                                       "to_epoch": 1}}
CLAIMS = {"claims": {"core:artifact.frozen": {
    "act_class": "self_attesting", "subject_types": ["artifact"],
    "ordering_levels": ["emission"], "capture_required": False,
    "revocation_authority": "same_signer"}}}


class OldRegistry(r3.VoiceRegistry):
    """종전 r3 규칙(철회 끝 = n) — 대조용."""
    REVOKE_END_OFFSET = 0


class World:
    """in-process hub 하나 위의 원장. 사건은 전부 실제 admit 경로를 지난다."""

    def __init__(self):
        keys = he.KeyRegistry()
        keys.register(LAB_PUB, signer_id="lab:organum", key_id="k1", key_epoch=1)
        self.hub = he.HubIndex(
            key_registry=keys,
            claim_registry=he.ClaimRegistry(CLAIMS, expected_sha256=he.canonical_sha(CLAIMS)),
            log=hl.TransparencyLog(), receipt_seckey=HUB_SEED,
            source_domain="lab:organum/hub")
        self.anchor = {"lab_pubkeys": {"lab:organum": LAB_PUB},
                       "receipt_pubkey": sp.public_key(HUB_SEED).hex(),
                       "source_domain": "lab:organum/hub"}
        self.timeline = []              # (seq, bundle)
        self.attestations = {}          # voice seed → 가장 최근 보증 bundle
        self.speeches = []              # (seq, speech bytes, sig, att bundle, speech bundle)

    def _admit(self, body_bytes, locator):
        b = r3.admit_with_bundle(self.hub, LAB_SEED, CFG, SIGNER, body_bytes, locator)
        v = r3.verify_bundle(b, self.anchor)
        assert v.get("ok"), v
        self.timeline.append((v["seq"], b))
        return b, v["seq"]

    def attest(self, voice_seed, tag):
        vpub = voice.mint_voice(voice_seed)
        decl = r3.make_declaration(r3.ATTEST_KIND, "lab:organum", CODY, vpub,
                                   at=f"2026-09-28T00:00:{len(self.timeline):02d}Z")
        b, seq = self._admit(r3._canon(dict(decl, note=tag)), f"file://att-{tag}.json")
        self.attestations[voice_seed] = b
        return seq

    def revoke(self, voice_seed, tag):
        vpub = voice.mint_voice(voice_seed)
        decl = r3.make_declaration(r3.REVOKE_KIND, "lab:organum", CODY, vpub,
                                   at=f"2026-09-28T00:00:{len(self.timeline):02d}Z")
        _, seq = self._admit(r3._canon(dict(decl, note=tag)), f"file://rev-{tag}.json")
        return seq

    def speak(self, voice_seed, tag):
        """발화 — 가장 최근 보증 bundle을 사슬로 든다(없으면 발화하지 않는다)."""
        speech = f"r3n1 발화 {tag}".encode()
        sig = voice.sign_speech(voice_seed, speech)
        b, seq = self._admit(speech, f"file://speech-{tag}.md")
        self.speeches.append((seq, speech, sig, self.attestations[voice_seed], b))
        return seq

    def grades(self, registry_cls):
        reg = registry_cls()
        for _, b in sorted(self.timeline, key=lambda e: e[0]):
            assert reg.ingest_verified(reg.attach_consistency(b, self.hub.log), self.anchor) == []
        out = {}
        for seq, speech, sig, att_b, sp_b in self.speeches:
            g = r3.grade_r3(speech, CODY, sig, att_b, sp_b, self.anchor, reg)
            out[seq] = g["grade"]
        return out, reg


V1 = hashlib.sha256(b"r3n1-voice-1").digest()
V2 = hashlib.sha256(b"r3n1-voice-2").digest()


def test_경계_사례_넷의_등급과_두_규칙의_일치():
    w = World()
    a1 = w.attest(V1, "a1")                 # 보증 좌표 a1
    s1 = w.speak(V1, "s1")                  # 보증 직후(a1+1): 유효 시작 좌표
    s2 = w.speak(V1, "s2")                  # 철회 직전
    r1 = w.revoke(V1, "r1")                 # 철회 좌표 r1
    s3 = w.speak(V1, "s3")                  # 철회 직후(r1+1)
    a2 = w.attest(V1, "a2")                 # 같은 키 재보증
    s4 = w.speak(V1, "s4")                  # 재보증 뒤
    assert (s1, s2, r1, s3, a2, s4) == (a1 + 1, a1 + 2, a1 + 3, a1 + 4, a1 + 5, a1 + 6)

    new, reg_new = w.grades(r3.VoiceRegistry)
    old, reg_old = w.grades(OldRegistry)
    assert new == old                                       # admit된 발화의 등급은 같다
    assert [new[s] for s in (s1, s2, s3, s4)] == ["verified", "verified", "rejected", "verified"]

    vpub = voice.mint_voice(V1)
    # 저장 좌표: 새 규칙은 r1+1, 옛 규칙은 r1
    assert [row["revoked_at"] for row in reg_new._intervals[(("lab:organum", "Cody", 1), vpub)]] \
        == [r1 + 1, None]
    assert [row["revoked_at"] for row in reg_old._intervals[(("lab:organum", "Cody", 1), vpub)]] \
        == [r1, None]
    # 좁은 주장의 경계: 철회 좌표 자체를 묻는 질의만 다르다(그 좌표에는 발화가 없다)
    assert reg_new.valid_at(CODY, vpub, r1) is True
    assert reg_old.valid_at(CODY, vpub, r1) is False
    for q in range(1, a2 + 1):
        if q != r1:
            assert reg_new.valid_at(CODY, vpub, q) == reg_old.valid_at(CODY, vpub, q), q


def test_보증_전_발화는_두_규칙_모두_rejected():
    w = World()
    w.attest(V2, "pre")                     # V2 보증(발화 사슬용)
    w.revoke(V2, "pre-r")
    s0 = w.speak(V2, "after-revoke")        # 철회 뒤 발화
    new, _ = w.grades(r3.VoiceRegistry)
    old, _ = w.grades(OldRegistry)
    assert new == old and new[s0] == "rejected"


@pytest.mark.parametrize("seed", range(6))
def test_무작위_원장에서_두_규칙의_발화_등급이_같다(seed):
    """보증·철회·재보증·발화를 섞은 원장 — admit된 모든 발화의 등급이 두 규칙에서 같다."""
    rnd = random.Random(1000 + seed)
    w = World()
    voices = [V1, V2]
    attested = {V1: False, V2: False}
    ever = {V1: False, V2: False}
    for i in range(14):
        v = rnd.choice(voices)
        op = rnd.choice(["attest", "revoke", "speak", "speak"])
        if op == "attest" and not attested[v]:
            w.attest(v, f"{seed}-{i}")
            attested[v] = ever[v] = True
        elif op == "revoke" and attested[v]:
            w.revoke(v, f"{seed}-{i}")
            attested[v] = False
        elif ever[v]:
            w.speak(v, f"{seed}-{i}")
    new, _ = w.grades(r3.VoiceRegistry)
    old, _ = w.grades(OldRegistry)
    assert new == old
    assert len(new) == len(w.speeches)
