"""trust snapshot v0 참조 검증기 — **v0.5 교정판**을 코드로 옮긴 것.

제품이 아니다(experiments/). 목적은 계약의 자기 검증이다. 합성 fixture 벡터를 이 검증기로
돌려 계약 문구가 스스로 모순 없이 판정하는지 본다. 기대값은 벡터 생성기가 계약 문구에서
손으로 적은 것이고, 이 모듈을 불러 만들지 않는다(순환 금지).

v0.4 동결판(5bf7cac)의 실패 기록과 그때의 판정은 fixture r1(dev b18088d)에 남아 있다.
v0.5가 바꾼 것(이음 131 합의):
- F1 판정 좌표 T+1 — ① 좌표 범위·활성 정의·§4.3 key_revoked를 한 묶음으로.
- F2 prev 대조 — 저장 id 항목 우선, 없으면 (크기, root)로. 같은 크기 다른 root는 fork.
- F3 T ≥ 1, prev 항목 크기 ≥ 1.
- W2 source_domain을 고정값과 정확히 대조하고, 파생 운영 lab이 issuer.id여야 한다.
- I6 상태가 ok가 아닐 때 받은 판은 채택·상태 전이 없이 관측 기록만 남긴다.

원칙:
- 무상태. 저장소 읽기·쓰기는 호출자(서비스) 몫이다.
- 새 암호 0. BIP-340(schnorr_pure)·정규화 bytes(hub_envelope)·RFC 9162(hub_log) 재사용.
- 예외 대신 판정. 공개 입력의 모양이 틀리면 snapshot_invalid·schema_invalid로 수렴한다.
"""

from __future__ import annotations

import hashlib
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

_SRC = Path(__file__).resolve().parents[2] / "src"
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))
from organum import hub_envelope as he  # noqa: E402
from organum import hub_log as hl  # noqa: E402
from organum import schnorr_pure as sp  # noqa: E402

SCHEMA = "organum-hub/trust-snapshot/v0"
CONTRACT_VERSION = "v0.5"

OPERATING_EVENTS = ("snapshot_invalid", "snapshot_fork", "snapshot_rollback",
                    "snapshot_gap", "snapshot_expired", "trust_state_lost")
BOOT_STATUSES = ("ok", "unreachable", "lost", "uninitialized")   # ok 아니면 운영 경보
RETRY = {"trust_unavailable": "wait", "schema_invalid": "never",
         "body_mismatch": "never", "unknown_signer": "after_curation",
         "signature_invalid": "never", "key_revoked": "never"}

_PINNED_KEYS = {"id", "key_id", "key_epoch", "pubkey", "source_domain"}
_BODY_KEYS = {"schema", "issuer", "source_domain", "anchor", "anchor_since",
              "issued_at", "not_after", "audit", "bindings", "prev"}
_BINDING_KEYS = {"signer_id", "key_id", "key_epoch", "pubkey", "valid_from_seq",
                 "revoked_at_seq", "origin"}
_PREV_KEYS = {"snapshot_id", "tree_size", "root", "consistency"}
_STATE_KEYS = {"snapshot", "adopted_at", "anchor_start", "effective_not_after"}
_ORIGIN_KINDS = ("bootstrap", "signer.introduced", "key.rotated")
_HEX = set("0123456789abcdef")


# ── 작은 도구 ────────────────────────────────────────────────────────────────

def parse_time(v) -> datetime | None:
    """RFC3339 UTC-Z(hub 봉투와 같은 술어) → aware datetime. 형식 밖이면 None."""
    if not he._is_rfc3339_z(v):
        return None
    body = v[:-1]
    fmt = "%Y-%m-%dT%H:%M:%S.%f" if "." in body else "%Y-%m-%dT%H:%M:%S"
    return datetime.strptime(body, fmt).replace(tzinfo=timezone.utc)


def fmt_time(dt: datetime) -> str:
    s = dt.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S")
    if dt.microsecond:
        s += "." + f"{dt.microsecond:06d}".rstrip("0")
    return s + "Z"


def _is_hex(v, nbytes: int) -> bool:
    return isinstance(v, str) and len(v) == 2 * nbytes and set(v) <= _HEX


def _is_int(v, lo: int = 0) -> bool:
    return type(v) is int and v >= lo


def snapshot_id(snap: dict) -> str:
    """§2.1: sha256(canonical_bytes(body)) — 서명 대상 digest 그대로."""
    return he.canonical_sha(snap["body"])


def _sig_ok(sig_hex, digest: bytes, pub_hex: str) -> bool:
    if not (_is_hex(sig_hex, 64) and _is_hex(pub_hex, 32)):
        return False
    return sp.verify(bytes.fromhex(sig_hex), digest, bytes.fromhex(pub_hex))


def _tuple(b: dict) -> tuple:
    return (b["signer_id"], b["key_id"], b["key_epoch"])


def _active(b: dict) -> bool:
    """§2 활성 = revoked_at_seq가 null. 판정 좌표 T+1에서 valid_from_seq ≤ T+1은 ①이 보장한다."""
    return b["revoked_at_seq"] is None


def operating_lab(source_domain: str, bindings: list) -> str | None:
    """source_domain에서 운영 lab을 파생한다 — hub 도입 권한 파생과 같은 규칙(Orin I1 r3).

    첫 조각이 `lab:` 문법이면 그것. bare name n이면 bindings에 `lab:n`의 bootstrap 결속이
    있을 때만 `lab:n`. 어느 쪽도 아니면 None."""
    head = source_domain.split("/", 1)[0]
    if he._LAB_ID.fullmatch(head):
        return head
    cand = f"lab:{head}"
    if he._LAB_ID.fullmatch(cand) and any(
            b["signer_id"] == cand and b["valid_from_seq"] == 0
            and b["origin"]["kind"] == "bootstrap" for b in bindings):
        return cand
    return None


# ── §4.1 ① 문서 내부 계약 ────────────────────────────────────────────────────

def doc_problems(snap, *, pinned: dict, now: datetime, skew: int) -> list:
    """문서와 고정값만으로 판정하는 것 전부. 빈 목록이면 ① 통과.

    검사하지 않는 것(§4.1): bindings가 기준점 T의 전체 registry와 같은지. 원장 없이는
    알 수 없다 — 발급자 서명·파생 구현·원장 재생 감사의 책임(§8)."""
    if set(pinned) != _PINNED_KEYS:
        return ["서비스 고정값은 id·key_id·key_epoch·pubkey·source_domain 다섯"]
    if not (isinstance(snap, dict) and set(snap) == {"body", "signature"}):
        return ["문서 최상위는 {body, signature}"]
    b = snap["body"]
    if not (isinstance(b, dict) and set(b) == _BODY_KEYS):
        return ["body 키 집합이 계약과 다름"]
    try:
        raw = he.canonical_bytes(b)
    except he.HubEnvelopeError as e:
        return [f"정규화 불가: {e}"]
    p = []
    if b["schema"] != SCHEMA:
        p.append("schema가 organum-hub/trust-snapshot/v0 아님")
    iss = b["issuer"]
    if not (isinstance(iss, dict) and set(iss) == {"id", "key_id", "key_epoch"}):
        return p + ["issuer 모양"]
    if (iss["id"], iss["key_id"], iss["key_epoch"]) != \
            (pinned["id"], pinned["key_id"], pinned["key_epoch"]):
        p.append("issuer가 고정 발급자와 다름")
    if b["source_domain"] != pinned["source_domain"]:
        p.append("source_domain이 고정값과 다름")
    if not _sig_ok(snap["signature"], hashlib.sha256(raw).digest(), pinned["pubkey"]):
        p.append("스냅샷 서명이 고정 키로 서지 않음")

    # 기준점 — 서명된 트리 헤드 원문(§2.1)
    T = None
    a = b["anchor"]
    if not (isinstance(a, dict) and set(a) == {"body", "signature"}
            and isinstance(a["body"], dict)
            and set(a["body"]) == {"schema", "tree_size", "root"}):
        p.append("anchor 모양")
    else:
        if not _is_int(a["body"]["tree_size"], 1):
            p.append("anchor.tree_size는 1 이상 정수(T ≥ 1)")
        else:
            T = a["body"]["tree_size"]
        if not _is_hex(a["body"]["root"], 32):
            p.append("anchor.root hex64 아님")
        if not hl.verify_tree_head(a, bytes.fromhex(pinned["pubkey"])):
            p.append("기준점 트리 헤드 서명이 고정 키로 서지 않음")

    # 시각(§4.1 ①, §5)
    since, issued, nafter = (parse_time(b[k]) for k in
                             ("anchor_since", "issued_at", "not_after"))
    if None in (since, issued, nafter):
        p.append("시각 형식(RFC3339 Z)")
    else:
        if issued - now > timedelta(seconds=skew):
            p.append("issued_at이 서비스 시각보다 허용 오차 넘게 미래")
        if not nafter > issued:
            p.append("not_after ≤ issued_at")
        if not since <= issued:
            p.append("anchor_since > issued_at")

    if b["audit"] == "logged":
        p.append("audit=logged — 결속별 증거의 모양이 정해지기 전까지 거부(첫 shadow는 table)")
    elif b["audit"] != "table":
        p.append("audit는 table 또는 logged")

    # bindings
    bs = b["bindings"]
    shape_ok = isinstance(bs, list)
    if shape_ok:
        for x in bs:
            if not (isinstance(x, dict) and set(x) == _BINDING_KEYS
                    and isinstance(x["origin"], dict)
                    and set(x["origin"]) == {"kind", "seq"}
                    and isinstance(x["signer_id"], str) and isinstance(x["key_id"], str)
                    and _is_int(x["key_epoch"], 1) and _is_hex(x["pubkey"], 32)
                    and _is_int(x["valid_from_seq"])
                    and (x["revoked_at_seq"] is None or _is_int(x["revoked_at_seq"]))
                    and x["origin"]["kind"] in _ORIGIN_KINDS
                    and _is_int(x["origin"]["seq"])):
                shape_ok = False
                break
    if not shape_ok:
        p.append("bindings 모양")
    else:
        tuples = [_tuple(x) for x in bs]
        if tuples != sorted(tuples) or len(set(tuples)) != len(tuples):
            p.append("bindings가 (signer_id, key_id, key_epoch) 사전순이 아니거나 중복")
        if len({x["pubkey"] for x in bs}) != len(bs):
            p.append("bindings pubkey 중복")
        if isinstance(b["source_domain"], str) and \
                operating_lab(b["source_domain"], bs) != iss["id"]:
            p.append("source_domain에서 파생한 운영 lab이 issuer.id와 다름")
        if T is not None:
            # 판정 좌표 T+1: T에서 일어난 lifecycle 전이는 좌표 T+1로 나타난다(원장 규칙)
            for x in bs:
                vf, rv, og = x["valid_from_seq"], x["revoked_at_seq"], x["origin"]
                where = "/".join(map(str, _tuple(x)))
                if vf > T + 1:
                    p.append(f"valid_from_seq > T+1: {where}")
                if rv is not None and not vf <= rv <= T + 1:
                    p.append(f"revoked_at_seq가 [valid_from_seq, T+1] 밖: {where}")
                if og["seq"] > T:
                    p.append(f"origin.seq > T: {where}")
                if og["kind"] == "bootstrap":
                    if vf != 0 or og["seq"] != 0:
                        p.append(f"bootstrap 결속은 valid_from_seq·origin.seq 둘 다 0: {where}")
                elif og["seq"] < 1 or vf != og["seq"] + 1:
                    p.append(f"valid_from_seq ≠ origin.seq + 1: {where}")
            own = [x for x in bs if _tuple(x) ==
                   (iss["id"], iss["key_id"], iss["key_epoch"])]
            if not own or not _active(own[0]) or own[0]["pubkey"] != pinned["pubkey"]:
                p.append("발급자 자신의 결속이 없거나 비활성이거나 고정 키와 다름")

    # prev
    pv = b["prev"]
    if not isinstance(pv, list) or not all(
            isinstance(e, dict) and set(e) == _PREV_KEYS
            and _is_hex(e["snapshot_id"], 32) and _is_int(e["tree_size"], 1)
            and _is_hex(e["root"], 32) and isinstance(e["consistency"], list)
            and all(_is_hex(h, 32) for h in e["consistency"]) for e in pv):
        p.append("prev 모양(항목 tree_size ≥ 1 포함)")
    else:
        ids = [e["snapshot_id"] for e in pv]
        if len(set(ids)) != len(ids):
            p.append("prev snapshot_id 중복")
        if T is not None and any(not e["tree_size"] < T for e in pv):
            p.append("prev 항목의 tree_size ≥ T")
    return p


# ── §4.2 상한 ────────────────────────────────────────────────────────────────

def effective_not_after(body: dict, anchor_start: datetime, params: dict) -> datetime:
    """min(not_after, issued_at + service_max_ttl, anchor_start + anchor_max_age)."""
    return min(parse_time(body["not_after"]),
               parse_time(body["issued_at"]) + timedelta(seconds=params["service_max_ttl"]),
               anchor_start + timedelta(seconds=params["anchor_max_age"]))


def make_state(snap: dict, *, anchor_start: datetime, now: datetime, params: dict) -> dict:
    return {"snapshot": snap, "adopted_at": fmt_time(now),
            "anchor_start": fmt_time(anchor_start),
            "effective_not_after": fmt_time(
                effective_not_after(snap["body"], anchor_start, params))}


def usable(state, now: datetime) -> bool:
    """③ 쓸 판 — `effective_not_after` **전**일 때만(now < ena, 반열림)."""
    return state is not None and now < parse_time(state["effective_not_after"])


# ── §4.1 ② 저장 상태와의 대조 ────────────────────────────────────────────────

def _compare(stored: dict, new: dict) -> tuple:
    """(판정, 이유). 판정 = refresh | extend | snapshot_rollback | snapshot_fork | snapshot_gap."""
    sb, nb = stored["body"], new["body"]
    sT, sroot = sb["anchor"]["body"]["tree_size"], sb["anchor"]["body"]["root"]
    nT, nroot = nb["anchor"]["body"]["tree_size"], nb["anchor"]["body"]["root"]
    if nT < sT:
        return "snapshot_rollback", "새 T < 저장 T"
    if nT == sT:
        if nroot != sroot:
            return "snapshot_fork", "같은 T에 다른 root"
        if he.canonical_bytes({"b": nb["bindings"]}) != he.canonical_bytes({"b": sb["bindings"]}):
            return "snapshot_fork", "같은 T·root에 다른 bindings"
        return "refresh", "같은 T 재발급"
    sid = snapshot_id(stored)
    # 저장 id 항목이 있으면 그 T·root를 먼저 정확히 대조한다
    if any((e["tree_size"], e["root"]) != (sT, sroot)
           for e in nb["prev"] if e["snapshot_id"] == sid):
        return "snapshot_fork", "prev의 저장 id 항목이 저장 T·root와 다름"
    # 대조 키는 (크기, root) — 같은 크기에 다른 root가 하나라도 있으면 갈라짐
    cands = [e for e in nb["prev"] if e["tree_size"] == sT]
    if any(e["root"] != sroot for e in cands):
        return "snapshot_fork", "prev가 저장 T에 다른 root를 적음(같은 크기 두 root)"
    if not cands:
        return "snapshot_gap", "prev에 저장 T 크기 항목이 없음"
    for e in cands:
        # 신뢰 근거는 prev의 root가 아니라 **서비스가 저장한 root**다.
        if not hl.verify_consistency(sT, bytes.fromhex(sroot), nT, bytes.fromhex(nroot),
                                     [bytes.fromhex(h) for h in e["consistency"]]):
            return "snapshot_fork", "일관성 증명이 저장 root에서 새 root로 서지 않음"
    return "extend", "저장 기준점에서 새 기준점으로 확장 확인(로그 확장만 — 표 동일성·완전성 아님)"


def verify_snapshot(snap, *, last, now: str, pinned: dict, params: dict) -> dict:
    """§4.1 ①②③. 반환 {events, adopted, state, reason, problems}.

    `last`가 없으면 채택하지 않는다 — 첫 채택은 운영자 재기준화로만(§4.2).
    ①②를 모두 통과한 새 판이 도착 시 이미 만료면 채택하고 곧바로 닫는다(I1)."""
    now_dt = parse_time(now)
    out = {"events": [], "adopted": False, "state": last, "reason": None, "problems": []}
    probs = doc_problems(snap, pinned=pinned, now=now_dt, skew=params["skew"])
    if probs:
        out["events"].append("snapshot_invalid")
        out["problems"] = probs
    elif last is None:
        out["reason"] = "저장 상태 없음 — 첫 채택은 재기준화로만(§4.2)"
    else:
        verdict, why = _compare(last["snapshot"], snap)
        out["reason"] = why
        since = parse_time(snap["body"]["anchor_since"])
        if verdict == "refresh":
            # anchor_start는 이른 쪽으로만 — 재발급은 기준점 수명을 늘리지 못한다.
            start = min(parse_time(last["anchor_start"]), since)
        elif verdict == "extend":
            start = min(now_dt, since)
        else:
            start = None
            out["events"].append(verdict)
        if start is not None:
            out["adopted"] = True
            out["state"] = make_state(snap, anchor_start=start, now=now_dt, params=params)
    if not usable(out["state"], now_dt):
        out["events"].append("snapshot_expired")
    return out


def check(state, *, now: str) -> list:
    """③ 쓸 판 확인만(주기 점검)."""
    return [] if usable(state, parse_time(now)) else ["snapshot_expired"]


def observe_ignored(snap, *, status: str, now: str) -> dict:
    """I6: 신뢰 상태가 ok가 아닐 때 받은 판 — 채택·상태 전이 없이 관측만 남긴다."""
    sid = T = None
    try:
        sid = snapshot_id(snap)
        T = snap["body"]["anchor"]["body"]["tree_size"]
    except (KeyError, TypeError, he.HubEnvelopeError):
        pass
    return {"kind": "trust.input_ignored", "status": status, "snapshot_id": sid,
            "tree_size": T, "at": now}


# ── §4.2 저장소 판별·재기준화 ────────────────────────────────────────────────

def classify_store(store: dict, *, pinned: dict, params: dict) -> dict:
    """닿는 저장소의 내용을 가른다. 닿지 않음은 호출자가 판별한다(저장소 장애).

    반환 status: ok | lost | uninitialized. ok가 아니면 운영 경보다. 상태는 있는데
    표지가 없으면 유실로 본다(I3)."""
    marker, last = store.get("marker"), store.get("last_accepted")
    if marker is None and last is None:
        return {"status": "uninitialized", "events": [], "state": None,
                "reason": "저장소 비어 있음 — 처음인지 지워졌는지 서비스가 가를 수 없다"}
    lost = lambda why: {"status": "lost", "events": ["trust_state_lost"],  # noqa: E731
                        "state": None, "reason": why}
    if last is None:
        return lost("표지는 있는데 last_accepted가 없음")
    if marker is None:
        return lost("last_accepted는 있는데 표지가 없음(I3)")
    if not (isinstance(last, dict) and set(last) == _STATE_KEYS):
        return lost("last_accepted 깨짐(필드 누락 — anchor_start 유실 포함)")
    adopted = parse_time(last["adopted_at"])
    if adopted is None or None in (parse_time(last["anchor_start"]),
                                   parse_time(last["effective_not_after"])):
        return lost("last_accepted 시각 깨짐")
    if doc_problems(last["snapshot"], pinned=pinned, now=adopted, skew=params["skew"]):
        return lost("저장된 판이 ①을 통과하지 못함(깨짐)")
    return {"status": "ok", "events": [], "state": last, "reason": None}


def rebaseline(snap, *, declared: dict, reason: str, operator: str, now: str,
               pinned: dict, params: dict, prior_snapshot_id=None) -> dict:
    """운영자의 감사 가능한 재기준화(§4.2). 반환 ok면 state·marker·audit·events."""
    now_dt = parse_time(now)
    probs = doc_problems(snap, pinned=pinned, now=now_dt, skew=params["skew"])
    if reason not in ("genesis", "recovery"):
        probs.append("reason은 genesis 또는 recovery")
    if not (isinstance(operator, str) and operator):
        probs.append("operator 필요")
    if probs:
        return {"ok": False, "problems": probs}
    sid = snapshot_id(snap)
    ab = snap["body"]["anchor"]["body"]
    if (declared.get("snapshot_id"), declared.get("tree_size"), declared.get("root")) != \
            (sid, ab["tree_size"], ab["root"]):
        return {"ok": False, "problems": ["선언한 id·T·root가 제공된 판과 다름"]}
    start = min(now_dt, parse_time(snap["body"]["anchor_since"]))
    state = make_state(snap, anchor_start=start, now=now_dt, params=params)
    return {"ok": True, "state": state,
            "marker": {"kind": "trust.initialized", "issuer": pinned["id"],
                       "first_snapshot_id": sid},
            "audit": {"kind": "trust.rebaselined", "reason": reason,
                      "prior_snapshot_id": prior_snapshot_id, "snapshot_id": sid,
                      "tree_size": ab["tree_size"], "root": ab["root"],
                      "operator": operator, "at": now},
            "events": [] if usable(state, now_dt) else ["snapshot_expired"]}


# ── §4.3 쓰기 판정 ───────────────────────────────────────────────────────────

def _err(code: str, sid, signer, **extra) -> dict:
    return {"ok": False, "code": code, "retry": RETRY[code], "snapshot_id": sid,
            "signer": signer if isinstance(signer, dict) else None, **extra}


def verify_write(envelope, sig_hex, body, *, state, now: str) -> dict:
    """글쓴이 오류 순서 0–5(§4.3). 6(not_permitted)은 계약 밖.

    판 문서가 아니라 저장 상태를 받는다(W1) — 판정에 anchor_start가 든
    effective_not_after가 필요하다."""
    now_dt = parse_time(now)
    signer = envelope.get("signer") if isinstance(envelope, dict) else None
    if not usable(state, now_dt):
        return _err("trust_unavailable", None, signer)
    snap = state["snapshot"]
    sid, sb = snapshot_id(snap), snap["body"]
    T = sb["anchor"]["body"]["tree_size"]
    try:
        if not isinstance(envelope, dict):
            raise TypeError("봉투가 object가 아님")
        raw = he.canonical_bytes(envelope)
        probs = (he.validate_envelope(envelope) if isinstance(envelope.get("payload"), dict)
                 else ["payload가 object가 아님"])
    except (he.HubEnvelopeError, TypeError, KeyError, AttributeError, ValueError) as e:
        raw, probs = None, [f"봉투 모양: {e}"]
    if probs:
        return _err("schema_invalid", sid, signer, problems=probs)
    # I5: body_sha256이 있으면 본문이 있어야 하고 digest가 같아야 한다
    want = envelope["payload"].get("body_sha256")
    if want is not None and (body is None or hashlib.sha256(body).hexdigest() != want):
        return _err("body_mismatch", sid, signer)
    tup = (signer["id"], signer["key_id"], signer["key_epoch"])
    b = next((x for x in sb["bindings"] if _tuple(x) == tup), None)
    if b is None:
        return _err("unknown_signer", sid, signer)
    if not _sig_ok(sig_hex, hashlib.sha256(raw).digest(), b["pubkey"]):
        return _err("signature_invalid", sid, signer)
    if b["revoked_at_seq"] is not None:          # 판정 좌표 T+1(F1)
        return _err("key_revoked", sid, signer, revoked_at_seq=b["revoked_at_seq"])
    return {"ok": True, "accepted_under": {
        "issuer": sb["issuer"]["id"], "snapshot_id": sid, "tree_size": T,
        "root": sb["anchor"]["body"]["root"], "received_at": now}}
