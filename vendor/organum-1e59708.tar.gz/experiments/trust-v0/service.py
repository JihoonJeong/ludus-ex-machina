"""벡터 실행기 — 영속 저장소를 가진 최소 서비스 흉내(§4.2의 "서비스 몫").

`trust.py`는 무상태 판정기다. 이 모듈은 저장소(dict)와 도달 가능 여부를 들고, 벡터의
단계(op)를 순서대로 적용한다. 다른 언어로 이 벡터를 돌리는 쪽은 README의 단계 의미를
따르면 된다 — 이 파일은 그 의미의 참조 구현이다.
"""

from __future__ import annotations

import copy

import trust


class Service:
    def __init__(self, *, pinned: dict, params: dict):
        self.pinned, self.params = pinned, params
        self.store: dict = {}          # 영속: marker · last_accepted · audit · observations
        self.observations: list = []   # 무시된 입력의 관측(I6) — 저장소가 닿지 않아도 남긴다
        self.reachable = True
        self.status = None             # boot 전
        self.state = None

    # ── 기동 ──
    def boot(self) -> dict:
        if not self.reachable:
            self.status, self.state = "unreachable", None
            return {"status": "unreachable", "events": []}
        r = trust.classify_store(self.store, pinned=self.pinned, params=self.params)
        self.status, self.state = r["status"], r["state"]
        return {"status": r["status"], "events": r["events"]}

    # ── 새 판 ──
    def offer(self, snap: dict, now: str) -> dict:
        if self.status != "ok":
            obs = trust.observe_ignored(snap, status=self.status, now=now)
            self.observations.append(obs)
            if self.reachable:
                self.store.setdefault("observations", []).append(obs)
            return {"events": [], "adopted": False, "ignored": self.status, "observed": obs}
        r = trust.verify_snapshot(snap, last=self.state, now=now, pinned=self.pinned,
                                  params=self.params)
        if r["adopted"]:
            self.state = r["state"]
            self.store["last_accepted"] = copy.deepcopy(r["state"])
        return self._summary(r["events"], r["adopted"])

    def check(self, now: str) -> dict:
        if self.status != "ok":
            return {"events": [], "ignored": self.status}
        return {"events": trust.check(self.state, now=now)}

    # ── 쓰기 ──
    def write(self, envelope, sig_hex, body, now: str) -> dict:
        if self.status != "ok":
            return trust._err("trust_unavailable", None,
                              envelope.get("signer") if isinstance(envelope, dict) else None)
        return trust.verify_write(envelope, sig_hex, body, state=self.state, now=now)

    # ── 재기준화 ──
    def rebaseline(self, snap, *, declared, reason, operator, now) -> dict:
        if not self.reachable:
            return {"ok": False, "problems": ["저장소 닿지 않음"]}
        prior = trust.snapshot_id(self.state["snapshot"]) if self.state else None
        r = trust.rebaseline(snap, declared=declared, reason=reason, operator=operator,
                             now=now, pinned=self.pinned, params=self.params,
                             prior_snapshot_id=prior)
        if not r["ok"]:
            return r
        self.store["last_accepted"] = copy.deepcopy(r["state"])
        self.store.setdefault("marker", r["marker"])        # 표지는 첫 채택 때 한 번
        self.store.setdefault("audit", []).append(r["audit"])
        self.state, self.status = r["state"], "ok"
        out = self._summary(r["events"], True)
        out.update(ok=True, audit=r["audit"], marker=self.store["marker"])
        return out

    # ── 저장소 사고(시험용) ──
    def mutate(self, action: str) -> None:
        if action == "unreachable":
            self.reachable = False
        elif action == "reachable":
            self.reachable = True
        elif action == "drop_last_accepted":
            self.store.pop("last_accepted", None)
        elif action == "drop_anchor_start":
            self.store["last_accepted"].pop("anchor_start", None)
        elif action == "drop_marker":
            self.store.pop("marker", None)
        elif action == "corrupt_signature":
            sig = self.store["last_accepted"]["snapshot"]["signature"]
            self.store["last_accepted"]["snapshot"]["signature"] = \
                ("0" if sig[0] != "0" else "1") + sig[1:]
        elif action == "wipe":
            self.store.clear()
        else:
            raise ValueError(f"모르는 저장소 사고: {action}")

    def _summary(self, events, adopted) -> dict:
        out = {"events": list(events), "adopted": adopted}
        if self.state is not None:
            out.update(snapshot_id=trust.snapshot_id(self.state["snapshot"]),
                       anchor_start=self.state["anchor_start"],
                       effective_not_after=self.state["effective_not_after"])
        return out


def run_vector(vec: dict) -> list:
    """벡터 하나를 돌려 단계별 (기대, 실제) 쌍을 돌려준다."""
    svc = Service(pinned=vec["pinned"], params=vec["params"])
    docs, writes = vec.get("documents", {}), vec.get("writes", {})
    results = []
    for i, st in enumerate(vec["steps"]):
        op = st["op"]
        if op == "mutate":
            svc.mutate(st["action"])
            continue
        if op == "boot":
            got = svc.boot()
        elif op == "offer":
            got = svc.offer(docs[st["doc"]], st["now"])
        elif op == "check":
            got = svc.check(st["now"])
        elif op == "write":
            w = writes[st["write"]]
            body = w["body_utf8"].encode("utf-8") if w.get("body_utf8") is not None else None
            got = svc.write(w["envelope"], w["sig"], body, st["now"])
        elif op == "rebaseline":
            got = svc.rebaseline(docs[st["doc"]], declared=st["declared"],
                                 reason=st["reason"], operator=st["operator"], now=st["now"])
        else:
            raise ValueError(f"모르는 op: {op}")
        results.append((i, op, st["expect"], got))
    return results


def subset_match(want, got) -> bool:
    """기대값의 키만 본다(dict는 부분 일치, 그 밖은 같음)."""
    if isinstance(want, dict):
        return isinstance(got, dict) and all(
            k in got and subset_match(v, got[k]) for k, v in want.items())
    return want == got
