"""합성 발급자 — 제품 HubIndex·TransparencyLog·KeyRegistry로 원장을 쌓고 판을 파생한다.

결속표는 손으로 적지 않는다(§10 "hub에서 파생한다"). 원장 재생이 낸 registry와
lifecycle 사건 좌표에서 `bindings`·`origin`을 뽑는다. 그래서 좌표 경계(전이 효력은
사건 좌표의 다음부터)가 제품 규칙 그대로 벡터에 들어간다.

결정론: 고정 seed · 고정 시각 · BIP-340 aux 0 · provenance.platform 고정.
"""

from __future__ import annotations

import copy
import hashlib
import sys
from pathlib import Path

_SRC = Path(__file__).resolve().parents[2] / "src"
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))
from organum import hub_envelope as he  # noqa: E402
from organum import hub_log as hl  # noqa: E402
from organum import hub_ops as ho  # noqa: E402
from organum import schnorr_pure as sp  # noqa: E402

CLAIMS = {"claims": {"core:artifact.frozen": {
    "act_class": "self_attesting", "subject_types": ["artifact"],
    "ordering_levels": ["emission"], "capture_required": False,
    "revocation_authority": "same_signer"}}}
PLATFORM = "linux"


def seed_of(label: str) -> bytes:
    """합성 seed — 라벨에서 결정론 파생. 운영 키가 아니다."""
    return hashlib.sha256(b"organum-trust-v0-fixture/" + label.encode()).digest()


def pub_of(seed: bytes) -> str:
    return sp.public_key(seed).hex()


def _cfg(lab: str) -> dict:
    return {"machine_id": "m-" + hashlib.sha256(lab.encode()).hexdigest()[:16]}


def _envelope(lab, kind, payload, *, key_id, epoch, subject, at) -> dict:
    env = ho.build_envelope(_cfg(lab), kind, payload, signer=lab, key_id=key_id,
                            epoch=epoch, subject=subject, created_at=at)
    env["provenance"]["platform"] = PLATFORM
    return env


def sign_envelope(env: dict, seed: bytes) -> str:
    return sp.sign(hashlib.sha256(he.canonical_bytes(env)).digest(), seed).hex()


class Ledger:
    """발급자 원장. 사건은 제품 admit 경로로만 들어간다."""

    def __init__(self, *, issuer: str, source_domain: str, issuer_seed: bytes):
        self.issuer, self.source_domain, self.issuer_seed = issuer, source_domain, issuer_seed
        self.keys = he.KeyRegistry()
        self.keys.register(pub_of(issuer_seed), signer_id=issuer, key_id="k1", key_epoch=1)
        self.hub = he.HubIndex(
            key_registry=self.keys,
            claim_registry=he.ClaimRegistry(CLAIMS, expected_sha256=he.canonical_sha(CLAIMS)),
            log=hl.TransparencyLog(), source_domain=source_domain)
        self.signers = {issuer}
        self.origins = {pub_of(issuer_seed): {"kind": "bootstrap", "seq": 0}}
        self.records = []

    @property
    def T(self) -> int:
        return self.hub.log.tree_size

    @property
    def root(self) -> bytes:
        return self.hub.log.root()

    def copy(self) -> "Ledger":
        """같은 사건을 재생한 사본 — 옛 사본·갈라진 줄기를 만들 때."""
        other = Ledger(issuer=self.issuer, source_domain=self.source_domain,
                       issuer_seed=self.issuer_seed)
        for raw, sig, pub, meta in self.records:
            other._admit_raw(raw, sig, pub, meta)
        return other

    def _admit_raw(self, raw, sig, pub, meta) -> int:
        r = self.hub.admit(raw, sig, pub)
        if not (r["admitted"] and not r["duplicate"]):
            raise AssertionError(f"합성 원장 admit 실패: {r.get('problems')}")
        seq = r["accepted_seq"]
        if meta:
            signer, new_pub, kind = meta
            self.signers.add(signer)
            self.origins[new_pub] = {"kind": kind, "seq": seq}
        self.records.append((raw, sig, pub, meta))
        return seq

    def _admit(self, env, seed, meta=None) -> int:
        raw = he.canonical_bytes(env)
        return self._admit_raw(raw, sign_envelope(env, seed), pub_of(seed), meta)

    def _machine(self, lab):
        return {"type": "machine", "id": "machine:" + _cfg(lab)["machine_id"]}

    def introduce(self, signer: str, pubkey: str, *, at: str, key_id="k1", epoch=1) -> int:
        env = _envelope(self.issuer, "signer.introduced",
                        {"signer_id": signer, "key_id": key_id, "key_epoch": epoch,
                         "pubkey": pubkey},
                        key_id="k1", epoch=1, subject=self._machine(self.issuer), at=at)
        return self._admit(env, self.issuer_seed, (signer, pubkey, "signer.introduced"))

    def rotate(self, signer: str, seed: bytes, *, key_id, epoch, new_key_id, new_epoch,
               new_pubkey: str, at: str) -> int:
        env = _envelope(signer, "key.rotated",
                        {"new_key_id": new_key_id, "new_key_epoch": new_epoch,
                         "new_pubkey": new_pubkey},
                        key_id=key_id, epoch=epoch, subject=self._machine(signer), at=at)
        return self._admit(env, seed, (signer, new_pubkey, "key.rotated"))

    def revoke(self, signer: str, seed: bytes, *, key_id, epoch, target_key_id,
               target_epoch, at: str, reason="compromised") -> int:
        env = _envelope(signer, "key.revoked",
                        {"key_id": target_key_id, "key_epoch": target_epoch, "reason": reason},
                        key_id=key_id, epoch=epoch, subject=self._machine(signer), at=at)
        return self._admit(env, seed)

    def heartbeat(self, *, at: str, tag: str = "") -> int:
        """조용한 원장의 전진(§7) — 내용에 시각을 넣어야 멱등 수렴을 피한다."""
        data = f"heartbeat {at} {tag}".encode()
        payload = {"artifact": {"role": "artifact", "schema_id": "raw/v1",
                                "sha256": hashlib.sha256(data).hexdigest(),
                                "byte_length": len(data),
                                "media_type": "application/octet-stream"},
                   "bindings": [], "causal": {},
                   "claim": {"type": "core:artifact.frozen", "scope": "heartbeat",
                             "attests_ordering_of": "emission",
                             "evidence_basis": {"method": "raw-bytes-sha256",
                                                "verifier_schema": "raw/v1",
                                                "body_custody": "repo",
                                                "locator_authority": False}}}
        env = _envelope(self.issuer, "artifact.attested", payload, key_id="k1", epoch=1,
                        subject={"type": "artifact",
                                 "id": "artifact:heartbeat-" + at.replace(":", "")},
                        at=at)
        return self._admit(env, self.issuer_seed)

    def bindings(self) -> list:
        """원장 1..T 재생 뒤의 registry — 폐기 결속도 싣는다, 사전순."""
        out = []
        for s in sorted(self.signers):
            for b in self.keys.bindings_of(s):
                out.append({"signer_id": b["signer_id"], "key_id": b["key_id"],
                            "key_epoch": b["key_epoch"], "pubkey": b["pubkey"],
                            "valid_from_seq": b["valid_from_seq"],
                            "revoked_at_seq": b["revoked_at_seq"],
                            "origin": dict(self.origins[b["pubkey"]])})
        return sorted(out, key=lambda x: (x["signer_id"], x["key_id"], x["key_epoch"]))


def snapshot_id(doc: dict) -> str:
    return he.canonical_sha(doc["body"])


class Issuer:
    """정직한 발급기. 같은 (T, root)로 다시 낼 때 anchor_since를 유지한다."""

    def __init__(self, ledger: Ledger):
        self.ledger = ledger
        self.since: dict = {}

    def fork(self, ledger: Ledger) -> "Issuer":
        other = Issuer(ledger)
        other.since = dict(self.since)
        return other

    def issue(self, *, issued_at: str, not_after: str, prev: list = (),
              anchor_since: str | None = None, consistency_override: dict | None = None,
              audit: str = "table") -> dict:
        lg = self.ledger
        T, root = lg.T, lg.root
        honest = self.since.setdefault((T, root.hex()), issued_at)
        entries = []
        for d in prev:
            pb = d["body"]["anchor"]["body"]
            pid = snapshot_id(d)
            if consistency_override and pid in consistency_override:
                proof = consistency_override[pid]
            else:
                proof = [h.hex() for h in lg.hub.log.consistency_proof(pb["tree_size"], T)]
            entries.append({"snapshot_id": pid, "tree_size": pb["tree_size"],
                            "root": pb["root"], "consistency": proof})
        body = {"schema": "organum-hub/trust-snapshot/v0",
                "issuer": {"id": lg.issuer, "key_id": "k1", "key_epoch": 1},
                "source_domain": lg.source_domain,
                "anchor": hl.sign_tree_head(tree_size=T, root=root, seckey=lg.issuer_seed),
                "anchor_since": anchor_since or honest,
                "issued_at": issued_at, "not_after": not_after, "audit": audit,
                "bindings": lg.bindings(), "prev": entries}
        return sign_body(body, lg.issuer_seed)


def sign_body(body: dict, seed: bytes) -> dict:
    """body를 (다시) 서명한다 — 내부 모순 문서를 발급자 키로 만들 때도 쓴다."""
    sig = sp.sign(hashlib.sha256(he.canonical_bytes(body)).digest(), seed)
    return {"body": body, "signature": sig.hex()}


def resign(doc: dict, seed: bytes, mutate) -> dict:
    body = copy.deepcopy(doc["body"])
    mutate(body)
    return sign_body(body, seed)


def tamper(doc: dict, mutate) -> dict:
    """서명은 그대로 두고 body만 바꾼다(서명 불일치)."""
    out = copy.deepcopy(doc)
    mutate(out["body"])
    return out


def message(lab: str, seed: bytes, *, key_id: str, epoch: int, text: str, at: str,
            sign_seed: bytes | None = None) -> dict:
    """갤러리 쓰기 흉내 — message.posted 봉투 + 본문. sign_seed로 다른 키 서명을 만든다."""
    body = text.encode("utf-8")
    env = ho.build_message_envelope(_cfg(lab), signer=lab, key_id=key_id, epoch=epoch,
                                    to_lab="lab:issuer", to_id="gallery", to_epoch=1,
                                    body=body, body_locator="gallery://post",
                                    media_type="text/plain", created_at=at)
    env["provenance"]["platform"] = PLATFORM
    return {"envelope": env, "sig": sign_envelope(env, sign_seed or seed), "body_utf8": text}
