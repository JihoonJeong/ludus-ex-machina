# trust snapshot v0 — 합성 fixture 벡터와 참조 검증기

계약: `organum-hub/trust-snapshot/v0`, **v0.5 교정판**(이음 131 합의, Orin core 확인 대기). 본문은
[docs/trust-snapshot-contract-v0-draft.md](../../docs/trust-snapshot-contract-v0-draft.md).
v0.4 동결판의 실패 기록(fixture r1)은 dev `b18088d`와
[docs/trust-snapshot-v0-fixture-report.md](../../docs/trust-snapshot-v0-fixture-report.md)에 있다.

**제품이 아니다.** 계약이 스스로 모순 없이 판정하는지 보는 실험이다. 첫 shadow 범위
(`audit=table`, 합성 fixture만)를 따른다. 실제 서비스 저장소·시계·폴링은 여기서 검증하지 않는다.

## 파일

| 파일 | 역할 |
|---|---|
| `trust.py` | 참조 검증기. 무상태. §4.1 ①②③·§4.2 저장소 판별·재기준화·§4.3 쓰기 판정 |
| `service.py` | 벡터 실행기. 영속 저장소를 가진 최소 서비스 흉내. 단계 의미의 참조 구현 |
| `issuer.py` | 합성 발급자. 제품 `HubIndex`·`TransparencyLog`·`KeyRegistry`로 원장을 쌓고 판을 파생 |
| `make_vectors.py` | 벡터 생성기. **기대값은 계약 문구에서 손으로 계산해 적는다**(검증기를 부르지 않음) |
| `vectors/` | 벡터 30개 + `INDEX.json`(파일별 sha256과 묶음 digest) |
| `test_trust_vectors.py` | 전 벡터 실행, 결정론 재생성, 독립성·포괄성 검사 |
| `mutation_check.py` | 검증기 판정을 하나씩 망가뜨려 벡터가 잡는지 확인(공허한 시험 방지) |

## 돌리기

```bash
python3 -m pytest experiments/trust-v0 -q
```

```bash
python3 experiments/trust-v0/mutation_check.py
```

```bash
python3 experiments/trust-v0/make_vectors.py
```

마지막 명령은 `vectors/`를 다시 쓴다. 코드가 같으면 bytes도 같다.

## v0.4의 기록

v0.4 동결판에서 결함을 드러낸 벡터 넷(05·24·25·26)은 `history`에 그때의 판정과 기록 커밋을 싣는다.
기대값은 v0.5 판정이다. v0.4 판정을 그대로 돌려 보려면 `b18088d`를 체크아웃한다.

## 벡터 형식

```json
{
 "vector": "10-writer-errors",
 "kind": "contract | limit",
 "history": {"finding": "F1", "record": "b18088d", "v0_4": "…"},
 "refs": ["§4.3"],
 "purpose": "…",
 "honest_limit": "…",
 "params": {"service_max_ttl": 86400, "anchor_max_age": 172800, "skew": 300},
 "pinned": {"id": "lab:issuer", "key_id": "k1", "key_epoch": 1, "pubkey": "<64 hex>",
            "source_domain": "lab:issuer/hub"},
 "documents": {"A3": {"body": {…}, "signature": "…"}},
 "writes": {"alpha_k1": {"envelope": {…}, "sig": "<128 hex>", "body_utf8": "…"}},
 "steps": [{"op": "…", "expect": {…}}]
}
```

- `params`의 수는 **합성 값**이다. 운영 수치 제안이 아니다.
- 모든 문서와 봉투는 결정론 seed로 서명했다. seed는 `issuer.seed_of(라벨)`로 파생한다.
- 기대값은 **부분 일치**다. `expect`에 적힌 키만 본다. 목록은 통째로 같아야 한다.

## 단계 의미

| op | 입력 | 서비스가 하는 일 | 기대값 키 |
|---|---|---|---|
| `boot` | — | 저장소를 보고 셋으로 가른다. 닿지 않으면 `unreachable`. ok가 아니면 운영 경보 | `status`: ok·lost·uninitialized·unreachable, `events` |
| `offer` | `doc`, `now` | 상태가 ok일 때만 §4.1 ①②③. 아니면 채택·상태 전이 없이 관측 기록만 | `events`, `adopted`, `snapshot_id`(쓰는 판), `anchor_start`, `effective_not_after`, 무시면 `ignored`와 `observed` |
| `check` | `now` | ③만(주기 점검) | `events` |
| `write` | `write`, `now` | §4.3 순서 0–5 | 통과면 `ok: true`와 `accepted_under`. 거부면 `code`·`retry`(`key_revoked`는 `revoked_at_seq`) |
| `rebaseline` | `doc`, `declared`, `reason`, `operator`, `now` | §4.2 재기준화. 표지는 첫 채택 때 한 번만 쓴다 | `ok`, `audit`, `marker`, `events`, `anchor_start`, `effective_not_after` |
| `mutate` | `action` | 저장소 사고: unreachable·reachable·drop_last_accepted·drop_anchor_start·drop_marker·corrupt_signature·wipe | (기대값 없음) |

시각은 RFC3339 UTC-Z다. 쓸 판은 `now < effective_not_after`일 때만이다.
