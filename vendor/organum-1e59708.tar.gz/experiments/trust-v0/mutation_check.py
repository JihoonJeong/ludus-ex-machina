"""변이 검사 — 벡터가 검증기의 판정을 실제로 붙잡는지(공허한 시험이 아닌지) 본다.

검증기(trust.py)의 판정 한 곳을 일부러 망가뜨린 사본을 임시 디렉터리에 만들고 벡터 시험을
돌린다. 모든 변이가 **시험 실패**로 끝나야 한다. 수집 오류(모듈을 못 찾는 등)는 잡힘이 아니다 —
그렇게 세면 변이 검사 자체가 공허해진다(첫 실행에서 실제로 그랬다).

    python3 experiments/trust-v0/mutation_check.py

종료코드 0 = 기준선 통과 + 모든 변이가 시험 실패로 잡힘.
"""
import os, shutil, subprocess, pathlib, sys, tempfile

HERE = pathlib.Path(__file__).resolve().parent
src = HERE
env = dict(os.environ, PYTHONPATH=str(HERE.parents[1] / "src"))
muts = {
 "baseline (no mutation)": ("", ""),
 "expiry <= (closed interval)": ("return state is not None and now < parse_time", "return state is not None and now <= parse_time"),
 "refresh uses new anchor_since": ("start = min(parse_time(last[\"anchor_start\"]), since)", "start = since"),
 "extend ignores anchor_since": ("start = min(now_dt, since)", "start = now_dt"),
 "skip bindings compare": ("return \"snapshot_fork\", \"같은 T·root에 다른 bindings\"", "pass"),
 "skip consistency": ("if not hl.verify_consistency(", "if False and hl.verify_consistency("),
 "skip anchor bound": ("               anchor_start + timedelta(seconds=params[\"anchor_max_age\"]))", "               parse_time(body[\"not_after\"]))"),
 "skew >=": ("if issued - now > timedelta(seconds=skew):", "if issued - now >= timedelta(seconds=skew):"),
 "no revoked check": ("    if b[\"revoked_at_seq\"] is not None:          # 판정 좌표 T+1(F1)", "    if False:"),
 "skip body check": ("    want = envelope[\"payload\"].get(\"body_sha256\")", "    want = None"),
 "marker missing -> not lost": ("        return lost(\"last_accepted는 있는데 표지가 없음(I3)\")", "        pass"),
 "self-declare genesis": ("        return {\"status\": \"uninitialized\"", "        return {\"status\": \"ok\""),
 "no rollback": ("    if nT < sT:\n        return \"snapshot_rollback\"", "    if False:\n        return \"snapshot_rollback\""),
 "F1 back to T (v0.4)": ("                if vf > T + 1:", "                if vf > T:"),
 "F1 half-fix (key_revoked <= T)": ("    if b[\"revoked_at_seq\"] is not None:", "    if b[\"revoked_at_seq\"] is not None and b[\"revoked_at_seq\"] <= T:"),
 "F2 no (T,root) fallback": ("    cands = [e for e in nb[\"prev\"] if e[\"tree_size\"] == sT]", "    cands = [e for e in nb[\"prev\"] if e[\"snapshot_id\"] == sid]"),
 "F2 no stored-id check": ("    if any((e[\"tree_size\"], e[\"root\"]) != (sT, sroot)\n           for e in nb[\"prev\"] if e[\"snapshot_id\"] == sid):", "    if False:"),
 "F3 allow T=0": ("        if not _is_int(a[\"body\"][\"tree_size\"], 1):", "        if not _is_int(a[\"body\"][\"tree_size\"], 0):"),
 "W2 source_domain not pinned": ("    if b[\"source_domain\"] != pinned[\"source_domain\"]:", "    if False:"),
 "W2 operating lab not derived": ("                operating_lab(b[\"source_domain\"], bs) != iss[\"id\"]:", "                False:"),
 "W2 bare name not derived": ("    if he._LAB_ID.fullmatch(cand) and any(", "    if False and any("),
 "I6 not observed": ("    return {\"kind\": \"trust.input_ignored\"", "    return {\"kind\": \"ignored\""),
 "unknown signer passes": ("    if b is None:\n        return _err(\"unknown_signer\"", "    if b is None and False:\n        return _err(\"unknown_signer\""),
}
bad = 0
tmp = tempfile.mkdtemp(prefix="trust-mut-")
for name, (a, b) in muts.items():
    d = pathlib.Path(tmp) / "mut"; shutil.rmtree(d, ignore_errors=True)
    shutil.copytree(src, d, ignore=shutil.ignore_patterns("__pycache__"))
    t = (d / "trust.py").read_text()
    if a and t.count(a) != 1:
        print(f"ANCHOR MISSING: {name}"); bad += 1; continue
    if a:
        (d / "trust.py").write_text(t.replace(a, b))
    r = subprocess.run([sys.executable, "-m", "pytest", str(d), "-q", "-p", "no:cacheprovider"],
                       capture_output=True, text=True, env=env)
    tail = [l for l in r.stdout.splitlines() if " passed" in l or " failed" in l or " error" in l]
    summ = tail[-1] if tail else "NO SUMMARY"
    coll_err = "error" in summ and "failed" not in summ
    if not a:
        verdict = "BASELINE-OK" if r.returncode == 0 else "BASELINE-FAIL"
        bad += r.returncode != 0
    else:
        verdict = ("COLLECTION-ERROR" if coll_err else ("CAUGHT" if r.returncode else "MISSED"))
        bad += verdict != "CAUGHT"
    print(f"{verdict:16} {name} :: {summ}")
shutil.rmtree(tmp, ignore_errors=True)
sys.exit(1 if bad else 0)
