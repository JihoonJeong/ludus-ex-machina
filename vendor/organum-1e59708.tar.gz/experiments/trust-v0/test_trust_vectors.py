"""trust snapshot v0 벡터 시험 — v0.5 교정판.

    python3 -m pytest experiments/trust-v0 -q

v0.4 동결판의 판정과 실패 기록은 fixture r1(dev b18088d)에 있다. 여기서는 그 결함을 드러낸
벡터가 `history`에 v0.4의 판정을 남기고, 기대값은 v0.5 판정이다.
"""

import json
import sys
from pathlib import Path

import pytest

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import make_vectors  # noqa: E402
import service  # noqa: E402
import trust  # noqa: E402
from organum import hub_log as hl  # noqa: E402

VEC_DIR = HERE / "vectors"
FILES = sorted(p for p in VEC_DIR.glob("*.json") if p.name != "INDEX.json")
VECS = {p.stem: json.loads(p.read_text(encoding="utf-8")) for p in FILES}


@pytest.mark.parametrize("name", sorted(VECS))
def test_v0_5(name):
    bad = [{"step": i, "op": op, "want": want, "got": got}
           for i, op, want, got in service.run_vector(VECS[name])
           if not service.subset_match(want, got)]
    assert bad == []


def test_계약_판본이_맞물린다():
    assert trust.CONTRACT_VERSION == "v0.5"
    for name, v in VECS.items():
        assert "v0.5" in v["contract"], name
        assert set(v["pinned"]) == {"id", "key_id", "key_epoch", "pubkey", "source_domain"}, name


def test_v0_4_실패_기록이_벡터에_남는다():
    """F1·F2·F3을 드러낸 벡터는 v0.4의 판정과 기록 커밋을 history로 들고 있다."""
    found = {}
    for name, v in VECS.items():
        h = v.get("history")
        if h:
            assert h["record"] == "b18088d" and h["v0_4"], name
            found.setdefault(h["finding"], []).append(name)
    assert set(found) == {"F1", "F2", "F3"}


def test_벡터는_결정론으로_재생성된다(tmp_path):
    idx = make_vectors.emit(tmp_path)
    for p in sorted(VEC_DIR.iterdir()):
        assert (tmp_path / p.name).read_bytes() == p.read_bytes(), p.name
    assert sorted(x.name for x in tmp_path.iterdir()) == sorted(x.name for x in VEC_DIR.iterdir())
    assert idx["digest"] == json.loads((VEC_DIR / "INDEX.json").read_text())["digest"]


def test_기대값은_검증기와_독립이다():
    """생성기는 검증기를 import하지 않는다 — 같은 함수로 기대와 실제를 만들지 않는다."""
    src = (HERE / "make_vectors.py").read_text(encoding="utf-8")
    assert "import trust" not in src and "from trust" not in src
    assert "import service" not in src and "from service" not in src


def test_계약의_사건_오류_기동상태가_모두_벡터에_있다():
    events, codes, statuses = set(), set(), set()
    for v in VECS.values():
        for s in v["steps"]:
            e = s.get("expect", {})
            events.update(e.get("events", []))
            if "code" in e:
                codes.add(e["code"])
            if s["op"] == "boot":
                statuses.add(e["status"])
    assert set(trust.OPERATING_EVENTS) <= events
    assert set(trust.RETRY) <= codes
    assert set(trust.BOOT_STATUSES) <= statuses


def test_무시된_입력은_관측으로_남는다():
    """I6: 상태가 ok가 아닐 때 받은 판 — 채택·상태 전이 없음, 관측 기록은 있음."""
    seen = set()
    for v in VECS.values():
        for s in v["steps"]:
            if s["op"] == "offer" and "ignored" in s["expect"]:
                assert s["expect"]["adopted"] is False and s["expect"]["events"] == []
                assert s["expect"]["observed"]["kind"] == "trust.input_ignored"
                seen.add(s["expect"]["ignored"])
    assert seen == {"uninitialized", "lost", "unreachable"}


def test_한계_벡터_독립_헤드_대조는_갈라짐을_잡는다():
    """v0 밖 다음 층의 시연 — 같은 발급자 키로 서명된 같은 크기 두 헤드."""
    v = VECS["22-limit-old-copy-fork"]
    o = v["outside_v0"]["detect_fork"]
    pub = bytes.fromhex(v["pinned"]["pubkey"])
    r = hl.detect_fork(o["live_tree_head"], o["fork_tree_head"], pub)
    assert r["fork"] is o["expect_fork"] is True


def test_F1_좌표_경계는_제품_원장_규칙이다():
    """정직한 판의 결속 좌표가 T+1인 것은 합성 발급자가 아니라 제품 HubIndex가 정한다."""
    p3 = VECS["25-f1-revocation-at-anchor"]["documents"]["P3"]["body"]
    alpha = next(b for b in p3["bindings"] if b["signer_id"] == "lab:alpha")
    assert alpha["revoked_at_seq"] == p3["anchor"]["body"]["tree_size"] + 1
    p1 = VECS["24-f1-introduced-at-anchor"]["documents"]["P1"]["body"]
    alpha1 = next(b for b in p1["bindings"] if b["signer_id"] == "lab:alpha")
    assert alpha1["valid_from_seq"] == p1["anchor"]["body"]["tree_size"] + 1


def test_운영_lab_파생은_hub_도입_권한_규칙과_같다():
    boot = {"signer_id": "lab:issuer", "key_id": "k1", "key_epoch": 1, "valid_from_seq": 0,
            "origin": {"kind": "bootstrap", "seq": 0}}
    intro = dict(boot, valid_from_seq=5, origin={"kind": "signer.introduced", "seq": 4})
    assert trust.operating_lab("lab:issuer/hub", []) == "lab:issuer"
    assert trust.operating_lab("issuer/hub", [boot]) == "lab:issuer"
    assert trust.operating_lab("issuer/hub", [intro]) is None      # 도입 결속은 자격 없음
    assert trust.operating_lab("", [boot]) is None
    assert trust.operating_lab("Issuer/hub", [boot]) is None       # lab 문법 밖


def test_검증기는_공개_입력에_예외를_내지_않는다():
    """모양이 틀린 문서·봉투는 판정으로 수렴한다."""
    v = VECS["00-boot-genesis"]
    pinned, params = v["pinned"], v["params"]
    now = "2026-10-01T00:00:00Z"
    for junk in (None, [], {}, {"body": [], "signature": 1}, {"body": {}, "signature": "x"}):
        r = trust.verify_snapshot(junk, last=None, now=now, pinned=pinned, params=params)
        assert r["events"][0] == "snapshot_invalid"
    svc = service.Service(pinned=pinned, params=params)
    svc.boot()
    rb = next(s for s in v["steps"] if s["op"] == "rebaseline" and s["expect"].get("ok"))
    svc.rebaseline(v["documents"][rb["doc"]], declared=rb["declared"], reason="genesis",
                   operator="t", now=now)
    for env in (None, [], {"signer": 1}, {"payload": []}):
        r = svc.write(env, "zz", None, now)
        assert r["code"] == "schema_invalid"
