"""trust snapshot v0 합성 fixture 벡터 생성기.

입력(문서·봉투·서명)은 합성 발급자가 제품 원장 코드로 만든다(issuer.py). **기대값은 이
파일에 계약 문구(v0.5 교정판)에서 손으로 계산해 적는다.** 검증기(trust.py)를 부르지
않는다 — 같은 함수로 기대와 실제를 만들면 회귀 증거가 아니다.

    python3 experiments/trust-v0/make_vectors.py [출력 디렉터리]

출력은 결정론이다: 같은 코드는 같은 bytes를 낸다(시험이 대조한다).
수치(TTL·상한·허용 오차)는 **합성 값**이다. 운영 수치 제안이 아니다.
"""

from __future__ import annotations

import copy
import hashlib
import json
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import issuer as iz  # noqa: E402
from issuer import Issuer, Ledger, message, resign, seed_of, pub_of, tamper  # noqa: E402

from organum import hub_envelope as he  # noqa: E402
from organum import hub_log as hl  # noqa: E402

CONTRACT = "organum-hub/trust-snapshot/v0 — v0.5 교정판(이음 131 합의 · Orin core 확인 대기)"
RECORD_V0_4 = "b18088d"   # v0.4 동결판 실패 기록(fixture r1)
T0 = datetime(2026, 10, 1, tzinfo=timezone.utc)
H = 3600


def t(h=0, m=0, s=0) -> str:
    return (T0 + timedelta(hours=h, minutes=m, seconds=s)).strftime("%Y-%m-%dT%H:%M:%SZ")


P_STD = {"service_max_ttl": 24 * H, "anchor_max_age": 48 * H, "skew": 300}
P_DELAY = {"service_max_ttl": 24 * H, "anchor_max_age": 30 * H, "skew": 300}
PARAMS_NOTE = "합성 수치 — 운영 제안 아님(§7: 실제 수는 첫 검수에서 잰다)"

# §4.3 retry 표 — 계약 문구에서 옮겨 적음(검증기 상수를 가져오지 않는다)
RETRY = {"trust_unavailable": "wait", "schema_invalid": "never", "body_mismatch": "never",
         "unknown_signer": "after_curation", "signature_invalid": "never",
         "key_revoked": "never"}

S = {k: seed_of(k) for k in ("issuer", "alpha-k1", "alpha-k2", "beta-k1", "gamma-k1",
                             "mallory")}
ISS = "lab:issuer"
PINNED = {"id": ISS, "key_id": "k1", "key_epoch": 1, "pubkey": pub_of(S["issuer"]),
          "source_domain": "lab:issuer/hub"}
PINNED_BARE = dict(PINNED, source_domain="issuer/hub")
PINNED_OTHER = dict(PINNED, source_domain="lab:other/hub")

DOCS: dict = {}
WRITES: dict = {}
EXTRA: dict = {}


def sid(doc) -> str:
    return he.canonical_sha(doc["body"])


def dT(doc) -> int:
    return doc["body"]["anchor"]["body"]["tree_size"]


def droot(doc) -> str:
    return doc["body"]["anchor"]["body"]["root"]


def new_ledger() -> Ledger:
    return Ledger(issuer=ISS, source_domain="lab:issuer/hub", issuer_seed=S["issuer"])


# ── 세계: 발급자 원장과 판 ────────────────────────────────────────────────────

def build_main():
    L = new_ledger()
    I = Issuer(L)
    L.introduce("lab:alpha", pub_of(S["alpha-k1"]), at=t(-3))      # seq1 → alpha k1 vf 2
    L.introduce("lab:beta", pub_of(S["beta-k1"]), at=t(-2))        # seq2 → beta k1 vf 3
    Lg = L.copy()                                                  # 갈라질 사본(T=2)
    L.heartbeat(at=t(-1))                                          # seq3
    D = DOCS
    D["A3"] = I.issue(issued_at=t(0), not_after=t(6))
    D["A3_20"] = I.issue(issued_at=t(0, 30), not_after=t(20))
    D["A3_long"] = I.issue(issued_at=t(1), not_after=t(24 * 30 + 1))
    D["A3_skew_ok"] = I.issue(issued_at=t(1, 5), not_after=t(7))
    D["A3_skew_bad"] = I.issue(issued_at=t(1, 5, 1), not_after=t(7))
    D["A3b"] = I.issue(issued_at=t(5), not_after=t(11))
    A3 = D["A3"]
    iseed, mseed = S["issuer"], S["mallory"]

    # ① 문서 내부 모순 — 발급자 키로 다시 서명한 것과 서명만 깨진 것
    def swap_pub(b, who, pub):
        for x in b["bindings"]:
            if x["signer_id"] == who:
                x["pubkey"] = pub

    def set_field(b, who, k, v):
        for x in b["bindings"]:
            if x["signer_id"] == who:
                x[k] = v

    inv = {
        "inv_tampered": tamper(A3, lambda b: b.update(not_after=t(12))),
        "inv_anchor_sig": resign(A3, iseed, lambda b: b.update(anchor=hl.sign_tree_head(
            tree_size=3, root=bytes.fromhex(droot(A3)), seckey=mseed))),
        "inv_unsorted": resign(A3, iseed, lambda b: b["bindings"].reverse()),
        "inv_issuer_pub": resign(A3, iseed, lambda b: swap_pub(b, ISS, pub_of(mseed))),
        "inv_coord": resign(A3, iseed, lambda b: set_field(b, "lab:alpha", "valid_from_seq", 3)),
        "inv_times": resign(A3, iseed, lambda b: b.update(not_after=b["issued_at"])),
        "inv_since": resign(A3, iseed, lambda b: b.update(anchor_since=t(0, 1))),
        "inv_prev_size": resign(A3, iseed, lambda b: b.update(prev=[{
            "snapshot_id": "ab" * 32, "tree_size": 3, "root": droot(A3), "consistency": []}])),
        "inv_dup_pub": resign(A3, iseed, lambda b: swap_pub(b, "lab:beta",
                                                            pub_of(S["alpha-k1"]))),
        "inv_logged": resign(A3, iseed, lambda b: b.update(audit="logged")),
        "inv_not_pinned": resign(A3, iseed, lambda b: b["issuer"].update(id="lab:alpha")),
        "inv_revoked_order": resign(A3, iseed,
                                    lambda b: set_field(b, "lab:alpha", "revoked_at_seq", 1)),
        "inv_schema": resign(A3, iseed,
                             lambda b: b.update(schema="organum-hub/trust-snapshot/v1")),
        "inv_extra_key": resign(A3, iseed, lambda b: b.update(note="x")),
    }
    D.update(inv)
    D["A3_nobeta"] = resign(A3, iseed, lambda b: b.update(
        bindings=[x for x in b["bindings"] if x["signer_id"] != "lab:beta"]))
    # W2: source_domain — 발급자 키로 서명했지만 고정값과 다른 판
    D["sd_foreign"] = resign(A3, iseed, lambda b: b.update(source_domain="lab:mallory/hub"))
    D["sd_empty"] = resign(A3, iseed, lambda b: b.update(source_domain=""))
    D["sd_other_hub"] = resign(A3, iseed, lambda b: b.update(source_domain="lab:issuer/other-hub"))
    D["sd_other_lab"] = resign(A3, iseed, lambda b: b.update(source_domain="lab:other/hub"))

    Lr = L.copy()                                                  # 같은 T 재발급 세계
    Ir = I.fork(Lr)
    Ld = L.copy()                                                  # 지연 경계 세계
    Id = I.fork(Ld)

    L.rotate("lab:alpha", S["alpha-k1"], key_id="k1", epoch=1, new_key_id="k2",
             new_epoch=1, new_pubkey=pub_of(S["alpha-k2"]), at=t(6))   # seq4 → k2 vf 5
    L.revoke("lab:alpha", S["alpha-k2"], key_id="k2", epoch=1, target_key_id="k1",
             target_epoch=1, at=t(7))                                   # seq5 → k1 rv 6
    L.heartbeat(at=t(7, 30))                                            # seq6
    D["B6"] = I.issue(issued_at=t(8), not_after=t(14), prev=[D["A3b"], A3])
    D["B6_k1"] = I.issue(issued_at=t(8), not_after=t(14), prev=[D["A3b"]])
    D["B6_short"] = I.issue(issued_at=t(8), not_after=t(10), prev=[D["A3_20"]])
    B6 = D["B6"]
    Lf = L.copy()                                                      # 옛 사본(T=6)
    If = I.fork(Lf)

    L.revoke("lab:beta", S["beta-k1"], key_id="k1", epoch=1, target_key_id="k1",
             target_epoch=1, at=t(9))                                   # seq7 → beta rv 8
    EXTRA["live_sth7"] = hl.sign_tree_head(tree_size=L.T, root=L.root, seckey=S["issuer"])
    L.heartbeat(at=t(9, 30))                                            # seq8
    D["C8"] = I.issue(issued_at=t(10), not_after=t(16), prev=[B6, D["A3b"], A3])
    D["C8_k1"] = I.issue(issued_at=t(10), not_after=t(16), prev=[B6])
    L.introduce("lab:gamma", pub_of(S["gamma-k1"]), at=t(11))          # seq9 → gamma vf 10
    L.heartbeat(at=t(11, 30))                                           # seq10
    D["E10"] = I.issue(issued_at=t(12), not_after=t(18), prev=[D["C8"], B6, D["A3b"]])

    # B6의 prev 첫 항목(A3b)을 망가뜨린 판 — 발급자 키로 다시 서명
    def bad_root(b):
        b["prev"][0]["root"] = "00" * 32

    def bad_proof(b):
        b["prev"][0]["consistency"] = list(reversed(b["prev"][0]["consistency"]))

    D["B6_badroot"] = resign(B6, iseed, bad_root)
    D["B6_badproof"] = resign(B6, iseed, bad_proof)
    # 저장 판(A3b)의 크기를 다르게 적은 prev — 같은 크기 규칙만으로는 A3 항목으로 확장이 선다
    D["B6_badsize"] = resign(B6, iseed, lambda b: b["prev"][0].update(tree_size=4))

    # 같은 T=3에서 갈라진 줄기(다른 seq3)
    Lg.heartbeat(at=t(-1), tag="fork")
    D["G3"] = Issuer(Lg).issue(issued_at=t(0, 30), not_after=t(6, 30))

    # 옛 사본 + 발급자 키: T=6에서 새 attest로 T를 전진(beta 폐기를 모르는 줄기)
    Lf.heartbeat(at=t(9), tag="old-copy")
    D["X7"] = If.issue(issued_at=t(9, 10), not_after=t(15), prev=[B6, D["A3b"], A3])

    # 같은 T 재발급 세계(T=3)
    D["R5"] = Ir.issue(issued_at=t(5), not_after=t(25))
    D["R24"] = Ir.issue(issued_at=t(24), not_after=t(44))
    D["R40_late"] = Ir.issue(issued_at=t(40), not_after=t(60), anchor_since=t(40))
    D["R41_early"] = Ir.issue(issued_at=t(41), not_after=t(61), anchor_since=t(-10))
    D["R43"] = Ir.issue(issued_at=t(43), not_after=t(63))
    D["R49"] = Ir.issue(issued_at=t(49), not_after=t(69))
    D["R49_hide"] = Ir.issue(issued_at=t(49), not_after=t(69), anchor_since=t(49))
    Lr.heartbeat(at=t(49, 30))
    D["D4"] = Ir.issue(issued_at=t(50), not_after=t(56), prev=[D["R49"], D["R43"], D["R24"]])

    # 지연 경계 세계(T=3, anchor_max_age 30h)
    D["Q18"] = Id.issue(issued_at=t(18), not_after=t(26))
    D["Q24"] = Id.issue(issued_at=t(24), not_after=t(32))
    for name, hb, issued, nf in (("H4a", t(29, 58), t(29, 59), t(37, 59)),
                                 ("H4b", t(29, 59, 30), t(30), t(38)),
                                 ("H4c", t(28), t(28), t(36))):
        Lb = Ld.copy()
        Ib = Id.fork(Lb)
        Lb.heartbeat(at=hb)
        D[name] = Ib.issue(issued_at=issued, not_after=nf, prev=[D["Q24"], D["Q18"]])


def build_f1():
    """F1 세계: 기준점 T가 도입·폐기 사건 좌표와 같은 판."""
    L = new_ledger()
    I = Issuer(L)
    L.introduce("lab:alpha", pub_of(S["alpha-k1"]), at=t(-1))      # seq1 → vf 2 (T=1)
    DOCS["P1"] = I.issue(issued_at=t(0), not_after=t(6))
    L.heartbeat(at=t(0, 30))                                       # seq2
    DOCS["P2"] = I.issue(issued_at=t(1), not_after=t(7), prev=[DOCS["P1"]])
    L.revoke("lab:alpha", S["alpha-k1"], key_id="k1", epoch=1, target_key_id="k1",
             target_epoch=1, at=t(2))                              # seq3 → rv 4 (T=3)
    DOCS["P3"] = I.issue(issued_at=t(2, 10), not_after=t(8, 10), prev=[DOCS["P2"], DOCS["P1"]])
    L.heartbeat(at=t(3))                                           # seq4
    DOCS["P4"] = I.issue(issued_at=t(3, 10), not_after=t(9, 10),
                         prev=[DOCS["P3"], DOCS["P2"], DOCS["P1"]])


def build_f3():
    """F3 세계: 사건이 없는 원장(T=0)의 판."""
    L = new_ledger()
    I = Issuer(L)
    DOCS["Z0"] = I.issue(issued_at=t(0), not_after=t(6))
    L.heartbeat(at=t(0, 30))
    # 크기 0에서의 일관성 증명은 제품 함수가 만들지 않는다(범위 밖) — 빈 목록으로 싣는다
    DOCS["Z1"] = I.issue(issued_at=t(1), not_after=t(7), prev=[DOCS["Z0"]],
                         consistency_override={sid(DOCS["Z0"]): []})
    # v0.5 발급자 의무: 첫 판은 heartbeat 뒤(T ≥ 1), 크기 0 판을 prev에 싣지 않는다
    DOCS["Z1c"] = I.issue(issued_at=t(1, 5), not_after=t(7, 5))


def build_bare():
    """W2 세계: source_domain이 bare name(`issuer/hub`)인 발급자 — 운영 lab은 bootstrap 결속으로 파생."""
    L = Ledger(issuer=ISS, source_domain="issuer/hub", issuer_seed=S["issuer"])
    I = Issuer(L)
    L.introduce("lab:alpha", pub_of(S["alpha-k1"]), at=t(-2))
    L.heartbeat(at=t(-1))
    DOCS["N2"] = I.issue(issued_at=t(0), not_after=t(6))


def build_writes():
    W = WRITES
    W["alpha_k1"] = message("lab:alpha", S["alpha-k1"], key_id="k1", epoch=1,
                            text="alpha k1의 글", at=t(0))
    W["alpha_k2"] = message("lab:alpha", S["alpha-k2"], key_id="k2", epoch=1,
                            text="alpha k2의 글", at=t(8))
    W["beta_k1"] = message("lab:beta", S["beta-k1"], key_id="k1", epoch=1,
                           text="beta의 글", at=t(0))
    W["gamma_k1"] = message("lab:gamma", S["gamma-k1"], key_id="k1", epoch=1,
                            text="gamma의 글", at=t(0))
    W["sig_bad"] = message("lab:alpha", S["alpha-k1"], key_id="k1", epoch=1,
                           text="남의 키로 서명한 글", at=t(0), sign_seed=S["mallory"])
    body_bad = copy.deepcopy(W["alpha_k1"])
    body_bad["body_utf8"] = "본문을 바꿔치기한 글"
    W["body_bad"] = body_bad
    no_body = copy.deepcopy(W["alpha_k1"])
    no_body["body_utf8"] = None
    W["no_body"] = no_body
    gamma_body_bad = copy.deepcopy(W["gamma_k1"])
    gamma_body_bad["body_utf8"] = "gamma 본문 바꿔치기"
    W["gamma_body_bad"] = gamma_body_bad
    schema_bad = copy.deepcopy(W["alpha_k1"])
    del schema_bad["envelope"]["created_at"]
    schema_bad["sig"] = iz.sign_envelope(schema_bad["envelope"], S["alpha-k1"])
    W["schema_bad"] = schema_bad


# ── 기대값 모양(계약 문구에서) ────────────────────────────────────────────────

def adopt(doc, *, start=None, ena=None, events=()):
    e = {"events": list(events), "adopted": True, "snapshot_id": sid(doc)}
    if start is not None:
        e["anchor_start"] = start
    if ena is not None:
        e["effective_not_after"] = ena
    return e


def keep(events, doc):
    return {"events": list(events), "adopted": False, "snapshot_id": sid(doc)}


def ignored(status, doc):
    """I6: 채택·상태 전이 없이 관측만 남긴다."""
    return {"events": [], "adopted": False, "ignored": status,
            "observed": {"kind": "trust.input_ignored", "status": status,
                         "snapshot_id": sid(doc), "tree_size": dT(doc)}}


def wok(doc):
    return {"ok": True, "accepted_under": {"issuer": ISS, "snapshot_id": sid(doc),
                                           "tree_size": dT(doc), "root": droot(doc)}}


def werr(code, **extra):
    return {"ok": False, "code": code, "retry": RETRY[code], **extra}


def rb_ok(doc, *, start, ena, reason="genesis", prior=None, first=None, events=()):
    return {"ok": True, "events": list(events), "snapshot_id": sid(doc),
            "anchor_start": start, "effective_not_after": ena,
            "audit": {"kind": "trust.rebaselined", "reason": reason,
                      "prior_snapshot_id": prior, "snapshot_id": sid(doc),
                      "tree_size": dT(doc), "root": droot(doc)},
            "marker": {"kind": "trust.initialized", "issuer": ISS,
                       "first_snapshot_id": first or sid(doc)}}


RB_FAIL = {"ok": False}


class V:
    def __init__(self, name, *, kind, refs, purpose, params=P_STD, pinned=PINNED,
                 honest_limit=None, history=None):
        self.meta = {"vector": name, "contract": CONTRACT, "kind": kind, "refs": refs,
                     "purpose": purpose, "params": params, "params_note": PARAMS_NOTE,
                     "pinned": pinned}
        if honest_limit:
            self.meta["honest_limit"] = honest_limit
        if history:
            self.meta["history"] = dict(history, record=RECORD_V0_4)
        self.docs, self.writes, self.steps = {}, {}, []

    def _step(self, st):
        self.steps.append(st)
        return self

    def boot(self, status, events=()):
        return self._step({"op": "boot", "expect": {"status": status, "events": list(events)}})

    def offer(self, name, now, expect):
        self.docs[name] = DOCS[name]
        return self._step({"op": "offer", "doc": name, "now": now, "expect": expect})

    def check(self, now, events):
        return self._step({"op": "check", "now": now, "expect": {"events": list(events)}})

    def write(self, name, now, expect):
        self.writes[name] = WRITES[name]
        return self._step({"op": "write", "write": name, "now": now, "expect": expect})

    def rebaseline(self, name, now, expect, *, reason="genesis", declared=None):
        doc = DOCS[name]
        self.docs[name] = doc
        dec = {"snapshot_id": sid(doc), "tree_size": dT(doc), "root": droot(doc)}
        dec.update(declared or {})
        return self._step({"op": "rebaseline", "doc": name, "now": now, "reason": reason,
                           "operator": "operator:fixture", "declared": dec,
                           "expect": expect})

    def mutate(self, action):
        self.steps.append({"op": "mutate", "action": action})
        return self

    def to_json(self) -> dict:
        return dict(self.meta, documents=self.docs, writes=self.writes, steps=self.steps)


# ── 벡터 ─────────────────────────────────────────────────────────────────────

def vectors() -> list:
    D = DOCS
    out = []

    v = V("00-boot-genesis", kind="contract", refs=["§4.2", "§4.3 0"],
          purpose="빈 저장소: 서비스는 첫 기동을 스스로 선언하지 않는다. 판은 무시되고 쓰기는 "
                  "trust_unavailable. 운영자 재기준화(genesis)만 연다. 선언 불일치·이유 누락은 거부.")
    (v.boot("uninitialized")
      .offer("A3", t(0), ignored("uninitialized", D["A3"]))
      .write("alpha_k1", t(0), werr("trust_unavailable"))
      .rebaseline("A3", t(0), RB_FAIL, declared={"tree_size": 4})
      .rebaseline("A3", t(0), RB_FAIL, reason="first")
      .rebaseline("A3", t(0), rb_ok(D["A3"], start=t(0), ena=t(6)))
      .write("alpha_k1", t(0, 5), wok(D["A3"])))
    out.append(v)

    v = V("01-snapshot-invalid", kind="contract", refs=["§4.1 ①"],
          purpose="문서 내부 모순 열넷: 서명·기준점 서명·정렬·발급자 결속·좌표 정합·시각·prev 크기·"
                  "pubkey 중복·logged(이 참조 구현 범위 밖)·고정 발급자·폐기 순서·스키마·여분 키. "
                  "전부 snapshot_invalid이고 직전 판을 계속 쓴다.")
    v.rebaseline("A3", t(0), rb_ok(D["A3"], start=t(0), ena=t(6)))
    for name in ("inv_tampered", "inv_anchor_sig", "inv_unsorted", "inv_issuer_pub",
                 "inv_coord", "inv_times", "inv_since", "inv_prev_size", "inv_dup_pub",
                 "inv_logged", "inv_not_pinned", "inv_revoked_order", "inv_schema",
                 "inv_extra_key"):
        v.offer(name, t(1), keep(["snapshot_invalid"], D["A3"]))
    v.write("alpha_k1", t(1), wok(D["A3"]))
    out.append(v)

    v = V("02-snapshot-fork", kind="contract", refs=["§4.1 ②"],
          purpose="갈라짐 다섯: 같은 T 다른 root · 같은 T·root 다른 bindings · prev의 저장 id 항목 root "
                  "불일치 · 일관성 증명 불성립 · prev가 저장 판의 크기를 다르게 적음(저장 id 항목 우선 "
                  "대조가 잡는다). 그다음 정상 확장.")
    (v.rebaseline("A3", t(0), rb_ok(D["A3"], start=t(0), ena=t(6)))
      .offer("G3", t(0, 30), keep(["snapshot_fork"], D["A3"]))
      .offer("A3_nobeta", t(0, 40), keep(["snapshot_fork"], D["A3"]))
      .offer("A3b", t(5), adopt(D["A3b"], start=t(0), ena=t(11)))
      .offer("B6_badroot", t(8), keep(["snapshot_fork"], D["A3b"]))
      .offer("B6_badproof", t(8, 10), keep(["snapshot_fork"], D["A3b"]))
      .offer("B6_badsize", t(8, 15), keep(["snapshot_fork"], D["A3b"]))
      .offer("B6", t(8, 20), adopt(D["B6"], start=t(8), ena=t(14))))
    out.append(v)

    v = V("03-snapshot-rollback", kind="contract", refs=["§4.1 ②"],
          purpose="새 T < 저장 T는 무시하고 직전 판을 쓴다.")
    (v.rebaseline("A3", t(0), rb_ok(D["A3"], start=t(0), ena=t(6)))
      .offer("A3b", t(5), adopt(D["A3b"], start=t(0), ena=t(11)))
      .offer("B6", t(8), adopt(D["B6"], start=t(8), ena=t(14)))
      .offer("A3b", t(8, 10), keep(["snapshot_rollback"], D["B6"]))
      .write("alpha_k2", t(8, 15), wok(D["B6"])))
    out.append(v)

    v = V("04-snapshot-gap", kind="contract", refs=["§4.1 ②", "§4.1 표"],
          purpose="판을 놓쳤고 새 판의 prev 목록에 저장 판이 없다: gap. 직전 판은 만료 전까지만 쓴다.",
          honest_limit="gap 동안 서비스는 직전 판(T=3)으로 판정한다. 그사이 원장에서 폐기된 alpha k1이 "
                       "만료 전까지 통과한다 — 계약이 허용한 창이고 상한은 effective_not_after다.")
    (v.rebaseline("A3_20", t(0, 30), rb_ok(D["A3_20"], start=t(0), ena=t(20)))
      .offer("C8_k1", t(10), keep(["snapshot_gap"], D["A3_20"]))
      .write("alpha_k1", t(10), wok(D["A3_20"]))
      .check(t(20), ["snapshot_expired"])
      .write("alpha_k1", t(20), werr("trust_unavailable")))
    out.append(v)

    v = V("05-f2-missed-reissue", kind="contract", refs=["§4.1 ②", "§2 prev"],
          purpose="같은 T 재발급을 놓친 서비스. 발급자 목록(k=1)은 마지막 재발급만 싣는다. 저장 id는 "
                  "목록에 없지만 같은 크기·같은 root 항목이 있고 일관성 증명이 선다 — 확장으로 채택한다.",
          honest_limit="이 확장 확인은 로그 확장만 본다. 놓친 동일 T 판의 bindings가 저장 판과 같았는지, "
                       "발급자 표가 완전한지는 증명하지 않는다.",
          history={"finding": "F2", "v0_4": "snapshot_gap으로 거부하고 저장 판 A3_20을 계속 써서 "
                                             "폐기된 alpha k1이 통과했다"})
    (v.rebaseline("A3_20", t(0, 30), rb_ok(D["A3_20"], start=t(0), ena=t(20)))
      .offer("B6_k1", t(8), adopt(D["B6_k1"], start=t(8), ena=t(14)))
      .write("alpha_k1", t(8, 5), werr("key_revoked", revoked_at_seq=6)))
    out.append(v)

    v = V("06-snapshot-expired", kind="contract", refs=["§4.1 ③", "§4.2"],
          purpose="effective_not_after 경계(now < ena만 쓸 판). 만료는 상태 유실이 아니다 — 같은 T "
                  "재발급이 오면 재기준화 없이 다시 연다.")
    (v.rebaseline("A3", t(0), rb_ok(D["A3"], start=t(0), ena=t(6)))
      .check(t(5, 59, 59), [])
      .write("alpha_k1", t(5, 59, 59), wok(D["A3"]))
      .check(t(6), ["snapshot_expired"])
      .write("alpha_k1", t(6), werr("trust_unavailable"))
      .offer("A3b", t(6, 10), adopt(D["A3b"], start=t(0), ena=t(11)))
      .write("alpha_k1", t(6, 15), wok(D["A3b"])))
    out.append(v)

    v = V("07-trust-state-lost", kind="contract", refs=["§4.2"],
          purpose="표지는 있는데 last_accepted가 없다: 유실. 판정 중단, 새 판 무시, 재기준화(recovery) "
                  "뒤에만 연다. 표지는 첫 채택 때의 것이 남는다.")
    (v.rebaseline("A3", t(0), rb_ok(D["A3"], start=t(0), ena=t(6)))
      .mutate("drop_last_accepted")
      .boot("lost", ["trust_state_lost"])
      .offer("A3b", t(5), ignored("lost", D["A3b"]))
      .write("alpha_k1", t(5), werr("trust_unavailable"))
      .rebaseline("A3b", t(5, 10), rb_ok(D["A3b"], start=t(0), ena=t(11), reason="recovery",
                                          first=sid(D["A3"])), reason="recovery")
      .write("alpha_k1", t(5, 15), wok(D["A3b"])))
    out.append(v)

    v = V("08-lost-variants", kind="contract", refs=["§4.2"],
          purpose="유실의 다른 모양 셋: 저장 판 서명 깨짐 · anchor_start 유실(126) · 상태는 있는데 "
                  "표지가 없음. 셋째는 계약 표 밖이라 이 참조 구현의 해석(유실로 본다)이다.")
    (v.rebaseline("A3", t(0), rb_ok(D["A3"], start=t(0), ena=t(6)))
      .mutate("corrupt_signature").boot("lost", ["trust_state_lost"])
      .rebaseline("A3", t(0, 10), rb_ok(D["A3"], start=t(0), ena=t(6), reason="recovery"),
                  reason="recovery")
      .mutate("drop_anchor_start").boot("lost", ["trust_state_lost"])
      .rebaseline("A3", t(0, 20), rb_ok(D["A3"], start=t(0), ena=t(6), reason="recovery"),
                  reason="recovery")
      .mutate("drop_marker").boot("lost", ["trust_state_lost"]))
    out.append(v)

    v = V("09-store-unreachable", kind="contract", refs=["§4.2"],
          purpose="저장소가 닿지 않으면 판정 중단(wait). 돌아오면 재기준화 없이 그대로 재개.")
    (v.rebaseline("A3", t(0), rb_ok(D["A3"], start=t(0), ena=t(6)))
      .mutate("unreachable").boot("unreachable")
      .write("alpha_k1", t(1), werr("trust_unavailable"))
      .offer("A3b", t(5), ignored("unreachable", D["A3b"]))
      .mutate("reachable").boot("ok")
      .write("alpha_k1", t(5, 5), wok(D["A3"])))
    out.append(v)

    v = V("10-writer-errors", kind="contract", refs=["§4.3"],
          purpose="글쓴이 오류 여섯의 판정과 순서(본문 → 서명자 → 서명 → 폐기). after_curation: 같은 "
                  "bytes가 도입 판 채택 뒤에 통과한다. 폐기 전파: 판이 폐기를 싣기 전에는 통과한다.",
          honest_limit="alpha k1은 원장 seq5에서 폐기됐지만 서비스가 B6을 채택하기 전(T=3 판)에는 "
                       "통과한다 — §6의 전파 창.")
    (v.rebaseline("A3", t(0), rb_ok(D["A3"], start=t(0), ena=t(6)))
      .write("schema_bad", t(0, 5), werr("schema_invalid"))
      .write("body_bad", t(0, 5), werr("body_mismatch"))
      .write("no_body", t(0, 5), werr("body_mismatch"))
      .write("gamma_body_bad", t(0, 5), werr("body_mismatch"))
      .write("gamma_k1", t(0, 5), werr("unknown_signer"))
      .write("sig_bad", t(0, 5), werr("signature_invalid"))
      .write("alpha_k1", t(0, 5), wok(D["A3"]))
      .write("beta_k1", t(0, 5), wok(D["A3"]))
      .offer("A3b", t(5), adopt(D["A3b"], start=t(0), ena=t(11)))
      .offer("B6", t(8), adopt(D["B6"], start=t(8), ena=t(14)))
      .write("alpha_k1", t(8, 5), werr("key_revoked", revoked_at_seq=6))
      .write("sig_bad", t(8, 5), werr("signature_invalid"))
      .write("alpha_k2", t(8, 5), wok(D["B6"]))
      .offer("C8", t(10), adopt(D["C8"], start=t(10), ena=t(16)))
      .write("beta_k1", t(10, 5), werr("key_revoked", revoked_at_seq=8))
      .write("gamma_k1", t(10, 5), werr("unknown_signer"))
      .offer("E10", t(12), adopt(D["E10"], start=t(12), ena=t(18)))
      .write("gamma_k1", t(12, 5), wok(D["E10"])))
    out.append(v)

    v = V("11-missed-extend", kind="contract", refs=["§4.1 ②", "§2 prev"],
          purpose="판 하나(B6)를 놓쳐도 새 판의 prev 목록에 저장 판이 있으면 확장을 확인한다.")
    (v.rebaseline("A3", t(0), rb_ok(D["A3"], start=t(0), ena=t(6)))
      .offer("A3b", t(5), adopt(D["A3b"], start=t(0), ena=t(11)))
      .offer("C8", t(10), adopt(D["C8"], start=t(10), ena=t(16)))
      .write("beta_k1", t(10, 5), werr("key_revoked", revoked_at_seq=8)))
    out.append(v)

    v = V("12-expired-then-fork", kind="contract", refs=["§4.1 표"],
          purpose="직전 판이 만료된 뒤 갈라진 판이 오면 fork와 expired가 함께 나고 판정은 멈춘다.")
    (v.rebaseline("A3", t(0), rb_ok(D["A3"], start=t(0), ena=t(6)))
      .check(t(6), ["snapshot_expired"])
      .offer("G3", t(6, 30), keep(["snapshot_fork", "snapshot_expired"], D["A3"]))
      .write("alpha_k1", t(6, 30), werr("trust_unavailable")))
    out.append(v)

    v = V("13-long-not-after", kind="contract", refs=["§4.2"],
          purpose="발급자가 not_after를 30일로 적어도 서비스 상한(issued_at + service_max_ttl)이 이긴다.")
    (v.rebaseline("A3", t(0), rb_ok(D["A3"], start=t(0), ena=t(6)))
      .offer("A3_long", t(1), adopt(D["A3_long"], start=t(0), ena=t(25)))
      .check(t(24, 59, 59), [])
      .check(t(25), ["snapshot_expired"]))
    out.append(v)

    v = V("14-same-t-reissue-bounded", kind="contract", refs=["§4.2", "§7"],
          purpose="같은 T 재발급을 거듭 받아도 effective_not_after는 anchor_start + anchor_max_age에 "
                  "묶인다. 상한을 넘긴 재발급은 채택돼도 닫힌 채다. T가 전진하면 anchor_start를 다시 잡는다.")
    (v.rebaseline("A3", t(0), rb_ok(D["A3"], start=t(0), ena=t(6)))
      .offer("R5", t(5), adopt(D["R5"], start=t(0), ena=t(25)))
      .offer("R24", t(24), adopt(D["R24"], start=t(0), ena=t(44)))
      .offer("R43", t(43), adopt(D["R43"], start=t(0), ena=t(48)))
      .check(t(47, 59, 59), [])
      .check(t(48), ["snapshot_expired"])
      .offer("R49", t(49), adopt(D["R49"], start=t(0), ena=t(48), events=["snapshot_expired"]))
      .write("alpha_k1", t(49), werr("trust_unavailable"))
      .offer("D4", t(50), adopt(D["D4"], start=t(50), ena=t(56)))
      .write("alpha_k1", t(50, 5), wok(D["D4"])))
    out.append(v)

    v = V("15-anchor-since-one-way", kind="contract", refs=["§2 anchor_since", "§4.2"],
          purpose="같은 T 재발급의 anchor_since를 늦춰 적어도 anchor_start는 움직이지 않는다. 더 이르게 "
                  "적으면 이른 쪽으로만 움직인다.")
    (v.rebaseline("A3", t(0), rb_ok(D["A3"], start=t(0), ena=t(6)))
      .offer("R5", t(5), adopt(D["R5"], start=t(0), ena=t(25)))
      .offer("R24", t(24), adopt(D["R24"], start=t(0), ena=t(44)))
      .offer("R40_late", t(40), adopt(D["R40_late"], start=t(0), ena=t(48)))
      .offer("R41_early", t(41), adopt(D["R41_early"], start=t(-10), ena=t(38),
                                        events=["snapshot_expired"])))
    out.append(v)

    v = V("16-rebaseline-old-anchor", kind="contract", refs=["§4.2", "§7"],
          purpose="재기준화로 이미 오래된 기준점을 받으면, 정직한 anchor_since가 나이를 드러내 곧바로 "
                  "닫힌다.")
    (v.boot("uninitialized")
      .rebaseline("R49", t(50), rb_ok(D["R49"], start=t(0), ena=t(48),
                                       events=["snapshot_expired"]))
      .write("alpha_k1", t(50), werr("trust_unavailable")))
    out.append(v)

    v = V("17-limit-anchor-since-hidden", kind="limit", refs=["§2 anchor_since", "§7"],
          purpose="같은 기준점을 anchor_since = 지금으로 적어 재기준화에 내면 나이가 숨는다. 기대 결과: "
                  "채택되고 열린다.",
          honest_limit="anchor_since는 발급자의 서명된 자기 선언이다. 발급자 키를 쥔 쪽에게는 증거가 "
                       "아니다. 첫 채택·재기준화 이전의 나이는 독립 최신 헤드 대조나 감사 없이는 못 잡는다.")
    (v.boot("uninitialized")
      .rebaseline("R49_hide", t(50), rb_ok(D["R49_hide"], start=t(49), ena=t(69)))
      .write("alpha_k1", t(50), wok(D["R49_hide"])))
    out.append(v)

    for name, purpose, steps in (
        ("18-heartbeat-just-before",
         "anchor_max_age 바로 앞에 heartbeat 판이 도착한다. 서비스는 한 번도 닫히지 않는다.",
         lambda v: (v.offer("H4a", t(29, 59, 59), adopt(D["H4a"], start=t(29, 59),
                                                        ena=t(37, 59)))
                    .check(t(30), [])
                    .write("alpha_k1", t(30), wok(D["H4a"])))),
        ("19-heartbeat-just-after",
         "발급이 늦어 heartbeat 판이 anchor_max_age 경계에 도착한다. 그 순간 닫히고, 판이 오면 "
         "재기준화 없이 다시 연다. 계약 위반이 아니라 정직한 발급자의 가용성 사고다.",
         lambda v: (v.check(t(30), ["snapshot_expired"])
                    .write("alpha_k1", t(30), werr("trust_unavailable"))
                    .offer("H4b", t(30), adopt(D["H4b"], start=t(30), ena=t(38)))
                    .write("alpha_k1", t(30), wok(D["H4b"])))),
        ("20-poll-late",
         "발급은 제때(t+28h)인데 서비스 폴링이 늦어 경계를 넘긴다. 지연 항은 추정이 아니라 관측한 "
         "최악값으로 채워야 하는 이유.",
         lambda v: (v.check(t(30), ["snapshot_expired"])
                    .offer("H4c", t(30, 30), adopt(D["H4c"], start=t(28), ena=t(36)))
                    .write("alpha_k1", t(30, 30), wok(D["H4c"])))),
    ):
        v = V(name, kind="contract", refs=["§7 측정 조건", "§10"], params=P_DELAY,
              purpose=purpose + " (anchor_max_age 30h, 재발급 6h 주기)")
        (v.rebaseline("Q18", t(18), rb_ok(D["Q18"], start=t(0), ena=t(26)))
          .offer("Q24", t(24), adopt(D["Q24"], start=t(0), ena=t(30))))
        steps(v)
        out.append(v)

    v = V("21-skew-boundary", kind="contract", refs=["§4.1 ①", "§5"],
          purpose="issued_at이 서비스 시각 + 허용 오차(300s)면 받고, 1초 넘으면 snapshot_invalid.")
    (v.rebaseline("A3", t(0), rb_ok(D["A3"], start=t(0), ena=t(6)))
      .offer("A3_skew_bad", t(1), keep(["snapshot_invalid"], D["A3"]))
      .offer("A3_skew_ok", t(1), adopt(D["A3_skew_ok"], start=t(0), ena=t(7))))
    out.append(v)

    v = V("22-limit-old-copy-fork", kind="limit", refs=["§1 5", "§7"],
          purpose="옛 원장 사본(T=6)과 발급자 키를 쥔 쪽이 새 attest로 T를 7로 전진시킨 판. 저장 판(B6)"
                  "에서의 일관성 증명이 서므로 단일 서비스는 채택한다. 진짜 원장의 다음 판은 gap으로 보인다.",
          honest_limit="진짜 원장은 seq7에서 beta k1을 폐기했다. 갈라진 줄기의 판은 그 폐기를 모른다. "
                       "독립 최신 헤드 대조(v0 밖 다음 층) 없이는 이 계약이 잡지 못한다. outside_v0에 "
                       "같은 크기 두 트리 헤드의 detect_fork 결과를 적었다.")
    (v.rebaseline("A3", t(0), rb_ok(D["A3"], start=t(0), ena=t(6)))
      .offer("A3b", t(5), adopt(D["A3b"], start=t(0), ena=t(11)))
      .offer("B6", t(8), adopt(D["B6"], start=t(8), ena=t(14)))
      .offer("X7", t(9, 10), adopt(D["X7"], start=t(9, 10), ena=t(15)))
      .write("beta_k1", t(9, 15), wok(D["X7"]))
      .offer("C8", t(10), keep(["snapshot_gap"], D["X7"])))
    v.meta["outside_v0"] = {"detect_fork": {
        "live_tree_head": EXTRA["live_sth7"], "fork_tree_head": D["X7"]["body"]["anchor"],
        "expect_fork": True,
        "note": "같은 발급자 키로 서명된 같은 크기(7)의 두 트리 헤드가 root가 다르다 — "
                "다른 경로로 받은 헤드가 있으면 hub_log.detect_fork가 갈라짐으로 판정한다."}}
    out.append(v)

    v = V("23-expired-on-arrival", kind="contract", refs=["§4.1 ②③"],
          purpose="①②를 모두 통과한 새 T 판이 도착 시 이미 만료돼 있다. 채택하고 서명 쓰기를 곧바로 "
                  "닫는다(I1). 무효 판에는 직전 판 유지 규칙이 그대로다.",
          honest_limit="직전 판 A3_20은 t+20h까지 유효하지만 T=3이라 alpha k1 폐기(seq5)를 모른다. 직전 판을 "
                       "계속 썼다면 폐기된 키가 통과했다.")
    (v.rebaseline("A3_20", t(0, 30), rb_ok(D["A3_20"], start=t(0), ena=t(20)))
      .offer("B6_short", t(12), adopt(D["B6_short"], start=t(8), ena=t(10),
                                      events=["snapshot_expired"]))
      .write("alpha_k1", t(12), werr("trust_unavailable")))
    out.append(v)

    v = V("24-f1-introduced-at-anchor", kind="contract",
          refs=["§2 valid_from_seq", "§4.1 ①"],
          purpose="기준점 T가 signer.introduced 사건 좌표와 같다(도입 직후 발급). 새 결속의 "
                  "valid_from_seq는 T+1이다. 판정 좌표 T+1에서 정직한 판이 선다.",
          history={"finding": "F1", "v0_4": "① valid_from_seq ≤ T에 걸려 재기준화가 실패하고 쓰기는 "
                                             "trust_unavailable였다"})
    (v.boot("uninitialized")
      .rebaseline("P1", t(0), rb_ok(D["P1"], start=t(0), ena=t(6)))
      .write("alpha_k1", t(0, 5), wok(D["P1"])))
    out.append(v)

    v = V("25-f1-revocation-at-anchor", kind="contract",
          refs=["§2 revoked_at_seq", "§4.1 ①", "§4.3 5"],
          purpose="기준점 T가 key.revoked 사건 좌표와 같다(폐기 직후 발급 — 전파가 가장 급한 순간). "
                  "revoked_at_seq는 T+1이다. 판정 좌표 T+1에서 판이 채택되고 폐기가 곧바로 전파된다.",
          honest_limit="① 경계만 T+1로 풀고 §4.3을 revoked_at_seq ≤ T로 두는 반쪽 교정은 이 판을 채택한 "
                       "뒤 폐기된 키를 통과시킨다. v0.5는 셋(활성·좌표 범위·key_revoked)을 한 묶음으로 바꾼다.",
          history={"finding": "F1", "v0_4": "P3가 snapshot_invalid였고 서비스가 P2로 남아 폐기된 "
                                             "alpha k1이 t+2h15m에 통과했다"})
    (v.boot("uninitialized")
      .rebaseline("P2", t(1), rb_ok(D["P2"], start=t(1), ena=t(7)))
      .write("alpha_k1", t(1, 5), wok(D["P2"]))
      .offer("P3", t(2, 10), adopt(D["P3"], start=t(2, 10), ena=t(8, 10)))
      .write("alpha_k1", t(2, 15), werr("key_revoked", revoked_at_seq=4))
      .offer("P4", t(3, 10), adopt(D["P4"], start=t(3, 10), ena=t(9, 10)))
      .write("alpha_k1", t(3, 15), werr("key_revoked", revoked_at_seq=4)))
    out.append(v)

    v = V("26-f3-empty-ledger", kind="contract", refs=["§2 anchor", "§4.1 ①", "§7"],
          purpose="사건 없는 원장(T=0)의 판은 ①에서 거부된다. 크기 0 항목을 prev에 실은 판도 같다. "
                  "발급자는 첫 판 전에 살아 있는 원장에 heartbeat를 하나 쓴다 — 그 판(T=1)으로 연다.",
          honest_limit="이것은 발급자 의무의 경계다. 빈 저장소를 서비스가 스스로 genesis로 선언해도 된다는 "
                       "뜻이 아니다 — 재기준화는 여전히 운영자의 감사 가능한 행위다.",
          history={"finding": "F3", "v0_4": "Z0 재기준화가 성공한 뒤 Z1을 거짓 fork로 판정했다"})
    (v.boot("uninitialized")
      .rebaseline("Z0", t(0), RB_FAIL)
      .offer("Z1", t(1), ignored("uninitialized", D["Z1"]))
      .rebaseline("Z1c", t(1, 10), rb_ok(D["Z1c"], start=t(1), ena=t(7, 5))))
    out.append(v)

    v = V("27-source-domain", kind="contract", refs=["§3", "§4.1 ①"],
          purpose="발급자 키로 서명했어도 source_domain이 고정값과 정확히 같지 않으면 snapshot_invalid. "
                  "다른 lab · 빈 문자열 · 같은 lab의 다른 hub 셋.")
    v.rebaseline("A3", t(0), rb_ok(D["A3"], start=t(0), ena=t(6)))
    for name in ("sd_foreign", "sd_empty", "sd_other_hub"):
        v.offer(name, t(1), keep(["snapshot_invalid"], D["A3"]))
    v.write("alpha_k1", t(1, 5), wok(D["A3"]))
    out.append(v)

    v = V("28-source-domain-bare-name", kind="contract", refs=["§2 source_domain", "§3"],
          pinned=PINNED_BARE,
          purpose="source_domain이 bare name(`issuer/hub`)인 발급자. 운영 lab은 hub 도입 권한 파생과 같은 "
                  "규칙으로 bindings의 lab:issuer bootstrap 결속에서 파생한다.")
    (v.boot("uninitialized")
      .rebaseline("N2", t(0), rb_ok(D["N2"], start=t(0), ena=t(6)))
      .write("alpha_k1", t(0, 5), wok(D["N2"])))
    out.append(v)

    v = V("29-source-domain-pin-mismatch", kind="contract", refs=["§3", "§4.1 ①"],
          pinned=PINNED_OTHER,
          purpose="서비스 고정값(lab:other/hub)에서 파생한 운영 lab이 고정 발급자와 다르다. 배포 설정 "
                  "오류는 열리지 않는 쪽으로 닫힌다 — 고정값과 같은 문서도, 발급자의 정상 문서도 서지 않는다.")
    (v.boot("uninitialized")
      .rebaseline("sd_other_lab", t(0), RB_FAIL)
      .rebaseline("A3", t(0), RB_FAIL)
      .write("alpha_k1", t(0, 5), werr("trust_unavailable")))
    out.append(v)

    return out


def emit(out_dir: Path) -> dict:
    DOCS.clear(), WRITES.clear(), EXTRA.clear()
    build_main()
    build_f1()
    build_f3()
    build_bare()
    build_writes()
    out_dir.mkdir(parents=True, exist_ok=True)
    index = []
    for v in vectors():
        data = (json.dumps(v.to_json(), ensure_ascii=False, indent=1, sort_keys=True)
                + "\n").encode("utf-8")
        name = v.meta["vector"] + ".json"
        (out_dir / name).write_bytes(data)
        index.append({"file": name, "kind": v.meta["kind"],
                      "history": (v.meta.get("history") or {}).get("finding"),
                      "sha256": hashlib.sha256(data).hexdigest()})
    digest = hashlib.sha256("".join(f"{e['sha256']}  {e['file']}\n" for e in index)
                            .encode()).hexdigest()
    idx = {"contract": CONTRACT, "vectors": index, "digest": digest,
           "digest_rule": "sha256(각 줄 '<sha256>  <file>\\n'을 파일명 순으로 이은 bytes)"}
    (out_dir / "INDEX.json").write_bytes(
        (json.dumps(idx, ensure_ascii=False, indent=1) + "\n").encode("utf-8"))
    return idx


if __name__ == "__main__":
    target = Path(sys.argv[1]) if len(sys.argv) > 1 else HERE / "vectors"
    idx = emit(target)
    print(json.dumps({"vectors": len(idx["vectors"]), "digest": idx["digest"],
                      "out": str(target)}, ensure_ascii=False))
