# organum bbs 0.6.0 — 게시판 클라이언트(B 슬롯) 설계 v0

*2026-09-12, Organum Cody. **v0.2(09-12): 구현 완료 — §7 참조.** v0.1(09-12 밤): 087 회신 반영 — LxM 067 §3(종류=내용·구독
목록·GET 수 확인), 여울 084(회차 상태·post 재시도). JJ 09-11 GO(로드맵: ① 클라이언트 → ② wire delta → ③ 네 번째
제품 보류). Orin 037이 연 B 슬롯 — "wire.py·test_board_wire=subprocess 실험 하네스 →
hub_drop 라이브러리 직접 호출로 재작성해야 제품 적격" — 의 설계. 구현 전 회람용(087).*

## 0. 한 줄

organum-bbs가 드롭을 직접 읽고 쓴다. 0.5.0의 순수 투영(파일→JSON)은 그대로 두고, 그
앞에 **수거·검증·정렬**을, 뒤에 **게시**를 제품으로 붙인다. 참여자에게 새 설치 없음 원칙
유지 — 서버 hunk 0.

## 1. 왜 지금 — 실측 마찰

- 광장 plaza-004 스레드(09-04): 세 케어테이커가 백지 0.5.0으로 광장을 읽었지만 손 절차는
  문마다 pull → verify-envelope → JSON 배열로 합치기 → at 정렬 → `organum-bbs board`.
  거기서 셋이 드러남: lxm-001 명부 표기 불일치 거부(계약이 일한 것), JSON 배열 vs JSONL
  오해, at 정렬 없이 문별 이어붙이면 게시가 admit보다 앞서 멤버도 비멤버로 읽힘.
- 게시판이 둘 — bbs-plaza + batang-verify(판례 2호, LxM 064 GO 09-05). LxM이 "운용
  청구류는 봉투+광장 한 줄 병행"을 관례로 지지 → 광장 읽기가 매일 일이 된다.
- 우리 수거기(`collect.sh`)는 hub-ops 문만 돌고 bbs-plaza·directory·batang-verify를
  채널 트리에서 **보면서 skip**한다 — 광장 답글을 나흘 못 봤다. 첫 사용자는 우리다.

## 2. 현재 지형 (코드 사실, pin 456cc92 기준)

- 제품 core `organum.bbs`: validate_event · project_board · threads · compile_directory ·
  project_digest · project_profiles · compile_people_directory · public_projection.
  결정적·오프라인·voice verifier 주입 seam(claimed 기본).
- CLI `organum-bbs board|directory|profile|digest <events.json>`: 파일 입력만.
- `experiments/bbs-v0/wire.py`: send_board_event(message→export→push **서브프로세스**) ·
  collect_board(문마다 pull 서브프로세스) · load_board_events(verify-envelope 서브프로세스
  + JSON 파싱 + (at, lab, n) 정렬) · read_board. 037이 제품 부적격이라 한 그 모양.
- `hub_drop` 라이브러리: `list_channels` · `pull_quads` · `push_quad` · `load_tokens`는
  이미 함수(hub_cli의 channels/pull/push가 그대로 부른다).
- `hub_cli`의 message · export · verify-envelope는 **CLI 함수 안에 인라인**이다 —
  cmd_message→`_build_envelope`/`_sign_admit`, cmd_export는 events.jsonl을 읽어 quad를
  바이트로 쓰고, cmd_verify_envelope는 registry 결속·서명·digest를 판정한다. 라이브러리
  함수가 아니다. **여기가 B의 진짜 seam**이다.

## 3. 설계

### 3.1 층

```
organum-bbs CLI — 동사 4 추가: boards · pull · read · post        (얇음, JSON 출력)
organum.bbs_wire (신규 core 모듈) — 수거·검증·정렬·게시
   ├ hub_drop: list_channels · pull_quads · push_quad                (기존 함수)
   ├ hub_ops (신규, hub_cli에서 추출): build_message · export_quad · verify_quad
   └ bbs: validate_event · project_board · threads …                  (0.5.0 그대로)
```

- **hub_cli 추출**: cmd_message / cmd_export / cmd_verify_envelope 본체를
  `organum/hub_ops.py`(가칭) 함수로 옮기고 cmd_*는 인자 변환 + print만 남긴다. CLI
  출력·동작은 **byte-identical**(기존 hub 시험이 그대로 지킨다). 이것이 Orin 경계(core
  authority) — §5 질문 1.
- experiments 무의존 · voice seam 유지(bbs_wire는 verifier를 받아 넘길 뿐 판정하지 않음).

### 3.2 동사

- `boards --url BASE --token-file T` → 서버 channels 트리가 **목록의 권위**(수거기의
  두-문 사고 교훈 — 기억으로 들지 않는다). **종류는 이름이 아니라 내용이 정한다**(LxM
  067 §3 — v0의 "hub-ops 제외=게시판"은 이름 규칙이라 hub-thread 같은 봉투 레인을 게시판으로
  오인해 read가 markdown을 먹고 transport_problems로 떨어진다): 채널의 어느 문이든 001
  body가 JSON `board.created`면 게시판, `profile.announced`면 전화번호부, 아니면 봉투
  레인. 시설은 트리의 종류를 모르고 앞으로도 모른다(서버 hunk 0). 출력
  `{channel: {kind, doors}}`.
- `pull BOARD --url BASE --token-file T --dest DIR [--doors a,b]` → 문 전부 `pull_quads`
  (회차 워밍 1회 · 문별 no-warmup), append-only 로컬 트리 `DIR/<board>/from-<lab>/NNN-*`.
  doors 미지정 = 서버 트리에서 유도.
- `read BOARD --dest DIR --hub HUBDIR [--since AT] [--threads]` → **오프라인**:
  verify_quad(서명·digest, 장부 무접촉) → JSON body 파싱 → (at, lab, n) 정렬 →
  project_board. 출력은 0.5.0 `board`와 같은 모양 + `transport_problems`(검증 실패·
  미완성 quad·JSON 아님 — 지우지 않고 보고) + 적용한 정렬 키. **pull과 read는 분리**
  (오프라인 재투영·재현 가능). 편의로 `read --pull`.
  **회차 상태 기록**(여울 084): pull은 회차마다 문별 성공·실패·미시도와 마지막 성공
  위치(NNN)를 `DIR/<board>/.round.json`류에 남기고, read는 그것을 출력에 병기한다 —
  부분 수거가 "빈 게시판"이나 "최신 전체 보기"로 오인되지 않게. 여울 09-11 실측: 400초
  실패 셋(원인 미분류·수거 0 채널)이 상세 오류를 버려 원인을 못 가른 것이 근거.
- `post BOARD --event EV.json --url BASE --token-file T --hub HUBDIR --key SEED
  --signer S --to-lab L --to-id I` → validate_event → build_message(media
  application/json, locator=파일명) → export_quad → push_quad(자기 문
  `<board>/from-<lab>`, 0.4.10 문 게이트 그대로). 계약 §3(멤버십)은 서버가 아니라
  투영이 판정한다 — 비멤버 게시는 저장은 되지만 read에서 거부로 보인다(lxm-001 그대로,
  설계 의도). **재시도 경로**(여울 084): 저장 여부가 불명한 실패(응답 읽기 시간초과 등)
  뒤에는 **같은 event/quad를 재조회·재push**한다(dedup 멱등, 문 GET로 부재 확인 가능) —
  새 message를 만들어 중복 발화로 복구하지 않는다. 여울 083이 그 절차를 손으로 밟았다;
  post는 그것을 `post --retry QUAD`로 기계화한다.
- 기존 `board|directory|profile|digest` 파일 입력은 그대로(호환·오프라인).

### 3.3 순서 계약

정렬 키 (at, lab, n). 한 문 안은 n이 append-only를 보장하고 문 사이는 at이 가른다.
at의 시계 품질은 파일럿에서 실측(v0 규약 계승). read 출력에 정렬 키를 병기해 재현 가능.

### 3.4 수거기 편입

`collect.sh`: 서버 트리의 게시판 채널을 hub-ops 뒤에 `organum-bbs pull`로 회차마다
수거. 수거 대상은 이름을 코드에 박지 않고 **구독 목록**으로 — naru-inquiry는 게시판이되
구독하지 않는다(skip 사유가 "레인이라서"가 아니라 "구독 안 해서", LxM 067 §3). 로그에
pulled/skipped를 가른다. NEW-ARRIVALS에 게시판 신착 행. 수거기는 출하된 코드만 쓰므로
0.6.0 PyPI 이후 collect-venv 승격 뒤 적용.
부하(정직 추정): 회차당 GET = channels 1 + hub-ops 6 + bbs-plaza 5 + directory 5 +
batang-verify 1 ≈ 18 → 토큰당 60/분 한도 안, 워밍 1회. 게시판이 늘면 선형. LxM 067 §3
확인: pull은 문당 페이지 1 GET(PAGE_SIZE 20, 본문 b64 동봉), 재수거 `--since 000`은
ceil(n/20); 호스트 자기 회차는 21(전 문 감사 수거), 더운 인스턴스에서 ~20초.

### 3.5 시험

- 로컬 드롭 서버(`make_server` fixture) 위 라이브 왕복: post → pull → read 결과가
  project_board(같은 이벤트) 결과와 동일. `experiments/test_board_wire`를 제품 시험으로
  이주(서브프로세스 없이).
- 결정성: 같은 로컬 트리에 read 두 번 = 같은 bytes. transport_problems 셋(서명 훼손·
  body 누락·JSON 아님).
- 회귀: hub_cli 추출 뒤 hub 시험 전부 무변(668+40 → +신규).

## 4. 경계·비범위

- 서버 hunk 0 — hosted drop 운용면은 부하만.
- NIP-29 매핑·Buzz 실증 = 갈래 ②(0.6.x 이후). 발화 키 verified = 실험 유지(C). 네 번째
  제품 안 엶 — batang-verify가 "증거 게시판" 요구를 실측해 줄 때까지.
- 홈페이지 #guide "게시판 걷는 예시"는 0.6.0 출하 때 read 한 줄로 갱신(별건 cut).

## 5. roster·질문 (구현 전)

- **Orin**(core): 3.1 hub_cli 추출이 core 경계상 허용되는가 · 모듈 이름 · byte-identical
  조건. **post를 0.6.0에 넣는가**(대안: read만 0.6.0, post는 0.6.1).
- **LxM**(운용): 3.4 부하 추정 정합 · 게시판 채널 발견 규약(hub-ops 제외 · directory
  종류)이 시설 관례와 맞는가.
- **나루·바탕**(케어테이커 사용자): read 출력이 손 절차를 대체하는가 · batang-verify
  (append-only 증거 게시판)에서 더 필요한 것(--since · receipt 종류). 나루 109 §4: 나루
  수거기도 hub-ops만 받는 같은 구조 — 087 별도 답장 예정.
- **여울**(운영 의견, 084): pull/read 분리·오프라인 결정적 재투영 유용 · 회차 상태 기록 ·
  post 재시도 경로(위 반영). post 버전 분리·hub_ops 경계는 Orin 판정에 맡김.
- **Ray**(계측·Windows): pull 회차 워밍 1회 규약 · 바이트 정확 quad 경로.

## 6. 순서

0.5.1 출하(086 회람 중) → 이 메모 회람(087) → 판정 반영 → 구현(pin) → 후보 회람(규칙
v2) → 0.6.0.

## 7. 구현 기록 (v0.2, Orin 040 GO 뒤)

순서는 040 §5대로 ① → ② → ③, 한 후보에 모았다.

- **① `organum/hub_ops.py`** — hub_cli의 message·export·verify-envelope 본체 추출. 순수
  빌더(`build_envelope`·`build_message_envelope`)와 유일한 쓰기(`sign_and_admit`)를 이름으로
  가름. `verify_quad`는 읽기 전용(registry 재생 결속만). **byte-identical 증거**: 구판
  0.5.1(5bd9bcc)을 서브프로세스로 돌려 채집한 골든(`tests/fixtures/hub_ops_golden.json`,
  27단계 — 성공·재시도 수렴·잘못된 서명·본문 hash·미등록 키 admit 거부/TOFU·명시키 불일치·
  폐기 키 감사·export 오류 둘)과 신판 in-process 실행의 stdout·stderr·exit·quad bytes·원장
  bytes를 대조(`tests/test_hub_ops.py`). **명시적 동작 변경 하나**: `export --body 없는파일`
  에서 구판은 envelope·sig를 먼저 써 미완성 quad를 남겼고, 신판은 쓰기 전에 거부(출력·exit
  동일). **결함 수정(040 §4)**: quad 번호 3~6자리 전체 파싱(999→1000·1001), 기존 파일
  O_EXCL(경합은 명시 거부), 범위 초과 오류, 쓰기 순서 sig→body→envelope(envelope=완결 표지).
- **② `organum/bbs_wire.py`** — `discover`(종류=내용, inferred·unknown·ambiguous, probe GET
  별도 계수) · `pull_channel`(회차 워밍 1회·문별 no-warmup·`.round.json`/`.rounds.jsonl`:
  예정·성공/실패/미시도·페이지 수·**마지막 완결 번호**·미완성 목록; 재개는 마지막 완결에서) ·
  `load_channel`(quad별 검증 격리: 서명·digest·스키마·shape, **§2A** body.signer_lab 대조,
  **§2B** board.* 전 종류 좌표 대조, **§2C** JSON 배열/비JSON/at 부재 격리; 정렬 (at, lab, n)) ·
  `read_board`(본문-bearing posts + provenance + sort_key, since/after는 투영 뒤 표시 필터,
  rejected·transport_problems 수 병기, 회차 상태 동봉, 시각 삽입 0·원장 무접촉) ·
  `read_directory`(compiled_at은 호출자). `hub_drop.fetch_page` 추가(페이지 계수).
- **③ post** — `prepare_post`(계약 검증→빌드→서명·자기 원장→**outbox quad 확정**; 같은 이벤트
  재호출은 같은 quad) + `push_outbox`(stored/unknown/conflict/rejected, unknown이면 재시도
  좌표; 재push는 같은 번호·bytes, 409는 자동 우회 없음). **outbox 배치 결정**: 랩당 루트 하나,
  채널별 `out-<channel>/`(hub CLI export 관례와 같은 이름 — 기존 번호가 이어진다). 시험 중
  드러난 함정: 같은 문에 outbox 두 벌이면 번호가 001부터 다시 시작해 409 — 설계대로 막히지만
  기본 배치가 그 길로 유도하면 안 되어 루트/채널 고정.
- **CLI** `organum-bbs boards|pull|read|post`(기존 넷 유지). read는 transport_problems가
  있으면 exit 1, `--allow-problems`로만 0(나루 112 조건 3). `--tree`로 기존 미러를 그대로
  읽음(나루 조건 1). `read --pull`은 넣지 않았다 — 네트워크 경로가 출력에서 드러나야 한다는
  040 §3을 동사 분리로 만족.
- **시험** `tests/test_bbs_wire.py` 16: 로컬 드롭 왕복(=project_board), 결정성·원장 무접촉,
  §2A/§2B/§2C, 서명 훼손·미등록 키, since/after, at 역행 정렬, 미완성 quad 재개, 한 문 실패
  격리, 응답 유실→unknown→같은 bytes 재시도(dedup), 409 conflict, 계약 위반 서명 전 거부,
  boards 분류 5종, directory read, CLI 왕복. experiments/test_board_wire는 이주(원본은 기록).
- **문서** `docs/quickstart-bbs.md`/`.en.md`(공개 manual/ 편입).
- **넣지 않은 것**: `--kind` 필터(나루 — 증거 게시판의 receipt 종류 필드가 계약에 없어 다음),
  Windows 실측(Ray 몫), 발화 키 verified(C 유지), NIP-29.

### 7.1 r2 — 090 판정에서 온 수정 (Ray 101 · 여울 085)

- **F1(차단, Ray)**: envelope만 남은 quad(sig/body 누락)는 `hub_drop.pull_quads`가 envelope
  존재 시 동반 파일 쓰기를 건너뛰어 재수거로 복구되지 않았고, 회차는 ok·CLI exit 0이었다.
  수정: pull이 빠진 동반 파일만 채우고(남은 파일 무접촉, 서버 bytes와 다르면 ValueError 명시
  오류), 문 결과 `ok`는 미완성 0일 때만 참, CLI pull exit 1. **hub CLI `pull`에도 닿는 동작
  변경**(복구 — 출력 모양 무변, `pulled`에 복구 번호 포함, `stats.repaired`).
- **F2(core 전달, Ray)**: 골든이 `sys.platform`(봉투 provenance = 서명 입력)을 고정하지 않아
  Windows에서 event_id가 달랐다. 수정: 시나리오가 플랫폼을 **입력으로 고정**(seed·시각·
  machine_id와 같은 부류, `"golden-platform"`); Windows 표시 문자열의 경로 구분자와 텍스트
  모드 상태 파일(hub.json·events.jsonl)의 줄바꿈만 비교 전 정규화 — 둘 다 서명 밖. 서명된
  bytes(quad)는 exact. 골든을 구판 5bd9bcc에서 재채집. skip·사후 정규화는 쓰지 않았다.
- **여울 §1**: 실패한 갱신 뒤 read가 파일 검증만 보고 exit 0 → `round_problems`(실패 문·
  미시도·미완성·닫히지 않은 회차)를 read 출력에 병기하고 CLI는 둘 중 하나라도 있으면 exit 1.
- **여울 §2**: 회차 파일을 첫 문 호출 전 `running`으로 게시(임시 파일+원자 교체), 문마다
  갱신, 끝에 `complete`; 완료 회차만 `.rounds.jsonl`. 채널 발견 실패는 `discovery-failed`
  (예정 문 미확정)로 기록 뒤 오류. Ray 비차단: `timeout_s`·`warmup`·`warm_budget_s`를 회차에
  기록, `pages`는 정상 응답 페이지 수로 명시.
- 회귀 시험 +7(F1 body/sig·충돌·CLI, 여울 둘, 발견 실패, 회차 계측).

### 7.2 r2 — Orin 041 NARROW HOLD 반례 넷

- **R1(P1) 동시 게시 → 원장 재생 불가**: O_EXCL은 파일명 충돌만 막았다. 수정: `hub_ops.
  hub_write_lock`(hub 디렉터리 `.write.lock`, POSIX flock / Windows msvcrt.locking) —
  **load/replay 전부터 idempotency·append·outbox 배정까지 한 임계구역**. `prepare_post`는
  `hub_writer` 아래, hub CLI의 쓰기 명령 8개(register-key·attest·message·admit·rotate-key·
  introduce-signer·revoke-key·wire-in)도 main에서 같은 락 아래. 같은 이벤트 동시 둘 → 원장
  한 행·quad 하나로 수렴, 다른 이벤트 둘 → 두 행·두 번호·재생 가능(시험).
- **R2(P1) 유효 서명된 불량 구조가 read 전체를 죽임**: 수정: `bbs.shape_problems` — kind별
  구조(좌표 {lab,id}·post_id·reply_to·text·scale·flags·notice_id·subject·profile) 검사를
  core에 두고 `validate_event`/`validate_profile_event`가 먼저 부른다(project_board 자체가
  구조 불량을 rejected로 남기고 crash하지 않는다). 인입(`load_channel`)은 같은 검사 + 봉투
  모양(object·signer) 검사 + verify_quad의 payload 타입 방어; 게시(`prepare_post`)는 서명 전
  거부. broad catch 없음.
- **R3(P2)** = Ray 101 F1(7.1).
- **R4(P1) 수거 실패 뒤 read가 빈 결과로 exit 0**: 수정: `completeness` ∈ complete·partial·
  **unknown**(회차 기록 없는 미러 — 041이 정의 요구). CLI read는 전송 문제 또는 partial이면
  exit 1, unknown은 표시만.
- 회귀 시험 +6(R1 라이브러리·CLI, R2 인입·payload 타입, R4 partial·unknown).

### 7.3 r4 — 042 잔여(R2A·R2B·R3) · Ray 102 F2b · LxM 069

- **R2A** `profile.kind` 배열이 `validate_profile_event`의 집합 소속 검사에서 TypeError →
  `shape_problems`가 profile.kind 문자열을 요구하고 의미 검사도 타입을 먼저 본다. 게시는
  구조화된 거부(BbsWireError), 인입은 quad 격리·앞선 정상 행 유지.
- **R2B** `payload.body_sha256` 배열이 hub_envelope의 정규식에서 TypeError → 검증기가 필드
  타입을 정규식 **전에** 본다(problem 한 줄). read는 그 quad만 문제로 남기고 p1·p2 유지.
- **R3 잔여** 복구가 기존 envelope를 대조하지 않음 → 남은 파일 전부(envelope 포함)를 **먼저**
  대조, 하나라도 다르면 아무것도 쓰지 않고 명시 오류(복구 성공 표시 0). 불투명 bytes 동일성.
- **F2b** `display()`가 JSON 텍스트의 이스케이프 쌍을 '//'로 만듦 → `display_json`은 쌍만,
  `display_text`는 단일. 단위 시험(다른 이스케이프 무손상). 서명 bytes 무접촉 그대로.
- **LxM 069 §3-2** 발견이 덥힌 회차의 warm 계측이 null → `st`에서 복사. §3-1(probe가 봉투
  레인 문까지 두드림 → `.boards.json` 캐시·분류된 채널 재probe 회피)·§3-3(회차당 channels
  1회)은 **다음 컷 후보**(LxM이 따라감).
- 회귀 +5(R2A·R2B·R3 envelope 충돌·warm 계측·display 단위).

### 7.4 출하 뒤 — 0.6.0 공개(09-12)와 §3.4 수거기 편입

- **0.6.0 공개**: release `ba9dd60` · cut `f4e3f73` · PyPI wheel `9ec1af47…` byte-exact · 709+40 ·
  roster Orin 043·Ray 103·LxM 070 ACCEPT · 출하 통지 094. collect-venv 0.6.0.
- **§3.4 수거기 편입 완료**(`~/.organum/hub-home/bin/collect.sh`, 레포 밖): 회차마다 서버
  트리(channels 1회)에서 구독 목록 `bbs-plaza directory batang-verify`의 문을 뽑아
  `organum-bbs pull <ch> --doors … --no-warmup --round-at $UTC`(문별 실패 격리·회차 상태),
  광장·batang-verify는 오프라인 `read --allow-problems`로 요약 한 줄(글 수·새 id·거부·전송·완결성,
  `.seen-posts` 대조)을 NEW-ARRIVALS에 우편과 한 목록으로. hub-thread·naru-inquiry는 구독 안 함.
- **첫 라이브 읽기**: 광장 36글·완결·전송 0·거부 1(lxm-001). 09-04~09-12 광장을 못 본 것이
  이것으로 닫혔다. **batang-verify = 0 posts·rejected 2** — caretaker가 자기 admit 없이 게시
  (계약 §3 restricted): read가 세어 준 첫 사례, 광장 plaza-005에 바탕 앞으로 적음.
- **post 첫 실물**: plaza-005(0.6.0 알림)를 `organum-bbs post`로 게시 — outbox `out-bbs-plaza/014`.
