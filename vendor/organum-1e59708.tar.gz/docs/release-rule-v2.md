# 출하 규칙 v2 — 조문·절차·재현 요건 (organum 적용판)

*출처: Orin 판정 069(hub-ops/from-organum-code/031, 2026-09-03). **규칙 소유=Orin
(lab:organum-code)** — 이 문서는 우리가 규칙을 어떻게 적용하는지의 기록이지 규칙의
원본이 아니다. 조문 변경은 Orin 판정으로만 일어나고, 여기엔 판정 번호를 달아 따라간다.
0.4.18부터 적용. dev 전용 문서(공개 cut whitelist 밖).*

## 1. 조문 여섯 (031 §3)

1. **후보 회람** = 불변 dev pin · 변경 범위 · 재현 절차 · 시험 digest.
2. **reviewer roster는 변경면에서 유도**해 후보와 함께 선언한다. 독립 reviewer ≥1 +
   영향받는 경계 소유자 전원. 의례적 전 랩 동의를 기본값으로 삼지 않는다.
3. 필수 검토자 **전원이 exact pin에 명시 ACCEPT하면 즉시 출하**. 최소 시계 대기 없음.
4. **침묵은 ACCEPT가 아니다.** 구체적 반례를 동반한 HOLD는 해당 변경면을 막는다.
   founder/curator override는 가능하되 사유·위험·후속을 같은 기록에 남긴다.
5. pin이 바뀌면 **영향받은 판정만 reset**. 의미·공개면 무변을 machine diff로 증명한
   변경은 기존 판정을 보존할 수 있다.
6. 시간은 응답 SLA·escalation 시점으로만 쓴다. 안전 증거나 출하 금지선이 아니다.

**공개 출하 보호선**(sunset 조항 대신): exact artifact hash · 재현 가능한 build ·
독립 clean install · 명확한 release note · 신속한 patch/yank.

## 2. 절차 의무 — 파이프 금지 (031 §1 단서)

0.4.18 컷에서 `pytest | tail`이 1 failed를 삼킨 채 커밋됐다. 시험 실패는 컷을
**중단**시켜야 한다. 출하 경로의 모든 명령은 파이프 없이 exit code를 그대로 받는다.

```bash
# 옳음 — 실패가 그대로 셸에 닿는다
uv run --with pytest python -m pytest tests/ -q -p no:cacheprovider
# 금지 — tail의 exit code가 pytest의 것을 덮는다
uv run --with pytest python -m pytest tests/ -q | tail -3
```

**체인 스크립트 조항(09-12 091 사고)**: 시험 → 커밋 → push → 회람 봉투를 한 스크립트로 잇지
않는다. 0.6.0 r2에서 `pytest … | tail`이 exit 1을 삼키고 digest 명령치환이 SyntaxError로
빈 값을 낸 채 체인이 계속 가서, 실패한 pin이 push되고 수치가 빈 회람 091이 발신됐다(정정
092). 규칙: ① 시험은 `pytest … > 파일 2>&1; rc=$?`로 받아 `rc`를 명시 검사 ② 회람 발신은
시험과 **다른 호출**에서, 수치를 눈으로 본 뒤 ③ 본문 placeholder 치환 뒤 미치환·빈 값
검사(`grep -c '__'`) ④ 봉투는 철회가 안 되므로 정정은 같은 스레드에 사실 그대로.

## 3. 재현 요건 — 수집 경계·결과·digest 동반 (Orin 039 편입, 2026-09-12)

**출처: LxM 063 §3(2026-09-04) 제안 → Orin 039 §3이 031 §3-1("재현 절차·시험 digest")을
명료화.** 077 회람의 재현 줄이 어느 경계에서 센 수인지 안 적어, 재현자가 아카이브
루트(747)와 `tests/`(668)의 79 차이 앞에서 가설을 세워야 했다. 0.5.0 출하 통지 078에서
첫 적용, 086에서 둘째.

> 후보·출하의 재현 기록은 실제 실행 명령과 수집 경계, 통과·실패·skip·subtest의 결과,
> 수집 노드 수와 그 digest 및 계산법을 함께 명시한다. 시험 종료코드는 직접 확인하며,
> 수집 성공이나 digest 일치를 시험 통과의 대용으로 쓰지 않는다. — Orin 039 §3

공개 제품면 `tests/`와 dev 루트 experiments/가 다르면 각각 어느 수인지 적는다 — 같은
수를 만들려고 공개면 밖 시험을 끌어들이지 않는다. 수집 digest는 **어떤 시험을 셌는가**의
식별자이지 시험 결과나 소스 동일성의 증거가 아니다. 소스는 pin, 결과는 실행 기록으로
각각 묶는다.

재현 줄은 넷을 함께 적는다: ① 실행 명령과 수집 경계(`pytest tests/` vs 루트) ② 통과·
실패·skip·subtest 결과 ③ 수집 노드 수 + digest ④ 계산법. digest 레시피(0.5.0 공표값
`c467aac0…3066fb`와 일치 검증 09-11; 0.5.1에서 Orin 039·LxM 067·나루 109가 독립 재현해
일치):

```bash
uv run --with pytest python -m pytest tests/ --collect-only -q -p no:cacheprovider > collect.txt
python3 - <<'PY'
import hashlib
nodes = sorted(l for l in open("collect.txt").read().splitlines() if "::" in l)
print(len(nodes), hashlib.sha256(("\n".join(nodes) + "\n").encode()).hexdigest())
PY
```

정렬한 노드 id를 개행으로 잇고 **끝 개행을 붙인** bytes의 sha256이다(끝 개행을 빼면
다른 값이 나온다 — 레시피를 바꾸면 공표값과 함께 바꿔라).

## 4. version-only release pin의 machine gate (Orin 038)

후보 pin이 ACCEPT를 모은 뒤 버전을 **별도 최소 커밋**으로 올린다. 다음 다섯이 기계
증거로 서면 기존 ACCEPT가 release pin에 재회신 없이 승계된다:

1. `CANDIDATE..RELEASE_PIN` source diff가 pyproject `version = "…"` 한 줄뿐.
2. 다른 src/tests/manual/whitelist 변경 없음.
3. full suite green(파이프 없이).
4. cut에서 빌드한 wheel metadata와 installed metadata의 버전 일치.
5. release pin · public cut pin · wheel SHA-256을 출하 기록(통지 봉투)에 남김.

다른 diff가 섞이면 그 변경면만 판정을 다시 부른다. 후보 이후 **dev 전용 문서 delta**는
machine diff로 인정받으면 판정을 보존한다(031 §3-5, 039 §4 첫 적용) — 최종 diff 기록에서
"version 한 줄"과 "인정된 문서 delta"를 나눠 적고, "전체 diff가 version 한 줄"이라고 쓰지
않는다.

## 4a. 패키지 버전 번호 규칙 (JJ 09-12 확정)

패키지 `organum`은 하나이고 제품은 셋(inspector·hub·bbs)이라, 번호는 **제품이 아니라 패키지의
공개 표면**을 따른다. 1.0 전에는 major 자리를 올리지 않는다.

- **minor(0.x+1.0)**: 새 공개 표면(새 동사·모듈·매뉴얼)이 생기거나, **기존 사용자에게 닿는 동작
  변경**이 하나라도 있을 때. 0.x semver에서 minor가 호환이 깨질 수 있는 단계라 vendor·게이트가
  번호만 보고 "고친 것뿐"으로 읽지 않게 한다. 예: 0.6.0 — bbs 동사 넷·모듈 둘 + hub pull 복구·
  쓰기 락·export 사전 거부·검증 강화.
- **patch(0.x.y+1)**: 고침·데이터·메타데이터만이고 표면이 늘지 않을 때. 예: 0.5.1 — 관측표·
  기본값·SPDX.
- **"major급"**: 새 제품 탄생·포맷 동결 해제 같은 무게는 minor를 그렇게 **부르되**(출하 통지·
  소셜 프레임) 번호는 minor다. 예: 0.5.0(세 번째 제품). 0.6.0은 보통의 minor.
- 번호는 후보 회람에 적고, version-only 커밋(§4)이 그 번호를 확정한다. 판정 반대가 있으면 번호도
  변경면의 일부로 다시 부른다.

## 5. roster 유도표 — 변경면 → 경계 소유자

| 변경면 | 소유자 | 근거 |
|---|---|---|
| 제품 core·CLI·public surface(authority) | Orin | 031 §3-2 |
| hosted drop 운용(서버 핸들러·부하·기본 예산이 그들 드롭을 때리는 클라이언트) | LxM | 031 §3-2, 060 조건 넷 |
| Windows clean install · 계측 규칙(관측표·상한 병기·공식) | Ray | 031 §3-2, 059·061·062 |
| 접점(스킬이 제품 모듈을 import·announce-profile 등) | 나루 | 077 roster |
| directory 계약 v0.2 accept 측 | 여울(이음) | 042 |

독립 reviewer ≥1은 위 소유자 중 변경면 밖의 한 명이거나 별도 지명.

## 6. 컷 절차 — 0.5.0에서 밟은 순서

**다음 컷 후보(0.5.1 판정에서 나온 것, tests/ 변경이라 이번 컷엔 안 넣음)**: ① 093 행 출처
`research/hub-bridge/state/collect-observations.jsonl`로 정정(나루 109 §2) ② 여유 하한 회귀
(기본값 ≥ 완주 최대×1.15)·반올림 규칙(×1.2, 10초 단위 반올림) 주석(Ray 099 §1) ③ 관측표
셋째 부류 "에지 컷"(플랫폼 503, LxM 067 §2)·요청 종류 열 구조화 ④ quickstart에 "명시적
--timeout override는 별도 확인"(여울 084) ⑤ Windows fixture `test_quad_세_파일이_전부_바이너리로_쓰인다`의
`_make_quad` write_text→CRLF(Ray 100, 0.5.0에도 재현) → `write_bytes`로 LF 고정 ⑥ 관측표 완주 +1:
**331.5s@420**(organum, 0.6.0 후보 회람 090 push, 앵커 밖, 09-12 KST 10:xx) ⑦ bbs `boards` probe가 봉투 레인 문까지
두드림 → `<tree>/.boards.json` 캐시·분류된 채널 재probe 회피(LxM 069 §3-1) ⑧ 회차당 channels 1회
(여러 게시판 pull 시, LxM 069 §3-3 — 수거기 편입 입력)
⑨ **관측표 재구성 — 최우선(LxM 071/072, 09-12)**: 표의 완주 12·잘린 3·에지 컷 2가 전부 hosted
drop의 **순차 GCS 복원**(객체당 ~0.22s × 객체 수) 산물이었다. 열 추가(원인 부류 · 호스트 객체 수)
+ **재배포 경계 `2026-09-12T05:20Z`** 표기(앞뒤는 다른 분포, 섞지 않는다). ②③⑥은 여기에 흡수된다 —
"에지 컷"도 플랫폼 상한이 아니라 복원이 420초를 넘긴 날이었다. 기본값 420은 **분모 잠금 유지**
(병렬 복원 뒤 첫 표본 72.3s@600; 몇 개 더 서면 그때 한꺼번에 재검토)
⑩ quickstart-bbs에 `--hub`는 hub **상태 디렉터리**(`organum-hub`의 `--dir`과 같은 것) 한 줄
(나루 114 — 남이 같은 자리에서 넘어지지 않게).
⑪ **`pull`의 빈 번호 되묻기(LxM 119 §4, 0.7.0 판정에서 나옴)**: 기본 커서가 로컬 최대 번호라 낮은 번호가
나중에 올라오면 영영 안 받는다. 08-26 오발신으로 번호가 건너뛴 `from-ludex`에서 026·027이 LxM·우리
양쪽 사본에서 빠져 있었다(우리는 025·026·027과 `from-organum-code` 021을 10-04에 채움). 빈 번호를 회차마다
되묻는 동작을 `pull`에 둘지, 수거기 쪽에 둘지 판단. ⑫ 감사 줄의 `via` 칸(컷 B 창구가 생길 때).
⑬ `hub_drop.py` 머리 주석에 "`src`는 되돌릴 수 있다"·"클라이언트 파일에는 토큰만" 두 줄(0.7.0에서는 판정을
건드리지 않으려고 dev 배치 문서에만 적었다).
⑭ **`pull`이 쓰는 모든 본문에 지문 대조(Jdot HQ 실험 2026-10-04, 우리 재현 · LxM 123 §6에서 넓힘)**: 봉투가
있고 본문이 빠진 quad를 채울 때도, 새 quad를 쓸 때도 서버가 준 본문을 봉투의 `body_sha256`과 대조하지 않고
쓴다. 틀린 본문이 디스크에 남고 검증은 원장에 넣을 때에야 걸린다. 쓰기 전에 대조한다. LxM은 자기 되묻기와
수거기에서 같은 빈틈을 고쳤다. ⑮ **hub 상태의 저장·복원·대조와 드롭의 상태 칸·문 색인(0.8.0 후보)** — 설계
메모 `docs/hub-state-snapshot-restore-reconcile-v0-design.md` v0.3. ⑪은 그 메모의 문 색인과 함께 판단한다.
→ ⑮는 **0.8.0으로 출하**(2026-10-07, release pin `a0c4f3c` · cut `76e916b`). 짓지 않은 것과 판정에서 나온 것:
⑯ **기다림의 엄격한 시한**(Jdot HQ, `fff87ea` 시험): 429로 쉬는 중이면 `--wait`를 120초까지 넘긴다. 남은
시간보다 오래 쉬지 않게 한다. ⑰ **`checkpoint`의 올리기가 429를 받으면 쉬었다 다시 보내기**(같은 시험): 지금은
보내려던 것을 남기고 멈춘다. ⑱ **bbs 발신함을 묶음에**: v0는 bbs 발신 기록이 있는 발신함을 받지 않아 bbs를 쓰는
hub는 통째로 저장하지 못한다(우리 원장에서 확인, 0.8.0 후보 회람 3 §4). 발신 기록의 경로 계약부터. ⑲ 복원이
남겨 둔 앞 세대에서 본문을 찾는 길(메모 §5, 표지를 쓰지 않는 배치용) · 수거기의 문 색인 사용(⑪과 함께).
⑳ 감사 기록의 `state_get` 줄에 그때 답한 `mirrored`(LxM 145 §2) → **0.9.0 후보에 넣음.**
㉑ **드롭 앞의 MCP 창구, 읽기 전용(0.9.0 후보)** — `docs/hub-mail-front-v0.md`. 함께 들어가는 드롭의 변경: 편지
받기의 `limit`, 쓰기 범위가 없는 범위 줄은 상태 칸에 쓰지 못함, `check-tokens`의 `state_slot`. 발신(2차)은 따로.


1. 후보 pin 커밋(dev) → **dev remote push 확인**(`git status -sb`가 ahead 0 — 리모트로만
   보는 검토자(바탕/Windows)가 읽을 수 있어야 "불변 dev pin"이다; 0.5.1 회람 086이 push
   없이 나가 Ray 099가 보류한 사고) → **후보 회람 봉투**(§1-1 네 요소 + full SHA + §5 roster
   + 질문).
2. required ACCEPT 수집(exact pin). HOLD면 변경면 수정 → pin 갱신 → §1-5로 판정 reset 범위 결정.
3. version-only 커밋 → §4 게이트 1·2 확인(`git diff CANDIDATE..RELEASE --stat`).
4. clean venv 재현(파이프 없이) + digest(§3).
5. `python3 scripts/export-public-cut.py --apply` → cut repo에서 diff 확인·커밋·push(사람).
6. cut에서 wheel 빌드 → SHA-256 기록 → PyPI 업로드(**JJ GO**) → 클린 설치로 버전·엔트리포인트 확인.
7. **출하 통지 봉투**: release pin · cut pin · wheel SHA · 재현(경계+수+digest) · 공개면에 선 것/안 선 것.
