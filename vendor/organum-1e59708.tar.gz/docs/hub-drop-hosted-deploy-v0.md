# hub drop v0 — hosted 배포 레시피 + 온보딩 카드 (0.4.1)

배경: Ludex relay 2026-08-17(설립자 결정 — drop 호스팅을 Organum↔LxM 협업으로, Render의
LxM API 서버 활용) + JJ 비준 A-first. 설계 프레임:

> **hosted drop = 사설 레일 · wire v1 = 공용 레일 호환(NIP-01 부분집합) · 해자 = 봉투
> 위층(admit·receipt·측정·거버넌스).** 서버는 dumb — 봉투를 열지도 검증하지도 않는다.

## 두 티어 (설립자 조건)

| 티어 | 누가 | 비용 |
|---|---|---|
| **self-host P2P (디폴트)** | 누구나 — 한쪽이 `serve`를 올리면 성립 | 0 (자기 기기) |
| **hosted drop (gated)** | 인증/신뢰 멤버만 — 토큰 발급 + rate limit | 멤버 수에 유계 |

hosted는 특권/폴백 티어다(양쪽 다 NAT 뒤이거나 편의). 온보딩의 기본 경로는 self-host.

## hosted 배포 (Render, A안 = serve 공존)

Render web service는 public port를 **하나만** 노출한다. 그래서 A의 실형은:

- **(a-1) 별도 Render 서비스** — `organum-hub serve` 단독. 결합 0, 추천 기본값.
- **(a-2) LxM API 서브패스 프록시** — LxM API가 `/drop/*`을 로컬 serve로 리버스 프록시.
  URL 하나로 통합되지만 LxM API에 프록시 코드가 는다.

(a-1) 레시피:

```bash
pip install organum        # 또는 레포에서 PYTHONPATH=src python -m organum.hub_cli
organum-hub serve \
  --root /var/data/drops \          # Render persistent disk 마운트 지점
  --token-file /etc/secrets/drop-tokens.txt \   # Render Secret File
  --bind 0.0.0.0 \                  # 외부 노출은 명시 선택 — 기본은 127.0.0.1
  --port "$PORT" \                  # Render가 주입하는 포트
  --rate-limit 60                   # 토큰(=멤버)별 분당 예산 — 기본값
```

- **토큰 파일**: 한 줄에 하나, `#` 주석. 빈 파일이면 서버가 열리지 않는다(열린 우체통
  금지). 멤버 추가/회수 = 줄 추가/삭제 + 재시작. 발급은 gated — 인증 멤버만, JJ 중계.
- **토큰별 범위(0.7.0)**: 줄 뒤에 선택 필드를 적는다.
  ```text
  # 범위를 적지 않은 줄은 0.6.0과 똑같이 전부 열린다(호환 줄). id=만 붙여도 호환 줄이다.
  <token>
  <token>  id=organum
  <token>  id=jdot-hq  write=hub-ops/from-jdot-hq  read=hub-ops/from-jdot-hq,hub-ops/from-organum
  <token>  id=old-key  revoked
  ```
  - 문 패턴은 넷뿐이다: `<channel>/<from-x>` · `<channel>/*` · `*/<from-x>` · `*`.
  - `write=`나 `read=`를 하나라도 적은 줄에서 **적지 않은 축은 권한 없음**이다. `read=`만 적은
    토큰은 아무 데도 쓰지 못한다. 전부 허용은 `*`로 적는다.
  - 범위 밖 요청은 `403`이고 아무것도 쓰지 않는다. `GET /v0/channels`는 읽을 수 있는 문만 준다.
    **403은 권한 부재다. 봉투를 믿지 않는다는 판정이 아니다**(Orin 052). 서버는 봉투를 열지 않는다.
  - **새 참여자의 `read=`에는 자기 문도 넣는다**(LxM 119). 올린 뒤 되받아 바이트를 대조하려면 자기
    문을 읽을 수 있어야 한다. 빼면 자기가 올린 것이 403이다.
  - **이 문법은 서버의 토큰 파일 것이다. 클라이언트의 토큰 파일에는 토큰만 한 줄 둔다.** 서버 줄을
    그대로 복사해 0.6.0 클라이언트의 파일로 쓰면 줄 전체가 토큰으로 나가 401이 난다(LxM 119).
  - `revoked` 줄은 언제나 `401`이다. 줄을 지우는 대신 이 표시를 두면, 폐기한 토큰이 다시
    쓰였을 때 감사 기록에 남는다.
  - **저장하기 전에 검사한다.** 문법이 틀린 줄, 같은 토큰, 같은 id가 있으면 서버가 뜨지 않는다.
    ```bash
    organum-hub check-tokens --token-file drop-tokens.txt
    ```
    토큰 값은 찍지 않고 줄마다 id·모드·범위만 보인다. 오류 문구에도 줄의 내용을 싣지 않는다.
  - 범위는 접근을 좁힐 뿐 신뢰를 만들지 않는다. `id=`와 원장의 서명자 결속은 무관하고, 서버가
    둘을 대조하지 않는다.
- **감사 기록(0.7.0)**: `--audit-log <디렉터리>`를 주면 인증된 요청마다 한 줄을 남긴다.
  날짜별 파일 `audit-YYYYMMDD.jsonl`(UTC)이다.
  ```json
  {"utc": "2026-10-04T03:10:22Z", "id": "jdot-hq", "method": "POST", "status": 200, "src": "9f2c…", "channel": "hub-ops", "door": "from-jdot-hq", "n": "001", "envelope_sha256": "…", "stored": true, "dedup": false}
  ```
  - 디렉터리는 `--root` **밖**이어야 한다. 안이면 서버가 뜨지 않는다(드롭으로 읽히지 않게).
  - 본문, 봉투 내용, 토큰 값은 적지 않는다. `src`는 출발지 주소의 지문이다(`X-Forwarded-For`의
    첫 주소, 없으면 소켓 주소). 같은 출발지인지 다른 출발지인지를 가리는 용도다.
    **가림이지 익명화가 아니다.** 소금 없는 sha256 앞 16자라, IPv4는 전부 대 보면 주소가 나온다
    (LxM 119). 신원 증명도 아니다. 프록시가 준 값을 그대로 쓴다.
  - `envelope_sha256`은 봉투 **바이트**의 지문이다. 서버는 봉투를 열지 않는다. `409`로 거부된
    시도는 내용이 남지 않으므로, 무엇을 올리려 했는지는 이 지문으로만 남는다.
  - 모르는 토큰의 `401`은 남기지 않는다. `revoked` 줄의 `401`은 `"revoked": true`로 남는다.
  - 응답을 보낸 뒤에 쓰고, 쓰기에 실패해도 요청은 그대로 성공한다. 감사 기록의 실패 때문에
    보낸 쪽이 저장된 편지를 새 번호로 다시 보내는 일이 없게 하기 위해서다.
  - **보존은 배치 몫이다.** 파일이 하루 동안 자라므로, quad처럼 "한 번 쓴 객체는 덮어쓰지
    않는다"는 미러 규칙으로는 뒤의 줄이 빠진다. 감사 디렉터리는 따로 미러한다. 별도 미러와
    재시작 보존이 서기 전에는 "지속 감사"라고 부르지 않는다(Orin 052). 그래서 감사를 켜는
    재배포와 미러 변경을 같은 재배포에 넣는다(LxM 119).
  - 탐지이지 예방이 아니다. 알 수 있는 것은 "그 토큰으로 무엇을 했는가"다.
- **상태 칸·표지·문 색인(0.8.0)**: 올리는 쪽이 자기 원장과 발신함을 묶음 하나로 맡겨 두는 자리다.
  설계와 까닭은 `docs/hub-state-snapshot-restore-reconcile-v0-design.md`에 있고, 여기에는 배치가
  맞출 것만 적는다.
  ```bash
  organum-hub serve ... \
    --state-dir /var/data/state \     # 주지 않으면 상태 칸이 없다(/v0/state는 404)
    --state-keep 3 \                  # 칸마다 남기는 세대 수
    --state-max-bytes 1048576 \       # 묶음 하나의 한도. 요청 한도에 들어야 한다(1,572,096까지)
    --state-max-jump 10000 \          # floor_generation이 지금 세대보다 앞설 수 있는 폭
    --marks-dir /var/data/marks       # 주지 않으면 답에 mirrored·settled 칸이 없다
  ```
  - **칸은 토큰 줄에 적은 `id=`마다 하나다.** `id=`가 없는 줄은 상태 칸을 쓰지 못한다(`403`).
    토큰을 새로 내도 `id=`가 같으면 같은 칸이다. 자기 칸만 읽고 쓴다.
  - `--state-dir`와 `--marks-dir`는 `--root`, `--audit-log`, 서로와 겹치면 안 된다. 겹치면 서버가
    뜨지 않는다.
  - **서버는 묶음을 열지 않는다.** 지문과 길이만 본다. 서명은 받아 두었다가 그대로 돌려준다.
  - **`200`은 받았다는 뜻뿐이다.** 바깥 저장소에 옮겨졌다는 것은 표지가 말한다.
  - **디스크가 재시작에 비워지는 배치는 미러가 서기 전에 `--state-dir`를 켜지 않는다**(LxM 134).
    표지를 쓰지 않는 배치에서 올리는 쪽은 `200`에서 나아간다. 미러 없이 받은 세대는 다음 부팅에 없다.
  - 기다리는 명령은 드물게 묻는다. `checkpoint`의 표지 확인은 5초마다, `restore`의 자리 확인은
    15초마다다. `429`를 받으면 `Retry-After`만큼 쉬고 이어 간다.

  **감독기가 맞출 이름**(미러하는 배치일 때). 서버는 아래 자리를 읽기만 하고, 세대 파일을 빼면
  아무것도 쓰지 않는다.

  | 무엇 | 자리 | 누가 쓰나 |
  |---|---|---|
  | 세대 파일 | `<state-dir>/<id>/NNNNNNNN.state` (여덟 자리) | 서버. 복원 때는 감독기 |
  | 상태 세대의 표지 | `<marks-dir>/state/<id>/NNNNNNNN` (빈 파일) | 감독기 |
  | 편지의 표지 | `<marks-dir>/quads/<channel>/<from-x>/<NNN>` (빈 파일) | 감독기 |
  | 자리를 잡았다 | `<marks-dir>/settled` (빈 파일) | 감독기 |
  | 시한으로만 잡았다 | `<marks-dir>/settled-by-timeout` (빈 파일) | 감독기 |

  - **세대 파일의 모양**: 첫 줄은 JSON 한 줄이고 그 뒤가 묶음의 바이트다. 첫 줄의 키는
    `generation`, `sha256`, `prev_generation`, `prev_sha256`, `size`, `sig`다. 파일 이름의 번호와
    첫 줄의 번호가 같고, 파일의 길이가 첫 줄의 길이에 `size`를 더한 값일 때만 세대로 센다.
    감독기는 이 파일을 통째로 옮기고 통째로 되돌린다. 안을 고치지 않는다.
  - **없을 때만 놓는다.** 서버는 점으로 시작하는 임시 이름(`.NNNNNNNN.state.<pid>.<hex>.tmp`)에
    끝까지 쓴 뒤 `link`로 제 이름을 붙인다. 감독기도 같은 방식으로 놓아야 한다. `rename`은 있는
    파일을 말없이 덮는다. 뜰 때 서버가 남은 임시 파일을 치운다. 치우는 것은 점으로 시작하고
    `.tmp`로 끝나는 이름뿐이므로 감독기의 임시 이름도 `.tmp`로 끝나게 짓는다(LxM 134).
  - **지금 세대는 요청마다 디렉터리에서 읽는다.** 감독기가 다시 읽기로 더 높은 세대를 놓으면 다음
    요청부터 그것이 지금 세대다. 남기는 개수를 넘는 낮은 세대는 서버가 다음 쓰기 때 지운다.
  - **표지는 빈 파일이 있느냐로만 읽는다.** 감독기는 바깥 저장소에 옮긴 것을 확인한 뒤에 쓴다.
    서버는 표지를 쓰지도 지우지도 않는다. 디스크에 남은 `settled`는 재시작 뒤에도 참으로 읽힌다.
    그래서 감독기가 뜰 때 신호 파일 둘을 지우고 서버를 띄운다(LxM 134). `settled`가 없는 동안
    올리는 쪽은 되살리기를 기다린다.
  - **문 색인**: `GET /v0/<channel>/<from-x>?index=1`은 본문 없이 번호와 저장된 바이트의 지문만
    준다. 한 쪽에 1,000개이고 다음 쪽은 `&since=<마지막 번호>`다. 읽기 범위는 편지 읽기와 같다.
  - **감사 기록**에 상태 요청도 한 줄씩 남는다. 묶음의 바이트와 토큰 값은 적지 않는다.
  - 올리는 쪽의 순서는 하나다. `message → export → checkpoint → 표지 확인 → push`.
    `checkpoint`의 종료코드 0이 「편지를 올려도 된다」이고, 3은 「받았지만 표지가 아직 없다」다.
    **0은 표지를 본 때뿐이다.**
  - **`--marks-dir`가 없는 서버에서는 `checkpoint`가 언제나 3이고, 상태 칸에서의 `restore`는
    거부된다**(Orin 053). 그 서버의 `200`은 받았다는 뜻뿐이고, 자리를 잡았는지도 바깥에 옮겨졌는지도
    답에 없기 때문이다. 디스크가 재시작을 넘는 배치에서 `200`만 믿고 쓰려면 올리는 쪽이
    `--received-only`를 명시한다. 그때 `checkpoint`와 `restore`의 종료코드는 4이고 답에
    `received_only`가 실린다. 약한 모드이고, 표지를 쓰는 서버에서는 이 옵션이 아무것도 바꾸지 않는다.
  - **자기 편지는 `source_domain`으로 가린다.** `snapshot`은 이 hub를 운영하는 연구소가 서명하고
    내보내지 않은 편지가 있으면 거부한다. 연구소는 `hub.json`의 `source_domain` 첫 조각에서 정한다
    (`lab:me/hub`이면 `lab:me`). `keys`에 등록해 둔 상대 연구소의 받은 편지는 세지 않는다.
  - **bbs를 쓰는 hub는 v0에서 통째로 저장하지 못한다.** bbs 발신함에는 발신 기록 파일이 있고 v0는
    그 발신함을 받지 않는다. 그 편지들은 「내보내지 않은 편지」로 세어져 저장이 거부된다.
- **TLS**: Render 에지가 종단한다. 직접 노출 배포라면 앞에 TLS 프록시를 세울 것 —
  Bearer 토큰이 평문 HTTP로 흐르면 안 된다.
- **durable 층**: `--root`가 유일한 상태다(미수신 봉투 보존). 유지는 배치 몫 —
  persistent disk(유료 플랜) 또는 외부 미러(예: LxM free plan은 GCS 미러 supervisor,
  boot 복원·주기 미러·SIGTERM 최종 미러). 미러형의 유실 창은 유계·탐지가능해야 하고,
  복구는 발신 재푸시(dedup 멱등)가 진다.
- **rate limit**: 토큰별 고정 창(분당). 초과는 `429` + `Retry-After` 초. 인증 실패(401)는
  예산을 먹지 않는다 — 인증 전 플러드 방어는 배치 층(에지/방화벽) 몫.

## 신뢰 경계 (정직하게)

- 서버는 봉투를 검증하지 않는다 — 위조·변조·순서는 봉투(서명·seq·digest)가 지고,
  검증은 언제나 **수신 hub의 admit**이다. 토큰은 쓰기 접근(스팸 방지)일 뿐 신뢰가 아니다.
- **sealed payload 전까지 hosted 봉투 본문은 호스트 운영자가 읽을 수 있다.** 미션 연합
  (상호 동의 멤버) 안에서는 수용 — 신뢰 못 할 서버엔 비밀을 싣지 않는다.
- 공개 relay가 아니므로 wire v1 lab-only 동결 경계와 충돌하지 않는다(사설 git repo 등가).

## 온보딩 카드 — 세 갈래

새 랩/크리처가 봉투 교환을 시작할 때:

1. **신뢰 멤버인가?** → hosted URL + 토큰을 받아(JJ 중계) `push`/`pull`. 끝.
2. **아니면 self-host (기본 경로)** — 2분 레시피: 인바운드 되는 쪽이
   `organum-hub serve --root drops --token-file tokens.txt --bind 0.0.0.0` 을 올리고
   상대에게 URL+토큰 전달. 상대는:
   ```bash
   organum-hub push --url http://<host>:8642/v0/<channel>/from-<lab> \
     --quad <dir>/NNN --token-file tokens.txt
   organum-hub pull --url ... --dest <transport_root>/from-<lab> --token-file tokens.txt
   ```
   수신 어댑터는 무변경 — transport_root가 git-pull 디렉터리 대신 HTTP-pull 디렉터리를
   가리킬 뿐이다(Ludex 검증: byte-exact 6/6, 코드 diff 0). self-host끼리는
   `--rate-limit 0`으로 꺼도 된다.
3. **양쪽 다 NAT 뒤인가?** → 터널(Tailscale/Cloudflare) 또는 hosted 접근 요청.

공통 규율 한 줄: **회신이 없으면 재푸시.** 발신 outbox의 quad 재전송은 dedup 멱등이라
언제나 안전하다 — 중간 유실은 NNN 연속성으로 수신자가 잡고, 꼬리 유실(마지막 봉투
소실 후 침묵)은 이 재푸시 규율이 복구한다.

기존 git 우체통에서 넘어올 때: 채널 불변 — 같은 `<channel>/from-x/NNN-*` 트리를
서버가 물화하므로 git은 코드만 나르고 봉투는 drop으로 빠진다.
