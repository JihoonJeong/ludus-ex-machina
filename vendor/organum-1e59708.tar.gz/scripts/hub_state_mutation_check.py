"""0.8.0 변이 검사 — 상태 칸(서버)과 저장·복원·체크포인트(올리는 쪽)의 시험이 판정을 실제로 붙잡는지.

판정 한 곳을 일부러 망가뜨린 사본을 임시 디렉터리에 만들고 그 판정을 맡은 시험 파일을 돌린다.
모든 변이가 **시험 실패**로 끝나야 한다. 수집 오류는 잡힘이 아니다.

    python3 scripts/hub_state_mutation_check.py

종료코드 0 = 기준선 통과 + 모든 변이가 시험 실패로 잡힘.
"""
import os, pathlib, shutil, subprocess, sys, tempfile
ROOT = pathlib.Path(__file__).resolve().parents[1]
D, S, C = "src/organum/hub_drop.py", "src/organum/hub_state.py", "src/organum/hub_cli.py"
TD, TS = "tests/test_hub_drop_state.py", "tests/test_hub_state.py"
M = [
 ("baseline 서버", D, "", "", TD),
 ("baseline 올리는 쪽", S, "", "", TS),
 # ── 서버: 상태 칸 ──
 ("조건에서 지문을 뺌", D, "        if (expect_gen, expect_sha) == (cur_gen, cur_sha):", "        if expect_gen == cur_gen:", TD),
 ("floor를 무시(번호가 되돌아감)", D, "            new_gen = max(cur_gen, floor) + 1", "            new_gen = cur_gen + 1", TD),
 ("floor의 위쪽 끝 제거", D, "        if floor > cur_gen + self.state_max_jump:", "        if False:", TD),
 ("없을 때만 대신 덮어씀", D, "            os.link(tmp, final)\n            return True", "            os.replace(tmp, final)\n            return True", TD),
 ("중복 판정에서 지문을 뺌", D, "              and sha == cur_sha):", "              and True):", TD),
 ("id 없는 줄에도 칸을 줌", D, "        if not entry.explicit_id:", "        if False:", TD),
 ("서버가 만든 id를 적은 id로 침", D, "explicit_id=id_ is not None))", "explicit_id=True))", TD),
 ("묶음 한도 검사 제거", D, "        if len(blob) > self.state_max_bytes:", "        if False:", TD),
 ("요청의 지문 검사 제거", D, "        if hashlib.sha256(blob).hexdigest() != sha:", "        if False:", TD),
 ("남기는 개수로 지우지 않음", D, "                _state_prune(dirp, self.state_keep)", "                pass", TD),
 ("길이가 맞지 않는 파일도 셈", D, "        if path.stat().st_size != len(line) + size:", "        if False:", TD),
 ("이름과 머리의 번호가 달라도 셈", D, "        if not (type(gen) is int and gen == int(m.group(1)) and gen >= 1", "        if not (type(gen) is int and gen >= 1", TD),
 ("깨진 세대를 내줌", D, '    if len(blob) != header["size"] or hashlib.sha256(blob).hexdigest() != header["sha256"]:', "    if False:", TD),
 ("표지가 없어도 참이라고 답", D, "    return marks_dir.joinpath(*parts).is_file()", "    return True", TD),
 ("표지를 쓰지 않는 배치에서도 칸을 실음", D, "    if marks_dir is None:\n        return None", "    if marks_dir is None:\n        return False", TD),
 ("문 색인을 쪽으로 나누지 않음", D, "            for n in fresh[:INDEX_PAGE_SIZE]:", "            for n in fresh:", TD),
 ("문 색인에 본문을 실음", D, '             "body_name": None, "body_sha256": None, "body_size": None}', '             "body_name": None, "body_sha256": None, "body_size": None,\n             "envelope_b64": base64.b64encode(env_b).decode("ascii")}', TD),
 ("상태·표지 디렉터리의 겹침 허용", D, "            if d == other or other in d.parents or d in other.parents:", "            if False:", TD),
 ("요청 한도에 들지 않는 한도 허용", D, "    if state_max_bytes < 1 or 4 * math.ceil(state_max_bytes / 3) + _STATE_REQUEST_OVERHEAD \\\n            > REQUEST_MAX_BYTES:", "    if state_max_bytes < 1:", TD),
 ("뜰 때 임시 파일을 치우지 않음", D, "        _state_sweep_tmp(state_p)", "        pass", TD),
 ("감사 줄에 토큰 값", D, '"id": entry.id,\n                    "method"', '"id": entry.token,\n                    "method"', TD),
 # ── 올리는 쪽: 묶음 ──
 ("잘린 스트림 허용", S, "    if not d.eof:", "    if False:", TS),
 ("뒤에 붙은 바이트 허용", S, "    if d.unused_data:", "    if False:", TS),
 ("푼 크기의 상한 제거", S, "    if len(out) > limit or d.unconsumed_tail:", "    if False:", TS),
 ("모르는 조각 이름 허용", S, '            raise StateError(f"모르는 조각 이름: {name!r}")', "            pass", TS),
 ("조각의 지문을 안 봄", S, "        if len(chunk) != size or _sha(chunk) != sha:", "        if len(chunk) != size:", TS),
 ("목록의 지문을 안 봄", S, '    if _sha(line) != sha_line.decode("ascii", "replace"):', "    if False:", TS),
 # ── 올리는 쪽: 저장과 복원 ──
 ("불완전한 quad를 건너뜀", S, "        if not (env_p.is_file() and sig_p.is_file()):\n            raise SnapshotRefused(", "        if not (env_p.is_file() and sig_p.is_file()):\n            continue\n            raise SnapshotRefused(", TS),
 ("넣고 내보내지 않은 편지를 통과", S, "        if unexported and not allow_unexported:", "        if False:", TS),
 ("bbs 발신 기록을 통과", S, '        if f.name.endswith(".outbox.json"):', "        if False:", TS),
 ("발신함이 원장과 달라도 저장", S, '                or sig_p.read_bytes() != (row["sig"] + "\\n").encode("utf-8"):', "                or False:", TS),
 ("빈 자리가 아니어도 복원", S, "        if not _empty(target):", "        if False:", TS),
 ("본문을 지문 확인 없이 씀", S, "                    elif _sha(body) != digest:               # 쓰기 전에 본다", "                    elif False:", TS),
 # ── 올리는 쪽: 체크포인트 ──
 ("표지 없이도 올려도 된다고 답", S, '            if meta["mirrored"] is True:', "            if True:", TS),
 ("표지 없는 편지의 본문도 뺌", S, '                     if e.get("mirrored") is True and e["n"] in local', '                     if e["n"] in local', TS),
 ("기록에 없는 409에서 스스로 다시 올림", S, '            if known is None and cur != (0, ""):', "            if False:", TS),
 ("연장 확인 제거", S, "            _check_extension(hub, outboxes, doors, last)", "            pass", TS),
 ("보낸 번호를 floor에 넣지 않음", S, '                rec["floor"] = max(floor, predicted)', "                pass", TS),
 ("달라진 것이 없어도 다시 뜸", S, "                    unchanged = last\n", "                    unchanged = None\n", TS),
 ("받았다는 기록에 지금의 디스크를 적음(Jdot HQ D1)", S, '**res["sent"]})', "**_ledger_summary(hub, outboxes)})", TS),
 ("발신함이 달라졌는데 그 위에 다시 올리지 않음", S, '            if res["sent"] != _ledger_summary(hub, outboxes, doors):', "            if False:", TS),
 ("429에서 기다리지 않고 그만둠", S, "        if st != 429 or clock() >= deadline:", "        if True:", TS),
 ("서버가 말한 쉴 시간을 안 봄", S, '    return max(default, float(body.get("retry_after") or 0))', "    return default", TS),
 # ── Orin 053의 셋 ──
 ("받은 편지를 자기 미발신 편지로 셈(A)", S, '                    and env.get("signer", {}).get("id") == own and eid not in exported):', "                    and eid not in exported):", TS),
 ("자기 연구소를 못 정해도 저장(A)", S, "        if own is None and not allow_unexported:", "        if False:", TS),
 ("맨이름 hub에서 같은 이름의 키를 안 봄(A)", S, '    if he._LAB_ID.fullmatch(cand) and any(k.get("signer_id") == cand for k in cfg.get("keys") or []):', "    if he._LAB_ID.fullmatch(cand):", TS),
 ("번호 대응이 달라도 정상 체크포인트 통과(B)", S, '        if (now["count"], now["sha256"]) != (old["count"], old["sha256"]):', "        if False:", TS),
 ("문이 달라도 정상 체크포인트 통과(B)", S, '        if doors.get(name) != old.get("door"):', "        if False:", TS),
 ("실었던 발신함을 빼도 통과(B)", S, "        if name not in outboxes:\n            raise CheckpointStopped(", "        if name not in outboxes:\n            continue\n            raise CheckpointStopped(", TS),
 ("표지 없는 서버의 200을 올려도 된다고 답(C)", S, '                out = {"mirrored": None, "ready_to_push": False, "marks_absent": True}', '                out = {"mirrored": None, "ready_to_push": True, "marks_absent": True}', TS),
 ("표지 없는 서버의 묶음으로 기본 복원(C)", S, "            if not received_only:\n                raise StateError(", "            if False:\n                raise StateError(", TS),
 ("약한 복원을 보고에 표시하지 않음(C)", S, '    if "settled" not in body:\n        report["received_only"] = True', '    if False:\n        report["received_only"] = True', TS),
 # ── 올리는 쪽: 상태 칸에서 되살리기 ──
 ("증인 확인 제거", S, "            if not _extends(wm, wp, manifest, parts):", "            if False:", TS),
 ("표지 없는 남은 세대도 증인으로", S, '            if "mirrored" in k and k["mirrored"] is not True:\n                continue', '            if False:\n                continue', TS),
 ("자리를 잡았다는 신호를 안 봄", S, '        elif body.get("settled") is not True and not (accept_timeout and body.get("settled_by_timeout")):', "        elif False:", TS),
 ("시한으로 잡은 것을 기본으로 받음", S, '        elif body.get("settled") is not True and not (accept_timeout and body.get("settled_by_timeout")):', '        elif body.get("settled") is not True and not body.get("settled_by_timeout"):', TS),
 ("복원이 표지를 안 봄", S, '        elif body.get("mirrored") is not True:', "        elif False:", TS),
 ("묶음의 서명을 안 봄", S, "    if not ok:", "    if False:", TS),
 ("번호 대응이 달라도 잇는다고 봄", S, '            if new_index.get(i["n"]) != i:', "            if False:", TS),
 # ── 명령줄 ──
 ("넘치는 본문을 원장에 넣음", C, '    if fit is not None and not fit["fits"]:', "    if False:", TS),
 ("표지 전인데 종료코드 0", C, '    return 4 if r.get("received_only") else 3', '    return 4 if r.get("received_only") else 0', TS),
 ("약한 모드를 종료코드 0으로(checkpoint)", C, '    return 4 if r.get("received_only") else 3', '    return 0 if r.get("received_only") else 3', TS),
 ("약한 모드를 종료코드 0으로(restore)", C, '    return 4 if report.get("received_only") else 0', "    return 0", TS),
 ("대조의 종료코드를 버림", C, '    return report["exit"]', "    return 0", TS),
]
env = dict(os.environ)
bad = 0
tmp = tempfile.mkdtemp(prefix="statemut-")
for name, target, a, b, test in M:
    d = pathlib.Path(tmp) / "w"
    shutil.rmtree(d, ignore_errors=True)
    (d / "tests").mkdir(parents=True)
    shutil.copytree(ROOT / "src", d / "src", ignore=shutil.ignore_patterns("__pycache__", "*.egg-info"))
    shutil.copy(ROOT / test, d / "tests/")
    f = d / target
    src = f.read_text(encoding="utf-8")
    if a and src.count(a) != 1:
        print(f"ANCHOR MISSING({src.count(a)}): {name}"); bad += 1; continue
    if a:
        f.write_text(src.replace(a, b), encoding="utf-8")
    r = subprocess.run([sys.executable, "-m", "pytest", str(d / "tests"), "-q", "-p", "no:cacheprovider", "-x"],
                       capture_output=True, text=True, env=env, cwd=d)
    tail = [l for l in r.stdout.splitlines() if " passed" in l or " failed" in l or " error" in l]
    summ = tail[-1] if tail else "NO SUMMARY"
    coll = "error" in summ and "failed" not in summ and "passed" not in summ
    if not a:
        v = "BASELINE-OK" if r.returncode == 0 else "BASELINE-FAIL"; bad += r.returncode != 0
    else:
        v = "COLLECTION-ERROR" if coll else ("CAUGHT" if r.returncode else "MISSED"); bad += v != "CAUGHT"
    print(f"{v:16} {name} :: {summ}")
shutil.rmtree(tmp, ignore_errors=True)
sys.exit(1 if bad else 0)
