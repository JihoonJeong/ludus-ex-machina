"""hub_drop 0.7.0 변이 검사 — tests/test_hub_drop_scope.py가 판정을 실제로 붙잡는지(공허한 시험이 아닌지).

서버 판정 한 곳을 일부러 망가뜨린 사본을 임시 디렉터리에 만들고 그 시험 파일을 돌린다. 모든 변이가
**시험 실패**로 끝나야 한다. 수집 오류는 잡힘이 아니다.

    python3 scripts/drop_scope_mutation_check.py

종료코드 0 = 기준선 통과 + 모든 변이가 시험 실패로 잡힘.

넣지 않은 변이 둘(결과가 같은 변이): 필드의 빈 값 검사를 빼도 다음 문법 검사가 거부한다. 감사 쓰기의
예외 삼킴을 빼도 감사를 응답 **뒤에** 쓰므로 응답은 그대로다(그래서 '응답보다 먼저, 보호 없이'로 잰다).
"""
import os, pathlib, shutil, subprocess, sys, tempfile
ROOT = pathlib.Path(__file__).resolve().parents[1]
M = {
 "baseline": ("", ""),
 "sig 닻 $로": (r'_SIG_RE = re.compile(r"^[0-9a-f]{128}\Z")', r'_SIG_RE = re.compile(r"^[0-9a-f]{128}$")'),
 "n 닻 $로": (r'_N_RE = re.compile(r"^[0-9]{3,6}\Z")', r'_N_RE = re.compile(r"^[0-9]{3,6}$")'),
 "body_name 닻 $로": (r'_BODY_NAME_RE = re.compile(r"^body\.[a-z0-9]{1,8}\Z")', r'_BODY_NAME_RE = re.compile(r"^body\.[a-z0-9]{1,8}$")'),
 "범위 검사 제거": ('        if not entry.allows(axis, loc[0], loc[1]):', '        if False:'),
 "쓰기를 읽기 범위로 판정": ('        gate = self._gate("write")', '        gate = self._gate("read")'),
 "읽기를 쓰기 범위로 판정": ('        gate = self._gate("read")', '        gate = self._gate("write")'),
 "생략한 축을 전부 허용": ('write=_SCOPE_ALL if legacy else scope.get("write", ()),', 'write=scope.get("write", _SCOPE_ALL),'),
 "id만 붙은 줄을 범위 줄로": ('        legacy = not scope\n', '        legacy = not scope and id_ is None\n'),
 "문 목록 안 추림": ('            self._send(200, {"channels": _filter_tree(_channel_tree(self.root), entry)})', '            self._send(200, {"channels": _channel_tree(self.root)})'),
 "채널 별 무시": ('    return ch in ("*", channel) and dr in ("*", door)', '    return ch == channel and dr in ("*", door)'),
 "문 별 무시": ('    return ch in ("*", channel) and dr in ("*", door)', '    return ch in ("*", channel) and dr == door'),
 "폐기 줄 통과": ('        if entry.revoked:\n', '        if False:\n'),
 "폐기 줄이 예산을 먹음(한도 검사가 먼저)": ('        if entry.revoked:\n            self._send(401, {"error": "bearer 토큰 필요"})', '        if self.limiter.check(entry.token) is not None:\n            self._send(429, {"error": "x"})\n            return None\n        if entry.revoked:\n            self._send(401, {"error": "bearer 토큰 필요"})'),
 "부가 기록이 응답보다 먼저, 보호 없이": ('        self._send(200, {"n": n, "stored": True, "dedup": False})\n        self._audit(entry, 200, channel=channel, door=door, n=n,', '        open(self.audit_dir / "sidecar", "a").close()\n        self._send(200, {"n": n, "stored": True, "dedup": False})\n        self._audit(entry, 200, channel=channel, door=door, n=n,'),
 "감사에 토큰 값": ('"id": entry.id,\n                    "method"', '"id": entry.token,\n                    "method"'),
 "감사 출발지 그대로": ('        return hashlib.sha256(addr.encode("utf-8", "replace")).hexdigest()[:16]', '        return addr'),
 "감사가 운반 트리 안 허용": ('        if audit_p == root_r or root_r in audit_p.parents:', '        if False:'),
 "409 지문 누락": ('                self._audit(entry, 409, channel=channel, door=door, n=n,\n                            envelope_sha256=env_sha, stored=False)', '                self._audit(entry, 409, channel=channel, door=door, n=n, stored=False)'),
 "중복 토큰 허용": ('    for attr, label in (("token", "같은 토큰이 두 줄에 있다"), ("id", "같은 id가 두 줄에 있다")):', '    for attr, label in (("id", "같은 id가 두 줄에 있다"),):'),
 "중복 id 허용": ('    for attr, label in (("token", "같은 토큰이 두 줄에 있다"), ("id", "같은 id가 두 줄에 있다")):', '    for attr, label in (("token", "같은 토큰이 두 줄에 있다"),):'),
 "모르는 필드 무시": ('                if not sep or key not in ("id", "write", "read") or not value:\n                    raise ValueError("알 수 없는 필드이거나 값이 비었다(필드는 id= · write= · read= · revoked)")', '                if not sep or key not in ("id", "write", "read") or not value:\n                    continue'),
 "429 뒤에 범위(403이 예산 무소비)": ('        retry = self.limiter.check(entry.token)\n        if retry is not None:', '        retry = None if _split_path(self.path.split("?", 1)[0]) and not entry.legacy else self.limiter.check(entry.token)\n        if retry is not None:'),
 "오류에 줄 내용 실림": ('            raise ValueError(f"토큰 파일 {lineno}번째 줄: {e}") from None', '            raise ValueError(f"토큰 파일 {lineno}번째 줄: {e} [{line}]") from None'),
 "발신함 번호 닻 $로": None,
}
env = dict(os.environ)
bad = 0
tmp = tempfile.mkdtemp(prefix="dropmut-")
for name, pair in M.items():
    d = pathlib.Path(tmp) / "w"
    shutil.rmtree(d, ignore_errors=True)
    (d / "tests").mkdir(parents=True)
    shutil.copytree(ROOT / "src", d / "src", ignore=shutil.ignore_patterns("__pycache__", "*.egg-info"))
    shutil.copy(ROOT / "tests/test_hub_drop_scope.py", d / "tests/")
    if pair is None:
        f = d / "src/organum/hub_ops.py"; a, b = r'_QUAD_N_RE = re.compile(r"^[0-9]{3,6}\Z")', r'_QUAD_N_RE = re.compile(r"^[0-9]{3,6}$")'
    else:
        f = d / "src/organum/hub_drop.py"; a, b = pair
    src = f.read_text(encoding="utf-8")
    if a and src.count(a) != 1:
        print(f"ANCHOR MISSING({src.count(a)}): {name}"); bad += 1; continue
    if a:
        f.write_text(src.replace(a, b), encoding="utf-8")
    r = subprocess.run([sys.executable, "-m", "pytest", str(d / "tests"), "-q", "-p", "no:cacheprovider", "-x"],
                       capture_output=True, text=True, env=env, cwd=d)
    tail = [l for l in r.stdout.splitlines() if " passed" in l or " failed" in l or " error" in l]
    summ = tail[-1] if tail else "NO SUMMARY"
    coll = "error" in summ and "failed" not in summ and "passed" not in summ
    if not a:
        v = "BASELINE-OK" if r.returncode == 0 else "BASELINE-FAIL"; bad += r.returncode != 0
    else:
        v = "COLLECTION-ERROR" if coll else ("CAUGHT" if r.returncode else "MISSED"); bad += v != "CAUGHT"
    print(f"{v:16} {name} :: {summ}")
shutil.rmtree(tmp, ignore_errors=True)
sys.exit(1 if bad else 0)
