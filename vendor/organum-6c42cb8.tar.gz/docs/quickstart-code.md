# Organum Code 프리뷰 안내 — supervised coding runtime

> **Source-only public preview** (`0.1.0-preview.1`). 소스와 릴리스 좌표는
> 공개되어 있지만, native 바이너리 배포도 production-ready도 아직 아닙니다.
> 이 페이지는 프리뷰 단계의 제품이 무엇이고 무엇이 아닌지를 정직하게 적어
> 두는 곳입니다.

## 무엇인가

Organum Code는 **backend-neutral coding runtime**입니다 — 서명된 Hub 메시지와
backend 실행을 **감독자(supervisor)가 소유한 경계** 안에서 잇습니다. Hub의
signer/envelope authority를 **복제하지 않고 소비합니다**: 신원과 권위 판정은 Hub
층에 남고, Code는 그 판정 위에서 실행을 감독합니다.

inspector가 "내 에이전트가 뭘 했나"를 사후에 재고, hub가 "커뮤니티끼리 어떻게
믿나"에 답한다면, Code는 그 다음 자리 — **믿을 수 있는 메시지를 실제 실행으로
잇는 자리**를 맡습니다.

## 공개 좌표 (검증 가능한 사실)

- 소스 저장소: <https://github.com/ludex-lab/organum-code>
- annotated immutable tag: `v0.1.0-preview.1` (public commit `b951cb87`)
- source-only prerelease:
  <https://github.com/ludex-lab/organum-code/releases/tag/v0.1.0-preview.1>
- source 아카이브: `organum-code-v0.1.0-preview.1-source.tar` — SHA-256
  `3cec10ed2105a5892b8331417426a683ce0353087b4208ebb5771c02881c66aa`

SHA-256은 **아카이브 무결성** 확인 수단입니다 — publisher authenticity(서명·공증)가
아닙니다. 서명/공증(notarize, Windows code-signing)은 아직 없습니다.

## 설치 — `pip install organum`과 별개입니다

Code는 **standalone 설치**입니다. `pip install organum`에 포함되지 않고,
Inspector/Hub와 단일 설치가 아니며, Python stdlib-only 제품도 아닙니다.

현재 공개 설치 경로는 **소스 경유 하나**입니다 — Bun `1.4.0`(공식 current
stable)이 먼저 동작해야 합니다:

```bash
bun --version        # 1.4.0 — 이게 실패하면 여기서 멈추세요
bun add --global github:ludex-lab/organum-code#v0.1.0-preview.1
organum-code --version
# 제거는:
bun remove --global organum-code
```

이 경로는 macOS·Ubuntu에서 CI로, 저자 로컬에서 실측으로 확인됐고 —
**Windows는 독립 검증이 진행 중**입니다("Windows verified"를 아직 말하지
않는 이유). Bun 설치·업그레이드가 실패하면 Organum Code 설치를 진행하지
마세요. native 바이너리 아카이브(다운로드-한-번 설치)는 다음 슬라이스이며,
공개 전까지 이 페이지는 그 존재를 약속하지 않습니다.

## 검증 구조 (현재 시점의 사실)

tag `v0.1.0-preview.1`과 main의 6-job CI가 macOS·Ubuntu·Windows에서 green입니다
— 두 레인: 고정된 Bun `1.3.14` producer/release 기반, 그리고 Bun `1.4.0`
source-consumer 설치/실행/제거. 이는 **검증 구조에 대한 서술**이며, 아직
닫히지 않은 것(Windows canonical consumer 검증)은 위에 그대로 적어 두었습니다.

## 경계 — 아직 아닌 것

- native binary/MSIX 배포 아님 — 공개면은 source-only
- signed / notarized / Windows code-signed 아님
- production-ready 아님
- 모든 backend/provider adapter가 같은 성숙도로 공개 준비된 것 아님

기준 pin: `ludex-lab/organum-code` `b951cb87` · tag `v0.1.0-preview.1` /
source-only preview.
