# Organum Code preview guide — supervised coding runtime

> **Source-only public preview** (`0.1.0-preview.1`). The source and release
> coordinates are public, but there is no native binary distribution yet and it
> is not production-ready. This page exists to state honestly what the product
> is at the preview stage — and what it is not.

## What it is

Organum Code is a **backend-neutral coding runtime** — it joins signed Hub messages
to backend execution inside a **supervisor-owned boundary**. It **consumes rather
than reproduces** the Hub's signer/envelope authority: identity and authority
decisions stay in the Hub layer, and Code supervises execution on top of those
decisions.

Where inspector measures after the fact ("what did my agents do?") and hub answers
"how do agent communities trust each other?", Code takes the next seat — **joining
trustworthy messages to actual execution**.

## Public coordinates (verifiable facts)

- Source repository: <https://github.com/ludex-lab/organum-code>
- Annotated immutable tag: `v0.1.0-preview.1` (public commit `b951cb87`)
- Source-only prerelease:
  <https://github.com/ludex-lab/organum-code/releases/tag/v0.1.0-preview.1>
- Source archive: `organum-code-v0.1.0-preview.1-source.tar` — SHA-256
  `3cec10ed2105a5892b8331417426a683ce0353087b4208ebb5771c02881c66aa`

SHA-256 is an **archive integrity** check — it is not publisher authenticity.
Signing/notarization (notarize, Windows code-signing) does not exist yet.

## Install — separate from `pip install organum`

Code is a **standalone install**. It is not part of `pip install organum`, is not a
single install with Inspector/Hub, and is not a Python stdlib-only product.

The only public install path today is **via source**, and Bun `1.4.0` (the
official current stable) must work first:

```bash
bun --version        # 1.4.0 — if this fails, stop here
bun add --global github:ludex-lab/organum-code#v0.1.0-preview.1
organum-code --version
# to remove:
bun remove --global organum-code
```

This path is verified by CI on macOS and Ubuntu and by the author's local runs —
**Windows is under independent verification** (which is why this page does not
say "Windows verified"). If installing or upgrading Bun fails, do not proceed
with the Organum Code install. A native binary archive (download-once install)
is the next slice; until it is published, this page does not promise it exists.

## Verification structure (facts as of now)

The 6-job CI is green on macOS·Ubuntu·Windows for both the tag
`v0.1.0-preview.1` and main — two lanes: the pinned Bun `1.3.14`
producer/release foundation, and the Bun `1.4.0` source-consumer
install/run/remove path. This describes the **verification structure**; what has
not closed yet (Windows canonical consumer verification) is stated above as-is.

## Boundaries — not yet

- no native binary/MSIX distribution — the public surface is source-only
- not signed / notarized / Windows code-signed
- not production-ready
- not all backend/provider adapters are publicly ready at the same maturity

Reference pin: `ludex-lab/organum-code` `b951cb87` · tag `v0.1.0-preview.1` /
source-only preview.
