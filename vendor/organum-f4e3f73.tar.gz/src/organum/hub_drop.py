"""organum-hub drop — git 없는 저마찰 전달: 최소 HTTP 우체통 (v0).

첫 접촉 실험(2026-08-16)의 수확에서 나왔다: git이 transport로서 하던 일 셋
(운반·순서·접근권) 중 순서(seq)와 귀속(서명)은 봉투가 이미 지므로, carrier에
남은 요구는 **dumb 바이트 운반 + 목록 조회**뿐이다. 그 이상을 서버에 두지 않는다.

## 신뢰 분담 (정직하게)

- 위조·변조·순서 방지 = **봉투**(서명·seq·digest). 서버는 봉투를 열지도 검증하지도
  않는다 — 검증은 언제나 수신 hub의 admit이 한다. 서버를 신뢰할 필요가 없다.
- 쓰기 접근 = **bearer 토큰**(스팸·낙서 방지일 뿐, 신뢰가 아니다).
- 읽기 기밀 = **배치**(사설망/TLS/토큰) — 사설 git repo와 같은 노출 등급.
  공개 relay가 아니므로 wire v1의 lab-only 동결 경계와 충돌하지 않는다.

## 설계점: 같은 트리를 물화한다

서버 저장소는 git 우체통과 **동일한** `<channel>/from-x/NNN-{envelope.json,sig.txt,
body.*}` 트리다. 파일이 git pull 대신 HTTP로 도착할 뿐이라, 수신 어댑터는
transport_root 스왑만으로 무변경 동작한다.

## 프로토콜 — organum-hub/drop/v0

- `POST /v0/<channel>/<from-x>`  body = {"n","envelope_b64","sig"[,"body_name",
  "body_b64"]} → 200 {"n","stored","dedup"} · 409(같은 n 다른 내용) · 400/401/413
- `GET  /v0/<channel>/<from-x>?since=NNN` → 200 {"quads":[…], "more"} (n 오름차순,
  페이지 20; envelope가 마지막에 쓰이므로 미완성 quad는 목록에 나오지 않는다)
- `GET  /v0/channels` → 200 {"channels": {"<channel>": ["from-x", …], …}} —
  수거기의 문 목록(0.4.9). "채널이 몇 개 있는가"는 서버만 아는데 아무도 물을 수
  없었고, 각 랩이 목록을 기억으로 들다 한 랩이 네 문 중 두 문만 보는 사고가 났다.
  토큰 소지자 전용(예산 1 소비). 정확히 2세그먼트 경로만 예약이라 `channels`라는
  이름의 채널과도 충돌하지 않는다(그 채널의 문은 여전히 3세그먼트).
- 인증: `Authorization: Bearer <token>` (토큰 파일 한 줄 하나, `#` 주석)
- **발신 규약: 자기 문에만 쓴다** — `from-x`는 x가 쓰는 문이고, 다른 집이 읽게
  하려면 자기 문에 올리면 된다(각자 pull한다). 서버는 이걸 **막지 않는다**
  (dumb carrier가 발신자를 판정하기 시작하면 그게 더 나쁘다) — 대신 클라이언트가
  기본 거부한다(0.4.10 `_check_door`, 실사고 산물).
- 토큰(=멤버)별 rate limit: 초과는 429 + `Retry-After` 초. hosted(gated) 티어의
  비용 유계 조건 — 인증 실패(401)는 멤버가 아니므로 예산을 먹지 않고, 인증 전
  플러드 방어는 배치 층(에지/방화벽) 몫이다.

서버는 의도적으로 **단일 스레드**다(요청 직렬화 → 쓰기 경쟁 0). 랩 규모
저빈도 전달이 대상이고, 상주 부담은 프로세스 하나 — 내리면 그만이다.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import math
import re
import time
import urllib.error
import urllib.parse
import urllib.request
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

DROP_PROFILE = "organum-hub/drop/v0"
ENVELOPE_MAX_BYTES = 65536          # hub_wire CONTENT_MAX_BYTES와 같은 값
BODY_MAX_BYTES = 1_048_576
REQUEST_MAX_BYTES = 2 * 1_048_576
PAGE_SIZE = 20
RATE_LIMIT_PER_MINUTE = 60          # 토큰별 기본값 — 0이면 끔(self-host P2P용)
_WINDOW_SECONDS = 60.0
# 기본 예산의 출처(0.4.17, Ray 061): "콜드스타트 ~1분"은 천장에 잘린 값이었다 —
# 천장 400에서 완주 4회가 207~248초(Ray, 08-29~30), LxM 정확값 102.1초(08-27).
# 관측 최대 위 ~20% 여유가 이 수의 공식이다(0.4.17: 248→300 · 0.4.18: 292.8→350 ·
# 0.5.1: 352.6→420 — 나루 089·093의 완주가 표를 밀어올린 첫째·둘째 사례; 093은 새
# 기본 350을 하루 만에 넘었다). 술어는 "몇 초면 되나"가 아니라 "분포의 몇 %를
# 덮는가"(Ray 059) — 420은 관측된 완주 전부를 덮지만, ≥400 잘린 값(09-02)이 분포
# 위끝은 그보다 높을 수 있다고 신호한다. 그것도 관측이지 보증이 아니다. 나루 093의
# 다른 읽기("예산은 완주를 덮는 수가 아니라 잘린 값이 안 나올 때까지 올리는 수")는
# 공식 자체를 바꾸자는 제안이라 계측 규칙 소유자(Ray) 판정 몫 — 0.5.1은 공식 유지.
# 죽은 호스트 앞에서 기본 대기가 길어지는 트레이드는 호출별 --timeout이 받는다(0.4.16).
# ★ 이 수의 원장은 tests/test_hub_drop.py의 _COLDSTART_COMPLETIONS 관측표다(0.4.18,
# Ray 062) — 새 완주 관측은 거기에 행으로 추가하라. 표의 최댓값이 이 수를 넘으면
# 회귀가 시끄럽게 말한다(양방향).
CLIENT_TIMEOUT_SECONDS = 420
                                    # — Ludex 관찰: 종전 30s 고정이 콜드스타트와 겹쳐
                                    # 핸드셰이크 EOF로 보였다. 재푸시는 dedup 멱등.

# 무인증 깨우기 GET(0.4.6)의 예산 — **본 호출 예산에서 파생한다**(0.4.14, Ray 045).
#
# 종전엔 20초 독립 상수였는데, 같은 파일 세 줄 위가 콜드스타트를 ~1분으로 적고
# 있었다. **두 상수가 같은 콜드스타트에 대해 서로 다른 말을 하고 있었다**: 워밍이
# 막으라고 있는 상황(진짜로 식은 인스턴스)이 정확히 워밍이 실패하는 상황이었고,
# `_warm`은 설계대로 조용히 삼키므로 실패한 사실이 아무 데도 안 남았다.
# Ray 실측: 무인증 GET이 401을 돌려주기까지 55초 — 20초 예산으로는 구조적으로
# 도달할 수 없다. 같은 날 그들 pull(timeout 170)은 살고 push는 죽었다.
#
# 숫자를 올리지 않고 **결속**한다: 워밍이 존재하는 이유가 본 호출을 살리는 것이므로
# 두 예산이 독립인 것이 결함의 뿌리였다. 이렇게 두면 다음 사람이 이 주석을 안 읽어도
# 두 줄이 어긋날 수 없다(호스트 티어가 바뀌어 90을 고치면 워밍도 따라 움직인다).
# 대가: 인스턴스가 진짜 죽었을 때 최악 벽시계가 워밍+본 호출로 늘어난다 —
# 워밍 실패는 여전히 본 호출을 막지 않으므로 보험의 성질은 그대로다.
WARMUP_TIMEOUT_SECONDS = CLIENT_TIMEOUT_SECONDS

_CHANNEL_RE = re.compile(r"^[a-z0-9][a-z0-9-]{0,63}$")
_SENDER_RE = re.compile(r"^from-[a-z0-9][a-z0-9-]{0,63}$")
_N_RE = re.compile(r"^[0-9]{3,6}$")
_SIG_RE = re.compile(r"^[0-9a-f]{128}$")
_BODY_NAME_RE = re.compile(r"^body\.[a-z0-9]{1,8}$")


class DropError(Exception):
    """drop 클라이언트 실패 — 서버 상태코드와 본문을 담는다."""

    def __init__(self, status: int, message: str):
        super().__init__(f"HTTP {status}: {message}")
        self.status = status


def load_tokens(path: str | Path) -> list[str]:
    lines = Path(path).read_text(encoding="utf-8").splitlines()
    toks = [l.strip() for l in lines if l.strip() and not l.strip().startswith("#")]
    if not toks:
        raise ValueError(f"토큰 파일이 비어 있다: {path} — 열린 우체통은 만들지 않는다")
    return toks


def _token_match(tokens: list[str], header: str | None) -> str | None:
    """일치한 토큰을 돌려준다(없으면 None) — rate limit이 멤버 단위로 키를 잡도록."""
    if not header or not header.startswith("Bearer "):
        return None
    given = header[len("Bearer "):].strip()
    for t in tokens:
        if hmac.compare_digest(given, t):
            return t
    return None


class RateLimiter:
    """토큰(=멤버)별 고정 창 카운터. per_minute<=0이면 끔.

    단일 스레드 서버 전제의 in-memory 카운터다 — 프로세스 재시작이면 창도
    리셋된다(비용 유계가 목적이지 정밀 계량이 아니다). 키는 토큰의 sha256
    접두라 자료구조에 비밀 원문을 한 벌 더 들고 있지 않는다."""

    def __init__(self, per_minute: int, clock=time.monotonic):
        self.per_minute = per_minute
        self._clock = clock
        self._windows: dict[str, tuple[float, int]] = {}

    def check(self, token: str) -> int | None:
        """허용이면 None(예산 1 소비), 초과면 Retry-After 초(1..60)."""
        if self.per_minute <= 0:
            return None
        key = hashlib.sha256(token.encode("utf-8")).hexdigest()[:16]
        now = self._clock()
        start, count = self._windows.get(key, (now, 0))
        if now - start >= _WINDOW_SECONDS:
            start, count = now, 0
        if count >= self.per_minute:
            return max(1, math.ceil(_WINDOW_SECONDS - (now - start)))
        self._windows[key] = (start, count + 1)
        return None


def _quad_files(dirp: Path, n: str) -> dict | None:
    """완성 quad만 번들로. envelope는 마지막에 쓰이므로 존재+비어있지 않음 = 완성."""
    env_p = dirp / f"{n}-envelope.json"
    sig_p = dirp / f"{n}-sig.txt"
    if not (env_p.is_file() and sig_p.is_file()):
        return None
    env_b = env_p.read_bytes()
    if not env_b:
        return None
    bundle = {"n": n,
              "envelope_b64": base64.b64encode(env_b).decode("ascii"),
              "sig": sig_p.read_text(encoding="utf-8").strip(),
              "body_name": None, "body_b64": None}
    bodies = sorted(dirp.glob(f"{n}-body.*"))
    if bodies:
        bundle["body_name"] = bodies[0].name[len(n) + 1:]
        bundle["body_b64"] = base64.b64encode(bodies[0].read_bytes()).decode("ascii")
    return bundle


def _validate_bundle(obj) -> tuple[str, bytes, str, str | None, bytes | None]:
    """POST 본문 검증 — 모양과 크기만. 봉투 내용 검증은 서버의 일이 아니다."""
    if not isinstance(obj, dict):
        raise ValueError("본문은 JSON 객체")
    n = obj.get("n")
    if not (isinstance(n, str) and _N_RE.match(n)):
        raise ValueError("n은 3~6자리 숫자 문자열")
    sig = obj.get("sig")
    if not (isinstance(sig, str) and _SIG_RE.match(sig)):
        raise ValueError("sig는 hex128")
    try:
        env_b = base64.b64decode(obj.get("envelope_b64", ""), validate=True)
    except Exception:
        raise ValueError("envelope_b64 디코드 실패")
    if not env_b or len(env_b) > ENVELOPE_MAX_BYTES:
        raise ValueError(f"envelope는 1..{ENVELOPE_MAX_BYTES} 바이트")
    body_name, body_b = obj.get("body_name"), None
    if body_name is not None:
        if not (isinstance(body_name, str) and _BODY_NAME_RE.match(body_name)):
            raise ValueError("body_name은 body.<ext> 꼴")
        try:
            body_b = base64.b64decode(obj.get("body_b64", ""), validate=True)
        except Exception:
            raise ValueError("body_b64 디코드 실패")
        if len(body_b) > BODY_MAX_BYTES:
            raise ValueError(f"body는 {BODY_MAX_BYTES} 바이트 이하")
    return n, env_b, sig, body_name, body_b


def _channel_tree(root: Path) -> dict[str, list[str]]:
    """channel/sender 트리 — root 디렉터리 열거를 POST와 같은 문법 필터로 거른다.

    정직한 성질 하나: **첫 봉투가 POST된 문만 보인다**(디렉터리가 그때 생기므로).
    수거기 용도로는 그게 정확히 맞는 의미다 — 약속된 채널이 아니라 실재하는 문.
    문이 하나도 없는 채널은 목록에 없다(POST 경로로는 만들어질 수 없는 모양이라,
    있다면 손이 만든 잔재다)."""
    tree: dict[str, list[str]] = {}
    if not root.is_dir():
        return tree
    for ch in sorted(root.iterdir()):
        if not (ch.is_dir() and _CHANNEL_RE.match(ch.name)):
            continue
        doors = sorted(d.name for d in ch.iterdir()
                       if d.is_dir() and _SENDER_RE.match(d.name))
        if doors:
            tree[ch.name] = doors
    return tree


def _split_path(path: str) -> tuple[str, str] | None:
    parts = [p for p in path.split("/") if p]
    if len(parts) != 3 or parts[0] != "v0":
        return None
    channel, sender = parts[1], parts[2]
    if not (_CHANNEL_RE.match(channel) and _SENDER_RE.match(sender)):
        return None
    return channel, sender


class _DropHandler(BaseHTTPRequestHandler):
    server_version = "organum-hub-drop/0"
    root: Path
    tokens: list[str]
    limiter: RateLimiter

    def _send(self, status: int, obj: dict, headers: dict | None = None):
        raw = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        for k, v in (headers or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(raw)

    def _auth(self) -> str | None:
        """인증 → rate limit. 실패 시 응답까지 보내고 None, 통과면 토큰.

        순서가 계약이다: 인증 실패(401)는 limiter 호출 **전**에 반환 — 멤버가
        아니면 예산을 먹지 않는다(무인증 워밍 GET이 공짜인 근거, 0.4.6)."""
        token = _token_match(self.tokens, self.headers.get("Authorization"))
        if token is None:
            self._send(401, {"error": "bearer 토큰 필요"})
            return None
        retry = self.limiter.check(token)
        if retry is not None:
            self._send(429, {"error": f"rate limit — {retry}초 뒤에"},
                       headers={"Retry-After": str(retry)})
            return None
        return token

    def _gate(self) -> tuple[str, str] | None:
        """인증 → rate limit → 경로 순. 실패 시 응답까지 보내고 None."""
        if self._auth() is None:
            return None
        path = self.path.split("?", 1)[0]
        loc = _split_path(path)
        if loc is None:
            self._send(404, {"error": "경로는 /v0/<channel>/<from-x>"})
            return None
        return loc

    def do_GET(self):  # noqa: N802 — BaseHTTPRequestHandler 계약
        if self.path.split("?", 1)[0] == "/v0/channels":
            if self._auth() is None:
                return
            self._send(200, {"channels": _channel_tree(self.root)})
            return
        loc = self._gate()
        if loc is None:
            return
        since = "000"
        if "?" in self.path:
            q = dict(p.split("=", 1) for p in
                     self.path.split("?", 1)[1].split("&") if "=" in p)
            since = q.get("since", "000")
            if not _N_RE.match(since) and since != "000":
                self._send(400, {"error": "since는 3~6자리 숫자"})
                return
        dirp = self.root / loc[0] / loc[1]
        ns = []
        if dirp.is_dir():
            ns = sorted({f.name.split("-", 1)[0] for f in dirp.glob("*-envelope.json")
                         if _N_RE.match(f.name.split("-", 1)[0])}, key=int)
        fresh = [n for n in ns if int(n) > int(since)]
        quads = [b for n in fresh[:PAGE_SIZE] if (b := _quad_files(dirp, n))]
        self._send(200, {"quads": quads, "more": len(fresh) > PAGE_SIZE})

    def do_POST(self):  # noqa: N802
        loc = self._gate()
        if loc is None:
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            length = 0
        if length <= 0 or length > REQUEST_MAX_BYTES:
            self._send(413, {"error": f"요청은 1..{REQUEST_MAX_BYTES} 바이트"})
            return
        try:
            n, env_b, sig, body_name, body_b = _validate_bundle(
                json.loads(self.rfile.read(length).decode("utf-8")))
        except (ValueError, UnicodeDecodeError) as e:
            self._send(400, {"error": str(e)})
            return
        dirp = self.root / loc[0] / loc[1]
        dirp.mkdir(parents=True, exist_ok=True)
        env_p = dirp / f"{n}-envelope.json"
        if env_p.is_file() and env_p.read_bytes():
            prior = _quad_files(dirp, n)
            same = (prior is not None
                    and base64.b64decode(prior["envelope_b64"]) == env_b
                    and prior["sig"] == sig and prior["body_name"] == body_name
                    and (body_b is None or
                         base64.b64decode(prior["body_b64"] or "") == body_b))
            if same:
                self._send(200, {"n": n, "stored": True, "dedup": True})
            else:
                self._send(409, {"error": f"{n}은 이미 다른 내용으로 존재 — "
                                          "먼저 쓴 것이 남는다"})
            return
        # 쓰기 순서: sig·body 먼저, envelope 마지막 — envelope가 완성 표지
        (dirp / f"{n}-sig.txt").write_bytes((sig + "\n").encode("utf-8"))
        if body_name is not None:
            (dirp / f"{n}-{body_name}").write_bytes(body_b)
        env_p.write_bytes(env_b)
        self._send(200, {"n": n, "stored": True, "dedup": False})


def make_server(root: str | Path, token_file: str | Path,
                bind: str = "127.0.0.1", port: int = 8642,
                rate_limit_per_minute: int = RATE_LIMIT_PER_MINUTE,
                clock=time.monotonic) -> HTTPServer:
    tokens = load_tokens(token_file)
    handler = type("Handler", (_DropHandler,),
                   {"root": Path(root), "tokens": tokens,
                    "limiter": RateLimiter(rate_limit_per_minute, clock=clock)})
    return HTTPServer((bind, port), handler)


# ── 클라이언트 ──────────────────────────────────────────────────────────────

def _warm(url: str, timeout: int = WARMUP_TIMEOUT_SECONDS) -> bool:
    """콜드스타트 깨우기 — **무인증 bare GET** (0.4.6, LxM 008–010 + Ludex 명세).

    두 줄이 명세다:
    ① **HTTPError는 생존으로 센다.** 401·404 둘 다 "인스턴스가 섰다"는 증거다 —
      워밍업이 확인하는 것은 인증이 아니라 생존이다. 실패로 세면 **진단이 뒤집힌다**:
      토큰이 틀린 멤버가 "콜드스타트가 안 풀린다"고 보고하게 된다.
    ② **어떤 실패도 본 호출을 죽이지 않는다** — 워밍업은 보험이지 게이트가 아니다.
      깨우기 실패로 봉투를 안 보내면 새 실패 경로를 만드는 셈이다.

    **본체에 두는 이유**(Ludex 발견, LxM 010): 클라이언트마다 각자 구현하면 누군가는
    토큰을 실어 보내고, 그 순간 워밍업이 멤버 예산을 먹기 시작한다. 무인증 GET이
    공짜인 성질(`_gate()`가 인증 실패를 limiter 호출 **전**에 반환)은 "무인증"이
    지켜질 때만 성립하므로, 규율이 아니라 **코드로 고정한다**."""
    try:
        with urllib.request.urlopen(
                urllib.request.Request(url, method="GET"), timeout=timeout):
            return True
    except urllib.error.HTTPError:
        return True                      # ① 401/404 = 인스턴스 생존
    except Exception:                    # ② 네트워크·TLS·타임아웃 전부 삼킨다
        return False


def _warm_measured(url: str, stats: dict | None = None, *,
                   timeout: int = WARMUP_TIMEOUT_SECONDS) -> bool:
    """워밍 + **지연 계측**(0.4.6). 호스트가 "이 시각엔 따뜻하다"고 공지할 때,
    그 공지의 생사는 약속이 아니라 **관측**으로 판정돼야 한다 —
    *"등록되어 있다는 것과 오늘 아침에 돌았다는 것은 다른 사실이다"*(LxM 022).

    멤버의 평상 트래픽이 그대로 증거가 된다: 공지 시각에 `warm_ms`가 수십 ms면
    시간표가 돌았고, 수만 ms면 안 돌았다. 추가 요청도 새 인프라도 없다.

    `timeout`은 **호출자의 예산을 관통시킨다**(0.4.16, Orin 026). 0.4.14가
    `WARMUP_TIMEOUT_SECONDS = CLIENT_TIMEOUT_SECONDS`로 **기본값 둘**을 결속했는데,
    호출별 override는 본 요청에만 닿고 워밍은 계속 기본값을 썼다 — 그래서
    `--timeout 7`이 "전체 7초"가 아니라 **"워밍 최대 90초 + 본 요청 7초"**였다.
    결속이 기본값 층에서만 성립하고 호출 층에서 끊겨 있었다는 뜻이다. 예산을
    좁히는 쪽은 대개 급한 쪽인데, 그 사람이 정확히 못 받고 있었다."""
    t0 = time.monotonic()
    ok = _warm(url, timeout=timeout)
    if stats is not None:
        stats["warm_ms"] = int((time.monotonic() - t0) * 1000)
        stats["warm_ok"] = ok
        # 상한 병기(0.4.18, Ray 계측 규칙): "상한 없는 값은 길이인지 절단인지
        # 영원히 모른다" — warm_ms가 실패면 이 값은 길이가 아니라 절단점이다.
        stats["warm_budget_s"] = timeout
    return ok


def _request(url: str, token: str, data: bytes | None = None,
             timeout: int = CLIENT_TIMEOUT_SECONDS) -> dict:
    req = urllib.request.Request(
        url, data=data, method="POST" if data is not None else "GET",
        headers={"Authorization": f"Bearer {token}",
                 **({"Content-Type": "application/json"} if data else {})})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        try:
            msg = json.loads(e.read().decode("utf-8")).get("error", "")
        except Exception:
            msg = ""
        raise DropError(e.code, msg or e.reason) from None


def push_quad(url: str, token: str, quad_prefix: str | Path,
              timeout: int = CLIENT_TIMEOUT_SECONDS, warmup: bool = True,
              stats: dict | None = None,
              allow_foreign_door: bool = False) -> dict:
    """export가 만든 quad(`<dir>/NNN` 접두)를 POST. 같은 내용 재전송은 dedup 수렴.

    발신 문 게이트(0.4.10, `_check_door`)가 **네트워크 접촉 전에** 돈다 — 자기 문이
    아니면 아무것도 보내지 않고 거부한다. 정당한 대리 전달은 `allow_foreign_door`.

    `stats` dict를 주면 워밍 계측(`warm_ms`·`warm_ok`)을 채워 준다 — 반환 모양은
    안 바꾼다(교차 랩 소비 계약 보존)."""
    prefix = Path(quad_prefix)
    n = prefix.name
    if not _N_RE.match(n):
        raise ValueError(f"quad 접두는 <dir>/NNN 꼴: {quad_prefix}")
    env_p = prefix.parent / f"{n}-envelope.json"
    sig_p = prefix.parent / f"{n}-sig.txt"
    if not (env_p.is_file() and sig_p.is_file()):
        raise ValueError(f"quad 불완전: {env_p.name} / {sig_p.name} 필요")
    _check_door(url, env_p.read_bytes(), allow_foreign_door)
    if warmup:
        _warm_measured(url, stats, timeout=timeout)
    bundle = {"n": n,
              "envelope_b64": base64.b64encode(env_p.read_bytes()).decode("ascii"),
              "sig": sig_p.read_text(encoding="utf-8").strip(),
              "body_name": None, "body_b64": None}
    bodies = sorted(prefix.parent.glob(f"{n}-body.*"))
    if bodies:
        bundle["body_name"] = bodies[0].name[len(n) + 1:]
        bundle["body_b64"] = base64.b64encode(bodies[0].read_bytes()).decode("ascii")
    return _request(url, token, json.dumps(bundle).encode("utf-8"), timeout=timeout)


def _door_for_signer(signer_id) -> str | None:
    """봉투 서명자 → 그가 쓸 수 있는 문 이름. 파생 불가면 None(호출자가 fail-closed).

    문법은 결정적이다: 봉투 스키마의 signer.id는 `lab:<name>` 고정이므로
    `lab:x` → `from-x`. 다만 lab 문법(`.`·`_` 허용)이 sender 문법(`-`만)보다
    넓어서 파생 결과가 문 이름이 못 되는 경우가 있다 — 그때는 추측하지 않고
    None을 돌려준다(r3 교훈: 파생이 안 서는 자리는 fail-closed)."""
    if not isinstance(signer_id, str) or not signer_id.startswith("lab:"):
        return None
    door = f"from-{signer_id[len('lab:'):]}"
    return door if _SENDER_RE.fullmatch(door) else None


def _check_door(url: str, env_b: bytes, allow_foreign_door: bool) -> None:
    """**발신 문 게이트**(0.4.10) — 자기 문에만 쓴다. 실사고에서 나왔다.

    2026-08-26, 나는 우리 서명 봉투를 `from-ludex`·`from-ray`에 POST했다. 서버는
    dumb carrier라 막지 않았고(설계된 성질이고 좋은 성질이다), append-only라
    철회도 못 했다. 세 번째 문이 409로 막힌 것이 사고를 두 자리에서 멈춰 세웠다.
    **서버가 막지 않는다는 것과 해도 된다는 것은 다르다** — 그 사이를 규율이
    메우고 있었고, 규율은 한 번의 착각으로 무너진다. 그래서 기계로 옮긴다.

    층위(0.4.5 admit 게이트와 같은 자리): **서버가 아니라 클라이언트**다. carrier가
    발신자를 판정하기 시작하면 그게 더 나쁘다. 그리고 라이브러리 본체에 둔다
    (_warm과 같은 논리, Ludex 010): 클라마다 구현하면 누군가는 빼먹는다.

    **축을 혼동하지 말 것**: 이 게이트는 *전송로의 문*을 본다. 0.4.5의
    `--accept-foreign-target`은 *봉투의 수신자*를 본다. 다른 축이고, 발신이 타 lab을
    target하는 것은 여전히 본래 목적이다(그 경계는 옮기지 말 것).

    성공 조건을 명시-나열한다(fail-open 3연발의 교훈 — 게이트는 열거형으로만):
    ① URL이 `/v0/<channel>/<from-x>`로 파싱된다 ② 봉투가 JSON으로 읽힌다
    ③ signer.id에서 문 이름이 파생된다 ④ 파생한 문 == URL의 문. 넷 다 참일 때만
    통과하고, 그 밖은 전부 거부다. 정당한 대리 전달은 `allow_foreign_door`로
    **명시**한다 — 실수가 아니라 결정이 되도록."""
    if allow_foreign_door:
        return
    loc = _split_path(urllib.parse.urlsplit(url).path)
    if loc is None:
        raise ValueError(
            f"push 대상 URL이 /v0/<channel>/<from-x> 꼴이 아니다: {url} — "
            "발신 문을 판정할 수 없어 거부한다(allow_foreign_door로 명시 가능)")
    try:
        signer_id = (json.loads(env_b.decode("utf-8")).get("signer") or {}).get("id")
    except (ValueError, UnicodeDecodeError, AttributeError):
        raise ValueError(
            "봉투를 JSON으로 읽을 수 없어 발신 문을 판정할 수 없다 — 거부한다"
        ) from None
    door = _door_for_signer(signer_id)
    if door is None:
        raise ValueError(
            f"서명자 {signer_id!r}에서 문 이름을 파생할 수 없어 거부한다"
            "(fail-closed) — 의도한 전달이면 allow_foreign_door로 명시하세요")
    if door != loc[1]:
        raise ValueError(
            f"남의 문에 쓰려 한다 — URL의 문 {loc[1]}, 이 봉투의 서명자 "
            f"{signer_id}(자기 문 {door}). 발신은 자기 문에만 하고, 다른 집이 읽게 "
            "하려면 자기 문에 올리면 된다(각자 pull한다). 대리 전달이 정말 의도라면 "
            "allow_foreign_door로 명시하세요")


def list_channels(url: str, token: str,
                  timeout: int = CLIENT_TIMEOUT_SECONDS,
                  warmup: bool = True, stats: dict | None = None) -> dict:
    """서버의 channel/sender 트리를 묻는다(0.4.9). `url`을 **그대로** GET한다 —
    CLI `--url`도 `…/v0/channels` 전체 경로를 받는다(base만 주면 서버가 404로
    "경로는 /v0/<channel>/<from-x>"를 돌려준다 — 09-11 우리 오용 실측, 0.5.1 정정).

    수거 목록을 기억이 아니라 서버에 묻기 위한 한 콜이다. 어느 랩의 수거기가
    채널 목록을 기억으로 들다 네 문 중 두 문만 보게 된 사고가 근거 — "영수증은
    수거가 일어났다고 말하지, 회차가 완전했다고 말한 적이 없다"(Ray). 수거기는
    회차 시작에 이 트리와 자기 목록을 대조하면 같은 병에서 벗어난다."""
    if warmup:
        _warm_measured(url, stats, timeout=timeout)
    return _request(url, token, timeout=timeout)


def fetch_page(url: str, token: str, since: str = "000",
               timeout: int = CLIENT_TIMEOUT_SECONDS,
               stats: dict | None = None) -> dict:
    """한 문의 한 페이지(`?since=NNN`, PAGE_SIZE) — 0.6.0 bbs_wire의 종류 탐색·재개용.
    `stats["pages"]`를 1 올린다(회차 GET 계수, Orin 040 §4)."""
    page = _request(f"{url}?since={since}", token, timeout=timeout)
    if stats is not None:
        stats["pages"] = stats.get("pages", 0) + 1
    return page


def pull_quads(url: str, token: str, dest: str | Path,
               since: str | None = None,
               timeout: int = CLIENT_TIMEOUT_SECONDS,
               warmup: bool = True, stats: dict | None = None) -> list[str]:
    """새 quad를 받아 로컬 우체통 트리에 내려쓴다. since 생략 시 로컬 최대 NNN부터.

    로컬도 append-only 우편함이다 — 이미 있는 파일은 절대 덮어쓰지 않는다.

    0.6.0(Ray 101 F1): envelope는 있는데 sig/body가 **빠진** quad는 서버가 다시 주면
    빠진 파일만 채운다(복구). 남아 있는 파일은 건드리지 않고, 남아 있는 파일의 bytes가
    서버와 다르면 ValueError로 **명시 오류**(손으로 바뀐 트리를 조용히 고치지 않는다).
    복구된 번호도 반환 목록에 들어가고 `stats["repaired"]`가 센다.

    `stats` dict를 주면 워밍 계측(`warm_ms`·`warm_ok`)과 정상 응답 페이지 수(`pages`)를
    채워 준다."""
    if warmup:
        _warm_measured(url, stats, timeout=timeout)
    dest = Path(dest)
    dest.mkdir(parents=True, exist_ok=True)
    if since is None:
        have = [int(f.name.split("-", 1)[0]) for f in dest.glob("*-envelope.json")
                if _N_RE.match(f.name.split("-", 1)[0])]
        since = f"{max(have):03d}" if have else "000"
    written: list[str] = []
    while True:
        page = fetch_page(url, token, since, timeout=timeout, stats=stats)
        for q in page["quads"]:
            n = q["n"]
            if not _N_RE.match(n):
                raise DropError(502, f"서버가 준 n이 형식 위반: {n!r}")
            env_p = dest / f"{n}-envelope.json"
            sig_p = dest / f"{n}-sig.txt"
            sig_bytes = (q["sig"] + "\n").encode("utf-8")
            body_p = body_bytes = None
            if q.get("body_name"):
                if not _BODY_NAME_RE.match(q["body_name"]):
                    raise DropError(502, f"서버가 준 body_name 형식 위반: "
                                         f"{q['body_name']!r}")
                body_p = dest / f"{n}-{q['body_name']}"
                body_bytes = base64.b64decode(q["body_b64"])
            if not env_p.exists():
                sig_p.write_bytes(sig_bytes)
                if body_p is not None:
                    body_p.write_bytes(body_bytes)
                env_p.write_bytes(base64.b64decode(q["envelope_b64"]))   # 완결 표지는 마지막
            else:
                # 완결된 로컬 quad(세 파일 다 있음)는 종전 계약대로 **무접촉**(0.4.x: 이미 받은
                # 것은 손대지 않는다 — 변조는 read의 서명 검증이 잡는다). **복구가 필요한
                # quad**(동반 파일이 빠짐)만 042 R3: 남아 있는 파일 전부(envelope 포함)를
                # 먼저 대조하고, 하나라도 서버 bytes와 다르면 아무것도 쓰지 않고 명시 오류 —
                # 충돌하는 quad에 복구 성공 표시가 남지 않는다. 대조는 불투명 bytes 동일성.
                trio = ((env_p, base64.b64decode(q["envelope_b64"]), "envelope"),
                        (sig_p, sig_bytes, "sig"), (body_p, body_bytes, "body"))
                missing = [t for t in trio if t[0] is not None and not t[0].exists()]
                if missing:
                    for path, want, label in trio:
                        if path is not None and path.exists() and path.read_bytes() != want:
                            raise ValueError(
                                f"{path.name}: 로컬 {label} bytes가 서버와 다르다 — 덮어쓰지 "
                                "않는다(손으로 바뀐 트리는 사람이 판정한다)")
                    for path, want, _label in missing:
                        path.write_bytes(want)
                    if stats is not None:
                        stats["repaired"] = stats.get("repaired", 0) + 1
            written.append(n)                  # 반환 = 페이지에서 본 번호(종전 의미 유지)
            since = n
        if not page.get("more"):
            return written
