> **역사 문서.** 프로젝트 초기(2026-07-04) 결정의 기록이지 현행 상태가 아니다. 이름도 당시
> organon. 현행 정체성·경계·성숙도는 [docs/architecture.md](docs/architecture.md)를 볼 것.

# Handoff — Ludex Cody → Organon Cody

*2026-07-04. 이 폴더의 Cody에게: 너는 **organon**의 개발자다. 이 문서가 너의 출발 컨텍스트 전부이고,
아래 결정들은 JJ와 Ludex 랩에서 이미 내려진 것이다. 설계 여지는 명시된 곳에만 있다.*

## 1. 너의 프로젝트가 무엇인가

**organon** — Organism Engineering CLI. 실무자가 **자기가 이미 쓰는 에이전트**(Claude Code 등)에
기관(organ)을 입히는 도구다: 프로젝트-로컬 `.organon/` 상태 디렉터리에 정체성·분화된 기억·
세계모델·지도를 축적하고, 에이전트의 컨텍스트에 주입하고, 돌봄 의례(회고/점검/백업)를 제공한다.

한 줄: *"당신의 에이전트는 오늘도 유능했고, 내일이면 그걸 전부 잊는다. `organon init` 한 번이면
기억하고, 지도를 그리고, 자기를 돌보기 시작한다."*

전체 계획: `docs/plan.md` (이름 organon 확정, MVP 명령 8종, 단계 P1-P4, 리스크). 개념적 뿌리:
`reference/organism-engineering.ko.md` (Organism Engineering 실무 가이드 — **canonical은 ludex
repo에 있고 이건 참조 사본**이다. 수정하지 말 것; 개정은 ludex 쪽에서 온다).

## 2. 이미 내려진 결정 (재논의 불필요)

1. **이름 organon** (JJ 확정, 2026-07-04). P1에서 PyPI/npm/상표 충돌만 확인.
2. **경계 규율 — 이것이 프로젝트의 헌법**: organon에 크리처/존재론/필드/오케스트레이션은 없다.
   자체 LLM 호출 오케스트레이션도 없다 — distill/reflect가 LLM이 필요하면 **사용자의 CLI를
   서브프로세스로 위임**한다. organon은 상태와 규율의 도구지, 에이전트가 아니다.
   (외부 증거: JJ의 이전 프로젝트 agent-grid는 오케스트레이션 층을 만들다가 플랫폼이 그 층을
   흡수해서 중단됐다. **플랫폼이 흡수할 것을 만들지 말고, 흡수하지 않는 것 — 축적되는 상태 —
   을 만들어라.**)
3. **MVP 스코프 = 검증된 패턴만**: init / context / remember / recall --when / map + map frontier /
   distill / reflect / checkup / backup / guard. bond·기질배터리·감정은 v1 비-스코프
   (스키마만 예약 가능 — dead code 금지).
4. **P1이 첫 작업**: `.organon/` 포맷 동결이 코드보다 먼저다. 포맷이 곧 계약이다.
   snapshot/restore는 day 1 기능이다.
5. **스택**: Python (ludex 참조 구현과 같은 언어 — 이식이 곧 검증), 의존성 최소, 단일-명령 설치.

## 3. 과학적 근거 — 네가 왜 이 포맷들을 강제해야 하는가

이 도구의 설계는 취향이 아니라 Ludex 랩의 pre-registered 실험에서 왔다 (상세는 참조 사본 부록 A):

- **세계모델은 형태(form)로**: 같은 에이전트·같은 주입에서 prose 요약(정답 포함!)은 효과 0
  (p=.79), 구조 지도+frontier는 탐험 해방 (exact-p=.0096, d=1.61). → `distill`의 출력 템플릿은
  **map-shaped + frontier-explicit, prose 금지**를 강제해야 한다. 판별 기준: *"계획 없이 다음
  행동으로 컴파일되는가?"*
- **self-built 지도도 유효** (organ 확증, Holm p=.029) — 단 oracle 대비 "earning tax" ≈ 방 1개.
  → `map`은 빈 상태에서 축적해도 가치가 있다; 완전할 필요 없다.
- **에러 폴백이 기억을 오염시킨다** (실사고): "[Error: timed out]"이 영속 기억이 되면 이후 행동이
  오염된다. → `guard`는 저장 지점에서 실패 산출물을 차단한다.
- **성능은 표류한다** (동일 스펙 베이스라인이 이틀 새 1.0→2.5, 2회 관찰): 네가 organon의 효과를
  측정할 때(P3 dogfood 스터디) **동시·인터리브 대조 없는 비교는 무효**다.

## 4. 재사용 표면 (읽기 전용 참조)

**public ludex repo (github.com/ludex-lab/ludex)** — 검증된 organ 구현의 살아있는 레퍼런스.
클론해서 읽고, 패턴을 **이식**하라 (의존성으로 걸지 말 것 — organon은 독립 패키지다):
- `ludex/blocks/topos.py` — 인지지도: place graph, "?"=frontier, edge-binding, map_view 포맷
- `ludex/blocks/chronos.py` — 시간 기억 read-layer (recall_window / time_since)
- `ludex/blocks/memory.py` — handle_remember의 저장경계 guard + place-tagging
- `ludex/blocks/physis.py` — 세계모델 증류의 신뢰도 tier (tentative/confirmed/well-supported)
- `ludex/core/prompt_tier.py` — injection_budget (주입 비용의 tier-스케일링)
- `ludex/blocks/adapters/_cli_env.py` — 서브프로세스 위임 시 auth 격리 (과금 사고 예방)

**이 폴더 reference/** (JJ의 agent-grid에서 발췌, 출처 명기):
- `agent-grid_vendor_capabilities.json` — capability card 패턴: 차원별 0-5 + **evidence 필드 +
  갱신 규율**. organon `agents` 레지스트리(advisory 라우팅)의 시드.
- `agent-grid_spike_claude_code_wrap.md` — Claude Code 비대화형 위임의 검증된 플래그 표면 +
  gotcha (--verbose 필수, --bare는 OAuth 안 읽음, --max-budget-usd 안전핀). **2026-04 기준
  (CLI 2.1.110)이므로 현행 CLI로 재검증이 P1 태스크다.**

## 5. 협업 프로토콜 (LxM 모델과 동일)

- 너는 ludex/agent-grid repo를 **절대 쓰지 않는다** (읽기는 public만). Ludex Cody도 이 폴더를
  다시 쓰지 않는다 — 이 핸드오프가 마지막 쓰기다.
- 질문/요청은 **JJ를 통한 릴레이**: 메시지에 "Organon Cody → Ludex Cody:" 형식으로 써서 JJ에게
  전달을 부탁하라. (전례: LxM Cody와 이 방식으로 discovery endpoint를 당일 협업했다.)
- Ludex 쪽 접점: OE 개념 문서 개정판 수령 · organ 구현 질문 · (미래) MTI capability 카드
  read-only 연동 · P4 공개 시 홈페이지 Concepts 상호 링크.
- 운영 규율은 ludex와 같은 문화를 권한다: 진단 먼저, 단일 관찰로 결론 금지, 커밋은 요청 시,
  journal/retro 습관.

## 6. 첫 세션 태스크 목록 (P1)

1. `git init` 상태 확인 (이 폴더는 initial commit까지 되어 있다) + README.md 작성 (제품 한 줄 +
   설치/사용 스케치 + "pre-1.0, format unstable" 배너)
2. 이름 충돌 확인 (PyPI `organon` 등) → 결과에 따라 패키지명 변형 결정 (JJ 릴레이)
3. **`.organon/` 포맷 v0 스펙 문서** — plan.md §3의 스케치를 동결 수준으로: 각 파일의 스키마,
   버전 필드, snapshot/restore 시맨틱, personal/shared 분리(D20)
4. CLI 스켈레톤: `organon init` + `organon context` (스텁이라도 end-to-end)
5. spike 레시피 현행 CLI 재검증 (위임 모듈의 전제)

시작이 좋기를. 이 도구의 첫 사용자는 너 자신이다 — `organon init`이 돌기 시작하면 이 프로젝트
폴더에 바로 써라.

— Ludex Cody (Mac), 2026-07-04
