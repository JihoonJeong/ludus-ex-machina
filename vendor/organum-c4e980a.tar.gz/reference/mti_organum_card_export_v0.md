<!-- 참조 사본. canonical: github.com/JihoonJeong/model-temperament-index/organum_card_export_v0.md
     수령: 2026-07-04 JJ 릴레이 (Ray). 수정 금지 — 개정은 MTI 쪽에서 온다. -->

# MTI → Organum card export — schema v0

*Ray, 2026-07-04. The version-pinned export contract for MTI temperament data consumed
read-only by [organum](../organum) (`.organum/agents/<name>.card.json`). Locked at organum's P1
format-freeze per organon-plan §9-3. **MTI is the sole writer of these cards; organum only reads.***

## Why a separate export format (not mti.json directly)

`creatures/<name>/mti.json` (schema `mti/v1`) is Ludex's *internal* representation — it assumes a
creature, a cohort context, and Ludex's render pipeline (`/twin`). If organum read it directly the
two projects would couple: any internal change would break organum. The export card is a **stable,
minimal, self-describing** projection. Internal `mti/v1` may evolve freely; `mti.card/v0` changes
only on an explicit version bump.

## The contract (5 rules)

1. **`card_format` is mandatory and is the discriminator.** Value `"mti.card/v0"`. Organum reads
   only card_formats it knows (reserved in organum spec §8); an unknown value → **ignore the card,
   do not error** (forward compatibility).
2. **Read-only for organum.** MTI (or its exporter) is the only writer. Organum never writes back
   into an agent card.
3. **Advisory-only.** `advisory: true` is fixed. Organum may surface a card in context/routing
   *hints* ("this agent is measured Fluid") but MUST NOT auto-route or auto-execute on it. Matches
   the agent-grid lesson (§7-1): capability/disposition cards *inform*, humans decide.
4. **Additive evolution.** New fields may be added within v0; organum ignores unknown fields. Only
   a **breaking** change (rename/remove/re-semantic a field) bumps to `mti.card/v1`.
5. **measured ≠ asserted.** Every card carries `provenance` with an evidence link, `measured_at`,
   and the battery protocol version. A card with no provenance is invalid and must be ignored.

## Schema (`mti.card/v0`)

```json
{
  "card_format": "mti.card/v0",        // REQUIRED, discriminator
  "agent": "<organum agent alias>",     // REQUIRED, the user's name for this agent
  "brain_model": "<measured model id>", // REQUIRED, the model the battery actually ran on
  "kind": "temperament",                // REQUIRED, card class (organum groups by kind)
  "advisory": true,                     // REQUIRED, always true for v0
  "disposition": {                      // REQUIRED, the 4 MTI axes
    "reactivity": { "score": 0.0-1.0, "z": <float>, "pole": "<fluid|anchored|neutral>" },
    "compliance": { "score": 0.0-1.0, "z": <float>, "pole": "<guided|independent|neutral>" },
    "sociality":  { "score": 0.0-1.0, "z": <float>, "pole": "<social|solitary|neutral>" },
    "resilience": { "score": 0.0-1.0, "z": <float>, "pole": "<tough|brittle|neutral>" }
  },
  "summary": "<one-line human-readable disposition>",   // REQUIRED, for context injection
  "score_semantics": {                  // REQUIRED, makes the numbers self-describing
    "score": "cohort percentile [0,1]",
    "z": "cohort-relative standard score",
    "pole": "named pole label"
  },
  "provenance": {                       // REQUIRED (rule 5)
    "instrument": "MTI",
    "battery_protocol": "<e.g. MTI v2 Phase-4>",
    "cohort": "<cohort id>",
    "cohort_n": <int>,
    "measured_at": "<YYYY-MM-DD>",
    "temperature": <float>,
    "evidence": "<citation / repo@commit / URL>",
    "measures": "disposition, NOT capability"   // the MTI central caveat, machine-readable
  }
}
```

### Field mapping from internal `mti/v1`
- `mti/v1.axes.*` → `disposition.*` verbatim (score/z/pole unchanged).
- `mti/v1.provenance.{battery_protocol,cohort,cohort_n,measured_at,temperature,brain_model}` →
  `provenance.*` / top-level `brain_model`.
- **Added on export:** `card_format`, `agent`, `kind`, `advisory`, `summary` (rendered from poles),
  `score_semantics`, `provenance.evidence`, `provenance.measures`.
- **Dropped on export:** the internal render note (Ludex-specific).

## Staleness (organum-side, spec'd here so both sides agree)

Organum SHOULD flag a card stale when the agent's currently-configured model ≠ `brain_model`
(the disposition was measured on a different brain). Mirrors Ludex `/twin` staleness. `measured_at`
older than the battery's re-measure cadence is a soft warning, not invalidation.

## Example (real data — Loom's brain, exaone3.5:7.8b, `creatures/Loom/mti.json`)

See `organum_cards/exaone-local.card.json` in this repo. Exporter (natural next step, one function:
`mti.json → card.json`) is P1-side; not built here — the **schema** is the deliverable.
