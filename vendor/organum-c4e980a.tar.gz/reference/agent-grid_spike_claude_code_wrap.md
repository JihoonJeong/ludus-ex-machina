# Sprint 0 Spike: Claude Code Subprocess Wrap (Risk K4 검증)

**날짜**: 2026-04-16
**목표**: Risk K4 검증 — Claude Code를 워커 daemon에서 비대화형 subprocess로 wrap 가능한가?
**결과**: ✅ **검증 성공**. 추가 우회 (MCP server 노출 등) 불필요. 거의 모든 wrap 우려가 CLI 플래그로 해결됨.

---

## 검증된 환경

```
claude --version  →  2.1.110 (Claude Code)
node v22.16.0
macOS Darwin 25.4.0
```

---

## 핵심 CLI 플래그 (워커 wrap에 필요한 모든 것)

| 플래그 | 용도 | 우리 워커 daemon에 함의 |
|---|---|---|
| `-p / --print` | 비대화형 단일 prompt 실행 | 워커 invocation의 기본 모드 |
| `--output-format json\|stream-json` | 구조화 출력 | text는 안 씀, stream-json 우선 |
| `--include-partial-messages` | streaming chunk 포함 | A2A `TaskArtifactUpdateEvent` 매핑 |
| `--verbose` | stream-json 사용 시 필수 | (gotcha) verbose 없으면 prompt 인식 안 됨 |
| `--input-format stream-json` | 실시간 streaming 입력 (옵션) | follow-up turn 동적 주입 가능 |
| `--max-budget-usd X` | 하드 cost cap | **워커 안전성 핵심** — over-budget 자동 abort |
| `--permission-mode acceptEdits` | 권한 자동 승인 | 워커는 prompt 못 답하므로 필수 |
| `--allowed-tools "Read Edit Write Bash"` | 도구 제한 | sandboxing, capability 정확히 매칭 |
| `--disallowed-tools` | 도구 차단 | 보안 정책 |
| `--add-dir <path>` | 추가 작업 디렉토리 허용 | 작업 scope 한정 |
| `--no-session-persistence` | 세션 저장 안 함 | 워커는 stateless task 단위 |
| `--session-id <uuid>` | 명시적 세션 ID | A2A `Task.id`와 매핑 |
| `--resume` | 이전 세션 재개 | follow-up task 처리 |
| `--mcp-config <file>` | MCP 서버 추가 | 우리 도구 확장 가능 (예: agent-grid 데이터 fetch) |
| `--bare` | 최소 모드 (hooks/keychain/auto-memory 끄기) | 단, ANTHROPIC_API_KEY 필수 (OAuth 안 읽음) |
| `--system-prompt` / `--append-system-prompt` | 역할 prompt | 워커별 specialty 설정 |
| `--model <name>` | 모델 선택 | capability ad와 일치 보장 |
| `--effort low\|medium\|high\|max` | reasoning effort | cost·quality tradeoff 워커 단에서 |
| `--fallback-model` | overload 시 폴백 | resilience! D27 (vendor diversification)과 다른 layer |
| `--json-schema` | 구조화 출력 검증 | A2A artifact의 structured data part에 활용 |

---

## 검증 시나리오 1: 단순 호출 + JSON 출력

**명령**:
```bash
claude -p --output-format json --no-session-persistence --max-budget-usd 0.10 \
  "What is 2+2?"
```

**결과**: 1.7초, 단일 turn, 결과 "4". JSON 출력 구조:

```json
{
  "type": "result",
  "subtype": "success",
  "is_error": false,
  "duration_ms": 1722,
  "duration_api_ms": 1524,
  "num_turns": 1,
  "result": "4",
  "stop_reason": "end_turn",
  "session_id": "...",
  "total_cost_usd": 0.05247525,
  "usage": {
    "input_tokens": 6,
    "cache_creation_input_tokens": 7079,
    "cache_read_input_tokens": 16103,
    "output_tokens": 6,
    "service_tier": "standard"
  },
  "modelUsage": {
    "claude-opus-4-7[1m]": { ... }
  },
  "permission_denials": [],
  "terminal_reason": "completed"
}
```

**핵심 관찰:**
- `total_cost_usd`는 메터링 시 가격 — Max 구독 사용자엔 실 청구 0 (정보용)
- `cache_creation_input_tokens` / `cache_read_input_tokens`로 시스템 prompt cache 활용 명시
- `modelUsage`는 모델별 분리 (multi-model 워커 추적)
- `permission_denials` 배열로 보안 audit
- `service_tier: standard` — Max는 standard tier로 처리됨

---

## 검증 시나리오 2: 실제 코드 리팩터링 (R11 Sprint 0 워크로드)

**준비**: messy `calc.py` (PEP8 위반, if/elif 체인, division-by-zero 미처리)

**명령**:
```bash
echo "Refactor calc.py to use PEP8 style (spaces, type hints), handle division by zero with ValueError, and use a dict-based dispatch instead of if/elif chain. Keep the same external interface. After editing, run 'python calc.py' to verify it still works." | \
claude -p --output-format json --no-session-persistence --max-budget-usd 1.00 \
  --permission-mode acceptEdits --allowed-tools "Read Edit Write Bash"
```

**결과**: 18.4초, **6 turns** (자동 multi-step), 완벽한 리팩터링 + 검증 실행

리팩터링된 파일:
```python
from operator import add, sub, mul, truediv
from typing import Callable

_OPS: dict[str, Callable[[float, float], float]] = {
    'add': add,
    'sub': sub,
    'mul': mul,
    'div': truediv,
}

def calc(a: float, b: float, op: str) -> float:
    if op == 'div' and b == 0:
        raise ValueError('division by zero')
    return _OPS[op](a, b)

print(calc(10, 5, 'add'))
print(calc(10, 5, 'div'))
```

**핵심 관찰:**
- `--allowed-tools "Read Edit Write Bash"` 정확히 작동 — 다른 도구 사용 안 함
- `--permission-mode acceptEdits` 덕분에 prompt 없이 진행
- `num_turns: 6` — Read → Edit → Bash (verify) 자동 chaining
- 결과 message에 검증 결과 포함: "`python3 calc.py` runs and prints `15` and `2.0` as expected"
- 추가 발견: opus-4-7 main + haiku-4-5 보조 (비용 최적화 자동)

---

## 검증 시나리오 3: stream-json 실시간 출력

**명령**:
```bash
echo "Add a docstring to the hi() function and PEP8 spacing." | \
claude -p --output-format stream-json --include-partial-messages --verbose \
  --no-session-persistence --max-budget-usd 0.50 \
  --permission-mode acceptEdits --allowed-tools "Read Edit"
```

**관찰된 event 종류** (line-delimited JSON):

| Event type | 함의 |
|---|---|
| `system.init` | 시작 시 1회: tools/MCP/model/permissionMode/session_id/CLI version 메타 |
| `system.status` | requesting/processing 상태 변경 |
| `stream_event.message_start` | 새 assistant message 시작, ttft_ms 포함 |
| `stream_event.content_block_start` | 새 컨텐츠 블록 (thinking / tool_use / text) |
| `stream_event.content_block_delta` | 부분 JSON delta (partial_json) — 매우 fine-grained |
| `stream_event.content_block_stop` | 컨텐츠 블록 종료 |
| `stream_event.message_delta` | usage 누적, stop_reason |
| `stream_event.message_stop` | message 완료 |
| `assistant` | 완성된 assistant message (delta 합산본) |
| `user` | tool_result 사용자 측 echo |
| `rate_limit_event` | rate limit 상태 (allowed/throttled, resetsAt) |

**워커 daemon → A2A 매핑 안**:

| Claude Code event | A2A event | NATS subject |
|---|---|---|
| `system.init` | `TaskStatusUpdateEvent(state=WORKING)` | `agent-grid.tasks.{id}.events` |
| `assistant` (text content) | `TaskArtifactUpdateEvent` (text chunk, append=true) | 같음 |
| `assistant` (tool_use) | `TaskStatusUpdateEvent` (metadata: tool name/input) | 같음 |
| `user` (tool_result) | `TaskStatusUpdateEvent` (metadata: tool result summary) | 같음 |
| `rate_limit_event` | `TaskStatusUpdateEvent(state=WORKING, message="rate limited")` | 같음 |
| final `result` | `TaskStatusUpdateEvent(state=COMPLETED)` + `TaskArtifactUpdateEvent` (append=false, lastChunk=true) | 같음 |
| `is_error: true` | `TaskStatusUpdateEvent(state=FAILED, message=error)` | 같음 |

---

## 발견한 Gotchas (실 구현 시 주의)

1. **stream-json + verbose**: `--include-partial-messages` 사용 시 `--verbose` 같이 안 주면 "Input must be provided" 에러. 정확한 조합 필요.

2. **prompt as argument vs stdin**: 단순 케이스는 positional argument OK, 복잡한 prompt나 escape 문제 시 **stdin 파이프가 더 안정적**:
   ```bash
   echo "..." | claude -p --output-format json ...   # 권장
   ```

3. **--bare 모드 + auth**: `--bare`는 OS keychain·OAuth 무시 → ANTHROPIC_API_KEY 환경변수 필수. 워커 daemon이 contributor 머신의 OAuth를 활용하려면 **bare 모드 사용 안 함**.

4. **Max 사용자 cost 표시**: `total_cost_usd` 필드는 메터링 시 이론적 가격, Max 구독엔 실 청구 0. 워커가 이 값을 capability ad의 `cost_tier`로 변환:
   - `total_cost_usd > 0` + `service_tier=standard` 그러나 사용자 Max → `cost_tier: "subscribed"`
   - `total_cost_usd > 0` + 일반 API → `cost_tier: "metered"`

5. **MCP servers**: 시작 시 자동 spawn (`status: "needs-auth"` 또는 "pending"이면 인증 필요). 워커는 `--mcp-config`로 명시적 제어 또는 `--strict-mcp-config`로 다른 MCP 무시.

6. **Tool list 동적**: `system.init` event의 `tools` 배열은 사용자 환경의 도구 + MCP 도구 합본. 워커 daemon이 시작 시 한 번 init만 호출해서 capability ad 만들 수 있음 (또는 cache).

7. **Skills/agents**: Claude Code는 사용자가 정의한 skills + agents 자동 로드. 워커가 신뢰할 수 없는 환경이면 `--bare` 또는 `--setting-sources` 제한.

8. **shell cwd 리셋**: subprocess 종료 시 부모 shell cwd 원래대로 (정상 동작).

---

## 워커 daemon 의사 코드 (Python)

```python
import asyncio
import json
import uuid
from pathlib import Path

class ClaudeCodeWrapper:
    """Subprocess wrapper for Claude Code CLI as agent-grid worker."""
    
    def __init__(self, work_dir: Path, max_budget_usd: float = 1.0,
                 allowed_tools: list[str] = None, model: str = None):
        self.work_dir = work_dir
        self.max_budget_usd = max_budget_usd
        self.allowed_tools = allowed_tools or ["Read", "Edit", "Write", "Bash"]
        self.model = model
    
    async def execute_task(self, task_id: str, prompt: str, on_event):
        """Execute a task and stream events to on_event callback."""
        cmd = [
            "claude", "-p",
            "--output-format", "stream-json",
            "--include-partial-messages",
            "--verbose",
            "--no-session-persistence",
            "--session-id", task_id,  # A2A Task.id mapping
            "--max-budget-usd", str(self.max_budget_usd),
            "--permission-mode", "acceptEdits",
            "--allowed-tools", " ".join(self.allowed_tools),
            "--add-dir", str(self.work_dir),
        ]
        if self.model:
            cmd.extend(["--model", self.model])
        
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=str(self.work_dir),
        )
        
        # Send prompt via stdin
        proc.stdin.write(prompt.encode())
        proc.stdin.close()
        
        # Stream events
        async for line in proc.stdout:
            line = line.strip()
            if not line:
                continue
            try:
                event = json.loads(line)
                await on_event(event)  # 워커가 NATS로 publish
            except json.JSONDecodeError:
                # 비-JSON 라인 (드물게 있음, 로그)
                pass
        
        await proc.wait()
        return proc.returncode
    
    async def get_capability(self) -> dict:
        """Probe environment for Agent Card capability."""
        # 1) claude --version → version
        # 2) 빠른 init만 (--print "" 또는 minimal prompt)으로 system.init event에서 tools/model 추출
        # 3) Agent Card extended with x-agent-grid 반환
        ...
```

---

## A2A → Claude Code 매핑 표 (구현 참고)

| A2A 개념 | Claude Code 대응 |
|---|---|
| `Task.id` | `--session-id <uuid>` |
| `Task.message.parts[0].text` | stdin prompt |
| `Task.metadata.x-agent-grid.requirements.tools` | `--allowed-tools` |
| `Task.metadata.x-agent-grid.requirements.model_class` | `--model` (mapping table 필요) |
| `Task.metadata.x-agent-grid.deadline` | `--max-budget-usd` (시간 → cost cap 변환) |
| `TaskStatusUpdateEvent` | `system.status`, `stream_event.message_start/stop`, `result` |
| `TaskArtifactUpdateEvent` | `assistant.content[].text` (chunked from `content_block_delta`) |
| `Agent Card.skills` | `--system-prompt` (워커 specialty 정의) |
| `Agent Card.x-agent-grid.tools` | tool probe 결과 (init event의 `tools`) |
| `Agent Card.x-agent-grid.model` | `--model` 선택 + 결과 검증 |

---

## 결론

**Risk K4 = SOLVED.** Claude Code subprocess wrap은 **잘 작동하며**, 우리가 설계한 워커 daemon 패턴에 거의 직접 매핑됨:

- 비대화형: ✅ `-p`
- 구조화 출력: ✅ JSON / stream-json
- Streaming: ✅ stream-json + partial messages
- Cost cap: ✅ `--max-budget-usd`
- Sandboxing: ✅ `--allowed-tools` + `--add-dir` + `--permission-mode`
- Session 매핑: ✅ `--session-id` (A2A Task.id 직접 매핑)
- Multi-step 자동: ✅ tool chaining (Read → Edit → Bash) auto
- Verification 내장: ✅ "run python calc.py to verify" 자연 처리
- 모델 선택: ✅ `--model`
- 폴백: ✅ `--fallback-model` (overload 시)
- 도구 확장: ✅ `--mcp-config`

**다음 단계**: Sprint 0 본격 구현 진입 가능.

1. 위 의사 코드 기반 `ClaudeCodeWrapper` 구현 (~300-500 LOC)
2. NATS 클라이언트 + 단순 broker (capability ad + work queue)
3. 단순 orchestrator (CLI submit + stream tail)
4. End-to-end "hello world": orchestrator submit → broker → worker → result

본 spike에서 검증된 invocation 패턴 그대로 구현하면 됨.

---

## 비용 (Max 구독 사용자 기준)

- 시나리오 1 (단순): $0.05 (정보용, 실 청구 0)
- 시나리오 2 (리팩터링): $0.16 (정보용)
- 시나리오 3 (docstring): ~$0.10 (정보용)
- **총 spike 비용**: $0 (Max 구독, ~$0.30 메터링 가격 표시)
