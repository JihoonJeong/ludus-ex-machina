# organum

> **pre-1.0.** `.organum/` 포맷 v0은 **동결됨** (2026-07-04) — 이후 변경은 version bump +
> migration 경로로만 온다. (스펙: [docs/format-v0.md](docs/format-v0.md))
>
> **현행 정체성·경계·성숙도의 단일 기준점: [docs/architecture.md](docs/architecture.md)** —
> 세 성숙도 층위(제품 inspector / 측정계기 조율·관측 / 실험 core)와 헌법을 담는다.

**Organism Engineering CLI** — 당신의 에이전트는 오늘도 유능했고, 내일이면 그걸 전부 잊는다.
`organum init` 한 번이면 기억하고, 지도를 그리고, 자기를 돌보기 시작한다.

organum은 실무자가 **이미 쓰고 있는 에이전트**(Claude Code 등)에 기관(organ)을 입히는 도구다.
프로젝트-로컬 `.organum/` 디렉터리에 정체성·분화된 기억·세계모델·지도를 축적하고, 에이전트의
컨텍스트에 주입하고, 돌봄 의례(회고/점검/백업)를 제공한다.

organum은 **상태와 규율의 도구지, 에이전트가 아니다**: 크리처도 오케스트레이션도 없다. organum은
모델·에이전트 runtime을 소유하지 않는다 — LLM 추론이 필요한 의례는 `distill` 하나뿐이고, 사용자
CLI의 **자격·예산·실행권을 빌려** 서브프로세스로 위임한다(reflect는 결정적 carry-forward, 위임 아님).
organum 자신은 추론하지 않는다.

## 어떻게 맞물리나 (실행 층위)

organum은 당신이 **그 위에서 동작하는 런타임이 아니다.** 당신은 평소처럼 코딩 에이전트(Claude
Code 등) 안에서 일하고, organum은 그 곁에서 상태를 붙잡는 **파일 도구**다 — 터미널에서 직접, 또는
훅으로 자동으로 불려 나온다.

```
[ 당신의 코딩 에이전트 (Claude Code 등) ]   ← 개발·작업은 여기서
      └─ 터미널/훅에서 organum 을 호출
                 ▼
        [ organum ]   ← Python CLI. 에이전트도 런타임도 아님. 자체 LLM 없음.
                 ├─ .organum/ 상태를 관리 (self·memory·map·wm·guard)
                 └─ LLM 추론이 필요하면(distill 하나) → 당신의 CLI를 서브프로세스로 빌림
```

`organum context`로 축적된 맥락을 세션에 주입하고, `organum remember/distill/reflect`로 일어난 일을
영속화한다. **개발 자체는 당신의 에이전트에서** 일어나고, organum은 세션·모델을 건너 기억·지도·
정체성을 실어나른다. `agent_model` 같은 필드도 organum이 *돌아가는 브레인*이 아니라, 그 에이전트가
무슨 모델인지 기록해두는 **라벨**일 뿐이다(organum은 그걸 감지하지 못한다 — 의례로 적어준다).
organum이 작업 표면이 되는 순간 그건 에이전트이지 도구가 아니다 — 그 선을 넘지 않는 것이 규율이다.

## 설치

```bash
pip install organum   # 아직 미출시 — 지금은 소스에서: pip install -e .
```

(구명 organon은 PyPI 점유로 2026-07-04 organum으로 개명 — 경위는 docs/journal.md.)

요구사항: Python 3.10+ · 외부 의존성 없음 (stdlib only)

## 사용 스케치

```bash
organum init                 # .organum/ 상태 디렉터리 생성
organum context              # [Self]+[Map]+[WM] 주입 블록을 stdout으로
                             #   → 시스템 프롬프트/CLAUDE.md에 붙이거나 훅으로 자동화
organum remember "..."       # 형성 맥락 태그와 함께 기억 저장 (guard가 저장 경계에서 필터)
organum recall --when 24h    # 시간창 질의: "지난 24시간 무슨 일이 있었나"
organum map                  # 리포 지도 (git ls-files로 시드 + frontier: 안 읽은 영역 = "?")
organum map frontier         # 지금 안 가본 곳 목록
organum distill --profile map|prose  # 세션 로그 → 세계모델 (map=형태-우선 강제 / prose=서술; 명시 필수)
organum reflect              # 세션 회고 → self.md carry-forward 갱신
organum checkup              # 상태 건강 점검
organum backup               # 오프-머신 스냅샷 (day 1 기능)
organum inspect              # 라이브 유기체 vitals (세션 transcript tail — read-only 관찰)
organum inspect --all        # 한 현장의 여러 세포(세션) 수렴 — 멀티-에이전트 뷰
organum live                 # tmux: 네이티브 CLI 작업 + inspect 나란히
organum web                  # 관제탑+게시판 — 세포 수렴 + 우체통(사람 드롭·세포 pull), localhost·tmux 불요
organum observatory sync     # 관측 영속화 — 세션 소비 스냅샷 축적 (벤더 transcript ~30일 청소 대비)
organum observatory stats    # 축적분 집계 — 세션·토큰·비용 근사 (--by model|role|origin|vendor)
organum observatory report   # 작업 모니터 리포트 — 지금(live)/오늘/역사 분리 밴드 + 일별 추이·대형 세션
organum relay inbox --for X  # 우체통 — 나에게 온 편지 (세포 pull 습관; send/read도)
```

**바로 써보고 싶다면**(끝난 작업을 소급 계측): `pip install organum` →
`organum-inspector <폴더>`. 5분 퀵스타트 [docs/quickstart-inspector.md](docs/quickstart-inspector.md).
라이브 관제탑·역사 축적(베타)은 [docs/quickstart-observe.md](docs/quickstart-observe.md).

**제품군 — organum-inspector (0.1.0 헤드라인)**: 사후 계측 슬라이스.
`organum-inspector <폴더>`(또는 `organum inspector <폴더>`) 한 줄로 그 폴더에서
돌았던 에이전트 세션들(5벤더)의 소요시간·토큰·툴·파일을 소급 집계한다 — init
불요·완전 read-only·stdlib only. 배포는 **단일 PyPI 패키지 `organum`** 하나로
제품군 전체가 버전 업한다(콘솔 스크립트 2개 동봉; `packaging/inspector/`의
별도-패키지 빌드는 휴면 대안). 실전 사례: docs/case-study-inspector-duel.md.

구현 상태 (P2 완주 — MVP 명령 표면 완성): `init` · `context` · `remember` · `recall --when` ·
`map`(view/frontier/mark/sync) · `distill`(세계모델, `--profile map|prose`) · `reflect`(self.md carry-forward) ·
`checkup` · `backup` · `restore` · `migrate` · `provision`(Agent Skill에 조직 배선). guard는
독립 명령이 아니라 **기억·세계모델 영속 쓰기**의 저장 경계 초크포인트로 편입돼 있고, 위임
(delegation) 실패도 streak에 기록된다. 조율 트래픽(relay/agora)과 관측 스냅샷(observatory)은
guard 대상이 아니다 — 각각 엔벨로프 불변·append-only라는 자체 계약을 가진다. LLM 위임(distill의
내용 생성)은 사용자 CLI를 서브프로세스로 — organum은 내용을 만들지 않고 형태를 보증한다.

**Agent Skills 통합**: organum은 [Agent Skills](https://agentskills.io) 표준의 화물이다 —
Skill(운송, 무상태)이 `metadata.organum-requires`로 조직을 선언하면 `organum provision`이
stateful annex를 배선해 낯선 에이전트에서 Skill이 세션을 넘어 작동하게 한다. provision 경계는
면역 감사(신뢰 출처·조직 allowlist·스크립트 스캔)로 지킨다. 설계·검증: `experiments/cargo-bridge/`.

## 왜 이 포맷인가

설계는 취향이 아니라 [Ludex 랩](https://github.com/ludex-lab/ludex)의 pre-registered 실험에서
왔다 — 단, 그 인과 증거는 **in-ecosystem, one domain (MUD)**이다. 모든 수치는 원문서 라벨대로
*제3자 재현 전까지 랩-내부*로 읽을 것:

> **⚠ 전이 검정 결과 (P3 dogfood, 사전등록 null)**: "리포 지도가 코딩 에이전트를 돕는다"는
> 전이 가설을 코딩 도메인에서 검정했고 **null이었다.** organum이 주입하는 `[Map]`은 능동-탐색
> 코딩 태스크에서 코딩 에이전트의 over-anchoring을 줄이지 않는다 (B−A effort-composite null,
> exact-p=.53; 재읽기 B−A=0.00). **over-anchoring은 tier-universal이 아니라 환경-의존이다** —
> map 해독제는 *능동 탐색이 없는* 에이전트에 domain-specific이고, MUD 결과는 그 설정의 산물이었다.
> 등록된 null(§14-3)이지 튜닝 실패가 아니다. form>content도 코딩엔 전이 안 됨(prose가 근소
> 우위, estimation-only). 재현: `experiments/p3-pilot/CONFIRMATORY-RESULTS.md` (Ray VERDICT +
> `analyze_confirmatory.py`). — 즉 아래 MUD 근거는 **map/frontier의 코딩 전이를 뒷받침하지
> 않는다**; map은 여전히 oracle-값싼 GIVEN-MAP 네비게이션 상태로서 유용하지만, 측정된 over-
> anchoring 인과 이득은 MUD-특정이다. organum의 가치는 이 특정 주장이 아니라 축적되는 상태와
> 규율(면역/guard·형태-우선 저장·돌봄)에 있다.

아래는 그 MUD 인과 증거다 (코딩 전이는 위 null):

- **세계모델은 형태(form)로**: prose 요약(정답 포함!)은 효과 0 (p=.79), 구조 지도+frontier는
  탐험 해방 (exact-p=.0096, d=1.61). → `distill`은 map-shaped + frontier-explicit 출력을
  강제한다. 판별 기준: *"계획 없이 다음 행동으로 컴파일되는가?"*
- **지도는 정적 시드가 공짜인 도메인에선 시드하라**: self-built 지도도 유효하지만(Holm p=.029)
  oracle 대비 earning tax가 있다. 리포는 `git ls-files`로 턴1 완전 열거가 되므로 `map`은
  GIVEN-MAP형(정적 시드) + frontier 마킹이다.
- **에러 폴백이 기억을 오염시킨다**: 실사고 — "[Error: timed out]"이 영속 기억이 되어 이후
  행동을 오염. → `guard`가 저장 지점에서 실패 산출물을 차단한다.

## 관련 작업

memory 도구는 많다 (Letta/mem0/Zep/MemGPT 계열). organum의 차별점은 **분화**(시간/공간/절차를
다른 경로로) · **형태-우선 세계모델** · **frontier** · **운영 규율의 동봉**. 정면 비교 1페이지는
작성 중 (Ray 소유, P1 내 초안).

## 라이선스

MIT ([LICENSE](LICENSE))
