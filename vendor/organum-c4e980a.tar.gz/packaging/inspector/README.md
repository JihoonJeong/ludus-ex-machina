# organum-inspector (얇은 배포 — 휴면)

> **현행 배포 전략 (JJ 결정 2026-07-15): 단일 PyPI 패키지 `organum`으로 제품군
> 전체를 버전 업** — inspector는 같은 휠의 `organum-inspector` 콘솔 스크립트로
> 설치된다. 이 폴더의 별도-패키지 빌드(sync.py → organum_inspector 네임스페이스)는
> "코드 일부만 공개"가 필요해질 경우를 위한 휴면 대안으로만 남긴다.



**Post-hoc metering for AI coding agents.** You gave the same task to two agents
yesterday — which one finished faster, and what did each actually consume? This
tool answers that *after the fact*: it reads the session transcripts your agent
CLIs already leave on disk and prints duration, tokens, tool calls, and files
touched, per session and per vendor.

```
$ organum-inspector ~/projects/my-design-task

━ organum inspector · my-design-task · 창 45일 · 2 세션
  vendor   model         시작           소요      in      out    cache  tools files
  codex    gpt-5.6-sol   07-15 10:14   3.4h    36.3M   73.9K   34.4M   442    10
  grok     grok-4.5      07-15 12:10   1.4h   131.7K       —       —   190    43
```

- **Read-only.** Nothing is written to your project. No setup, no daemon, no API keys.
- **Five vendors.** Claude Code, OpenAI Codex, Gemini (Antigravity `agy`), Grok CLI, OpenCode.
- **Honest.** `—` means the vendor doesn't record that number on disk — it is never
  silently zero. Token semantics differ per vendor; duration, tool calls, and files
  are the safe cross-vendor axes.
- **Machine-friendly.** `--json` emits records ready for your own analysis pipeline.

Part of the **organum** product family ([ludex-lab.github.io/organum](https://ludex-lab.github.io/organum/)) —
the shared-cognition substrate for teams of AI agents. Inspector is the standalone
read-only slice: if you want live convergence (control tower), durable consumption
history, and multi-agent coordination fields, that's `organum` itself.

## Install

```bash
pipx install organum-inspector   # or: pip install organum-inspector
```

## Build (maintainers)

Source of truth lives in the organum monorepo (`src/organum/`). To build this
thin distribution:

```bash
python3 packaging/inspector/sync.py
python3 -m build packaging/inspector
```
