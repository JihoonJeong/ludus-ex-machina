#!/usr/bin/env python3
"""organum-inspector 얇은 배포의 소스 동기화 — 빌드 전에 1회 실행.

진실의 소스는 src/organum/ 하나다. 이 스크립트가 필요한 3개 모듈만
organum_inspector 네임스페이스로 복사하며 import 2종을 다시 쓴다
(별도 네임스페이스 = 나중에 full organum을 설치해도 충돌 없음).

    python3 packaging/inspector/sync.py && python3 -m build packaging/inspector
"""
from pathlib import Path

HERE = Path(__file__).parent
SRC = HERE.parent.parent / "src" / "organum"
DST = HERE / "src" / "organum_inspector"

REWRITES = [
    ("from organum import inspect as ins", "from organum_inspector import vitals as ins"),
    ("from organum import adapters", "from organum_inspector import adapters"),
    ("from organum.inspect import", "from organum_inspector.vitals import"),
]
FILES = {"adapters.py": "adapters.py", "inspect.py": "vitals.py", "inspector.py": "cli.py"}


def main() -> int:
    DST.mkdir(parents=True, exist_ok=True)
    for src_name, dst_name in FILES.items():
        text = (SRC / src_name).read_text(encoding="utf-8")
        for old, new in REWRITES:
            text = text.replace(old, new)
        (DST / dst_name).write_text(text, encoding="utf-8")
        print(f"  {src_name} → organum_inspector/{dst_name}")
    (DST / "__init__.py").write_text(
        '"""organum-inspector — organum 제품군의 read-only 사후 계측 슬라이스."""\n'
        '__version__ = "0.1.0"\n', encoding="utf-8")
    print("sync 완료 — build 가능")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
