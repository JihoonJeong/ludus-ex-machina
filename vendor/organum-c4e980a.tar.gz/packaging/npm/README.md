# organum

**Organism Engineering CLI** — give the agent you already use persistent organs:
identity, differentiated memory, world models, a repo map with an explicit frontier,
and care rituals.

organum is Python-first. Install it from PyPI:

```bash
pip install organum
```

This npm package currently reserves the name; an npm distribution is planned.
Status: pre-1.0, format unstable.
