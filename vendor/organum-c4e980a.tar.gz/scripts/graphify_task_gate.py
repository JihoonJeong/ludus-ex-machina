#!/usr/bin/env python3
"""graphify loadout-변주 과제 gate — 결정적 판정 (docs/graphify-loadout-tasks-v0.md).

답변 파일(answers/<arm>/T<n>.md)에 required facts가 전부(case-insensitive substring)
있으면 pass. judge 없음 — 표면 사실 매칭의 한계는 과제 문서 경계 3에 선등록됨.

사용: python3 scripts/graphify_task_gate.py <answers/arm-dir> [--json]
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

FACTS: dict[str, list[str]] = {
    "T1": ["combat.py", "resolve_damage", "actions.py", "apply_attack"],
    "T2": ["basic.py", "idle", "wander", "chase", "apply_monster_behaviors", "game.py"],
    "T3": ["Move", "Attack", "input.py"],
    "T4": ["monsters.py", "MonsterDef", "_populate", "game.py"],
    "T5": ["speed", "aggro_range", "_speed_allows_move", "basic.py"],
    "T6": ["intent_for_key", "input.py", "try_move", "actions.py"],
    "T7": ["player_alive", "game.py"],
    "T8": ["mapgen", "generate", "new_game", "game.py"],
}


def gate(answers_dir: Path) -> dict:
    out = {"arm": answers_dir.name, "tasks": {}, "pass": 0, "total": len(FACTS)}
    for tid, facts in sorted(FACTS.items()):
        p = answers_dir / f"{tid}.md"
        if not p.is_file():
            out["tasks"][tid] = {"pass": False, "missing": facts, "note": "answer file absent"}
            continue
        try:
            text = p.read_text(encoding="utf-8", errors="replace").lower()
        except OSError as e:
            out["tasks"][tid] = {"pass": False, "missing": facts, "note": f"read error: {e}"}
            continue
        missing = [f for f in facts if f.lower() not in text]
        ok = not missing
        out["tasks"][tid] = {"pass": ok, "missing": missing}
        out["pass"] += ok
    return out


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("answers_dir")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args(argv)
    d = Path(args.answers_dir).expanduser()
    if not d.is_dir():
        print(f"gate: no such dir: {d}", file=sys.stderr)
        return 1
    res = gate(d)
    if args.json:
        print(json.dumps(res, ensure_ascii=False, indent=1))
    else:
        for tid, r in sorted(res["tasks"].items()):
            mark = "✓" if r["pass"] else "✗"
            miss = f"  missing: {', '.join(r['missing'])}" if r["missing"] else ""
            print(f"  {mark} {tid}{miss}")
        print(f"gate: {res['pass']}/{res['total']} pass · arm={res['arm']}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
