#!/usr/bin/env python3
"""organum 소비자측 독립 reference — RFC 8785 (JCS) canonicalizer (stdlib-only).

S12 differential qualification의 consumer-owned 구현. **저자 독립성 규율**: RFC 8785
스펙 + organum-code S12a 동결 계약 문서에서만 유도 — producer의 TS/Python 구현을
읽지 않고 작성됨(2026-07-26, 분업 합의 (a)). fixture에서는 입력(raw·candidate·mapping)만
읽는다 — 기대값(canonical/sha256/error/effectClass)은 참조하지 않음(비교·게이트 판정은
producer 몫 = differential의 의미).

출력 계약(교환 표면): valid → {id, canonical, bytes, sha256(lowercase)} ·
invalid → {id, error ∈ {invalid_json, duplicate_key, invalid_number, invalid_unicode}} ·
toolNames → {id, effectClass} (byte-exact 일치만 mapping 클래스 상속, case/NFC-NFD/
homoglyph 변형은 unknown — 코퍼스 등록 툴 클래스는 read).

사용: python3 scripts/rfc8785_reference.py <fixture.json> [--out results.json]
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import sys
from decimal import Decimal

MAX_INPUT_BYTES = 1 << 20        # bounded ingest (계약: oversized input 거부)
MAX_CANONICAL_BYTES = 65536      # 계약: canonical 출력 상한
MAX_DEPTH = 512


class CanonError(ValueError):
    def __init__(self, cls: str, msg: str = ""):
        super().__init__(msg or cls)
        self.cls = cls


# ── 파싱 (fail-closed ingress) ───────────────────────────────────────────────

def _reject_const(c):
    # JSON 문법 밖 수치 리터럴(NaN/Infinity/-Infinity) — 비유한 binary64 거부
    raise CanonError("invalid_number", f"non-finite literal {c}")


def _pairs_no_dup(pairs):
    d = {}
    for k, v in pairs:
        if k in d:  # 디코드된(unescape 후) 키 기준 — "a"와 "a"도 충돌
            raise CanonError("duplicate_key", k)
        d[k] = v
    return d


def parse(raw: str):
    if len(raw.encode("utf-8", errors="surrogatepass")) > MAX_INPUT_BYTES:
        raise CanonError("invalid_json", "oversized input")
    try:
        val = json.loads(raw, object_pairs_hook=_pairs_no_dup,
                         parse_constant=_reject_const)
    except CanonError:
        raise
    except (json.JSONDecodeError, RecursionError) as e:
        raise CanonError("invalid_json", str(e))
    _validate(val, 0)
    return val


def _validate(v, depth: int):
    if depth > MAX_DEPTH:
        raise CanonError("invalid_json", "excessive depth")
    if isinstance(v, str):
        _check_unicode(v)
    elif isinstance(v, bool) or v is None:
        pass
    elif isinstance(v, int):
        # ES 파싱 의미론(RFC 8785): nearest double로 반올림 — 정밀도 손실은 거부하지
        # 않는다(Appendix B 벡터가 요구: 295147905179352830000 등). 거부는 크기
        # 오버플로(binary64 밖)만 — 계약의 "out-of-range".
        try:
            f = float(v)
        except OverflowError:
            raise CanonError("invalid_number", "int overflow")
        if not math.isfinite(f):
            raise CanonError("invalid_number", "int overflow")
    elif isinstance(v, float):
        if not math.isfinite(v):  # 1e999 등이 float('inf')로 조용히 파싱되는 경로
            raise CanonError("invalid_number", "non-finite")
    elif isinstance(v, list):
        for x in v:
            _validate(x, depth + 1)
    elif isinstance(v, dict):
        for k, x in v.items():
            _check_unicode(k)
            _validate(x, depth + 1)
    else:
        raise CanonError("invalid_json", f"non-JSON value {type(v).__name__}")


def _check_unicode(s: str):
    for ch in s:
        cp = ord(ch)
        if 0xD800 <= cp <= 0xDFFF:   # json.loads가 짝 없는 surrogate를 남긴 경우
            raise CanonError("invalid_unicode", f"lone surrogate U+{cp:04X}")
        if 0xFDD0 <= cp <= 0xFDEF or (cp & 0xFFFF) in (0xFFFE, 0xFFFF):
            raise CanonError("invalid_unicode", f"noncharacter U+{cp:04X}")


# ── 직렬화 (RFC 8785 §3.2) ───────────────────────────────────────────────────

_TWO_CHAR = {0x08: "\\b", 0x09: "\\t", 0x0A: "\\n", 0x0C: "\\f", 0x0D: "\\r",
             0x22: '\\"', 0x5C: "\\\\"}


def _ser_string(s: str) -> str:
    # §3.2.2.2: 두 글자 이스케이프 + 그 외 C0만 \u00xx(소문자 hex) — 나머지는 리터럴
    out = ['"']
    for ch in s:
        cp = ord(ch)
        if cp in _TWO_CHAR:
            out.append(_TWO_CHAR[cp])
        elif cp < 0x20:
            out.append(f"\\u{cp:04x}")
        else:
            out.append(ch)
    out.append('"')
    return "".join(out)


def _es_number(x) -> str:
    """ECMAScript Number::toString (RFC 8785 §3.2.2.3이 요구) — shortest round-trip
    십진(digits s·위치 n: value = s×10^(n−k), k=len(s)) 후 ES 포맷 규칙."""
    f = float(x)
    if f == 0.0:
        return "0"                      # -0 포함 (ES String(-0) == "0")
    neg = f < 0.0
    m = -f if neg else f
    d = Decimal(repr(m))                # repr = shortest round-trip 십진
    t = d.as_tuple()
    digits = "".join(map(str, t.digits)).rstrip("0")
    stripped = len(t.digits) - len(digits)
    n = (t.exponent + stripped) + len(digits)   # value = 0.digits × 10^n 형태의 n
    k = len(digits)
    if k <= n <= 21:
        s = digits + "0" * (n - k)
    elif 0 < n <= 21:
        s = digits[:n] + "." + digits[n:]
    elif -6 < n <= 0:
        s = "0." + "0" * (-n) + digits
    else:
        exp = n - 1
        mant = digits[0] + ("." + digits[1:] if k > 1 else "")
        s = f"{mant}e{'+' if exp >= 0 else '-'}{abs(exp)}"
    return ("-" if neg else "") + s


def _sort_key_utf16(s: str) -> bytes:
    return s.encode("utf-16-be")        # UTF-16 코드 유닛 사전순 == 바이트 사전순


def serialize(v) -> str:
    if v is True:
        return "true"
    if v is False:
        return "false"
    if v is None:
        return "null"
    if isinstance(v, str):
        return _ser_string(v)
    if isinstance(v, (int, float)):
        return _es_number(v)
    if isinstance(v, list):
        return "[" + ",".join(serialize(x) for x in v) + "]"
    if isinstance(v, dict):
        items = sorted(v.items(), key=lambda kv: _sort_key_utf16(kv[0]))
        return "{" + ",".join(_ser_string(k) + ":" + serialize(x) for k, x in items) + "}"
    raise CanonError("invalid_json", f"non-JSON value {type(v).__name__}")


def canonicalize(raw: str) -> tuple[str, int, str]:
    """raw JSON 텍스트 → (canonical text, UTF-8 byte 수, 소문자 sha256)."""
    text = serialize(parse(raw))
    b = text.encode("utf-8")
    if len(b) > MAX_CANONICAL_BYTES:
        raise CanonError("invalid_json", "canonical output over bound")
    return text, len(b), hashlib.sha256(b).hexdigest()


# ── native tool 매핑 (byte-exact — 정규화·casefold 없음) ─────────────────────

def tool_effect(candidate: str, mapping: str, mapped_class: str = "read") -> str:
    return mapped_class if candidate.encode("utf-8") == mapping.encode("utf-8") else "unknown"


# ── 스펙 자가 검증 (RFC 8785에서 유도한 불변 — producer 산출물 미참조) ────────

def _self_check():
    assert _es_number(1e21) == "1e+21"
    assert _es_number(1e20) == "100000000000000000000"
    assert _es_number(1e-6) == "0.000001"
    assert _es_number(1e-7) == "1e-7"
    assert _es_number(-0.0) == "0"
    assert _es_number(5) == "5"
    assert _es_number(1.5) == "1.5"
    assert serialize(json.loads('{"b":1,"a":2}')) == '{"a":2,"b":1}'
    # UTF-16 코드 유닛 정렬: astral(surrogate pair D83D DE00)이 U+E000보다 앞
    s = serialize(json.loads('{"\\ue000":1,"\\ud83d\\ude00":2}'))
    assert s.index("\U0001F600") < s.index("\ue000")
    assert _ser_string("\x01a\n") == '"\\u0001a\\n"'


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("fixture")
    ap.add_argument("--out", default=None)
    args = ap.parse_args(argv)
    _self_check()
    d = json.loads(open(args.fixture, encoding="utf-8").read())
    res = {"schema": "organum/rfc8785-consumer-reference/v1",
           "valid": [], "invalid": [], "toolNames": []}
    for c in d.get("valid", []):
        try:
            text, nb, dig = canonicalize(c["raw"])
            res["valid"].append({"id": c["id"], "canonical": text,
                                 "bytes": nb, "sha256": dig})
        except CanonError as e:  # valid 케이스가 거부되면 그대로 표면화(정직)
            res["valid"].append({"id": c["id"], "error": e.cls})
    for c in d.get("invalid", []):
        try:
            canonicalize(c["raw"])
            res["invalid"].append({"id": c["id"], "error": None})  # 통과 = 불일치 표면화
        except CanonError as e:
            res["invalid"].append({"id": c["id"], "error": e.cls})
    for c in d.get("toolNames", []):
        res["toolNames"].append({"id": c["id"],
                                 "effectClass": tool_effect(c["candidate"], c["mapping"])})
    out = json.dumps(res, ensure_ascii=False, indent=1)
    if args.out:
        open(args.out, "w", encoding="utf-8").write(out + "\n")
        print(f"results → {args.out}")
    else:
        print(out)
    return 0


if __name__ == "__main__":
    sys.exit(main())
