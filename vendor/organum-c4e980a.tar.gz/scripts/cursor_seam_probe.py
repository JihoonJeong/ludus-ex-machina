#!/usr/bin/env python3
"""cursor seam probe v1 — backend-neutral 계약(C1–C4) receipt 생성·검증 (dev 전용).

Orin seam 판정(봉투 002)의 실행 + 재판정(봉투 006) 5항목 + **r3(007 반례 2건):**\nP1 성공 게이트 명시 3조건(fail-open 폐쇄)·version 호출 포함 전 spawn allowlist·\nOUT_ROOT 0700. v1 5항목:
1. gate fail-open 폐쇄 — 모든 모드가 validate 문제(위반 포함) 있으면 exit≠0.
2. env custody — denylist가 아니라 **최소 allowlist**만 child에 전달.
3. fixture/ambient 격리 — fixture는 빈 합성 home만 보고(실전사 무접촉),
   custody는 repo 밖 `~/.organum/seam-probe-runs/<run>/` dir 0700·file 0600.
4. 표시 정확성 — observed_mode는 **성공 실행 관측 후에만**(그 전엔 null+inferred);
   usage는 미보고(not reported)와 0을 구분, P2는 전 카운터 검사.
5. raw record 명칭 정확성 — stdout head를 canonical이라 부르지 않는다: final JSON
   명시 파싱(record_kind=final-json | non-json-text), run id로 재실행 멱등.

모드: --fixture(provider-zero + 목 반례 배터리·custody/격리 자기검사, spawn 0)
     --reparse <raw파일> (기존 raw의 오프라인 재파싱 — 유료 재호출 대체)
     --p1 / --p2 (라이브 각 1회 — 재호출은 JJ 1-call 승인 후에만)
"""

from __future__ import annotations

import argparse
import glob
import hashlib
import json
import os
import re
import stat
import subprocess
import sys
import time
import uuid
from pathlib import Path

RECEIPT_SCHEMA = "cursor-seam-probe/v1"
PARSER_VERSION = "cursor-suffix/v0"
RECORD_CAP_BYTES = 262_144
OUT_ROOT = Path.home() / ".organum" / "seam-probe-runs"      # repo 밖 custody
_ENV_ALLOW = ("PATH", "HOME", "TMPDIR", "LANG", "LC_ALL", "SHELL", "USER", "TERM")

# provider-zero 고정본 — 합성 session id(실전사와 충돌 불가)·실측 usage 모양 유지
FIXTURE_SID = "00000000-0000-4000-8000-0000fixture01"
FIXTURE_STDOUT = json.dumps({
    "type": "result", "subtype": "success", "is_error": False,
    "duration_ms": 5188, "duration_api_ms": 5188, "result": "ok",
    "session_id": FIXTURE_SID, "request_id": "00000000-0000-4000-8000-0000fixture02",
    "usage": {"inputTokens": 9184, "outputTokens": 36,
              "cacheReadTokens": 8188, "cacheWriteTokens": 0}})
# Orin 목 반례: invalid model인데 success+usage를 돌려주는 배신 vendor
MOCK_FALLBACK_STDOUT = json.dumps({
    "type": "result", "subtype": "success", "is_error": False, "duration_ms": 9,
    "result": "ok(auto-fallback)", "session_id": FIXTURE_SID,
    "request_id": "00000000-0000-4000-8000-0000fixture03",
    "usage": {"inputTokens": 5, "outputTokens": 1,
              "cacheReadTokens": 0, "cacheWriteTokens": 0}})


def _sha256(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def _private_dir(p: Path) -> Path:
    p.mkdir(parents=True, exist_ok=True)
    os.chmod(p, 0o700)
    return p


def _write_private(path: Path, data: bytes) -> None:
    with open(path, "xb") as fh:                 # create-only
        fh.write(data)
    os.chmod(path, 0o600)


def parse_model_suffix(model_id: str) -> dict:
    d = {"parser": PARSER_VERSION, "base": None, "effort": None, "fast": False}
    rest = model_id
    if rest.endswith("-fast"):
        d["fast"] = True
        rest = rest[:-5]
    m = re.match(r"^(.*)-(low|medium|high|xhigh|max)$", rest)
    if m:
        d["base"], d["effort"] = m.group(1), m.group(2)
    else:
        d["base"] = rest
    return d


def allowlist_env() -> tuple[dict, dict]:
    """최소 allowlist — 그 밖 전부 미전달. 이름 목록도 기록하지 않는다(값·이름 위생)."""
    env = {k: os.environ[k] for k in _ENV_ALLOW if k in os.environ}
    meta = {"policy": "allowlist", "kept": sorted(env),
            "dropped_count": len(os.environ) - len(env)}
    return env, meta


def build_receipt(*, requested_id: str, argv: list, stdout_bytes: bytes,
                  stderr_bytes: bytes, exit_code: int, wall_ms: int, cwd: str,
                  cli_version: str, env_meta: dict, run_dir: Path,
                  tag: str, home: Path, expect_error: bool) -> dict:
    _private_dir(run_dir)
    # 5) final JSON 명시 파싱 — stdout 전체가 JSON이어야 final-json이다
    vendor, record_kind, record_src = None, "non-json-text", "cursor-headless-stdout"
    try:
        vendor = json.loads(stdout_bytes.decode("utf-8"))
        record_kind = "final-json"
    except (json.JSONDecodeError, UnicodeDecodeError):
        if not stdout_bytes.strip() and stderr_bytes.strip():
            stdout_bytes, record_src = stderr_bytes, "cursor-headless-stderr"
    record = stdout_bytes[:RECORD_CAP_BYTES]
    raw_path = run_dir / f"{tag}-raw-record.{'json' if record_kind == 'final-json' else 'txt'}"
    _write_private(raw_path, record)

    v = vendor or {}
    usage_reported = isinstance(v.get("usage"), dict)
    u = v.get("usage") or {}
    sid = v.get("session_id")

    transcript = {"chats_path": None, "transcript_path": None,
                  "session_match": False, "snapshot_sha256": None,
                  "snapshot_byte_length": None, "search_home": str(home)}
    if sid:
        chats = home / ".cursor" / "chats" / hashlib.md5(cwd.encode()).hexdigest() / sid
        transcript["chats_path"] = str(chats) if chats.is_dir() else None
        for tr in glob.glob(str(home / ".cursor" / "projects" / "*"
                                / "agent-transcripts" / sid / f"{sid}.jsonl")):
            b = Path(tr).read_bytes()
            snap = run_dir / f"{tag}-transcript.jsonl"
            _write_private(snap, b)
            transcript.update({"transcript_path": tr, "session_match": True,
                               "snapshot_sha256": _sha256(b),
                               "snapshot_byte_length": len(b)})
            break

    violations = []
    if exit_code == 0 and v.get("is_error") is True:
        violations.append("supervisor exit 0 vs vendor is_error true")
    if not expect_error and not (exit_code == 0 and record_kind == "final-json"
                                 and v.get("is_error") is False):
        # r3(Orin 반례): 성공 게이트를 명시 3조건으로 — vendor JSON이 아예 없는
        # supervisor 실패(exit 7·non-JSON stderr)가 정상 receipt로 새던 fail-open 폐쇄.
        violations.append(f"P1 위반: 성공 게이트 미충족 — exit {exit_code} · "
                          f"record {record_kind} · vendor_is_error {v.get('is_error')}")
    if expect_error:
        # 4) invalid model 계약: 성공 봉합·auto-fallback 금지 + 전 카운터 검사
        if exit_code == 0 or (vendor is not None and v.get("is_error") is False):
            violations.append("P2 위반: invalid model이 success/fallback으로 봉합됨")
        if usage_reported and any((u.get(k) or 0) > 0 for k in u):
            violations.append("P2 위반: invalid model에 usage 소비 관측")

    # 4) observed_mode: 성공 실행이 실제 관측됐을 때만 — 그 전엔 null + inferred
    auth_observed = (record_kind == "final-json" and v.get("is_error") is False
                     and exit_code == 0 and "--api-key" not in argv)
    normalized = {k: u.get(k) for k in ("inputTokens", "outputTokens",
                                        "cacheReadTokens", "cacheWriteTokens")} \
        if usage_reported else None
    return {
        "receipt_schema": RECEIPT_SCHEMA,
        "backend": {"id": "cursor", "cli_version": cli_version},
        "contract": {
            "provider_access": "native_subscription",
            "external_network": "vendor_native",
            "auth": {"requested_mode": "native_subscription",
                     "observed_mode": ("native_subscription" if auth_observed else None),
                     "inferred_mode": (None if auth_observed else "native_subscription"),
                     "observed_from": ("성공 실행 경로(final-json success)+argv+env allowlist"
                                       if auth_observed else
                                       "미관측 — argv(--api-key 부재)만으로는 추정")}},
        "model": {"requested_id": requested_id, "observed_id": None,
                  "derived": parse_model_suffix(requested_id)},
        "usage": {"reported": usage_reported, "raw": (dict(u) if usage_reported else None),
                  "normalized": normalized,
                  "source": ("cursor-headless-final-json" if usage_reported else None),
                  "completeness": ("native-passive" if usage_reported else "not-reported")},
        "terminal": {"supervisor_reason": "exit", "exit_code": exit_code,
                     "signal": None, "vendor_is_error": v.get("is_error"),
                     "vendor_subtype": v.get("subtype"),
                     "adapter_violation": (" · ".join(violations) or None)},
        "timing": {"wall_time_ms": wall_ms, "vendor_duration_ms": v.get("duration_ms")},
        "identity": {"native_session_id": sid, "native_request_id": v.get("request_id")},
        "transcript": transcript,
        "env_custody": env_meta,
        "raw_record": {"path": str(raw_path), "kind": record_kind, "source": record_src,
                       "sha256": _sha256(record), "byte_length": len(record),
                       "size_capped": len(stdout_bytes) > RECORD_CAP_BYTES,
                       "parser_version": PARSER_VERSION},
        "cwd": cwd,
    }


def validate_receipt(r: dict) -> list:
    problems = []
    for k in ("receipt_schema", "backend", "contract", "model", "usage",
              "terminal", "timing", "identity", "transcript", "raw_record"):
        if k not in r:
            problems.append(f"필수 키 부재: {k}")
    rr = r.get("raw_record") or {}
    try:
        p = Path(rr["path"])
        if _sha256(p.read_bytes()) != rr["sha256"]:
            problems.append("raw record digest 불일치")
        if stat.S_IMODE(p.stat().st_mode) != 0o600:
            problems.append("raw record 파일 모드가 0600이 아님")
        if stat.S_IMODE(p.parent.stat().st_mode) != 0o700:
            problems.append("custody dir 모드가 0700이 아님")
    except (OSError, KeyError):
        problems.append("raw record 파일/digest 검증 불가")
    u = r.get("usage") or {}
    if u.get("reported"):
        for k, v in (u.get("normalized") or {}).items():
            if (u.get("raw") or {}).get(k) != v:
                problems.append(f"normalized[{k}]≠raw")
    if (r.get("model") or {}).get("requested_id") in (None, ""):
        problems.append("model.requested_id(identity) 부재")
    viol = (r.get("terminal") or {}).get("adapter_violation")
    if viol:
        problems.append(f"adapter_violation: {viol}")
    env = r.get("env_custody") or {}
    if env.get("policy") != "allowlist":
        problems.append("env custody가 allowlist가 아님")
    return problems


def _finish(tag: str, receipt: dict, run_dir: Path) -> int:
    problems = validate_receipt(receipt)
    rpath = run_dir / f"{tag}-receipt.json"
    _write_private(rpath, json.dumps(receipt, ensure_ascii=False, indent=1).encode())
    print(json.dumps({"tag": tag, "receipt": str(rpath), "problems": problems},
                     ensure_ascii=False, indent=1))
    return 1 if problems else 0        # 1) fail-open 폐쇄 — 모드 무관 단일 규칙


def _run_live(requested_id: str, tag: str, prompt: str, expect_error: bool,
              runner=subprocess.run) -> int:
    import tempfile
    _private_dir(OUT_ROOT)                     # 비차단 hardening: 루트도 0700
    run_dir = OUT_ROOT / f"{tag}-{uuid.uuid4().hex[:12]}"
    env, env_meta = allowlist_env()            # r3(Orin 반례 2): version 호출 **전에**
    cli = runner(["cursor-agent", "-v"], capture_output=True, text=True, env=env)
    with tempfile.TemporaryDirectory(prefix="cursor-seam-") as td:
        (Path(td) / "sample.txt").write_text("synthetic non-secret fixture\n",
                                             encoding="utf-8")
        argv = ["cursor-agent", "-p", "--trust", "--output-format", "json",
                "--model", requested_id, prompt]
        t0 = time.monotonic()
        p = runner(argv, cwd=td, env=env, capture_output=True, timeout=300)
        receipt = build_receipt(
            requested_id=requested_id, argv=argv, stdout_bytes=p.stdout,
            stderr_bytes=p.stderr, exit_code=p.returncode,
            wall_ms=int((time.monotonic() - t0) * 1000), cwd=td,
            cli_version=cli.stdout.strip() or "?", env_meta=env_meta,
            run_dir=run_dir, tag=tag, home=Path.home(), expect_error=expect_error)
    return _finish(tag, receipt, run_dir)


def _build_offline(tag: str, stdout: bytes, *, requested_id: str, exit_code: int,
                   expect_error: bool, home: Path, run_dir: Path) -> dict:
    _, env_meta = allowlist_env()
    return build_receipt(
        requested_id=requested_id, argv=["cursor-agent", "-p"], stdout_bytes=stdout,
        stderr_bytes=b"", exit_code=exit_code, wall_ms=1, cwd="/fixture/pz",
        cli_version="fixture", env_meta=env_meta, run_dir=run_dir, tag=tag,
        home=home, expect_error=expect_error)


def cmd_fixture() -> int:
    """provider-zero + 목 반례 배터리 — 전부 합성 home(실전사 무접촉)·spawn 0."""
    import tempfile
    out = {"mode": "fixture-v1", "checks": []}
    rc = 0
    with tempfile.TemporaryDirectory(prefix="seam-home-") as th:
        home = Path(th)                                   # 3) 빈 합성 home
        base = OUT_ROOT / f"fixture-{uuid.uuid4().hex[:12]}"
        # A. 정상 provider-zero: 문제 0 + ambient 무접촉(session_match False) 기대
        r = _build_offline("pz", FIXTURE_STDOUT.encode(), requested_id="kimi-k3-low",
                           exit_code=0, expect_error=False, home=home,
                           run_dir=base / "pz")
        pz_problems = validate_receipt(r)
        ok_a = (not pz_problems and r["transcript"]["session_match"] is False
                and r["contract"]["auth"]["observed_mode"] == "native_subscription")
        out["checks"].append({"name": "pz-clean+ambient-isolated", "pass": ok_a,
                              "problems": pz_problems})
        # B. Orin 목 반례: invalid model인데 success+usage → 위반 검출+exit≠0 필수
        r = _build_offline("mock-fallback", MOCK_FALLBACK_STDOUT.encode(),
                           requested_id="definitely-not-a-model-xyz", exit_code=0,
                           expect_error=True, home=home, run_dir=base / "mock")
        mp = validate_receipt(r)
        ok_b = any("P2 위반" in x for x in mp)             # 1) 반례가 시끄럽게 죽는가
        out["checks"].append({"name": "mock-fallback-detected", "pass": ok_b,
                              "violations": r["terminal"]["adapter_violation"]})
        # C. 미보고 usage 구분: usage 없는 성공 JSON → reported False·위반 아님
        no_usage = json.dumps({"type": "result", "is_error": False, "result": "ok",
                               "session_id": FIXTURE_SID, "duration_ms": 1})
        r = _build_offline("no-usage", no_usage.encode(), requested_id="auto",
                           exit_code=0, expect_error=False, home=home,
                           run_dir=base / "nou")
        ok_c = (r["usage"]["reported"] is False
                and r["usage"]["completeness"] == "not-reported"
                and not validate_receipt(r))
        out["checks"].append({"name": "usage-not-reported-distinct", "pass": ok_c})
        # D. 미관측 auth 강등: 실패 실행에서 observed_mode null + inferred
        r = _build_offline("err", "no json here".encode(), requested_id="kimi-k3-low",
                           exit_code=1, expect_error=True, home=home,
                           run_dir=base / "err")
        ok_d = (r["contract"]["auth"]["observed_mode"] is None
                and r["contract"]["auth"]["inferred_mode"] == "native_subscription"
                and r["raw_record"]["kind"] == "non-json-text")
        out["checks"].append({"name": "auth-unobserved-null+non-json-kind", "pass": ok_d})
        # E. Orin 반례: supervisor 실패(exit 7·빈 stdout·non-JSON stderr)가
        #    expect_error=False에서 위반으로 시끄럽게 죽는가
        r = build_receipt(requested_id="kimi-k3-low", argv=["cursor-agent", "-p"],
                          stdout_bytes=b"", stderr_bytes=b"spawn: boom",
                          exit_code=7, wall_ms=1, cwd="/fixture/pz",
                          cli_version="fixture", env_meta=allowlist_env()[1],
                          run_dir=base / "supfail", tag="supfail",
                          home=home, expect_error=False)
        ep = validate_receipt(r)
        ok_e = any("성공 게이트 미충족" in x for x in ep)
        out["checks"].append({"name": "p1-supervisor-failure-detected", "pass": ok_e,
                              "violations": r["terminal"]["adapter_violation"]})
        # F. Orin 반례 2: version·live 두 spawn 모두 allowlist env를 받는가 (목 runner)
        calls = []
        class _R:
            returncode = 0
            stdout = FIXTURE_STDOUT.encode()
            stderr = b""
        def fake_runner(argv, **kw):
            calls.append({"argv": argv[:2], "has_env": "env" in kw,
                          "env_keys": sorted((kw.get("env") or {}).keys())})
            r_ = _R()
            if "-v" in argv:
                r_.stdout = "mock 0.0"      # 실경로는 text=True(str) — 목도 동일
            return r_
        _run_live("kimi-k3-low", f"mocklive-{uuid.uuid4().hex[:8]}",
                  "mock", False, runner=fake_runner)
        allowed = set(_ENV_ALLOW)
        ok_f = (len(calls) == 2 and all(c["has_env"] for c in calls)
                and all(set(c["env_keys"]) <= allowed for c in calls))
        out["checks"].append({"name": "both-spawns-allowlisted", "pass": ok_f,
                              "calls": calls})
        rc = 0 if all(c["pass"] for c in out["checks"]) else 1
    print(json.dumps(out, ensure_ascii=False, indent=1))
    return rc


def cmd_reparse(path: str) -> int:
    """기존 raw record의 오프라인 재파싱 — 유료 재호출 없이 v1 receipt 재생성."""
    raw = Path(path).read_bytes()
    run_dir = OUT_ROOT / f"reparse-{uuid.uuid4().hex[:12]}"
    r = _build_offline("reparse", raw, requested_id="definitely-not-a-model-xyz",
                       exit_code=1, expect_error=True, home=Path.home(),
                       run_dir=run_dir)
    return _finish("reparse", r, run_dir)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--fixture", action="store_true")
    ap.add_argument("--reparse", default=None)
    ap.add_argument("--p1", action="store_true")
    ap.add_argument("--p2", action="store_true")
    a = ap.parse_args()
    if a.fixture:
        return cmd_fixture()
    if a.reparse:
        return cmd_reparse(a.reparse)
    if a.p1:
        return _run_live("kimi-k3-low", "p1",
                         "Read sample.txt and reply with its exact contents.", False)
    if a.p2:
        return _run_live("definitely-not-a-model-xyz", "p2", "Reply: ok", True)
    ap.print_help()
    return 2


if __name__ == "__main__":
    sys.exit(main())
