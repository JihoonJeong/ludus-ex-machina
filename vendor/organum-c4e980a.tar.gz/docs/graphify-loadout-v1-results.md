# graphify loadout-변주 v1 (replacement) — 결과: 유효 전달 · 자발 채택 0

*2026-07-27. 상태: **VALID** — organ-effect-matrix 첫 실제 loadout 대조 기록.
v0(격리, `graphify-loadout-v0-results.md`)의 대체 라운드. 측정 소유=organum,
실행=organum-code(runner `7a7b450`·재-emit `f027b96`), 게이트 재판정·cells 검증=양측 독립.*

## 설정 (v0에서 달라진 것)

- 근본 수리: `graphifyy[mcp]==0.9.27`(optional MCP 의존성 누락이 v0 원인) ·
  containment이 uv-tool 루트 read-only 승인 · `graphify__*` 쿼리 10툴만 auto-grant.
- **delivery 게이트(항체 3호) 통과**: qualification cell(명시 쿼리)에서 노출·호출·완료
  전부 true + 본 라운드 graphify arm 8/8 노출 telemetry.
- 나머지 프로토콜 동일(counterbalance·신선 세션 `gfx-<arm>-t<n>-r1`·중립 프롬프트 —
  "MCP를 써라" 지시 없음).

## 결과 (나란히 — 합산·판결 없음)

| 축 | bare | graphify |
|---|---|---|
| gate (결정적, 양측 재판정 일치) | **7/8** | **7/8** |
| 공동 실패 | T4 (`_populate`·`game.py` 누락) | T4 (동일) |
| input | 517,434 | 492,309 |
| cache (효율) | 406,912 (78.6%) | 364,480 (74.0%) |
| output | 8,461 | 12,757 |
| requests | 42 | 39 |
| elapsed | 149s | 194s |
| **Graphify 노출 / 호출** | 0/8 · 0/8 | **8/8 · 0/8** |

비고: bare T8 attempt 1이 provider max_tokens 절단 — 선언된 infra-only retry 1회,
error ledger 보존.

## 정직한 판독

1. **주 발견 = "available organ, zero adoption."** 전달은 실증됐으나 중립 프롬프트에서
   solar-open2(explorer, Grok ACP)는 graph를 한 번도 쿼리하지 않았다. 이것이 이 조합
   (brain×role×task×env)에서의 organ 유용성 관측이다 — Ludex Taxis "organ 붙임≠도움",
   우리 P3 null과 같은 계열.
2. **usage 차이는 어느 것도 graph 쿼리에 귀속 불가**(호출 0). cache 효율 78.6→74.0%는
   "툴 선언 10개가 프롬프트 프리픽스를 바꿔 캐시 분절" **가설**(미검정 — 후속 검정 후보).
   output +50%·elapsed +30%는 미귀속 관측.
3. gate 동률(7/8)·공동 실패 T4는 arm 무관한 과제 난점 — v0의 arm 차이(8/8 vs 5/8)가
   분산이었음을 재보강.
4. **소형 리포 경계 유지**: Graphify의 대형-리포 주장에 대한 판정 아님. 이 결과는
   "소형 리포 + 중립 프롬프트 + 이 브레인·하네스"의 서술 셀이다.

## 매트릭스 기록 (첫 varied 셀 — 실물)

```
[reported] solar-open2 × explorer × discovery/navigation × [graphify] — n 8
  in 492.3K · out 12.8K · cache 364.5K · contrast varied-no-score
[reported] solar-open2 × explorer × discovery/navigation × [bare] — n 8
  in 517.4K · out 8.5K · cache 406.9K · contrast varied-no-score
```

passive 증거와 분리(source 축) 유지, contrast=varied-no-score — score 원천이 없고
채택이 0이므로 **organ 효과 주장은 없다**(서술 셀). warren `.organum` 캐노니컬에
ingest됨(16/0 dup — 이번엔 선언 loadout이 사실).

## 항체 정련 (v0 → v1)

- 가시성(노출) = **validity 게이트** (미통과=격리, v0).
- 채택(호출) = **측정된 결과** (0도 1급 관측, v1). run별 adoption count 라벨.

## 후속 후보 (미착수 — 각각 별도 설계·게이트)

- **3-arm**: 중립 / 사용-허용 명시("graph 도구를 써도 된다") / bare — 채택의 프롬프트
  민감도 분리.
- 대형 리포 target(Graphify 주장 도메인) · 다른 brain·하네스 조합.
- 캐시-분절 가설 검정(툴 선언 수만 변주).
