# Two-lens whole-view v0 — 설계 (필드-state × transcript-activity)

*2026-07-19. warren R3 dogfood가 뽑은 seam ③(collab-bench-warren-round3.md §seam(3)·수정큐 ③).
chief의 **필드-기반** whole-view가 critic(solar-oc)을 "idle"로 봤지만 transcript엔 실제 활동(툴 21·파일
접근 6·토큰 67k)이 있었다. 두 렌즈 차이 = **"활동 실재·field 미ship = coordination 실패"**를 측정 가능.
이 문서 = 그 융합의 설계 + 정직성 계약. 빌드 전 JJ 리뷰.*

## 0. 문제

whole-view(관제탑·chief·roster)가 셀 liveness를 **한 렌즈**로만 본다:
- 현재 `roster.merge`는 declared presence(last_beat)와 derived observation(transcript age)을 exact
  cell_key로 병합하되 **`live`를 단일 boolean으로 붕괴** — transcript-활동과 field-활동을 못 가른다.
- 그래서 **"몸은 일하는데 필드엔 조용한"**(heads-down) 셀과 **"진짜 idle"**을 구별 못 한다. R3에서 chief가
  정확히 이걸 틀렸다(일하는 critic을 idle로 봄). RFP R4(publish 강제) 실패 모드도 정확히 heads-down이다.

## 1. 두 렌즈 (둘 다 organum이 이미 가짐)

- **필드 렌즈(declared/coordination)** — 셀이 *공유한* 것: relay·agora·hub 게시(`from_id`), session note/ship,
  roster 선언(focus·open_to). "소통/공유하고 있나?"
- **transcript 렌즈(observed/activity)** — 셀의 몸이 *한* 것: 어댑터 파생(model·tools·files·tokens·last_ts·
  liveness). inspect/observatory가 이미 계산. "몸이 움직이나?"

둘은 **cell_key로 join**된다(6라운드로 동결된 identity 계약 — `state.cell_key`·`from_id`·C3 마커 cross-ref·
join→roster). R3 때는 이 join이 `join_status=global-store-disabled`라 사람이 수동 대조했지만, **지금은
join이 단단하다.** 그래서 이제 융합이 정직하게 가능하다.

## 2. 두 liveness 신호 (분리 보존)

현재 merge가 하나로 뭉개는 걸 **둘로 나눈다**:

- **transcript-live** — 파생 관찰의 `age ≤ live_secs`(기본 90s). 몸이 지금 움직이나.
- **field-live** — 이 셀(`from_id`==cell_key)의 **마지막 관측가능 조율이 field_window(기본 15분) 안**인가.
  카운트: relay·agora 게시(from_id) · session note/ship. **`beat`(heartbeat)는 제외**(JJ 결정 — 하트비트는
  "소통"이 아님; 실제 공유만). field_window는 transcript live_secs보다 길다(게시는 분-스케일; chief 판단으로 조정).

## 3. 융합 상태 taxonomy (v0 = primary 3개, JJ 결정)

**primary 3개**(chief legibility 우선 — "괜찮음/깜깜하게 일함/멈춤"):

| transcript-live | field-live | state | 의미 · chief 사다리 |
|---|---|---|---|
| — | ✓ | **engaged** | 최근 참여(공유) 중 — 건강. transcript 순간 상태 무관 |
| ✓ | ✗ | **heads-down** | 일하는데 필드 조용 — coordination smell. **넛지: "산출을 publish"**(R4 규율) |
| ✗ | ✗ | **idle** | 양쪽 무활동 — 정지. 세션 열림+임계 초과면 stuck 의심(checkup stale-session과 연결) |

field-live ✓면 transcript 순간 상태와 무관하게 **engaged**(transcript-live=90s는 노이즈 — 일하는 셀도 매
순간 idle 깜빡임; field-live=15분이 "참여 중"의 안정 신호). engaged 안에서 transcript-idle이면 dim
**"paused"** 부가 표기(별도 state 아님 — 곧 idle로 갈 조기 힌트용, 옛 posted-quiet를 접음).

**확장성(JJ 지적: dogfood하다 더 세분화 필요할 수 있음)**: state는 `(transcript_live, field_live, 세션
열림·idle 등)` → 라벨을 **한 함수(`coordination_state`)에서 계산**하게 짜서, 새 상태(예: blocked·stuck·
draining) 추가가 그 한 곳 수정으로 되게 한다. 신호(transcript_live·field_live·field_ts·session)는 항상
분리 보존하므로 나중 세분화에 데이터가 이미 있다.

**정직 버킷(measured≠asserted — R3 critic 규율 준수)**:
- **unattributed** — transcript 관찰은 있으나 **declared cell로 join 안 됨**(ORGANUM_CELL 마커 없음/미join).
  role을 주장하지 않는다. "관측된 몸, 미귀속"으로 표시하고 사람 cross-ref 대상. (R3의 declared=null 케이스.)
- **declared-unobserved** — 선언은 있으나 transcript 없음(비-어댑터 body, 또는 transcript 만료 — Claude Code
  ~30일 청소). field 렌즈로만 liveness.

## 4. 정직성 계약 (핵심 — R3 seam(3)이 명령한 것)

- **state는 서술이지 판정이 아니다.** heads-down = "transcript 활동 + field 조용"이라는 **관측**이지
  "실패"라는 단언이 아니다(깊은 분석 중일 수 있다). chief 사다리는 advisory(넛지·강제 아님, 관제탑 not 관제사).
- **transcript 활동을 field 기여로 승격 금지.** heads-down 셀의 private activity(툴·파일·토큰)는 **field
  contribution과 별도 열**로 보존. 사람 재프롬프트 뒤 나온 산출을 자동으로 "seam 발견"·"field 기여"로 안 올림.
- **귀속은 identity join으로만.** cell_key join이 없으면 unattributed(role 미주장). "파일 N"은 변경이 아니라
  접근/관측일 수 있음을 표시(edit=session diff로 별도).
- **미측정=None('—') vs 0 구분 유지**(기존 C2 규율) — field-live 신호가 없는 것과 field-활동 0을 구분.

## 5. 어디에 뜨나

- **`organum roster`(CLI)** — ✅ v0 배선. 각 셀에 state 점(●engaged·◐heads-down·○idle·◌declared-unobserved·
  ◍unattributed) + 헤더에 heads-down 카운트. engaged인데 transcript-idle이면 "engaged·paused" 부가.
- **`organum web`(관제탑)** — ⏳ v0.1 후속. web은 현재 `roster.merge`를 안 쓰고 자체 계산 → coordination_state를
  web payload에 얹는 배선 필요.
- **chief whole-view** — heads-down·idle+open-session을 개입 사다리 후보로(재확인→넛지→PAUSE→에스컬레이트).
  단 chief가 읽고 판단; organum은 상태만 계산.

**note**: session 시작/note도 field-live로 카운트(관제탑이 보는 조율)라, 갓 join한 셀은 engaged(15분 창
안). 15분간 무note·무게시면 field-live 소멸 → transcript 활동 있으면 heads-down, 없으면 idle. R3 solar-oc는
organum 세션 없이(`global-store-disabled`) transcript만 활동+미게시라 heads-down으로 잡힌다.

## 6. 빌드 스케치 (대부분 additive — 재사용 우세)

- **field-recency 계산(신규, 작음)** — 셀별 마지막 필드 활동 ts = max(relay·agora·hub `from_id`==cell의 최근
  게시 ts, session 최근 note/ship ts). field.list_all/session.status 재사용, from_id 필터.
- **`roster.merge` 확장** — 단일 `live` 대신 `{transcript_live, field_live, coordination_state}` 계산(기존
  `live`는 하위호환 유지 = transcript_live or field_live). unattributed/declared-unobserved 분류.
- **render 확장** — roster.render·web payload·chief 요약에 state.
- **테스트** — 2×2 각 상태 · unattributed(join 없음) · heads-down 정직성(field 기여 승격 안 함) · 미측정 '—'.

## 7. 경계

서술적 whole-view지 dispatch 아님. state는 관측, 사다리는 advisory. organum은 "누가 일하며 안 올리나"를
*보여줄* 뿐, 누구에게 뭘 시키지 않는다. RFP R4(하네스가 publish 강제)의 **substrate 관측 짝** — actor가
규율을 집행하고, organum이 그 규율 이행/미이행을 정직하게 계측한다.
