# 포지셔닝 — organum vs 런타임/ADE (예: Orca)

*2026-07-12, JJ가 Orca(Agentic Development Environment) 자료 공유 → 교차점·차별화 분석. 경계 검증 +
니치 확인. 빌드 아님(포지셔닝 reference).*

## Orca = 환경/런타임 (ADE)

Orca는 **데스크탑 앱 = 환경/런타임**이다: PTY를 소유하는 백그라운드 데몬, 내장 터미널·MD/이미지
뷰어·웹브라우저(컴포넌트 셀렉터), 멀티디바이스(win/mac/linux)+모바일 QR, 계정 전환, git 플랫폼
(GitHub/GitLab/Jira/Linear) 연동, 자동화 템플릿, 오케스트레이션 배관, Mailbox+message-send.
Agent-agnostic(Claude/Codex/Gemini/opencode/minimax). YC-backed, 실력 있는 팀. 36 세션 ~1GB 안정.

## 핵심 — 경쟁이 아니라 **다른 층**

- **Orca = 환경/런타임** (세션을 *돌린다*, PTY 소유, 터미널·브라우저·앱).
- **organum = organ/인지/규율 층** (환경 *위에서* 돈다, Orca 포함 아무 터미널에서도). 터미널도
  런타임도 아님 — [[persistence-ontology]]·plan §1 경계 그대로.

**우리가 터미널/멀티플렉서/런타임을 안 만든 게 옳았다**: Orca가 YC 자금으로 그걸 훨씬 잘 한다.
organum이 그걸 만들었으면 흡수됐을 것("DESQview→Windows 흡수"의 실사례). 경계가 이걸 예측·회피했다.

## organum의 니치 = Orca가 스스로 인정한 빈틈

JJ 관찰(원문): *"Orca 메시징은 Mailbox+send는 되지만 **디스코드 같은 값을 주는 레이어가 별도로
필요**하고 규격 개선 필요."* → **그 별도 레이어가 organum의 홈그라운드다.** 런타임의 조율/인지 층은
얇고, 그걸 코히어런트하게 만드는 것 =
- 지속·분화된 **기억** · 형태-우선 **세계모델** · **map/frontier** · **면역(guard)**
- **coordination membrane**: single-writer · provenance · join(가입) · 에티켓 · stigmergy · family/lineage
- 과학적 규율(measured≠asserted, P3 등록된 null)

= **Orca는 몸/환경, organum은 신경·면역·기억·규율.**

## 기능 triage — 흡수(경량) / 적응 / 남김(런타임) / 보유

*판정 기준: organum 정체성(상태+규율+인지 *층*)에 맞고 가벼우면 흡수, 런타임/앱/통합이면 남김.*

| Orca 기능 | 판정 | organum 대응 |
|---|---|---|
| 멀티세션 안정성(36세션 1GB, PTY) | **남김** | 프로세스 안 돌림 — transcript만 읽음(가벼워 scale OK) |
| MD/이미지 뷰어·내장 브라우저 | **남김** | 웹 허브는 *대시보드*지 뷰어 스위트 아님 (거대·Orca 레인) |
| 브라우저 컴포넌트 셀렉터→세션 | **남김** | 브라우저 자동화 = 별개(예: claude-in-chrome) |
| PTY 데몬 reopen&continue | **남김** | 우리 방식 = 상태 디스크 지속, 아무 에이전트가 재-read |
| project/workspace/agent 계층 | **적응** | site-bound + **로스터(join/presence)**가 우리 버전 (인지 뷰지 파일탐색기 아님) |
| 유려 UX/멀티디바이스 앱 | 적응(경량) | 웹 허브는 다듬되 *앱이 아니라* stdlib 대시보드 |
| **시스템 푸시 알림** | **흡수(경량)** | 허브가 "세포 입력대기·guard 차단·너에게 편지" 알림 |
| Agent-agnostic (claude/codex/gemini…) | **보유/확장** | 벤더-중립(우리 베팅). **갭**: Codex/Gemini transcript 리더(관찰 어댑터) |
| 계정 전환·git 플랫폼 연동·이슈/PR 탐색 | **남김** | 통합·앱 레인, 지면 흡수 |
| orca CLI: 세션간 메시지 / 오케스트레이션 | 메시지=**흡수**(relay 보유) / 오케스트레이션=**남김**(디스패처 안 만듦) |
| 자동화 러너(템플릿) | 러너=**남김** / 상태=흡수 | organum은 자동화가 *쓰는 기억·상태*를 제공, 러너 아님 |
| 모바일 QR 연동 | **흡수(경량)** | localhost 허브를 LAN 바인드 + QR |
| 완벽한 한글 | **흡수/완료** | i18n(웹 완료 · CLI/docs P4) |
| 네이티브 윈도우(no WSL) | **남김** | organum은 그냥 Python — PTY 걱정 없음 |
| **Mailbox+send "별도 레이어 필요"** | **핵심/소유** | relay+membrane+인지 = 바로 그 레이어 |

## 덜어내기 규율 — organum이 *되지 말 것*

Orca를 따라잡으려 기능을 부풀리면 진다. organum의 해자는 **얇고 깊은** 규율·인지 층이지 넓은 앱이
아니다. 최소·집중 유지:
- **런타임/터미널/데스크탑 앱이 되지 않는다** (PTY·뷰어·브라우저·통합·계정 = Orca 레인).
- **웹 허브 = 경량 대시보드 + 조율 보드**, 앱 아님. 뷰어·에디터·브라우저를 안 붙인다.
- 오케스트레이션(디스패치)을 삼키지 않는다 — 네이티브/런타임이 굴리고 organum은 인지·규율만.
- 우리 것도 최소로: 기능마다 "이게 *상태+규율+인지 층*인가, *런타임/앱*인가"를 묻고 후자면 뺀다.

## 로드맵 함의 (홈페이지·다음 빌드)
- **흡수(가벼운 것부터)**: 로스터(join→presence) · 알림 · 모바일 QR · 크로스-벤더 transcript 리더.
- **이미 보유**(홈페이지에서 내세울 것): 벤더-중립 · 크로스-플랫폼 웹 · relay(메시징) · i18n · 규율(membrane·guard·family·provenance).
- **안 만듦**: 터미널·PTY·뷰어·브라우저·git통합·계정전환·자동화 러너.
- **홈페이지 각도**: "Orca(또는 아무 런타임) *위에서* 도는, 멀티-에이전트를 코히어런트하게 만드는 인지·규율 층." 런타임과 경쟁 아님 — 런타임이 못 주는 *의미·기억·규율*을 준다.

## 한 줄
organum은 Orca의 경쟁자가 아니라, **아무 런타임(Orca 포함) 위에서 도는 "멀티-에이전트를 코히어런트
하게 만드는 규율·인지 층"**이다. Orca 등장 = 시장 증명 + 경계 검증 + 니치를 대신 광고해준 것.

관련: [[shared-cognition-harness]] · [[collaboration-template]] · plan §1(경계)
