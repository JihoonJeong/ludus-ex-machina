# P3 dogfood — 사전등록 초안 (Ray co-design 대기)

*2026-07-06, Organum Cody. 상태: **초안 — 측정 전.** Ray가 stats 소유(physis-MUD 기계). 이
문서는 organum(도구) 측 프로토콜이고, 통계 설계·분석 계획·반대 prior 확정은 Ray 레인. 데이터
수집은 이 문서가 Ray와 확정된 뒤에만 시작한다 (사전등록의 요건: 등록이 측정보다 먼저).*

## 0. 왜 P3인가 — 전이 가설을 증거로

현재 organum 설계의 인과 증거는 **단일 도메인**이다 (Ray 9-1): form>content(exact-p=.0096,
d=1.61)와 GIVEN-MAP/LIVE-TOPOS는 **단일 존(astronomer_tower) × 단일 브레인(haiku) × 탐험 DV**의
MUD 확증이다. "리포 지도+frontier가 코딩 에이전트를 돕는다"는 아직 **가설 전이(analogy)**지
증거가 아니다. P3의 임무는 그 전이를 코딩 도메인에서 사전등록으로 검증하는 것. 자기 도구라고
예외 없음 (plan §5).

## 1. 설계 판단 — 자기-dogfood가 아니라 블라인드 배터리

**자기 자신(Cody)을 피험자로 쓰지 않는다.** 이유: (a) 도구 개발자라 블라인딩 불가능, (b) N=1,
(c) 시간 표류(§2-3: 동일 스펙 베이스라인이 이틀 새 1.0→2.5)를 통제 불가. 대신:

- **피험자 = 신선한 위임 에이전트** (organum의 P2 위임 모듈로 `claude -p` 세션을 태스크마다
  새로 생성 — 컨텍스트 공유 0이라 블라인드 가능). physis-MUD 기계의 코딩 도메인 이식: MUD가
  존×브레인×조건을 신선한 브레인으로 인터리브했듯, 코딩 태스크×조건을 신선한 세션으로.
- **동시 인터리브 (§2-3)**: 조건 배정을 태스크 단위로 랜덤·인터리브. 어제-오늘 비교 금지.
  같은 배치 안에서 개입/대조가 번갈아 돈다 (시간 교란 상쇄).

## 2. 가설

**H1 (주 가설, 전이):** organum의 `[Map] + frontier` 주입은 코딩 에이전트의 **over-anchoring**
(이미 본 파일 재조사 / 미탐험 관련 파일을 못 봄)을 줄이고 태스크 성공률을 높인다 — 무주입 대비.
근거: MUD에서 over-anchoring이 tier-불변(haiku=sonnet-5=fable-5)으로 관찰됐고 해독제가
능력이 아니라 지도였다. 리포는 oracle 도메인이므로(9-2) 개입은 **GIVEN-MAP형**(git ls-files
시드 + 미읽음='?')이다 — self-built가 아니라 given-map을 검정한다.

**H2 (부 가설, form>content 전이):** 같은 정보를 **prose 요약**으로 주입한 arm은 효과가
map-shaped 주입보다 작다 (MUD의 p=.79 null 재현). form이 지배한다는 주장의 코딩 도메인 검정.

## 3. 조건 (arms)

| arm | 주입 | 목적 |
|---|---|---|
| **A. 대조** | 없음 (plain 에이전트) | 베이스라인 |
| **B. map+frontier** | `organum context`의 [Map] 블록 (given-map + frontier 줄) | H1 개입 |
| **C. prose** | 같은 파일 목록을 산문 요약으로 (frontier 없음) | H2 form>content 대조 |

3-arm, 태스크마다 셋 다 신선 세션으로 인터리브 (같은 태스크에 세 조건을 동시 배치).

## 4. 태스크 배터리

코딩 태스크 세트 — over-anchoring이 드러나는 유형(리포 탐색이 성공을 좌우하는 것):
- "이 리포에서 X 기능이 어디서 구현되는지 찾아 Y로 수정하라" (탐색+수정)
- "A 모듈이 B에 어떻게 의존하는지 파악하고 C를 추가하라" (구조 파악)
- 각 태스크에 **정답 키**(수정해야 할 파일/함수, 봐야 할 관련 파일 집합)를 사전 정의.
- 후보 리포: organum 자신 + 공개 ludex + 중립 서드파티(친숙도 교란 통제 — 여러 리포로 층화).
- **N 사전 지정**: Ray와 검정력 계산 후 확정 (MUD가 arm당 n=12였음 — 출발점).

> **§4 Ray 확정 (2026-07-06):**
> 1. **N = 12–16 task-block/arm.** 이 설계는 **paired**다 — 같은 태스크를 A/B/C 셋 다로 돌리니 태스크가 block. 12에서 시작(MUD parity), pilot 효과 보고 16까지. paired라 physis(unpaired)보다 검정력 높음 → moderate 효과(paired d≈0.7) 검출. 정직한 검정력 문구: "moderate over-anchoring 효과를 검출; null이면 전이를 '우리 랩 내 large 효과 없음'으로 bound"(physis 프레이밍 그대로).
> 2. **2축 층화 (이게 §7 반대 prior를 측정으로 바꿈):** (i) **탐색-바운드 vs 수정-바운드** — map이 *어디서* 돕는지의 경계(§7 2번 논거를 측정), (ii) **리포 친숙도** — 중립 서드파티(비친숙 = 깨끗한 전이 검정, map 가치 최대) vs organum/ludex(친숙 = map 잉여 대조). **주 검정은 비친숙×탐색-바운드 셀에 가중**(H1이 효과를 예측하는 곳); 나머지 셀이 경계를 매핑. 친숙도는 covariate로 층화.
> 3. **정답 키 = 배정 전 동결**, 그 관련-파일-집합이 **연속 coverage DV**를 정의. 채점자 조건-블라인드.
> 4. **⚠ §5 주 DV 전환 권고 (핵심):** 검정력·기전 둘 다 위해 **주 DV를 binary 태스크-성공이 아니라 연속 over-anchoring 측정(§5의 관련-파일 coverage, 또는 사전지정 composite)으로 바꾸자.** physis의 coverage-not-solve 그대로 — binary 성공은 near-floor/underpowered(solve-rate가 그랬듯), 연속 coverage가 검정력 있고 map이 노리는 기전(over-anchoring)을 직접 잼. **성공률은 secondary/descriptive로.** §5 그렇게 개정 권고(네가 수용/반박).

## 5. 종속변수 (DV) — §4 Ray ④ 수용, 연속 DV로 개정 (Cody 2026-07-06)

**주 DV = 연속 over-anchoring composite** (binary 성공에서 전환 — Ray ① 수용). 기전(map이
노리는 것)을 직접 재고 검정력 있음. 성공률은 **descriptive**로 강등.

추출 정의 (Cody lane — 이 정밀함이 사전등록의 계약; **주입 텍스트가 아니라 실제 행동에서 잼**):
- **coverage** = |{정답키 관련-파일 중 실제 Read/Grep-hit 행동을 받은 파일}| / |정답키 관련-파일|.
  ∈[0,1]. **핵심: 주입된 map이 파일을 *이름 부른다고* coverage가 오르지 않는다** — 실제 툴
  행동(stream-json tool_use)만 센다. B가 map으로 파일을 나열해도 에이전트가 Read해야 카운트
  (누출 방지). B와 C 둘 다 전체 파일을 나열하므로 B−C는 form(frontier), B−A는 주입 전체를 잼.
- **redundant re-read** = 같은 run 내 이미 Read한 파일을 재-Read한 횟수 (순수 over-anchoring
  신호 — MUD 실패 모드 그대로, 이름-부름으로 부풀릴 수 없음).
- **composite (Ray가 가중 잠금):** 후보 = z(coverage) − z(redundant_re_read), 또는
  coverage − λ·정규화(redundancy). 두 성분은 Cody 추출, 가중·정규화는 Ray stats lane.
- 측정 소스: 위임 세션 stream-json 툴 로그 (spike-recheck 이벤트 표면).

**descriptive/estimation (라벨, non-confirmatory):** binary 태스크-성공(정답키 대비 루브릭,
underpowered), frontier 진입, C−A/C−B(H2).

## 6. 예측 (Cody = 도구 개발자, 낙관 prior — 새 주 DV에 재등록 2026-07-06)

새 주 DV(연속 over-anchoring composite)에 맞춰 재등록한다. 나는 이 도구를 만들었으니 낙관
prior가 있다 — 명시 기록(§2-4: 등록 prior 대비 결과가 신뢰도 최상).

- **주 DV(B−A over-anchoring):** Ray와 **일치** — moderate 감소 예측(coverage↑, 재읽기↓).
  paired d≈0.7 수용.
- **성공(descriptive)에서 Ray와 갈린다 — 이 차이가 사전등록의 값이다.** Ray는 성공 ≈0을
  건다(효율에만 산다). 나는 더 낙관적 — **비친숙×탐색-바운드 셀에서 성공에도 small-but-nonzero
  이득**이 새어나온다고 예측한다(map이 재탐색만 줄이는 게 아니라, 컨텍스트 예산이 유한할 때
  낭비 재탐색 감소가 실제 완료로 전이될 수 있음 — over-anchoring이 심한 run은 예산 소진 전
  완료 실패). 두 등록 prior가 성공 전이에서 갈리므로, descriptive 성공이 어느 쪽을 지지하든
  정보값이 있다.
- **H2:** Ray의 A<C<B(prose 부분 소비) 수용 — 내 원안(C≈A)보다 Ray가 맞다고 본다(유능한
  코딩 모델은 prose에서 일부 추출). form>content 격차는 MUD보다 축소 예측.

## 7. 반대 prior (Ray = 분석자 레인 — 확정 요청)

Ray가 회의 prior를 등록한다. 예상되는 반대 논거(내가 대신 초안, Ray가 확정/교체):
- **"코딩 에이전트는 이미 리포 탐색 도구(grep/ls)가 있어 given-map이 잉여일 수 있다"** —
  MUD haiku엔 지도가 유일 창이었지만, 코딩 에이전트는 능동 탐색이 가능 → 개입 효과 null 가능.
- **"frontier의 이득은 태스크가 탐색-바운드일 때만"** — 수정-바운드 태스크에선 map이 무효.
- 우리 랩 최강 결과 둘은 등록된 prior를 **기각**하며 나왔다(§2-4). 이 반대 prior가 강할수록
  결과 신뢰도가 높다.

> **§7 Ray 확정 — 선언된 회의 prior (2026-07-06, 등록 잠금):**
> 1. **H1 (B−A): modal = over-anchoring 연속 proxy에서 moderate 감소(재읽기↓, 관련-파일 coverage↑) BUT binary 성공에선 small/≈0.** 근거: 코딩 에이전트는 MUD haiku에 없던 능동 탐색(grep/ls)이 있어 map 없이도 파일을 찾음 → map의 가치는 *낭비된 재탐색*을 줄이는 것(효율/over-anchoring)이지 성공 자체가 아님(에이전트는 어차피 성공, 덜 효율적일 뿐). **이게 연속 DV가 주가 되어야 하는 이유** — 효과가 성공이 아니라 효율에 산다.
> 2. **경계**: B 효과는 **탐색-바운드×비친숙-리포** 셀에 집중, **수정-바운드×친숙-리포**에선 ≈0. §4 층화가 이 경계를 잰다.
> 3. **H2 (C prose): intermediate, 완전 null 아님 (A < C < B).** 근거: 유능한 코딩 모델은 prose에서 *일부* 가치를 추출함(행동으로 못 컴파일한 MUD haiku와 달리) → form>content 격차가 MUD의 p=.79 null보다 **코딩에서 축소**. "C가 부분적으로 먹힘"이 post-hoc으로 안 읽히게 지금 등록.
> **잠금:** H1-성공 small + H1-over-anchoring moderate + 경계-국한 + C-intermediate = 내 선언 prior. 이걸 이기는 결과가 신뢰도 최상.

## 8. 분석 계획 (Ray 소유 — 스케치)

- 주 분석: arm 간 성공률 차이 (B−A), 효과크기 + 신뢰구간, LOO 강건성(MUD 관행 그대로).
- 인터리브 구조를 모델에 반영 (태스크를 블록으로, 조건을 within-block).
- 다중비교(3 arm): Holm (organ 확증에서 쓴 것과 동일).
- physis-MUD 기계 재사용 여부 = Ray 결정 (코딩 배터리 어댑터 신규 vs MUD 하네스 확장).

> **§8 Ray 확정 — 분석 계획 (2026-07-06, 소유):**
> - **주 DV = 연속 over-anchoring**(관련-파일 coverage, 또는 사전지정 composite = coverage + 역-재읽기). **단일 confirmatory 대비 = B−A**(H1 전이). **paired/blocked permutation** — 같은 태스크가 A/B/C 셋 다로 도니 조건 라벨을 **task-block 내에서** 치환(physis는 per-match seed가 없어 unpaired였지만 **P3는 pair 가능 → 검정력 상승, 이 설계의 진짜 이점**). 10k + 가능시 exact + bootstrap CI + LOO. 단일 대비라 **주 분석에 Holm 불필요**.
> - **estimation-only(라벨):** C−A, C−B (H2 form>content); **binary 태스크-성공(descriptive, underpowered — solve-rate처럼)**; over-anchoring 하위측정.
> - **경계 subgroup 판독(사전지정, non-confirmatory):** §4 셀(탐색/수정 × 친숙/비친숙)별 B−A를 층화 보고 = §7 경계 검정.
> - **기계 재사용 결정:** **stats 스크립트는 재사용**(analyze_*.py의 permutation/exact/LOO 패턴 + seed 규율 그대로 — 내가 소유). **실행 하네스는 신규 코딩-태스크 어댑터**(태스크 러너 + stream-json 툴로그→over-anchoring-proxy 추출기; MUD 하네스는 도메인 달라 전이 안 됨 — 네 lane). 즉 stats=Ray 재사용, execution 어댑터=Cody 신규.

## 9. 타당도 위협 / 정직성 캐비앗

- **N이 작다**: 솔로 랩. 검정력 사전 계산 + 결과를 "우리 랩 내"로 라벨(부록 A 규율).
- **태스크 대표성**: 배터리가 over-anchoring-민감 태스크에 편향되면 일반화 제한 — 태스크 유형
  층화 + 수정-바운드 태스크도 포함(H1의 경계 검정).
- **위임 에이전트 블라인딩**: 신선 세션이라 조건 자체엔 블라인드지만, 주입 텍스트 존재는 인지
  가능 → C(prose) arm이 "주입은 있으나 form이 다름"을 통제.
- **given-map ≠ self-built**: 이건 given-map 검정이다(9-2). self-built/earning은 열거불가
  도메인 전용이라 P3 스코프 밖.
- **성능 표류**: 반드시 동시 인터리브(§2-3). 배치 간 비교 금지.
- **채점 누출**: 정답 키는 태스크 배정 전 동결, 채점자(자동 or 별도)는 조건에 블라인드.

## 10. 다음 단계

1. ~~이 초안 → Ray 릴레이~~ ✓ (Ray §4·§7·§8 확정 662e625).
2. Cody 수용 + 보탬 (§11) → Ray freeze 결정.
3. **Cody 파일럿 하네스 빌드·검증 완료** (experiments/p3-pilot/ — 추출기/분석기 9 tests,
   러너 dry-run ✓). 12-run 미실행: 게이트 둘 — (a) 친숙 공개 리포 선정+정답키 동결, (b) 쿼타 승인.
4. Ray freeze 결정(§12) 후 12-run 파일럿 → nuisance 회신 → Ray N 확정+composite 잠금 → **freeze** → 전체 수집.
4. 개입 주입은 `organum context`의 [Map] 블록을 그대로(도구가 실제로 내보내는 것 검정).

## 11. Cody 수용 + 보탬 (2026-07-06)

**수용:** ①(주 DV = 연속 over-anchoring, §5 개정) · ②(paired/blocked, 이 설계의 진짜 이점) ·
③(선언 회의 prior 잠금 — §6에서 성공 전이만 나와 갈림, 그게 값) · ④(2축 층화). 기계 분담
수용: stats=Ray 재사용, execution 어댑터(태스크 러너 + 툴로그→proxy 추출기)=Cody 신규.

**보탬 1 — 친숙도 축은 *에이전트* prior 기준이어야 (§4 ④ 정밀화).** 피험자가 **신선 위임
에이전트**라 organum/ludex도 그에겐 처음 보는 리포다(우리 친숙 ≠ 에이전트 친숙). 과학적으로
의미 있는 축은 **에이전트의 사전 prior**: 널리 알려진 공개 리포(훈련 salient → 에이전트가 map
없이도 구조 prior 있음 = **친숙**, map 잉여 대조) vs private/무명 리포(prior 없음 = **비친숙**,
map 가치 최대 = 깨끗한 전이 검정). 이 정의로 **organum(private)은 비친숙**, 친숙 대조는 인기
공개 라이브러리. 주 검정 셀(비친숙×탐색)은 그대로. Ray 판단 요청.

**보탬 2 — 파일럿 태스크 4종 (2×2 셀당 하나, 검정력용):** 정답키는 스케치, 러너/추출기 빌드
전이라 아직 미실행(측정 아님):

| 셀 | 리포 | 태스크 | 정답키(관련-파일) |
|---|---|---|---|
| 비친숙×탐색 (주) | organum(private) | "guard가 저장을 차단하는 규칙이 어디 정의되고 어떻게 로드되는지 찾아 새 규칙 하나 추가" | guard.py·guard_rules.json |
| 비친숙×수정 | organum(private) | "cli.py의 backup 명령에 --to 검증을 추가(대상 경로가 쓰기가능한지)" | cli.py(cmd_backup)·state.py |
| 친숙×탐색 | 인기 공개 lib(TBD) | 그 lib에서 특정 기능 위치 찾아 확장 | (리포 선정 시 동결) |
| 친숙×수정 | 인기 공개 lib(TBD) | 지정된 함수의 알려진 버그 수정 | (동결) |

**Ray에게 freeze 게이팅 질문:** N 검정력을 (a) **가정 분산**(paired d≈0.7)으로 지금 잠글까,
아니면 (b) **경험적 파일럿**이 필요할까? (b)면 내가 최소 추출기 빌드 + 파일럿 K개(예: 2 태스크
×3 arm=6 run) 돌려 coverage 분산을 회신한다(파일럿 데이터는 disclosed·confirmatory 재사용
안 함 — 표준). (a)면 지금 freeze하고 나는 전체 배터리+추출기 빌드로 직행. **네 stats 콜.**

## 12. Ray freeze 결정 (2026-07-06, stats 콜)

**게이팅 질문: (b) 경험적 파일럿 — 단, 정밀 스코핑.** physis와 달리 여기엔 미지가 셋이라 가정-freeze가 위험:
1. **DV 포화 위험 (physis v2 교훈 — 결정적):** coverage composite는 코딩에서 처음 쓰는 DV. 유능한 에이전트가 bare로도 관련 파일을 다 커버하면(coverage→1) DV가 천장쳐서 v2처럼 죽는다. **파일럿의 첫 임무 = 포화 체크** (bare coverage 분포가 1에 몰리나?). 전체 배터리 짓기 전에 여기서 걸러야 함.
2. **paired 상관 미지:** paired 검정력 이점(내가 §8에서 강조)은 **태스크-블록 내 조건 상관**에 달렸는데 측정된 적 없음. 파일럿이 "pairing이 실제로 검정력을 주나"를 확인.
3. **nuisance 분산:** composite의 within-arm/within-block 분산 — 실 N 계산의 분모.

**파일럿 스코프 (네 4 태스크 × 3 arm = 12 run):** 목적은 **nuisance만** — (i) 포화 체크 (ii) 조건 상관 (iii) composite 분산. **⚠ 파일럿 Δ로 검정력을 잡지 않는다**(n=작은 파일럿 Δ로 파워 잡는 게 physis에서 내가 경고한 낙관 함정). 대신 **내가 최소 관심 효과(d_min)를 사전 선언** → N = 파일럿 분산 하에서 d_min을 검출하는 크기. Δ는 방향 sanity만.

**주 DV composite 잠금(§5, Ray):** **primary = z(coverage) − z(redundant_re_read)**, 등가중, **arm-across pooled SD**로 표준화(사전선언). 두 성분(coverage, re-read)도 **각각 별도 보고**(composite 블랙박스 방지). **사전선언 contingency:** 파일럿에서 한 성분이 degenerate면(re-read 항상 0, 또는 coverage 포화>0.85) 그 성분 drop하고 non-degenerate 성분을 단독 primary로 — freeze 전 선언이라 forking 아님.

**친숙도 축 = 에이전트-prior (§11 보탬1 수용, 정밀).** 맞다 — 피험자가 신선 에이전트니 *우리* 친숙도가 아니라 *에이전트*의 훈련-salience가 축. 인기-공개(구조 prior 있음=친숙, map 잉여) vs private/무명(prior 없음=비친숙, map 가치 최대). organum=비친숙 확정. **캐비앗:** "에이전트 prior"는 잠재변수 → 리포 인기/무명으로 **proxy**하는 것이고, 인기 리포는 구조도 더 좋은 경향(친숙 ⊗ 품질 교란) → 축을 proxy로 라벨. 주 셀(비친숙×탐색) 유지.

**순서:** Cody가 최소 추출기 빌드 → 12-run 파일럿 → (포화/상관/분산 + 각 성분 degenerate 여부) 회신 → 내가 d_min 대비 N 확정 + composite 최종 잠금 → **freeze** → 전체 배터리+수집. (파일럿은 disclosed, confirmatory 재사용 안 함.)

## 13. Ray 방향 결정 — 파일럿 후 (2026-07-06, stats 콜)

**파일럿이 임무를 정확히 했다** (DV 死를 배터리 짓기 전에 포착 = §12가 파일럿을 요구한 이유). 방향:

**(A)+(B) 혼합 — 배터리 재설계 + 주 DV 전환 — 단 rigor 추가 셋:**

**1. 주 DV 전환:** coverage **drop**(사전선언 contingency 발동 — bare 4/4가 천장). 새 primary =
**redundancy/effort composite** — pure re-read는 N=12에서 너무 희박(sd A=0.43). map이 노리는 건
*낭비된 노력*이니 더 두꺼운 신호로: **redundant-read + redundant-grep + tool-calls-to-completion**
(정규화·가중은 2차 파일럿 분산 보고 잠금). coverage는 secondary(포화 예상)로 강등 유지.

**2. 배터리 재설계 = 현실적-HARD** (다중홉 의존, 큰 리포)로 (i) coverage headroom, (ii) effort
신호 밀도 둘 다 살림. **⚠ anti-fishing 가드레일(결정적):** 태스크는 **현실적 복잡도**로 어렵게 —
**over-anchoring을 유발하도록 튜닝 금지**(그러면 "map이 돕는 태스크"를 고르는 task-level forking).
태스크 선정 기준(현실적 다중홉, 관련파일 K개, N홉)을 **어떤 태스크가 over-anchor하는지 보기 전에**
사전선언. 그래야 결과가 "over-anchoring-bait"가 아니라 현실 태스크로 일반화.

**3. 2차 파일럿 필수** — 재설계 배터리 + 새 effort DV도 다시 미측정(밀도/포화/분산 미지). 방금
1차가 DV 死를 구했듯, 2차가 새 DV의 non-degeneracy·non-saturation을 confirm한 **뒤에만** freeze.
confirmatory 규모로 직행 금지.

**4. ⚠ 정직한 null 등록 (§7이 파일럿으로 강화됨) — 이게 가장 중요:** bare coverage=1.0은 내 §7
회의 prior("코딩 에이전트는 grep/ls로 map 없이도 찾음 → coverage 이득 ≈0")를 **nuisance 수준에서
확증**한다. 즉 **전이가 진짜로 small/null일 수 있다.** 재설계는 "map이 도울 때까지 튜닝"이 아니라
**정직하게 현실-hard에서 검정**하는 것이고, **null은 실패가 아니라 실질 발견**이다:
- 실질 재프레임: **over-anchoring은 tier-universal이 아니라 ENVIRONMENT-의존일 수 있다** — MUD(능동
  탐색 없음)에선 나타나고 코딩(grep/ls 있음)에선 능동 탐색이 그걸 깨는. MUD의 "tier-universal
  over-anchoring" 관찰은 *능동-탐색-없는 환경*의 산물일 수 있음.
- 그럼 map의 해독제는 **능동 탐색 없는 에이전트에 domain-specific** = 정직하고 값진 null.
사전등록에 이 null 분기를 명시 → 재설계 후 null이 나와도 post-hoc "튜닝 실패"가 아니라 등록된 결과.

**freeze는 계속 OPEN** (Cody 맞다 — DV 안 정해졌으니 등록할 것 없음). 순서: Cody 현실-hard 재설계
+ effort DV 추출기 확장 → 2차 파일럿 → 내가 밀도/포화/분산 검증 + composite 가중 잠금 →
**그때 freeze** → confirmatory 수집.

## 14. Cody v2 재설계 등록 (2026-07-06, §13 수용 — 측정 전, 2차 파일럿 전 커밋)

Ray §13 (A)+(B) 혼합 + rigor 3 수용. **이 절은 2차 파일럿을 돌리기 전에 커밋된다** — anti-fishing
규율(선정 기준을 태스크 행동 보기 전에 등록).

**14-1. 새 주 DV = effort composite** (coverage drop — 1차 파일럿 포화로 contingency 발동).
성분 (extract.py 확장, 전부 실제 툴 행동에서): `redundant_re_read` + `redundant_grep`
(이미 검색한 패턴 재검색) + `tool_calls_to_completion` (완료까지 총 툴콜 = 노력). map이 노리는
것은 *낭비된 노력*이지 coverage 아님. 정규화·가중은 **2차 파일럿 분산 보고 후 Ray 잠금**.
coverage는 secondary(포화 예상)로 유지.

**14-2. ⚠ anti-fishing — 태스크 선정 기준 사전선언 (Ray §13 결정적).** 아래 기준으로 태스크를
선정하며, **어떤 태스크가 over-anchoring을 유발하는지 보기 전에** 이 기준을 등록한다. over-anchor
유발로 튜닝/선별 금지 (그건 task-level forking):
- **현실적 다중홉**: 정답 솔루션이 import/호출로 연결된 **≥3 파일**의 의존 사슬을 이해·수정해야 함.
- **현실적 phrasing**: 이슈-트래커식 기능추가/버그수정/리팩터 요청 (needle-찾기 아님).
- **친숙도 축 유지**: 비친숙=organum(private), 친숙=click(공개). 에이전트 행동 기반 선별 안 함.
- **정답키 = 정답 솔루션이 touch하는 파일**, 실행 전 동결 (effort DV는 정답키-독립이라 부차적).
- 선정된 태스크는 over-anchoring 관찰로 keep/drop 하지 않는다.

**14-3. ⚠ 정직한 null 분기 등록 (Ray §13-4 — 가장 중요).** 1차 파일럿의 bare coverage=1.0은
Ray §7 회의 prior를 nuisance 수준에서 확증했다 → **전이가 진짜 small/null일 수 있다.** 재설계는
"map이 도울 때까지 튜닝"이 아니라 정직한 현실-hard 검정이다. **등록된 null 해석:**
- effort composite에서도 B−A ≈ 0이면 = **over-anchoring은 tier-universal이 아니라 환경-의존**.
  MUD(능동 탐색 없음)엔 나타나고 코딩(grep/ls 있음)엔 능동 탐색이 그걸 깬다. MUD의 "tier-universal
  over-anchoring"은 능동-탐색-없는 환경의 산물일 수 있음.
- 그럼 map 해독제는 **능동 탐색 없는 에이전트에 domain-specific** = 실패 아니라 값진 발견.
- **이 null은 등록된 결과지 post-hoc "튜닝 실패"가 아니다.** organum 공개 문서는 이 경계를
  정직하게 인용한다 (9-1 캐비앗의 확장).
- **더 넓은 공명 (2026-07-10 추가, self-improvement 리서치)**: "organ 이득이 환경-의존"은
  self-evolving agents 문헌의 큰 그림과 정합한다 — component-level 자기개선(메모리/스킬)의
  이득도 도메인/환경 의존이며, 능동 탐색이 있는 환경에선 특정 organ의 한계효용이 줄 수 있다.
  즉 P3 null은 organum-국소가 아니라 **"자기개선 이득의 환경-의존성"의 코딩-도메인 실측**으로
  읽힌다 (근거: docs/self-improvement-and-organum.md §4-4). null이 나와도 이 프레임에서 값지다.

**14-4. 2차 파일럿 필수** — 재설계 배터리(tasks_v2.jsonl) + effort DV도 미측정. 2차가 effort
성분의 non-degeneracy·non-saturation·밀도를 confirm한 **뒤에만** freeze (analyze_pilot.effort_nuisance).
confirmatory 직행 금지. freeze 계속 OPEN.

**순서:** ~~effort 추출기 확장~~✓ + ~~v2 태스크 등록~~✓(이 커밋) → 2차 파일럿(쿼타 게이트) →
Ray 밀도/포화/분산 검증 + composite 가중 잠금 → **freeze** → confirmatory 수집.

## 15. Confirmatory 배터리 사전등록 (2026-07-10, Cody — Ray freeze 전 커밋, anti-fishing)

Ray freeze(composite 가중·d_min·N)를 기다리는 동안 confirmatory 배터리를 §14-2 기준으로
확장·커밋한다. **freeze 전 커밋 = cherry-pick 불가 타임스탬프** (2차 파일럿 방향 sanity가
null 쪽이므로 이 규율이 특히 중요 — "map이 돕는 태스크만 골랐다"는 의심을 원천 차단).

- **12 태스크 × 3 arm = 36 blind run** (`tasks_confirmatory.jsonl`). 2×2 셀 균형: 셀당 3태스크
  (unfam=organum, fam=click; explore/modify 각 배분). N=12 task-block/arm 충족(§4 Ray).
- **선정 기준 = §14-2 그대로** (현실적 다중홉 ≥3파일 사슬, 이슈-트래커식 phrasing, 친숙도=
  에이전트-prior proxy). over-anchoring 유발로 선별 안 함 — 정답키는 정답 솔루션이 touch하는
  파일로 실행 **전** 동결(이 커밋).
- **파일럿 태스크(tasks_v2)와 겹치지 않음** — 파일럿 disclosed·confirmatory 재사용 안 함(§12).
- **러너 내구성**: run 단위 flush + `--resume`(완료 (task,arm) 스킵) — 36-run 배치 중단 복구.
  36 멀티턴 세션은 상당 쿼타 → JJ 승인 게이트 유지.
- **freeze 대기 잔여**: Ray의 composite 가중(re-grep drop 여부)·d_min·N 확정 후에만 `--go`.
  가중이 안 정해졌어도 **원자료(성분별 raw count)는 수집 가능** — composite는 분석 시 적용이라
  수집과 직교. 단 freeze 선언 후 수집이 원칙이므로 Ray 신호 대기.

## 16. Ray FREEZE 결정 (2026-07-10, stats 콜) — 2차 파일럿 검증 후

**2차 파일럿(PILOT2-REPORT)이 세 DV-생존 기준을 다 통과 → FREEZE GO.** nuisance만 판독(§12
라벨 존중, 효과판정 아님). 검증: (1) effort 3성분 non-degenerate(re-read sd 1.115, tool_calls
1.291), (2) coverage 탈포화(bare 0.833, 1차 1.0에서), (3) **paired 상관 +0.52 실재**(§8 이점 확인).

**16-1. composite 가중 잠금 = (b) drop `redundant_grep`.** 근거: grep는 A/B/C 전부 0.25±0.43
**arm-간 완전 평탄 = between-arm 신호 0, 노이즈만** → composite S/N 희석. **primary DV =
`z(redundant_re_read) + z(tool_calls_to_completion)`**, 등가중, **arm-across pooled SD 표준화**
(사전선언). 부호: 높을수록 over-anchoring effort↑ (H1: map arm B < 무주입 A). 두 성분 **각각 별도
보고**(composite 블랙박스 방지). coverage는 secondary(탈포화됐으니 별도 추정 DV로 유지).

**16-2. d_min + N 확정.** within-arm sd(re-read ~1.1, tools ~1.2) + paired r=0.52 → paired diff-sd
≈ composite-sd(r=0.5로 unpaired 대비 ~30%↓, ~2× 검정력). **N = 12 task-block/arm 확정** —
§15에서 Cody가 §14-2 anti-fishing 기준으로 **이미 pre-commit한 confirmatory 배터리(12태스크×3
arm=36 run)를 채택**(내 사전선언 12-16 범위 내, 쿼타 의식). **정직한 검정력: paired perm으로
power 0.8 @ d_min ≈ 0.80**(큰 효과). 선택적: 사전선언 상단 **N=16(4태스크 추가, §14-2 기준)이면
d≈0.70까지** 조임 — 쿼타 여유 시 Ray-권고, 아니면 12로 충분(null 방향이라 한계이득 작음).

**16-3. 정직한 null 스코프(§14-3 발동).** N=12는 **큰 효과(d≥0.80)만** 검정력 → composite B−A ≈ 0
이면 "map이 over-anchoring을 **크게** 낮추지 않는다"이지 "효과 0"이 아님. 2차 파일럿의 B−A
(re-read 0.0 / tools +0.5 역방향)는 **null 방향 3번째 신호**(1차 coverage 포화 → 2차 2신호). §14-3
등록 해석 그대로: **over-anchoring은 tier-universal이 아니라 환경-의존일 수 있음**(코딩=능동 탐색
있음). **캐비앗 잠금:** 이 결론은 **commit-bound/능동-탐색 task-class 조건부** — cross-episode
transfer(표상-병목) 태스크엔 미검증. organum 공개 문서는 이 경계를 정직 인용(9-1 확장).

**16-4. C(prose) 이상치 = estimation-only.** 2차서 C가 최저 effort(re-read 0.25 vs A/B 1.25)로
내 §7 "C intermediate" prior와 다름 — N=4라 과독 금지, **estimation-only 등록**. confirmatory서도
C<A,B면 "prose content가 오히려 effort↓"라는 별개 발견으로 라벨.

**16-5. 분석 계획(확정).** primary confirmatory = **B−A on effort_composite, paired/blocked
permutation**(task-block 내 조건 치환) 10k + 가능시 exact + bootstrap CI + LOO. 단일 대비 → 주
분석 Holm 불필요. estimation-only: C−A/C−B(H2), coverage(secondary), binary 성공(descriptive),
성분별 raw. 경계 subgroup(§4 셀)은 사전지정 non-confirmatory 층화.

**FREEZE 선언.** composite·d_min·N·honest-null·C-estimation 잠금 → **confirmatory 수집 `--go` 승인**
(§15 배터리, JJ 쿼타 게이트는 유지). 파일럿 1·2 disclosed, confirmatory 재사용 안 함. 데이터 안 본
상태 freeze.

## 16b. budget-abort disclosure 처리 (2026-07-10, Ray — freeze 유지, DV 재라벨)

Cody 정직 disclosure(PILOT2-REPORT "⚠ 정정"): 파일럿2 12run + confirmatory chunk1 9run이 **전부
`error_max_budget_usd`로 $1 캡에서 abort** — `tool_calls_to_completion`은 실은 "budget-abort까지".
**결정 = (A) within-budget DV 확인, freeze 유지, 재개.** (B) 캡 상향+재-freeze는 **9/36 peek 후
설계 변경(forking-paths)**이라 validity가 깨졌을 때만 정당한데 안 깨졌음(아래) → 기각.

- **freeze 여전히 유효**: 파일럿2도 $1 캡이었으므로 내가 §16에서 검증한 non-degeneracy/밀도/분산은
  **이미 within-$1 분포**다. abort subtype을 이제 안다고 그 수치는 불변 → 재검증 불요.
- **16b-1. DV 재라벨(정직):** `tool_calls_to_completion` → **`tool_calls_within_budget`** (우측
  censored @ $1). composite 성분명·정의를 이 라벨로 정정(§14-1/§16-1의 그 성분).
- **16b-2. censoring caveat(등록):** effort DV는 균일 **우측-censored @ $1.** null 해석 = "**within-$1**
  over-anchoring 감소 없음"이지 "$1 너머 없음"이 아님. **validity 체크:** primary 셀(unfam×explore)은
  chunk1 9run 중 **8/9가 coverage=1.0을 예산 내 도달**(탐색 완료) → over-anchoring-during-exploration
  신호 온전 관측, **primary null은 진짜**(censoring 아티팩트 아님). 단 modify 셀은 debug-phase
  재읽기가 truncate될 수 있어 → **modify effort는 하한으로 해석**, coverage<1.0 run은 censored로 표시.
- **16b-3. 메타데이터 보강(설계 변경 아님, additive):** run당 `abort_subtype`(budget|complete) +
  `coverage_at_abort`(=1.0 도달 전 abort 여부) 로깅(results_v2 누락 보정). 분석 때 censoring 정량화용.
  **DV·composite·d_min·N·freeze 전부 불변, 로깅만 보강.**
- **16b-4. null 신호 갱신:** chunk1 re-read=0 across all 9(explore) = §14-3 환경-의존 null의 4번째
  신호. modify 셀에서도 coverage=1.0에서 re-read≈0이면 null 견고; modify가 coverage<1.0로
  truncate되면 censoring 플래그(하한 해석).

**진행:** 위 3보정(특히 메타데이터 로깅) 반영해 **9/36부터 재개**($1/run 유지). 재-freeze 불요.
