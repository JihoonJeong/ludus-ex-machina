# graphify loadout-변주 v0 — 결과: **격리 (treatment-delivery 실패)**

*2026-07-27. 상태: **QUARANTINED** — organ 효과 주장에 사용 금지. 이 문서는 실패한
실험의 정직한 기록이자, loadout 대조 프로토콜에 새 항체를 남긴다.*

## 무슨 일이 있었나

16-run 매트릭스(2 arm × 8 task, Solar Open2, counterbalance)는 계획대로 완주했고
숫자도 나왔다 — graphify arm 입력 −21.8%·요청 −11.6%, gate 8/8(bare) vs 5/8(graphify).

그러나 organum-code의 사후 ACP telemetry 진단(diag1, 커밋 `319f69a`)이 밝힌 사실:
**graphify arm에 Graphify MCP 툴이 실제로는 노출되지 않았다** — available tools에 부재,
호출 네임스페이스 전부 `grok_build`, Graphify MCP 호출 0. 추정 원인: `graphify-mcp`가
uv tools 경로(admitted containment 가독 루트 밖)로 해석 / stdio MCP descriptor 미승인.

즉 두 arm은 사실상 같은 조건이었고, 관측된 차이는 **run 분산 + 미상 요인**이다.
재현 진단에서 T1/T2는 양 arm 모두 통과, T4는 양 arm 모두 실패 — 원래 arm 차이가
안정 효과가 아니었음을 보강한다.

## 격리 판정

- 이 16 run은 **loadout 대조 증거가 아니다** — 선언된 loadout(graphify)이 전달되지 않았다.
- warren `.organum`의 해당 세션 선언(gfx-graphify-t\*의 `loadout=["graphify"]`)은 **의도
  기록이지 사실이 아니다** — 캐노니컬 상태에 이 run들의 reported ingest를 하지 않는다
  (거짓 축 데이터를 알고 쓰는 것 금지). raw ledger(run/v0)·재-emit(observation/v1)·answers·
  진단 telemetry는 warren `observations/`에 실패-전달 증거로 보존.
- usage/gate 수치는 "그 라벨의 run들에서 사실"이나 Graphify에 귀속 불가.

## 항체 (organ-effect-matrix 프로토콜 개정 사항)

**"loadout 선언 ≠ loadout 전달."** 대조 실험은 arm 차이를 해석하기 **전에**
**treatment-delivery 증거**를 게이트로 요구해야 한다:

1. **가시성**: 해당 organ이 run의 가용 도구 목록에 실재했다는 telemetry (예: ACP
   `available_commands_update`).
2. **최소 노출**: organ 호출 ≥1 관측 — 0이면 그 run은 "노출 없음"으로 별도 라벨
   (사용 안 함=결과일 수 있으나, 가시성 없음=treatment 실패).
3. 이 게이트를 통과 못 한 run은 대조에서 격리 — joint_observed처럼 **필드로** 강제할 것
   (후속: observation/v1.x에 organ-delivery 증거 필드 논의, 또는 러너 사전 게이트).

이는 R3의 treatment contamination(stale cursor), P3의 환경-의존에 이은 세 번째 측정
항체다. organum-code가 자기 telemetry로 잡아 자기 결과를 스스로 격리 요청한 것 —
정직 문화의 실물.

## 다음

organum-code가 MCP 가시성 + 쿼리 1회를 qualification으로 실증한 뒤 대체 비교를 다시
돈다(별도 JJ_GO). 그때 delivery 게이트를 선등록 조건으로 포함한다.

## 참조

- 원 결과 편지: `_relay/20260727-…-graphify-matrix-complete.md`
- 격리 요청(그쪽 발신): `_relay/20260727-…-graphify-adoption-correction.md`
- 재-emit 16(observation/v1, 유효 검증 0 invalid): warren
  `observations/graphify-loadout-observation-v1/` — 격리 상태로 보존(비-ingest)
- 과제 세트·gate: `docs/graphify-loadout-tasks-v0.md`·`scripts/graphify_task_gate.py`
  (재사용 — 과제 자체는 유효, gate 재판정 일치 확인됨)
