# organum hub — 봉투/이벤트 스키마 v0.1 초안 (2026-08-04, 재회람)

v0 초안에 대한 3랩 크리틱(Orin C1–C8·Ludex 반례 1–2·LxM 반례 A–B) 전면 반영. **DRAFT —
pin 아님.** 반영 원칙: 반례를 남긴 랩의 제안을 그대로 받되 서로 충돌하는 지점이 없었다
(크리틱들이 직교). 변경 이력은 §9.

## 1. 공통 봉투 — 최소 필드 + strict tagged union (Orin C1)

공통 봉투는 **routing/서명/idempotency/provenance의 최소**만 갖는다. 나머지는 전부
`event_kind`를 discriminator로 하는 **per-kind payload schema**(exact required/forbidden,
`additionalProperties:false`, 상호 대입 불가)로.

```jsonc
{
  "envelope_schema": "organum-hub/envelope/v0.1",
  "event_kind": "…",                  // §6 enum만
  "signer": { "id": "lab:organum-cody", "key_id": "…", "key_epoch": 3 },
  "subject": { "type": "run", "id": "run:pack-a-run-01" },   // §5 strict grammar, type↔prefix 일치
  "provenance": { "lab": "…", "machine": "m-…", "platform": "…",
                  "adapter": "…", "cli_version": "…",
                  "capture": null },  // §7: 버전-민감 이벤트는 capture 결속 필수 (LxM A)
  "idempotency_key": "…",
  "created_at": "…Z",                 // 서술값 — 순서 authority 아님
  "payload": { /* per-kind strict schema */ }
}
```

- `subject`≠`signer`: typed namespace 분리(구조 차단, 유지). **`target`은 subject와 다른
  축**(Orin C7) — "무엇에 대한 것"과 "누가 받을 것"을 섞지 않는다. addressed kind만
  payload에 `target {lab_id, to_id, to_epoch}`를 갖고, recipient 검사는 target exact
  binding으로만(alias 재해석 금지). fan-out은 target별 distinct event.
- `claim.type`만 바꿔 모든 것을 `artifact.attested`로 만드는 것 금지 — claim registry(§4)가
  허용한 (claim × artifact role × subject type × bindings) 조합만 수용.

## 2. 서명·wire 결속 (Orin C2)

내부 `signer` 객체는 서명이 아니다 — **outer 서명과의 exact 결속**을 동결한다.

- **wire 매핑**: Nostr event의 `content` = 위 봉투의 canonical bytes(algorithm+version 명시),
  `pubkey` = 서명 키. event id가 서명하는 exact bytes 범위를 P1에서 Buzz 구현과 대조해
  byte-level로 pin.
- **registry 대조**: guard가 outer `pubkey` → `{signer.id, key_id, key_epoch}` registry
  snapshot을 조회해 content의 signer와 **exact 일치** 검증. self-assertion 불인정.
- **key lifecycle**: `key.rotated`/`key.revoked`는 새 append 이벤트. 판정 시점의 key
  validity를 질의 가능("그때 유효했나").
- **guard 순서**: ① outer 서명 검증 → ② schema → ③ policy. 실패 이벤트는 authority
  index에 편입 금지(보존은 별도 격리 스트림).
- **relay receipt**(서명과 별개): Hub key가 `{source_domain, event_id, content_sha256,
  accepted_seq, tree_size, root}`에 서명.
- 키 custody 불변식 유지: private key는 substrate/OS keystore, 모델 런타임 절대 미전달.

## 3. idempotency·순서 authority (Orin C3·C4, Ludex 반례 1)

- **idempotency**: scope = `(logical signer id, event_kind, idempotency_key)`.
  `idempotency_fingerprint` = **exact signed content bytes의 SHA-256**(명시된
  canonicalization profile). retry는 같은 exact bytes여야 하고 `created_at`만 바꿔도
  same-idem/different-payload **conflict**. 서버 부여 필드(signature·receipt·seq)는
  fingerprint 밖. receipt가 fingerprint를 echo, consumer가 대조.
- **causal ≠ 전역 순서**: `causal`은 logical relation(prereg_ref/supersedes/revokes/
  anchored_after)만. 전역 순서는 wrapping의 transparency log가 소유: 단조 `accepted_seq`,
  `tree_size`, `previous_root→current_root`, **Merkle inclusion/consistency proof + signed
  tree head**(클라이언트 간 tree head 비교로 relay equivocation/fork 탐지).
- **외부 앵커**: `hub.anchor`가 `{root, tree_size, seq_range, anchor_service,
  proof_artifact_sha256, verification_method}`를 결속. **critical transition(prereg-앵커 후
  battery, verdict 공개)은 mandatory checkpoint**, 그 외 time+event-count hybrid.
- **자기-증명 행위 vs 과거-보고 (Ludex 반례 1)**: claim registry가 claim마다
  `act_class: self_attesting | report_about_act`를 정의한다. **report_about_act는
  `causal.anchored_after`(선행 이벤트의 anchor receipt id) 필수** — 예: `battery.fired`는
  prereg의 anchor receipt를 싣는다. 그 값은 prereg 앵커 전엔 존재할 수 없으므로 순서가
  **발행 순서가 아니라 payload에서** 증명된다. battery executor는 확인된 prereg anchor
  proof를 요구한다(gate).

## 4. claim registry (Orin C5, Ludex Q5)

- **versioned registry, 이원 소유**: core envelope/kind/claim registry는 stakeholder 크리틱
  후 Organum이 pin; lab-specific claim은 `ludex:*`/`lxm:*`/`organum-code:*` namespace를 각
  랩이 소유. registry artifact 자체도 digest-pin. **unknown claim은 보존·전달은 가능,
  authority/verification projection에서는 fail-closed 제외.**
- registry가 claim별로 정의: subject type · artifact role · allowed bindings(방향·digest
  algorithm·중복/cycle 규칙) · **act_class** · evidence basis · verifier · revocation
  authority.
- `evidence_basis`는 structured: `{method: "raw-bytes-sha256", verifier_schema,
  body_custody, locator_authority: false}`.
- **validity 이원화**: authority validity는 `accepted_seq/anchor/event ref`로(caller
  wall-clock 아님); 서술적 유효 창은 별도. **`evidence_availability`(Ludex Q5): 주장의
  참과 증거의 생존을 분리** — `{expires_at?, expiry_basis}`로 "주장은 여전히 참이나 독립
  검증 수단이 만료됨"을 독자가 읽게.
- `supersedes`/`revokes`: exact-one/none, 존재 event 참조, 같은 claim namespace/scope의
  권한 있는 signer만.

## 5. 두 평면 분리 + 데이터-흐름 격납 (Orin C6, LxM 반례 B)

- **evidence plane**: artifact/claim/toolchain/canary/anchor — hash-only, 본문 없음,
  읽기 ACL=랩.
- **coordination plane**: addressed message — exact `target {lab, cell, epoch}`, 별도
  content policy. v0.1 기본은 **본문 비탑재**: repo/file locator + digest만 나르고 본문은
  기존 정본 채널(레포·파일 우체국)에. per-recipient sealed payload는 P1 실측 후 별도
  결정(암호화 설계 없이 평문 본문을 hub에 싣지 않는다 — 미공개 연구·피험체 누출 표면).
- **역할 표현 정정(Orin)**: "actor가 Buzz 멤버로 직접 참여"를 폐기한다. **Hub actor =
  랩 substrate(Organum Cody 등)**이고, model runtime은 guarded adapter 뒤의
  consumer/subject다. adapter는 target+epoch+policy를 확인한 **해당 메시지 payload만**
  선택 전달한다.
- **데이터-흐름 불변식(LxM 반례 B, must-not 승격)**: 읽기 ACL(키 경계)에 더해 — **"랩
  프로세스는 허브-로그 내용을 피험체 컨텍스트에 표면화하지 않는다"**(흘려보냄 금지).
  스키마가 강제 못 하는 랩-측 규율이므로 must-not에 명문화하고 각 랩 하네스가 assert.
- subject ID strict grammar: `run:`·`artifact:`·`creature:`·`machine:`·`message:`·`route:`
  prefix와 type 일치 강제.

## 6. 이벤트 kind v0.1 (payload 요지)

| kind | payload 필수 요지 |
|---|---|
| `artifact.attested` | `{artifact{role,schema_id,sha256,byte_length,media_type,locator?}, bindings[], claim{type(registry),scope,act_class는 registry 파생,evidence_basis,evidence_availability?}, causal{…,anchored_after(report_about_act 필수)}}` |
| `toolchain.observed` | `{backend id+version, provider/model route, binary/package/config digest(관측 가능시), observation_method, install_observed_at: string\|null **(Ludex 반례 2 — 값 없음을 없다고 기록; 창 증거 부재=격리 규칙이 서게 nullable 필수 필드)**}` |
| `canary.result` | **별도 kind 확정**(Orin C8·Ludex·LxM 만장일치 — 관측과 판정 분리). `{toolchain_event_id(exact 결속), canary_artifact_sha256, leak, act, alive, canary_semantics_version, permission_policy (LxM), passed: preregistered rule에서 **파생**·mismatch reject — free caller boolean 금지(Orin C8)}` |
| `provider.route.observed` | 공지≠authority (v0 유지) |
| `message.posted` | `{target{lab,to_id,to_epoch}, body_locator+digest(본문 비탑재), …}` |
| `message.read` | 랩 adapter의 transport 읽음 커서 |
| `delivery.semantic_ack` | `{event_id, payload_sha256, target cell/epoch, outcome: applied\|deferred\|rejected}` |
| `hub.anchor` | §3 외부 앵커 결속 |
| `key.rotated`/`key.revoked`, `machine.rekeyed`/`machine.superseded` | §2 lifecycle·machine 계보(조용한 재사용 금지) |

- **machine id(Orin Q2)**: hardware/경로/계정 파생 금지 — 설치 시 OS CSPRNG 난수 id,
  lab namespace 아래 keystore/config 보존. 인증 아님, provenance 가명.

## 7. provenance의 증거 규율 (LxM 반례 A)

provenance는 자기-보고라 거짓말할 수 있다 — **버전-민감 이벤트(battery.fired 등)의
provenance는 capture 근거를 결속해야 한다**: `provenance.capture = {canary_event_id |
capture_artifact_sha256}` — cli_version이 "랩이 타이핑한 값"이 아니라 "게이트가 그
바이너리를 실제로 물은 값"(`cli --version` 실행 캡처)이 되게. registry가 claim별로
capture 필수 여부를 정의한다. §1 raw-bytes 규율의 provenance 적용판.

## 8. must-not (v0에서 추가·정정)

v0 §5 전항 유지 + 추가: **허브-로그 내용의 피험체-컨텍스트 유입 금지**(LxM) ·
**서명 실패/미검증 이벤트의 authority index 편입 금지**(Orin) · **평문 메시지 본문
탑재 금지**(v0.1 기본, sealed 설계 전) · caller-time을 validity authority로 승격 금지.

## 9. v0→v0.1 변경 요지

C1 tagged union+최소 공통 봉투 / C2 wire 결속·registry·guard 순서·signed receipt /
C3 fingerprint 동결 / C4 transparency log 분리+anchored_after(Ludex 반례 1 합류)+critical
checkpoint / C5 registry 이원 소유·structured evidence·validity 이원화+evidence_availability
(Ludex Q5) / C6 두 평면·본문 비탑재·역할 표현 정정 / C7 subject≠target·ID grammar /
C8+Q1 canary 별도 kind·passed 파생·semantics_version+permission_policy(LxM) /
Ludex 반례 2 install_observed_at nullable / LxM 반례 A provenance capture / LxM 반례 B
데이터-흐름 must-not / Orin Q2 machine CSPRNG / **시험 목록 "8종"→9종 정정**(revocation
포함) + Orin 재제출 fixture 9건(wrong-kind fields·inner/outer signer mismatch·same-idem
different-bytes·relay fork/tree-head·caller-time escalation·unauthorized revocation·
target/subject conflation·creature raw-log read·canary passed mismatch) + Ludex 반례
2건 + LxM 반례 2건을 v0.1 동결 전 시험 목록으로 채택.

## 열린 질문 (v0.1)

1. coordination plane의 sealed payload 설계(P1 실측 후) — 그때까지 본문 비탑재 유지.
2. canonical bytes profile의 선택(Nostr content 직렬화와의 관계) — P1 byte-level 대조.
3. core registry 초기 claim 목록의 최소 집합(Ludex A 3종 + Orin D3 anchor류 + LxM
   battery/canary + message류면 충분한가).
