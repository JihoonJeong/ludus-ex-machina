# Anthropic Fable 5 cost-optimization 패턴 ↔ organum (참조)

*2026-07-24. 출처: Anthropic Fable 5 cost-optimization 웨비나 요약
(modernweblabs.com/ko/insights/anthropic-webinar-fable5-cost-optimization). 모델 벤더 자신이
**모델 이질성 + 역할-적합 배치 + 트랜스크립트-기반 측정**을 공식 권고 — organum 명제의 외부 검증.
이 문서 = 웨비나 패턴을 organum의 enable/measure 층에 매핑한 참조. 경계: 여기 패턴은 전부 **actor
층**이고 organum은 그 아래·옆(substrate+측정)이다.*

## 웨비나 핵심

**핵심 논제**: "잘 쓰는 조직은 Fable 5를 모든 곳에 쓰지 않는다." 구조화된 접근으로 **Fable 5 성능의
92%를 63% 비용에**(Advisor) / **96%를 46% 비용에**(Orchestrator) 달성.

### 두 프로덕션 패턴 (actor 층)

| 패턴 | 구조 | 규칙 | 결과 | 적합 |
|---|---|---|---|---|
| **Advisor** | Sonnet 5 실행, Fable 5는 막힐 때 자문 툴로 호출 | 비싼 토큰을 고난도 순간에만 | SWE-bench Pro 92%@63% | 순차 작업 |
| **Orchestrator** | Fable 5가 분해, 싼 모델(Sonnet/Haiku)이 병렬 실행 | **자체 툴 없음**(bash/MCP/실행 툴 미부여 → 스스로 안 하고 위임) | BrowseComp 96%@46% | fan-out·독립 서브태스크 |

선택 기준: **"일이 서로를 필요로 하지 않는 조각들로 쪼개지는가"** — 순차→Advisor, 병렬→Orchestrator.

### 네 기초 기법 (패턴보다 우선순위 높음)

1. **Prompt caching** — 캐시 적중 입력 토큰 **90% 할인**. 상위 고객 90%+ 적중률. 이 하나로
   "감당 불가"→"가능"으로 전환.
2. **Effort dial** — 모델 바꾸기 *전에* `output_config.effort`(low→max) 조정. 반직관: Fable 5
   low effort가 Sonnet high effort보다 쌀 때 있음(우월 모델이 더 적은 시도로 해결).
3. **Batch API** — 비실시간 작업 **50% 할인**, prompt caching과 곱연산 복리.
4. **Spend controls & task budgets** — 격리 실험 워크스페이스 + 지출 한도 + 태스크 예산으로
   runaway 방지.

**가격(2026-07)**: Fable 5 $10/$50 · Opus 4.8 $5/$25 · Sonnet 5 $3/$15(8/31까지 $2/$10) ·
Haiku 4.5 $1/$5. Fable 5 = Sonnet 3배 → 선택적 배치 필수.

**2주 로드맵**: 3-5 대표 태스크 선정 → 트랜스크립트 수동+Claude 분석(실패 패턴) → **모델별
baseline**(Haiku/Sonnet/low-Fable5/high-Opus) → Advisor/Orchestrator 구현 → shadow/A/B 검증.
**"트랜스크립트를 읽지 않으면 개선도 없다."**

## organum 매핑

### 검증됨 (벤더가 우리 명제 공인)

| 웨비나 | organum |
|---|---|
| "모든 곳에 Fable 5 쓰지 않는다" | **mission** — 이질성·경제성·"약한 친구도 제 몫" |
| "트랜스크립트 안 읽으면 개선 없다" | **inspector/observatory 존재이유**. 로드맵(트랜스크립트→모델 baseline→비용-성능) = observatory `--by model` + bench + inspector |
| Orchestrator "자체 툴 없음" | **harness>weights / RFP** — 하네스가 tool provisioning으로 조율 규율 강제(organum-code가 하는 것) |
| Effort dial(모델 전 effort) | **effort typed directive**(organum 정책·organum-code 작동), measurement phase 2 |
| Task budgets + 격리 워크스페이스 | measurement replay($1 cap·JJ_GO)·p3($1/run)·`actor-dogfood-safety.md` |
| Prompt caching #1 레버 | observatory가 **cache_read 이미 측정**(replay 71,824). wren.wtf cache-thrash와 연결 → 캐시효율=하네스 품질 지표 |

### 기회 (organum이 채울 것 — 측정층)

1. **비용최적화 패턴의 계측**: Advisor/Orchestrator 비용+성과 귀속, **하네스별 캐시효율**
   (cache_read/total = harness-lift의 측정가능 비용축), effort×cost×outcome. 제품 각도:
   "패턴 채택했다 → 먹히는 증거 데이터."
2. **role/loadout이 패턴 표현**: orchestrator loadout = 실행 organ 없음("no tools"), advisor =
   에스컬레이션 대상. organ-effect-matrix + 에스컬레이션 primitive를 벤더-공인 패턴에 연결.
   organum *정의·측정* / organum-code *강제·작동*.
3. **Advisor ≈ 에스컬레이션 primitive**: 싼 모델 실행→막히면 advisor 호출 = worker→advisor 셀
   에스컬레이션(escalate:true, 이미 채널 있음) → 코디네이션으로 표현·측정.

### ⚠ 경계 (재확인)

**Orchestrator는 문자 그대로 orchestrator**(분해·디스패치) → **organum이 구현하면 헌법 위반**
(coordination-architecture-principle). 이 패턴들은 **actor 층**(organum-code/하네스)에 살고, organum은
그 아래·옆에서 **enable(role/loadout/채널) + measure(비용/성과/귀속)**만. 웨비나가 정의한 게 전부
actor-층 패턴이라 오히려 **actor/substrate 분리가 옳음을 재확인** — vendor-neutral 측정층은 여전히 빔.

### 니치 안전성

웨비나는 **단일 벤더(Anthropic)** 패턴. organum 해자 = **크로스-벤더·크로스-하네스** 측정 +
teammate-fitness + 조율 substrate. 벤더가 방향 검증했으나 니치 미침식 — "이 워크플로를 이종 하네스에
걸쳐 돌리는 도구"로 포지셔닝 근거.

## 근시일 함의

- **effort-directive + 캐시효율 측정** = 벤더-검증 고가치 → harness-lift/measurement 재개 시 우선 ↑
- dogfood budget-cap = Anthropic "task budgets"와 정합(방법론 이미 맞음)
- 포지셔닝: Anthropic 공식이 heterogeneity·경제성·"read transcripts" 승인 = organum 명제의 시장 정당성
