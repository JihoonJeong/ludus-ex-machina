# hub 봉투 v0.2 기준 구현 — P1 byte-level 증거 현황 (2026-08-15, r6)

v0.2 design freeze candidate(3/3) 다음 단계는 "P1 byte-level 증거 → final critic → 최종
pin"이다(Orin 조건). 이 문서는 그 증거 중 **Buzz 인스턴스 없이 세울 수 있는 전부**를
기준 구현으로 세운 현황이다. 산출물 먼저 — 스펙 산문이 아니라 실행 가능한 코드와 그
fail-closed 회귀가 증거다.

**r2**: Orin final critic(BOUNDED REVISE, 2026-08-15)의 B1–B5 반영. frozen 계약과 달랐던
동작 3건(retry 비수렴·unknown claim 과잉거부·receipt 부재)과 fail-open/crash 2건
(validator 타입 예외 이탈·registry enum/digest fail-open)을 닫았다. §B1–B5와 §UNPROVEN 참조.

**r3**: LxM final critic **반례 C** 반영 — 버전 결속이 형식뿐이던 것을 두 층으로 올렸다.
① 스키마: `provenance.cli_version`은 자유 문자열이 아니라 null | `{value,
capture_artifact_sha256}` — 주소 없는 버전 주장 불가(결정 3 처방의 확장). ② 정책:
같은 capture digest가 서로 다른 값(버전·관측시각)을 낳으면 **capture 모순 conflict**
(idem conflict와 같은 층 — index 내부 정보만으로 판정되는 내적 정합. 한 봉투 안
자기모순·교차 필드·격리 이벤트 비등록까지 회귀). 재현 ①(지어낸 값 + 형식상 완전한
결속)은 봉투 층에서 원리적으로 못 막는 정직 경계로 **admitted를 회귀로 pin**했다 —
값↔bytes 대조는 §UNPROVEN의 capture artifact resolver 몫. LxM이 잠가달라 한
`assert_source_allowlist` 검사 순서(plane 검사가 멤버십보다 먼저 — allowlist 설정
오류로 plane:*가 들어가도 통과 불가)도 회귀로 고정.

**r4**: Orin r3 재판정(B1·B2·B3·B5·반례 C ACCEPT / 2-correction HOLD)의 **C1·C2** +
LxM **반례 D** 반영.
- **C1**: 오염 검사가 append **뒤**라 미수용 candidate bytes가 tree에 들어가고 재시도마다
  자랐다 → 검사를 append **앞**으로. 오염 상태에서 candidate 미수용·tree 불변·반복 시도
  불변을 회귀로 고정. **원자성 경계 명시**: 이 기준 구현은 single-writer·in-memory
  원자성만 보장한다 — 실 relay 저장소의 concurrent transaction/CAS는 P1 wire/storage 잔여.
- **C2**: revocation이 frozen §4의 "같은 claim namespace/scope" 결속을 안 봤다 → target은
  authority-projected `artifact.attested`여야 하고, namespace 일치 → scope exact 일치 →
  발행 signer 일치 순서로 검사. 음성 3(cross-scope·non-claim target·cross-namespace) +
  양성 1 회귀.
- **반례 D**: payload 스칼라가 미검증인데 r3부터 capture 맵에 권위를 세웠다 — 빈 값이
  먼저 오면 정직한 주장이 영구 봉쇄(first-writer-wins·unwind 없음). 제안 1(값 검증:
  backend_version 등 비어있지 않은 str·binary_digest hex64)과 제안 2(등록 자격 규약:
  schema 통과 admitted 값만) 구현. 제안 3(unwind)은 **결정을 문서에 박음**: 현
  first-writer-wins는 의도가 아니라 한계다 — frozen §4 revocation이 claim event만
  대상이라(C2) 관측 이벤트의 값 주장을 내릴 스펙 경로가 없다. unwind 설계는 dispute
  claim type과 같은 슬롯(방향: 원 signer만 자기 주장을 내린다). LxM 재현 스크립트를
  수정 후 재실행해 봉쇄원 사멸·정직 기록 성립을 확인.

**r5** (Orin LOCAL REFERENCE FINAL ACCEPT `84bd91d` **직후** — 교차 도착): LxM **반례
D-2** — 형제 맵 `_capture_install_times`의 값(`observed_at`)이 같은 구멍(null/12345/""/
"아무말" 전부 admitted → 빈 시각 선점 봉쇄). 처방을 그대로 받았다 — **"필드를 쫓지 말고
등록 지점에서 불변식으로"**: ① 스키마 — observed_at은 created_at 선례대로 RFC3339-Z 모양
강제. ② 구조 — collector(`_*_claims_of`)가 값을 내놓는 지점에서 `_eligible` 자격 불변식
(digest hex64·버전=비어있지 않은 str·시각=RFC3339-Z)을 예외로 강제. 스키마가 구멍이어도
정책 단계 quarantine으로 닫히고, **새 맵을 추가하며 검증을 잊으면 그 kind의 모든 봉투가
시끄럽게 죽는다** — D류 재발을 구조가 막는다. FINAL ACCEPT 경계 안의 국소 수정이며 Orin
delta ack 요청.

**r6** (Orin r5 delta HOLD 교정): 내 "RFC3339-Z"가 이름뿐이었다 — predicate가
`endswith("Z")` 하나라 `"아무말Z"`·`"2026-99-99T99:99:99Z"`가 통과해 맵을 선점했다.
shared predicate `_is_rfc3339_z`(regex lexical pin + strptime 달력 검증; fractional
seconds 허용·offset/leap second 미허용)를 **schema(created_at·observed_at)와 collector
불변식(_eligible)이 함께** 쓴다 — 규칙의 이름과 구현 일치. Orin 최소 회귀 전부:
accept 2종·reject 8종(suffix bypass·불가 달력·불가 시각·offset)·invalid-Z 선점 뒤
정상 시각 성립+tree 비오염·_eligible 직접 타격·created_at 동일 helper.

## 구현 (신규 3 모듈 + 회귀 3 파일)

| 모듈 | 내용 |
|---|---|
| `src/organum/hub_envelope.py` | canonical bytes profile v1 · 봉투/kind strict 스키마 · guard(서명→스키마→정책) · idempotency · claim registry · role/plane 격납 |
| `src/organum/hub_log.py` | RFC 6962형 Merkle transparency log — inclusion/consistency proof 생성·검증 · signed tree head · fork/equivocation 탐지 |
| `src/organum/schnorr_pure.py` | BIP-340 secp256k1(Nostr 서명 곡선) 순수 참조 구현 |

회귀 100본(봉투 85·log 10·schnorr 5): negative fixture 17종 + B1–B5 + C1·C2 + 반례 C·D·D-2 + RFC3339 + Merkle 전수
속성검사(1..32 전 사이즈의 전 (index,size)·(old,new) 쌍) + 변조/위조 거부.

## Orin 증거 목록 대비 현황

| 증거 항목 | 상태 |
|---|---|
| canonical bytes fixture | **섰다** — profile v1(정렬·압축·UTF-8·float 금지·2^53·surrogate 금지·ASCII key·깊이 64) + 비canonical bytes는 서명이 맞아도 거부 + 타입 혼동 배터리(B3) |
| signer binding | **섰다** — outer pubkey → key registry → 내부 signer exact 일치; self-assertion·revoked key·타 랩 키 전부 거부 |
| idem round trip | **섰다** — fingerprint = exact signed bytes SHA-256; created_at만 바꿔도 conflict; byte-identical 재전송은 **최초 결과로 수렴**(B1, `duplicate: true`) |
| Merkle/tree-head 반례 | **섰다** — equivocation·append-only 위반·미검증 head는 판정 불능(null — false≠null) |
| negative fixture 17 fail-closed | **섰다** — 아래 매핑표 |
| admission↔log↔receipt 조립(seam ④) | **섰다(r2)** — exact-once append·seq=index+1·signed relay receipt·e2e 회귀 |
| claim registry 의미론 | **부분** — act_class/ordering/subject/capture/revocation(same_signer)/enum 잠금은 섰다; **artifact role·allowed bindings(방향·cycle)·evidence_basis verifier 실행·evidence_availability 소비는 UNPROVEN**(§UNPROVEN) |
| seam 대조 | **로컬 4 이음매 완료** — relay와의 wire 이음매는 P1 잔여 |

### negative fixture 17 매핑

| # | 출처 | 시험 | 층 |
|---|---|---|---|
| 1 | Orin | wrong-kind fields | schema |
| 2 | Orin | inner/outer signer mismatch (+미등록 pubkey) | policy |
| 3 | Orin | same-idem different-bytes | policy |
| 4 | Orin | relay fork/tree-head equivocation (+append-only 위반·미검증 head=null) | log |
| 5 | Orin | caller-time escalation (window basis=wall_clock) | schema |
| 6 | Orin | unauthorized revocation | policy |
| 7 | Orin | target/subject conflation | schema |
| 8 | Orin | creature에 Hub-유래 payload(coordination 포함) 금지 | role |
| 9 | Orin | canary passed mismatch (rule 재도출 ≠ 기재) | policy |
| 10 | Ludex 반례 1 | report_about_act에 anchored_after 부재 | policy |
| 11 | Ludex 반례 2 | install_observed_at 값 지어내기 (capture 결속 없음) | schema |
| 12 | LxM 반례 A | capture-required claim에 provenance.capture=null | policy |
| 13 | LxM 반례 B | hub plane 소스의 피험체 allowlist 유입 (구조적 assert) | role |
| 14 | Orin Δ5 | gate 아닌 ref로 completed / 사전-발사 gate 부재 | policy |
| 15 | Orin Δ5 | canary self-reference · 자유 문자열 semantics | schema+policy |
| 16 | Orin Δ5 | measured_creature에 evidence-plane admission | role |
| 17 | Ludex 반례 3 | 게이트 산물(canary)이 prereg 앵커보다 이른 bracketed gate | policy |

17번의 짝 회귀: 같은 구조라도 `attests_ordering_of: emission`으로는 admitted —
라벨이 사실을 과장하지 않으면 통과한다(Δ2의 정직 라벨이 실제로 작동).

### seam — 4 이음매 (Orin 확인 완료, ④ 교정)

1. **canonical bytes ↔ 서명 입력**: 서명은 canonical bytes의 SHA-256에 대해서만;
   논리 동일·bytes 다른 직렬화는 서명이 유효해도 schema 층에서 거부. (확인됨)
2. **inner signer ↔ outer pubkey**: registry snapshot 경유 exact 3-tuple 일치. (확인됨)
3. **envelope bytes ↔ idem fingerprint**: 서버 부여 필드는 봉투 밖 — fingerprint에
   들어올 수 없는 구조. (확인됨)
4. **admission result/receipt ↔ exact log append/index/tree head** (Orin 교정 — 내 재구성
   "event bytes↔leaf hash"는 이것의 절반이었다): admitted canonical bytes만 exact-once
   append · `accepted_seq == leaf_index + 1` · signed relay receipt
   `{source_domain, event_id, content_sha256, idempotency_fingerprint, accepted_seq,
   tree_size, root}`가 그 append와 한 원자적 결과. reject/quarantine/retry는 tree 불변.
   log가 admission 밖에서 전진하면 다음 admit이 결속 위반으로 멈춘다. (r2에서 조립)

### B1–B5 반영 (Orin final critic r1 → r2)

| # | 지적 | 반영 |
|---|---|---|
| B1 | exact retry가 새 seq로 재수용(수렴 위반) | idem entry가 최초 결과를 보존, retry는 `duplicate: true`로 동일 event_id/seq/receipt 반환 — seq·log·receipt 전부 불변 |
| B2 | unknown claim의 transport/authority 합체 거부(frozen §4 위반) | `admitted=true` + `authority_projected=false` + `reason=unknown_claim` 분리. authority ref 조회(`authority()`)는 projected만 인정 |
| B3 | `subject.type=[]` → TypeError 이탈 | validator 예외를 ingress에서 schema/policy quarantine으로 폐쇄 + 타입 혼동 배터리 11종 회귀 |
| B4 | admission↔log↔receipt 미조립·서명 receipt 부재 | HubIndex가 log를 결속(seq=index+1 불변식, 외부 전진 탐지), signed relay receipt v1 발행 + `verify_relay_receipt` + e2e 회귀(inclusion proof까지) |
| B5 | registry enum·pinned digest fail-open | `revocation_authority`는 구현 enum(`same_signer`)만 ctor 수용 · ordering/subject/capture enum 잠금 · permission policy digest는 **등록·해석 가능해야** canary 통과 |

## UNPROVEN — 동결 문안이 요구하나 이 기준 구현이 아직 집행하지 않는 의미론

Orin 지적대로 **정직 강등**한다. 구현되기 전까지 아래는 "섰다"가 아니라 UNPROVEN이며,
final pin 전에 구현 또는 scope 재합의가 필요하다.

- **Δ3 cli_version 파생(값↔bytes)**: r3에서 버전 주장은 **주소 필수**(어느 capture에서
  왔는지)가 됐고 같은 capture의 **모순 주장은 거부**되지만, 기재된 값이 실제로 그 capture
  bytes에서 나왔는지는 여전히 대조하지 않는다(반례 C 재현 ① — admitted를 회귀로 pin한
  정직 경계). capture artifact resolver가 필요하다.
- **Δ6-2 gate window 집행**: `window.max_span`의 시작·만료·실행 중단을 집행하지 않는다
  (스키마 basis enum 검증만). 실행 runner 경계의 몫.
- ~~key lifecycle history~~ → **구현됨(0.3.0, 2026-08-16)**: KeyRegistry v2 —
  결속마다 valid_from_seq/revoked_at_seq 좌표, admitted `key.rotated`/`key.revoked`
  이벤트가 전이(효력은 n+1부터 — 모든 admitted record가 자기 좌표에서 유효 불변식),
  `was_valid(pubkey, seq)`=bool|None(미등록), 소급 무효화 없음, admission과 감사가
  같은 좌표 술어 공유.
- **capture 맵 unwind(반례 D 제안 3의 결정)**: first-writer-wins는 **의도가 아니라
  한계**다. frozen §4 revocation이 claim event(artifact.attested)만 대상이라 관측
  이벤트가 세운 값 주장을 내릴 스펙 경로가 없다. unwind는 dispute claim type과 같은
  설계 슬롯 — 방향은 원 signer만 자기 주장을 내리는 것(권한 확장 없이 닫힘).
- **log 원자성 경계(C1)**: 기준 구현은 single-writer·in-memory에서만 admission↔append
  원자성을 보장한다. 실 relay 저장소의 concurrent transaction/CAS는 P1 wire/storage 잔여.
- **claim registry의 artifact role·allowed bindings(방향·digest algorithm·중복/cycle)·
  evidence_basis verifier 실행·evidence_availability 소비**: §4가 동결한 규칙이나 registry가
  아직 강제하지 않는다.

## P1 잔여 (Buzz 인스턴스 필요 — JJ 게이트)

1. **Nostr outer event byte 범위**: 봉투 canonical bytes가 `content`에 실릴 때 event id가
   서명하는 exact 범위를 Buzz/NIP-01 직렬화와 byte-level 대조.
2. **Merkle wire-호환**: 여기 구현은 RFC 6962/9162를 따르지만 생성기·검증기가 같은
   모듈이라 **내적 정합**까지만 증명된다 — relay 구현의 proof와 교차 대조가 잔여.
3. **BIP-340 공식 서명 벡터 대조**: 공개키 유도는 공식 vector 0과 일치 확인; 서명
   bytes는 자체 결정론 pin(감사된 라이브러리와의 전수 대조는 P1에서).
4. sealed coordination payload 설계(v0.1 열린 질문 1 — 그때까지 본문 비탑재 유지).
5. **이의(dispute) 표시 자리**(LxM 관찰, 2026-08-15): 취소 권한 없이 반대 증거를 세울
   자리가 없다 — 틀린 주장을 한 랩이 침묵하면 영원히 authoritative로 남는다. 방향 후보:
   새 kind가 아니라 claim registry의 dispute claim type(원 주장 authority 불변·반대 증거
   digest 결속·독자가 병렬로 읽음). LxM 아레나 판정 계약과 함께 설계 예정.

## 알려진 무관 결함

`tests/test_observatory.py::TestReport::test_bands_separated`는 이 작업 **이전부터**
실패한다(stash 검증). hub 회귀는 이후 계속 확장 — 현 수치는 최신 pin 커밋 메시지가 authority다.
