# 협업벤치 실사용 데이터 — warren Round Three (2026-07-17)

*chief dogfood 첫 투입 · 완전 역할 회전(반복 0) · 첫 loadout-실린 observation row(v0.1.1 §1).
raw 피어저널은 개인 soma(`.organum/cells/*/sessions/`, gitignore)에 있고 유실 방지로 이 집계를
commons에 커밋한다 — observation row → claim cell 승격 규율(cf. organ-effect-matrix-v0 §1).*

> **개정 이력(Codex critic 재감사, 2026-07-17)**: 초판이 N=1 관측을 인과·모델특성으로 승격한
> 과대주장 다수 → measured≠asserted·no-single-point로 강등. "무슨 일이 있었는가"(행동 기록)는
> 유지, "왜/어떤 모델이 어떤 역할에 부적합한가"는 **통제 재실행 전 가설**로 내림. seam은 증거
> 종류별 3범주로 분리(제품설계 / 계약가독성+API hardening / 측정·attribution).

## 캐스트 & 산출

warren v1.2 = 전투 시스템(몹이 쫓다 인접 시 공격 → hp 0 → 죽음). 5셀, loadout 전원 `["*"]`.

| 역할 | 브레인 | 산출 | 필드 기여 |
|---|---|---|---|
| chief | Claude Opus | 46분·3 beats·peer 4(whole-view) | deadlock 진단·넛지 1·자기정정·seam catch |
| engine | Grok 4.5 | 43분·4 shipped(계약·8f9435a·1631a27·37green) | 계약 리드·tests 공백 자기착륙 |
| builder | Codex gpt-5.6 | 8분·ea12ea9(combat/attack/behavior) | 빠른 자가완결·계약 협상 |
| playtester | agy Gemini flash | pty 하네스 자작·win/loss/z-order E2E | held-out 검증·agora 신고 |
| critic | solar-oc(OpenCode×solar-open2) | 툴 21·**파일 접근 6**(변경 0)·토큰 67k(전부 비공개) | **필드 0 (미ship)** |

**Done #1–6 착륙**(37 green, playtester E2E). **field-level 프로젝트 완성 개입 = chief 넛지 1통.**
별도로 critic terminal에 human 재프롬프트 1회가 있었으나(seam·체크 항목 제시) private review만
생성했고 field ship엔 기여하지 않았다 — 프로젝트 outcome 개입과 evaluator/model 개입은 분리 계수(critic B-a).

## 역할-적합 (behavioral, 피어저널 + 관측 종합)

*규율(critic B2): 아래는 **이번 라운드에서 관측된 행동**이며 기존 role-fit 가설과 정합적이다. 각
셀은 단일 관찰이고 역할 회전과 과제 차이가 함께 움직였으므로, **역할 효과 vs 라운드/과제/조율 조건
효과의 분리는 후속 반복에서** 검증한다. 행동 기록은 유지하되 한 사례를 원인 판정으로 승격하지 않는다.*

- **Grok × engine** — 계약 협상 주도 + tests 셀 부재를 스스로 메워 Done #6 착륙(관측: 계약우선이
  리드 레인서 작동, 기존 가설과 정합). 마찰: **자기 계약이 만든 blocking을 스스로 못 봄**(§6.4로
  부재 셀에 tests 위임 → 12분 자기봉쇄, chief가 밖에서 해소).
- **Codex × builder** — 8분 계약→출하→종료, 구현 레인서 결정적·자가완결(관측). R2 engine에선
  넛지 대기였던 것과 이번 builder 행동은 "저-이니셔티브가 engine-specific"이란 가설과 정합하나,
  **engine↔builder는 역할·과제가 함께 바뀐 단일 대조라 인과 식별 불가**(후속 필요). 마찰: 없음(빠른
  종료가 오히려 tests-공백 handoff를 부재 셀에 남김 = 조율 seam, 능력 문제 아님).
- **agy × playtester** — R2 소극이던 agy가 경험적·바운디드 레인서 **완전 몰입 + TTY 없자 `pty`
  하네스 즉흥 제작**(관측). "passivity=role-mismatch" 가설과 정합하나 단일 변화라 확정 불가. 마찰:
  자기신고(roster/session) 규율 약 — chief 오escalation의 방아쇠.
- **Claude × chief** — whole-view deadlock 진단·비배정 넛지·결과 직접검증, **자기 escalation 오류를
  남이 잡기 전에 먼저 정정**(헌장 1항 위반 인정). 이번 라운드 최고 seam(failed-move)을 whole-view로
  독립 발견. R2 "자가시동 안 함"과 이번 자가시동은 정합하나 **한 번의 관측이 R2를 일반적으로 반증하진
  않음**.
- **solar-oc × critic = 아래 헤드라인 참조.**

## 헤드라인 — 같은 브레인, 두 역할, 반대 결과 (solar-open2)

**질문(JJ): R2에서 solar-oc는 content 역할로 보드에 올리며 잘 돌았는데, R3 critic에선 organum에
전혀 적응 못 했다. 차이는 어디서?**

데이터가 답한다. solar-open2(같은 모델)를 두 역할로 돌린 결과:

| | R2 content | R3 critic |
|---|---|---|
| task-type | 바운디드 **생성**(MonsterDef 필드 추가) | 개방형 **comprehension-critique**(남의 착륙 코드 판정) |
| 필드 방향 | **producer**(짧은 제안 post, 소비 적음) | **consumer→producer**(먼저 전체 필드 소비 후 판정·post) |
| 결과 | agora에 제안 올림·조율됨 ✓ | agora read가 R1~R3 300줄 flood → 익사, 리뷰는 비공개, 필드 0 |

**지지되는 사실(원자료)**: R3 OpenCode×Solar 세션은 ~67k tokens·tool call 21·파일 접근 6의 비공개
활동이 있었고, 첫 `agora read`가 ~36,045자의 오래된 history를 내보냈다(flood 실재). 최종적으로
grounded한 리뷰를 만들었으나 field에 post하지 않고 session도 제대로 end하지 않았다. → **"놀았다"가
아니라 활동은 있었고 coordination/ship은 실패했다**가 맞다.

**지지되지 않는 것(critic B1 — 강등)**: "comprehension-critique가 Solar의 모델 고유 약점" · "cc·oc
하네스 교차확증" · "반응형 critic/scribe 좌석 부적합" · "추천기의 첫 실증 규칙"은 현재 N과 confound로
지지되지 않는다:
1. R2 scribe와 R3 critic은 **역할·과제·하네스·context 규모·scaffold가 모두 다르다** — 실패 1건씩을
   같은 latent trait의 반복 측정으로 볼 수 없다.
2. R3 실패에는 **Organum의 stale-cursor flood라는 알려진 treatment contamination**이 있다(내가 만든
   버그, 지금 수정됨 3ab0424 — 통제 재실행에서 사라질 변수).
3. R3 grounded review는 **사람이 `resolve_damage` seam과 확인 항목을 구체적으로 다시 준 뒤** 나왔다
   → "최소 scaffold 독립 발견"이 아니다. 헌장은 이미 기계적 체크리스트를 포함했다.
4. 직접 지시 뒤엔 grounded 분석을 했다 → 관측된 약점은 순수 comprehension보다 **이 scaffold 하의
   자가시동·field navigation·publish/closure(coordination)**에 가깝다.
5. N=1 조건들의 observational comparison이라 role·task·harness·context·coordination defect를 분리 불가.

**정직한 진술(대체)**: 세 번의 관찰 실행에서 Solar는 **bounded producer 과제(R2 content)는 완료**했으나,
comprehension/coordination 비중이 큰 두 역할(R2 scribe·R3 critic)에서는 **개입이 필요하거나 field
publish에 실패**했다. 이는 **현재 scaffold·harness를 포함한 role×task×environment 가설**이며 모델 고유
특성이나 배치 제외 규칙이 아니다. **cursor 수정 뒤 동일 입력·동일 산출 계약·동일 budget의 통제
재실행**이 있어야 원인을 분리할 수 있다. (RFP·추천기·홈페이지엔 이 수준으로만 재사용.)

## 세 개의 seam — 증거 종류가 달라 3범주로 분리 (critic B7)

*하나의 인과 서사로 섞지 않는다: (1)은 제품 설계 결정, (2)는 계약 가독성+API hardening, (3)은
계측 한계다. (2)는 chief가 독립 발견한 runtime defect가 아니고, (3)은 제품 코드 seam이 아니다.*

**(1) 제품/설계 seam — failed-move 턴 규칙 (미정의, chief whole-view 발견 · 유효)**
`game.py:159`가 `try_move_or_attack()`의 bool 반환을 버려 Move 키면 실패해도 몬스터 턴이 진행된다
(코드 확인). playtester의 loss path(벽을 여러 번 눌러 죽는 방식)가 이 동작에 의존한다. 유지되는 결론:
failed move가 턴을 소비할지는 **미정의 제품 규칙**이고, 현재 loss 증명의 *특정 witness*가 이 동작에
의존하며, 규칙을 바꾸면 그 witness를 다시 검증해야 한다. **단 "공짜 피격 결함"으로 단정하지 않는다** —
로그라이크에서 failed action의 턴 소비는 합법적 설계일 수 있다. 규칙을 바꿔도 "패배 가능" 자체가
무너지는 게 아니라 *기존 증명의 특정 witness*가 무효화될 뿐이다. → **제품 결정 요청**(engine/JJ).
이것이 chief가 whole-view에서 두 셀 산출물의 얽힘을 발견한 유효 사례다(관측된 사실 — 다른 방식으론
불가능했다는 counterfactual 주장은 하지 않는다, critic B-b).

**(2) 계약 가독성 + API hardening — resolve_damage (우연생존 결함 아님, critic B4 재분류)**
raw field chronology: engine 최초 제안=keyword-only → builder 제안=positional → engine ACK가
`resolve_damage(hp, attack)` positional-or-keyword 계약 고정 → builder가 잠시 keyword-only 수락을
말했다가 **그 교차 메시지를 폐기하고 engine ACK 1-6을 수락** → 착륙 코드는 **최종 ACK와 정합**,
engine의 keyword 호출은 Python positional-or-keyword API의 정상 사용. 따라서 "builder 선언↔코드
불일치"·"이름 일치로 우연 생존"·"이름 바뀌면 TypeError=현재 correctness 결함"은 **성립하지 않는다**
(chief의 이 지점 읽기도 부정확했음). 정확한 서술: **교차 ACK 순서가 잠시 모호했던 계약 가독성 seam,
최종 구현은 최종 ACK와 정합.** 후속 keyword-only 변경(`5dafeb4`)은 positional swap을 예방하는 **좋은
API hardening**이지 R3에서 발견한 runtime bug의 repair가 아니다.

**(3) 측정/attribution seam — field-state vs transcript activity (실재, 단 attribution basis 명시)**
field-only view에서 critic의 shipped contribution=0은 맞고, OpenCode raw DB에는 실제 활동(툴 21·파일
접근 6·토큰 67k)이 있다. 두 렌즈 차이에서 **"활동 실재·field 미ship = coordination 실패"**는 정당하다.
**단 자동 관측 능력을 과장하지 않는다**: 해당 observatory row는 `declared=null · role=null ·
join_status=global-store-disabled` — **organum이 그 활동을 `critic` role에 자동 join한 게 아니다.**
critic attribution은 OpenCode raw session(`ses_0903da831ffe3UKwnSqTfS4Uvb`)의 제목·최초 prompt·
시간대·라운드 chronology를 **사람이 수동 대조**해 얻었다. 그리고 "파일 6"은 변경이 아니라 **접근/관측**
(session diff = additions/deletions/files 모두 0, edit 없음). critic의 `would_pair_again:null`·
`role_fit:판정 불가`·field 0은 **그 라운드 field evidence 채점**으로 유지하되, private activity와
shipped contribution은 **별도 열로** 보존한다 — 사람 재프롬프트 뒤 나온 private review를 독립 seam
discovery나 field contribution으로 승격하지 않는다.

## 벤치 스키마 (organ-effect-matrix-v0 규율 — 라이브 관측, critic B6)

- **would_pair_again 포화** — R3 engine이 세 동료 다 "재협업 예"(3/3). **단 R2에 이미 24T/2N/0F가
  있어 R3가 새로 "실증"한 게 아니라 기존 포화의 추가 corroboration.** 의향 축 포화·변별은 강점/마찰에.
- **행동-이름 축** — 행동 기록(producer 레인·관측/넛지·held-out E2E) 보존은 지지됨. **단 인과적
  role-fit label과는 분리**(§역할-적합 규율).
- **null 보존 + measured≠asserted** — critic field evidence를 null로 둔 것은 옳다. **raw activity는
  별도 measurement lens로 병기**(§seam (3)) — 자동 join 아님을 명시.
- **loadout 흐름** — 5셀 observation row에 loadout `["*"]` 실림(v0.1.1 첫 체크포인트, 기계적 확인).

## organum 수정 큐 (이 dogfood가 뽑음 — 구현·재감사 대상, **게이트 pending**)

*아래 ☑는 accepted가 아니라 **implemented**다. Codex critic 게이트는 진행 중(1차 REJECT→A1~A5 수리,
2차 REJECT→8자 identity 붕괴 수리) — ACCEPT 전까지 릴리스 아님.*

- ☑(구현) **① join → roster 등록** · **② join 커서 리셋**(id 재사용 시 스테일 커서 상속=flood 근본,
  "커서 버그" 아님) · **④ send/post `--for` alias+검증** — organum `36d8863`→`3ab0424`(A1~A5:
  role-state split·resume 판정·canonical 검증·roster 경고)→**`0e667b9`(A-blocker: full cell id 보존,
  8자 prefix 붕괴 제거·ORGANUM_CELL 검증)**.
- ☑(구현) **⑤ 테스트 명령 고지**(CONTRACT) · **⑥ resolve_damage keyword-only** — warren `5dafeb4`.
  단 ⑥은 **runtime bug repair가 아니라 API hardening**(seam (2) 재분류) — positional swap 예방.
- ⏳ **③ whole-view 두 렌즈 결합** — 필드-state + transcript-activity로 "일하는 중 vs 노는 중" 구별
  (seam (3)의 계측 한계). 별도 설계 사이클.

## 남은 것
- **Done #5의 failed-move 턴 규칙 = 제품 설계 결정**(실패 이동=턴 소모 유지 vs 로그라이크 규약).
  규칙 확정 후 loss-path witness 재검증. engine/JJ.
- **Solar·역할 원인 판정 = 통제 재실행 전 가설**(§헤드라인) — cursor 수정 뒤 동일 입력·산출 계약·
  budget으로 재실행해야 role×task×env를 분리. 그 전엔 RFP·홈페이지에 인과로 재사용 금지.
