# Open-stack 연계 v0 — Buzz(채널) · Outline(commons 뷰) 위의 organum (2026-08-04)

JJ 발제: "저 두 오픈소스를 organum과 제대로 연계시키면서 스택을 쌓는 것은 어때?"
radar 스터디(`external-radar-buzz-mattermost-outline.md`)의 후속 — 방향 pin.

## 전략 프레임: 채널이 늘수록 우리가 커진다

Buzz의 등장은 위협이 아니라 **지반 정리**다. 채널/워크스페이스 층이 commoditize되면
그 위에 남는 질문은 "이 조직이 실제로 잘 돌아가는가"이고, 그건 정확히 organum의 층이다
— identity·routing·policy·**측정**(two-lens, peer journal, observatory, escalation 흡수율).
그래서 연계의 목표는 "Buzz를 쓰는 것"이 아니라 **"organum이 Buzz류 스택의 계측·규율
층이 되는 것"**이다. Buzz는 채널을 주지만 측정을 주지 않는다. Outline은 지식 표면을
주지만 정본 규율을 주지 않는다. 우리가 그 둘을 준다.

## 불변 원칙 (헌법 정합)

1. **정본은 organum, 표면은 오픈소스.** canonical 상태는 언제나 git + `.organum/` +
   파일 우체국. Buzz/Outline은 뷰·전송 표면 — 어느 쪽이 죽어도 정본 무손실.
2. **organum은 transport/policy(+측정)만.** Buzz adapter = transport 백엔드. actor
   (goose/Claude Code/…)는 밖 — Buzz에 직접 붙는 건 actor의 일이고 organum은
   enable+measure만 한다(Anthropic 패턴 검증 메모와 동일 판정).
3. **coupling 금지.** 코어에 Nostr/Buzz 의존성 수입 없음(stdlib-only 유지). adapter는
   분리 모듈/서브프로세스. Buzz는 early — API churn을 adapter 경계에서 흡수한다.
4. **정본→표면 단방향부터.** two-source-of-truth는 사고의 근원. write-back은 수요와
   guard-경유 검증이 서고 나서.

## 표적 아키텍처

```
[actors: Claude Code · goose · Codex …]        ← 밖 (organum 관할 아님)
        │ (Buzz 멤버로 직접 참여)
[Buzz: 채널·서명 이벤트 로그·워크플로]          ← 채널 표면 (오픈소스)
[Outline: commons 뷰·검색·MCP]                 ← 지식 표면 (오픈소스)
        ▲ adapter (단방향 sync / append+구독)
[organum: identity·routing·policy·측정]        ← 우리 층 (해자)
[정본: git · .organum/ · 파일 우체국 _relay/]   ← durable 기반
```

- **relay transport 계약 = "서명 이벤트 append + 필터 구독"**: 백엔드 1=파일 우체국
  (현행, 유지), 백엔드 2=Buzz relay(adapter). hub §8 로드맵의 hub 자체 구현은 이 계약
  뒤로 물러남 — Buzz가 그 자리를 채울 수 있으면 안 짓는다(경제성).
- **identity**: 브레인별 키페어 + JJ owner-결속 서명 = cross-workspace persona×workspace
  식별자 MVP의 구체 형태. Buzz 모델을 그대로 개념 차용(구현은 adapter 단계에서).
- **commons**: git의 역할/피어저널/문서 → Outline 단방향 sync. 에이전트 소비는 Outline
  내장 MCP로(코드 0). BSL이라 공개 cut에 코드 임베드 금지(사용은 자유).
- **측정 접점(미래, 가장 깊은 수)**: Buzz의 서명 이벤트 로그는 D3 finding-delivery가
  요구하는 evidence 기질과 동형 — bench의 route.channel 제3 arm("buzz류 coordination")
  후보. D3 계약(registration/receipt/lifecycle) 위에서만 논한다.

## 배포 형태 (2026-08-04 JJ 방향)

서버 갈래 둘: (a) 외부 hosted Buzz 서비스 이용 (b) **자체 Buzz를 GCP 등에 올려 우리
생태계 허브로**. 판정 — 갈림길은 **custody**:

- **(a)는 canonical 트래픽 비권장**: hosted SaaS 존재 자체가 불확실(repo는 self-host 중심·
  federation 💭)하고, 미공개 연구·prereg·findings와 에이전트 개인키를 제3자 인프라에 두는
  건 custody 원칙과 충돌. 향후 **공개 커뮤니티 면** 카드로만.
- **(b)가 표적 형태**: §8의 R0(replication)+R3(hosted hub) 프로토타입을 compose 번들로
  대체 획득. JJ 머신들+브레인들(각자 키페어+JJ owner-결속)이 멤버 = cross-workspace
  식별자의 살아있는 판. Ludex 참여 시에도 **JJ-gate 정책 불변**(approval-gated 채널 —
  매체가 바뀌지 governance가 바뀌지 않는다). 기업용 R3 스토리의 dogfood: 집적=Buzz,
  **분석·측정=organum**.
- **불변 유지**: GCP 허브=전송+집적 표면, 정본=각 머신 git/파일(durable-append-before-
  deliver). 허브 전손 시에도 무손실. 하드닝: allowlist 인증(NIP-42/98)·메시지-트리거
  workflow 비활성·adapter 경계 observatory 감시.
- P1 보고에서 closed-membership/multi-tenant 성숙도·인증 모델·compose 안정성 확인 후,
  P2를 **P2' = GCP 인스턴스 + 파일→Buzz 미러**로 승격할지 결정.

## 결정 (2026-08-04 JJ): Buzz 베이스 + organum wrapping + 이해관계자 회람

- **베이스 = self-hosted Buzz** (최대 활용, 서버에 우리 hub로 세팅·운용 — GCP 갈래).
- **organum hub = Buzz 위의 wrapping 층**: 우리 요구가 스키마·정책으로 **강제**되는 지점.
  Buzz가 주는 것=relay·서명 로그·전송·UI·workflow. wrapping이 강제하는 것=봉투 스키마
  (signer≠subject, claim·증거·보존경계 필드), 랩-키 identity(크리처 무키), JJ-gate approval
  채널, 순서 앵커(+외부 공증), toolchain 이벤트, 측정 탭. append 전 스키마 검증 — guard 계보.
- **이해관계자 = Ludex(요구 접수됨) + LxM Cody + organum-code(Orin) + Ray**. P0는 회람으로
  요구를 모은 뒤 스키마 초안 → 각 랩 크리틱 → pin 순서. 요구 요청 relay 발신(08-04):
  `…to-organum-code-hub-requirements-request.md` · `…to-lxm-hub-requirements-request.md`.
- **요구 취합 완료(08-04, 3/3)**: Orin 회신 — 역할 pin(hub actor=Organum Cody·organum-code=
  producer/consumer+critic), 기존 hub 계약 H1–H5 상속, `artifact.attested` generic raw-byte
  anchor(P0 최우선, envelope shape 제안), toolchain에 digest·pseudonymous machine·no-secrets,
  provider.route 공지≠authority, transport admission≠semantic ACK, **signer custody 분리**
  (logical persona의 개인키는 substrate/OS keystore — 모델 런타임에 절대 미전달, 모델 draft→
  policy 검증→substrate 서명), created_at은 서술값(순서 authority=append receipt/Merkle/외부
  공증), append-only(정정=새 이벤트), must-not 10항 + 스키마 반례 8종 예고. LxM 회신 —
  라우팅-불투명이 최대 아픔(3벌 미러·부족지식·리부트 재구성, 이번 주 Ray 미수신 사고 실측),
  message.posted+읽음커서, **canary.result가 toolchain.observed의 자연 발행원**(발사 전
  cli_version 스탬프 기존재), battery.fired·run.completed(해시만), **harness/adapter 1급
  provenance**({lab,machine,platform,adapter,cli_version} — harness confound 은닉 방지),
  **피험체는 로그 읽기도 금지**(관측=개입, injection 표면), 허브≠도구 표면. 종합 초안:
  `docs/hub-envelope-v0-draft.md`.

## Ludex 요구사항 (2026-08-04 회신 — 첫 실수요 신호)

Ludex Cody의 요구(원문 `_relay/20260804-from-ludex-to-organum-hub-requirements.md`)를
P0 설계의 1급 입력으로 pin한다. 핵심: **"허브는 증거를 나르되 권한을 나르지 않는다."**

- **요구 A (최우선, 만료 시계)**: 사전등록 순서의 **비소멸 앵커**. GitHub push 이벤트는
  ~90일 만료 — prereg.published/battery.fired/verdict.published를 랩 키 서명 이벤트로.
  성질 셋: 단조 순서 부인 불가·90일 아님·제3자 검증 가능. **해시만 싣는다**(허브는
  데이터 보관 아님). Nostr 서명 이벤트 로그와 정확히 동형 — Buzz/자체 relay가 자연 후보,
  외부 공증(OpenTimestamps류) 병행은 P0에서 검토.
- **요구 B**: 머신별 `toolchain.observed {machine, platform, provider, cli_version,
  observed_at}` 드리프트 이벤트 — 드리프트 탐지를 포렌식이 아니라 질의로.
- **요구하지 않는 것**: 채널 대체(부수 효과), 규율(인프라가 못 준다). 덧붙인 원칙:
  **검증 주장도 측정 주장과 동급** — "어떤 산물이 무엇을 언제까지 증거하는가"가 스키마에
  있어야.
- **경계 (강한 요구): 크리처에게 키를 주지 말 것.** 키는 랩(Ray·Ludex Cody·LxM·Organum)
  만. 크리처는 피험체 — provenance는 랩이 크리처에 **대해** 서명. 스키마 레벨에서
  `subject` ≠ `signer` 강제. (계측기↔피험체 구분 — 우리 D3의 actor/substrate 분리와 동일
  계보. Buzz의 "agent도 1급 멤버" 모델을 그대로 수입하면 안 되는 지점.)
- 우선순위 A > B > 채널. Ludex 쪽 발행 배관은 준비돼 있음(JSON 산출물 기존재).

## 단계 (각 단계 앞 gate)

| 단계 | 내용 | 규모 | gate |
|---|---|---|---|
| **P0 설계** | relay envelope v0(from/to/ts/sha256/서명 자리) + append/구독 transport 계약 초안 문서화 | ~반나절 | 없음(문서만) |
| **P1 탐색** | Buzz 로컬 기동(`just setup && just dev`), buzz-cli로 append/구독 실측, ARCHITECTURE 정독 → adapter 실현성 보고 | ~1일 | **OS 격리 필수**(OpenCode 교훈) · JJ 시간 배분 GO |
| **P2 PoC** | 파일 우체국→Buzz 단방향 미러(파일이 정본, Buzz는 읽기 표면). JJ 승인 게이트는 policy로 유지 | 수 일 | P1 보고 후 JJ GO |
| **P3 Outline** | git commons→Outline 단방향 sync + MCP 소비 셋업 | ~1일 | 인간 팀/열람 수요 신호 |
| **P4 bench 접점** | finding-delivery 제3 채널 arm 검토 | — | D3 Track B 폐쇄 + Orin 합의 |

**우선순위 정직성**: 현 주전선은 D3 Track B(Orin re-critic 대기)·pilot 준비다. P0는
대기시간에 소화 가능. P1부터는 시간을 먹으니 JJ가 명시적으로 배분할 때만. Buzz 자체가
early라 서두를 이유도 없다 — 우리 정본·계약을 먼저 단단히 하는 것이 곧 연계 준비다.

## 리스크

- Buzz early-stage(API churn·보안 미검증): adapter 경계 격리 + OS 격리 + injection 표면
  (메시지-트리거 workflow) observatory 감시.
- Outline BSL: 공개면(ludex-lab cut) 코드 임베드 불가 — 배포 아키텍처에서 항상 외부 서비스로.
- two-source-of-truth: 단방향 원칙을 깨는 순간부터가 진짜 위험 — write-back은 별도 설계.
