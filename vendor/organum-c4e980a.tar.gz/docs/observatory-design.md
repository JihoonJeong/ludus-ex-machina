# Observatory — 관측 영속화 설계 (draft, JJ 리뷰 대기)

*2026-07-15. 배경: 단독-에이전트 셀프 모니터링 도그푸드에서 확인 — Claude Code는
transcript를 ~30일 후 청소한다(디스크 실측: 6월 초 이전 증거 부재). 벤더 transcript에
의존하는 한 관측 데이터는 시한부다. "세션 데이터를 모아 나중에 최적화"(JJ)가 성립하려면
organum이 관측 스냅샷을 자기 상태로 영속화해야 한다.*

## 0. 헌법 경계 (재확인)

- **read-only 관측의 영속화**지 새 관측 권한이 아니다. 벤더 파일은 절대 만지지 않는다.
- state+discipline: 수집은 사용자가 이미 돌리는 의례(checkup·web)에 편승한다.
  데몬 없음, 스케줄러 없음, 오케스트레이션 없음.
- C2 표시 정직성 상속: None=미측정은 영속 레코드에서도 None. 0으로 뭉개지 않는다.
- guard 교훈 상속: 실패/불완전 관측(last_ts 없음 등)은 기록하지 않는다 — 기억 오염 방지.

## 1. 무엇을 남기나 — 레코드 스키마

단위 = **세션-셀 1개**(터미널이든 서브에이전트든). 정규화 Cell(adapters._cell)의
영속판 + 선언 레이어 조인:

```json
{
  "v": 1,
  "vendor": "claude", "session_id": "<full>", "id": "ac5019bb",
  "model": "claude-fable-5", "origin": "terminal", "parent": null,
  "in_tok": 219, "out_tok": 88886, "cache": 7483526,
  "tools": {"Bash": 44, "Edit": 8}, "skills": {}, "files_touched": 12,
  "branch": "main", "first_ts": "...", "last_ts": "...",
  "declared": "cody", "role": "dev", "intent": "...", "sid_declared": "20260715T100403Z",
  "role_basis": "cell-role-unique", "join_method": "direct|marker|null",
  "join_status": "joined|role-ambiguous|no-marker|marker-unknown|marker-ambiguous|scan-incomplete|global-store-disabled|no-bridge",
  "declared_sessions": 1,
  "captured_at": "...", "capture_reason": "checkup|web|sync"
}
```

- 토큰·모델·계보(parent)·툴 분포 = 효율 통계의 원자재.
- **brain↔role 조인(협업벤치 v0.1, fail-closed)**: 조인 키 = 선언 셀 identity(직접 id 또는
  exact-unique·complete-scan 마커) + **셀당 role 유일성**(`role_basis=cell-role-unique`). 세션의
  started_at/ended_at은 *선언 시각*이지 작업 창이 아니라 시간창 매칭을 쓰지 않는다. 셀에 서로 다른
  role이 둘↑·마커 애매(0/2↑/불완전 scan)·전역 공유 DB(opencode)는 role=None. `intent/sid_declared`는
  후보 세션이 정확히 1개일 때만 채운다. `join_method`+`join_status`+`declared_sessions`가
  **미조인 이유를 감사 가능**하게 남긴다(적을수록 정직 — 오조인 금지가 미조인보다 우선).
  `join_status`: joined · role-ambiguous(identity 확인·role 비유일 — declared·join_method **보존**) ·
  no-marker(0개) · marker-unknown(1개인데 후보 밖) · marker-ambiguous(2개↑) · scan-incomplete
  (cap 초과·scan 중 변경·읽기 실패) · global-store-disabled(opencode) · no-bridge.
- raw transcript는 **저장하지 않는다**(프라이버시·부피·목적 초과). 집계 가능한 요약만.

## 2. 어디에 — `.organum/observatory/` [personal, gitignore]

```
observatory/
  2026-07.jsonl        # 월 샤드, append-only
  2026-08.jsonl
```

- **월 샤드 JSONL append-only**: crash-safe(부분 쓰기=마지막 줄 유실뿐), stdlib,
  단일-writer 아님이어도 append라 안전. 같은 session_id 재관측은 **그냥 다시 append**
  — 읽는 쪽이 `max(last_ts)` 레코드를 취한다(라스트-라이트-윈). 파일 mutate 없음.
- 컴팩션: checkup이 지난달 샤드의 중복을 1회 정리(같은 sid → 최신만). 선택적.
- personal(gitignore) 기본. 이유: 세션 소비량은 로컬 관측이고 부피가 크며, 팀 공유가
  필요한 통찰은 distill을 거쳐 worldmodel/피어저널로 가는 게 기존 규율(원자료≠commons).
  나중에 프로젝트가 원하면 `--shared` 승격을 논의(비-스코프).

## 3. 언제 — 트리거 3개, 전부 기존 표면

핵심 통찰: transcript가 ~30일 살아 있으므로 **실시간 캡처가 필요 없다**.
30일 내 아무 때나 스윕하면 무손실. 따라서:

1. **checkup에 스윕 통합** (주 트리거): `organum checkup`이 돌 때
   `adapters.snapshot(cwd, window_min=∞)`급 광역 발견 → 이번 달 샤드에 없거나
   last_ts가 전진한 셀만 append. 의례에 편승 = 습관이 곧 수집.
2. **web 폴링에 저비용 upsert** (보조): 관제탑이 이미 30초마다 snapshot을 뜨므로,
   셀이 관측 창(30분)을 떠날 때 1회 append. 관제탑 켜둔 프로젝트는 실시간급.
3. **`organum observatory sync`** (수동): 명시적 백필. `--window <days>`로 범위.

셋 다 같은 함수(`observatory.record(cells)`) 호출 — 멱등(같은 sid+last_ts면 skip).

## 4. 읽기 — `organum observatory stats` (MVP)

```
organum observatory stats [--since 30d] [--by model|role|origin|vendor]
```

- 기간 내: 세션 수 · 토큰 in/out/cache(미측정 제외 합산) · 비용 추정(inspect PRICES)
  · 서브에이전트 비율(스폰 수·토큰 점유율) · 모델 믹스 · (role 조인 시) 역할별 소비.
- 출력 = 관제탑 결의 텍스트 표. 그래프·대시보드는 web 패널 후속(비-MVP).
- harness-lift 실험([[harness-model-experiment]])이 이 stats를 그대로 계기로 사용:
  같은 과제 × 두 하네스 → `--by vendor` 비교.

## 5. 포맷 v0에 대해 — additive

- 신규 디렉터리 1개 + gitignore 1줄. 기존 파일 스키마 무변경. `v:1` 필드로 자체 버전.
- migrate 불요(신규 additive). format-v0.md에 §3.x observatory 추가.

## 6. 비-스코프 (명시)

- 데몬/백그라운드 워처 · cross-project 중앙 저장소(관측은 site-bound)
- raw transcript 보관 · LLM 요약(distill은 별도 의례로 이미 존재)
- 자동 최적화 제안(stats는 숫자만 — 해석은 사람/세포)

## 7. 구현 스케치 (승인 시)

- `src/organum/observatory.py`: `record(state_dir, cells, reason)` ·
  `load(state_dir, since)` · `stats(...)` — stdlib only, ~150줄 예상
- checkup 훅 1줄 + web payload 훅 3줄 + cli 서브커맨드
- tests: 멱등 append · 라스트-라이트-윈 · None 합산 제외 · 월 샤드 경계
