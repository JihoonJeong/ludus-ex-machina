# Native harness 요구사항 — organum-code RFP v0

*organum(플랫폼) → organum-code(actor). organum-code HANDOFF §4.B(session-aware plugin)·§4.C(live
bridge)를 **대체하지 않고 보완**한다 — 그 계획은 organum 툴을 agent에 *노출*하는 설계이고, 이 문서는
R3 dogfood가 증명한 **"툴 노출 ≠ 조율 역량"** 갭을 메우는 요구사항(하네스가 강제해야 할 규율 +
동결된 identity 계약)이다. 근거 데이터: `docs/collab-bench-warren-round3.md`, format-v0 §0.1.*

## 0. 왜 이 문서인가 — 한 줄 논제

**하네스가 organum 툴을 노출하는 것만으로는 약한 brain을 조율-유능하게 만들지 못한다.** R3 warren
dogfood에서 solar-open2(OpenCode 하네스, critic 역할)는 organum CLI 전체에 접근 가능했는데도 실패했다:
`agora read`가 ~36k자 history를 쏟아 익사했고, grounded 리뷰를 만들고도 **필드에 post하지 않아 팀
기여 0**이었으며, `python`/`pytest`/`PYTHONPATH`로 헤맸다. 즉 **coordination의 절반(consume 잘,
publish 반드시)을 brain이 실패**했다. organum-code의 명제("몸이 organum-역량을 이면 어떤 brain을
꽂아도 유능")가 성립하려면 하네스가 이 규율을 **강제·스캐폴드**해야 한다. 첫 고객이 정확히 그 실패한
brain(solar-open2)이라 성공 판정이 명확하다: **같은 brain이 이번엔 조율-유능한 셀로 돈다.**

## 1. 경계 (헌법 정합 — 재확인)

organum-code는 **actor**다(하네스+brain). organum coordination 아키텍처상 actor는 substrate 밖이다
— organum은 transport/policy 기층으로 남고 organum-code는 그걸 **native로 말하는 1st-party actor**다.
따라서: organum **공개 CLI/API만 소비**(내부 module import·DB write 금지, HANDOFF 원칙 유지),
**spawn·중앙 planner·자동 role 배정 금지**(v0.1 비목표 존중). 이 문서는 dispatch를 요구하지 않는다 —
brain이 조율 규율을 *따르도록 돕는* 것이지 *시키는* 것이 아니다.

## 2. 요구사항 (각 항목 = R3 실패 근거 + organum 공개 CLI 매핑)

### R1. 자동 온보딩 — brain이 기억하지 않아도 정향된 상태로 시작
**근거**: R3에서 강한 brain은 `organum join` 한 줄로 정향됐지만, 약한 brain은 사람이 한 문장을 줘도
헤맸다. **요구**: session 시작 시 하네스가 `organum join --role <R> --for <cell> --intent <…>`를
자동 실행하고 그 출력(**역할 헌장 + 오늘 goal + inbox**)을 agent의 첫 컨텍스트/system 프롬프트에
주입한다. brain이 join을 스스로 실행하리라 기대하지 않는다. (§4.B의 `organum_join`을 *부트 시 자동*으로.)

### R2. goal 상시 컨텍스트 — flood가 goal을 묻어도 잃지 않게
**근거**: R3에서 agora flood가 goal을 last-2 창 밖으로 밀어 늦은 셀이 목표를 놓쳤다. **요구**: 현재
goal(agora의 goal post)을 agent 컨텍스트에 **상시 유지·갱신**한다. join 타이밍이나 필드 소음과 무관하게
"지금 무엇을 향하나"가 항상 컨텍스트에 있어야 한다.

### R3. 필터된 필드 소비 — raw dump 금지
**근거**: solar-oc의 `agora read`가 R1~R3 전체 history(~36k자)를 쏟아 익사시켰다. (organum이 커서
버그를 고쳤지만) 하네스는 inbox/agora를 **경계 있는·최근·관련** 형태로 제시해야 한다 — pagination·요약·
스레드 스코프. **요구**: `organum_inbox`/`organum agora read`를 그대로 노출하지 말고 하네스가 bounded
view로 가공(가입 이후·관련 스레드 우선·길이 캡).

### R4. publish/handoff 강제 — coordination의 절반 (**최우선**)
**근거**: critic(solar-oc)이 grounded 리뷰를 만들고도 **필드에 안 올려 팀 기여 0**. 분석은 했으나 소통
실패. **요구**: 하네스가 **"산출을 팀에 publish"를 1급·프롬프트된 단계**로 만든다 — organum
COORDINATION_DISCIPLINE(제안 1회·조율은 agora·착륙 즉시 커밋·경보 존중·escalate)을 agent system
프롬프트에 baking + idle/종료 전에 "미publish 산출이 있나? `organum_send`/`organum_handoff`로 올려라"를
스캐폴드. **하네스가 brain이 실패한 coordination 절반을 이는 핵심.**

### R5. identity 계약 준수 (동결됨, format-v0 §0.1)
**근거**: §4.B는 `context.sessionID`를 cell id로 쓴다. 그런데 organum cell id 계약은 엄격하다(6라운드
적대 감사로 동결):
- **문법**: ASCII `[A-Za-z0-9._-]`, **1~40자**, 선/후행 점 금지. `context.sessionID`는 보통 이 도메인
  밖(길거나 opaque)이라, 하네스가 **결정적으로 valid cell id로 매핑**해야 한다(예: 안정 slug + 충돌
  회피). 매핑된 id를 `valid_cell_id` 도메인 안에 두어라 — 자유 id를 원장에 넣으면 조인 파서가 깨진다.
- **case-insensitive**: `Agent`≡`agent`. 매핑 결과는 소문자 정규화(cross-platform FS 안전).
- **한 cell = 하나의 안정 identity**: 같은 OpenCode root session은 항상 같은 cell id로 매핑(§9 Phase2
  통과 기준 "두 root session이 안 섞임"과 직결). from_id도 이 id로.
- **발신 identity 분리**: relay/agora post 시 **`--for <cell>`**(canonical, self-exclusion 판정용
  from_id를 채움)을 쓰고, 자유 display가 필요하면 `--from`은 별도. 자유 문자열을 identity로 쓰지 마라
  (organum이 false self-exclusion을 막지만 하네스가 애초에 canonical id를 주는 게 정본).

### R6. presence + liveness — whole-view가 이 셀을 보게
**근거**: R3에서 chief의 필드-기반 whole-view가 solar-oc의 비공개 활동을 못 봐 "idle"과 구별 못 했다
(관측 모델 seam). organum join이 이제 roster에 presence를 등록한다(수리 완료). **요구**: 하네스가
join으로 presence를 등록하고(자동), 가능하면 진행 비트(`organum session note`)로 활동을 필드에 남겨
whole-view가 "일하는 중 vs 노는 중"을 구별하게 한다.

### R7. 환경 역량 — 약한 brain이 명령으로 헤매지 않게
**근거**: solar-oc가 `python`(vs `python3`)·`pytest`·`PYTHONPATH=src`로 헤맸다. **요구**: 하네스/
profile이 프로젝트 실행·테스트 관례를 표면화한다(예: 프로젝트 CONTRACT/README의 테스트 명령을 agent
컨텍스트에 주입, 또는 profile에 검증된 명령 고정). 약한 brain일수록 이 스캐폴드가 성패를 가른다.

## 3. live bridge와의 관계 (§4.C 존중)

R1~R4는 대부분 **plugin(§4.B) 레벨**에서 충족 가능하다(bridge 불요). §4.C bridge의 delivery 계약
(relay가 진실·admission≠read·결정적 ID·polling fallback)은 그대로 옳다 — 이 문서는 그 위에 "무엇을
전달·강제하나"의 *내용*을 얹는다. bridge가 꺼져도 R1~R7이 polling(`organum relay inbox`)으로 성립해야
한다(§4.C-9와 정합).

## 4. 성공 판정 (첫 demo)

**같은 brain(solar-open2)이 R3에서 실패한 critic 역할을 organum-code 하네스로 다시 수행**했을 때:
- 사람 개입 없이 정향(R1)·goal 유지(R2)·필드 익사 없음(R3),
- 리뷰를 **필드에 publish**(R4) — 팀 기여 > 0,
- canonical·안정 cell id로 whole-view에 정확히 1셀로 등장(R5·R6),
- 테스트 명령으로 안 헤맴(R7).

이게 성립하면 "몸이 organum-역량을 이면 약한 brain도 조율-유능"이 실증된다 — harness>weights 명제의
제품화. 이후 API Gemini/Claude로 brain을 바꿔도 같은 하네스로 조율-유능.

## 5. 우리(organum)가 보장하는 것 / 미보장 (계약 명확화)

- **보장(신규 state)**: field·roster·soma·marker·observatory·MCP가 단일 `cell_key`(case-insensitive)로
  통일 · from_id로 발신 identity 분리 · loadout·join_status provenance · 커서가 "가입 이후"만 · `--for`
  canonical 검증. (6라운드 적대 감사로 동결.)
- **미보장(현재)**: legacy state 자동 migration(pre-release compat backlog, 현 사용자 0). organum-code는
  fresh state를 쓰므로 무관 — checkup이 legacy 잔재를 탐지·경고만 한다.
