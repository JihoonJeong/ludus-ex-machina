# Organum Code 프리뷰 안내 — supervised coding runtime

> **Internal preview** (`0.1.0-preview.1`). 아직 public release가 아니고,
> production-ready도 아닙니다. 이 페이지는 프리뷰 단계의 제품이 무엇이고 무엇이
> 아닌지를 정직하게 적어 두는 곳입니다.

## 무엇인가

Organum Code는 **backend-neutral coding runtime**입니다 — 서명된 Hub 메시지와
backend 실행을 **감독자(supervisor)가 소유한 경계** 안에서 잇습니다. Hub의
signer/envelope authority를 **복제하지 않고 소비합니다**: 신원과 권위 판정은 Hub
층에 남고, Code는 그 판정 위에서 실행을 감독합니다.

inspector가 "내 에이전트가 뭘 했나"를 사후에 재고, hub가 "커뮤니티끼리 어떻게
믿나"에 답한다면, Code는 그 다음 자리 — **믿을 수 있는 메시지를 실제 실행으로
잇는 자리**를 맡습니다.

## 설치 — `pip install organum`과 별개입니다

Code는 **standalone 설치**입니다. `pip install organum`에 포함되지 않고,
Inspector/Hub와 단일 설치가 아니며, Python stdlib-only 제품도 아닙니다.

현재 프리뷰 아카이브에는 다음이 들어 있습니다:

- 플랫폼별 standalone 바이너리
- release manifest와 SHA-256 체크섬
- POSIX/PowerShell 초기 bootstrap

bootstrap은 Bun·Node·네트워크·권한 상승·PATH 편집을 **요구하지 않으며**, 사용자가
명시한 absolute prefix 안에만 설치합니다.

SHA-256은 **아카이브 무결성** 확인 수단입니다 — publisher authenticity(서명·공증)가
아닙니다. 서명/공증(notarize, Windows code-signing)은 아직 없습니다.

## 검증 구조 (현재 시점의 사실)

source test 105개 파일과 compiled Node test 710건이 통과했고, macOS·Ubuntu·Windows
설치 스모크가 CI에 배선되어 있습니다. 이는 현재 **검증 구조에 대한 서술**이지,
원격 CI 성공 기록의 주장(예: "Windows verified")이 아닙니다.

## 경계 — 아직 아닌 것

- public release / production-ready 아님
- signed / notarized / Windows code-signed 아님
- 모든 backend/provider adapter가 같은 성숙도로 공개 준비된 것 아님

기준 pin: `ludex-lab/organum-code` `86406c2` · `0.1.0-preview.1` / `internal-preview`.
