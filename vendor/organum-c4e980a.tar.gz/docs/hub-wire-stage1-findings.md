# hub wire Stage 1 — Buzz relay 라이브 대조 결과 (2026-08-15)

Stage 0(`hub-wire-stage0-buzz-findings.md`)의 후보 매핑을 **실 Buzz relay에 라이브로
대조**했다. 격리: colima VM(CPU 2·RAM 3G 캡) 안 Docker 4-컨테이너(relay·postgres·redis·
minio), loopback-only, 실험 전용 신규 keypair(실 lab key·keychain 0). 측정 후 전량
teardown(잔여 프로세스 0) — on-demand 규율 준수.

## provenance

```text
relay image = ghcr.io/block/buzz@sha256:32937a6644ed340560ca4b1e445ecfc13a78bf6046358fdcf52e9018e4fe2afe
              (created 2026-08-15T00:42Z, :main)
증거        = docs/hub-wire-stage1-evidence/{frames.jsonl(전 송수신 프레임 verbatim),
              probe.py, compose.yml, relay-image-provenance.txt}
```

## 결과 — Stage 1 목록 전 항목 성립

| # | 측정 | 결과 |
|---|---|---|
| ① | **직렬화 동치 라이브**: 우리 계산 id의 kind-1 event(content=봉투 canonical bytes) | **수용(OK true)** — relay가 rust-nostr로 id를 재계산해 대조하므로 수용 자체가 byte 일치 증명 |
| ①' | **동치의 명시 증거**: 변조 id 거부 메시지 | `invalid event id: computed 45d147c6…, got 05d147c6…` — **relay가 재계산한 id가 우리 구현의 계산과 문자 단위 동일**(우리 mangle이 첫 char 4→0이었고 computed가 우리 원값 그대로) |
| ② | escape 경계 표본 5종(한글·emoji / 따옴표·역슬래시 / \n\t\b / \x1f / DEL) | 전부 수용 + **round-trip byte-identical** |
| ③ | kind 1 정책 요구 | `#h` 태그 없이 수용(community-global). NIP-42 인증은 필요 |
| ④ | round-trip byte 복원(저장 재조립 경유) | content 값 보존 확인 — Stage 0의 분해-컬럼 분석과 일치 |
| ⑤ | NIP-42 흐름 | 선제 challenge 관측 → kind 22242 AUTH(우리 직렬화+BIP-340) 수용 — **서명 상호운용 라이브 확인** |
| + | 변조 sig | `invalid schnorr signature` 거부 |
| + | 미지 kind 4242 | `restricted: unknown event kind` — allowlist 닫힘 라이브 확인(Stage 0 소스 분석 일치) |

Merkle proof 교차 대조는 Buzz 대상이 아님을 재확인한다(전역 순서는 우리 wrapping의
transparency log 소유 — Stage 0 문서 §5).

## 이 결과가 여는 것

- `hub_wire.py`의 후보 매핑(`nostr-wire-candidate/v0`)이 라이브 증거를 얻었다 —
  **wire profile pin(v1)은 3랩 final critic의 몫**이라 라벨은 아직 후보로 둔다.
- P1 잔여에서 남는 것: BIP-340 공식 벡터 전수(감사 라이브러리 대조 — 라이브 상호운용은
  이번에 확인), sealed coordination payload 설계, relay 저장소 동시성/CAS(스펙상
  우리 wrapping 층), UNPROVEN 목록(resolver·window·key history·unwind).

## 실사 중 잡힌 probe 자체 결함 (정직 기록)

1차 실사에서 판정이 한 프레임씩 밀렸다 — **Buzz는 클라이언트 CLOSE에도 `CLOSED` 확인
프레임을 보내는데** probe가 그걸 소비하지 않았고, 다음 판정이 그 잔여 프레임을 먹었다.
OK를 event id로 정확 매칭(`_await_ok`)하도록 교정 후 재실사 — 이 desync 관측 자체도
wire 계약의 발견이다(NIP-01은 CLOSE 확인을 요구하지 않으나 Buzz는 보낸다).

## Stage 1b — 3랩 크리틱 반영 후 최종 profile 라이브 (같은 날, r2)

3랩 회신(Orin W1–W4 BOUNDED REVISE · LxM 동치 스윕 63,504/0 + 영역 미강제 · Ludex 무이견)
반영 후 두 번째 라이브 창:

- **W1 조립**: 수신자 재서명 폐기 — v0.1 §2의 outer 서명을 **NIP-01 wire 서명으로 해석**.
  `hub_wire.admit_wire(hub, event)` = wire 검증(strict shape) → carrier 검사 →
  `HubIndex._admit_authenticated`(registry 결속→schema→policy→receipt). receipt가
  wire_event_id와 envelope event_id를 **둘 다 결속**(직접 경로는 wire null — 관측 없음).
  같은 봉투를 다른 created_at으로 재전송(wire id 상이) → 최초 event/seq/receipt로
  수렴·tree 불변(회귀).
- **W2 carrier pin**: kind 1 + exact `[["t","organum-hub-v1"]]`. **라이브 1건 성립**:
  publish OK → round-trip content byte-identical·tags/kind 보존 → **relay가 돌려준
  event 그대로 admit_wire 통과**(wire `43c69d3b…` / envelope `ce694183…` receipt 결속).
  증거 `stage1b-frames.jsonl`.
- **W3 strict shape**: id/pubkey hex64·sig hex128(lowercase)·tags list[list[str]]·
  content str + 65536B 보수 상한(relay acceptance limit 라이브 확인은 P1 잔여) ·
  carrier 아닌 kind/tags는 authority 인계 거부.
- **LxM 반영**: `allow_nan=False` + tags 계약을 **직렬화 경계에서 술어로 강제** —
  "선언된 동치 영역을 코드가 강제하지 않는다"의 폐쇄. NaN/Infinity가 bytes가 되는
  경로 소멸.
- **W4**: compose relay image를 관측 digest로 pin(재실행 동일 relay).

## 재현

colima start(캡) → `compose.yml`(digest pin) up → `probe.py`/`stage1b_probe.py` →
down -v → colima stop. 비용: VM 이미지 317M(1회) + 컨테이너 4개 실험 창 동안만. 상주 0.
