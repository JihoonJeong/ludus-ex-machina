# organ 효과 매트릭스 — 스키마 v0.1.1 (cross-lab canonical)

*organum이 초안을 호스팅한다(첫 데이터 shape를 쥔 쪽). Ludex가 GATED 면에서 리뷰로 왕복.
transfer-gate · soma/commons/field · 공통 어휘에 이은 **네 번째 공동 규율**. 2026-07-16 v0.1.1 동결
(Ludex GATED 리뷰의 수정 A[loadout 축]·B[delta는 cell] + 정직 플래그[action-selection both*] 반영).*

## 0. 무엇을 재나 (경계)

기존 AI 벤치는 **단독 능력**(SWE-bench 등, 격리)을 잰다. 빠진 축 = **역할×문제유형별 organ 유용성**과
**팀원 적합도**(단독 능력과 직교). organ 효과 매트릭스는 `(brain × role × problem-type) → organ 유용성`을
두 증거등급으로 채운다:

- **Ludex GATED-LIVE** — 통제·인과분리(role 고정, problem-type 순수변주). organ.card task_evidence 장부.
- **Organum dogfood RWE** — 생태타당성(실제 협업 세션), 단 harness×model confounded. observatory + 피어저널.

같은 벡터 스키마를 두 등급으로. "organ 붙임 ≠ 도움"을 측정으로 증명하는 게 목표(Taxis의 조건부·null·순손실).

## 1. observation row vs claim cell (분리)

과적합 방지는 문서가 아니라 **데이터 모양**이 한다. 그래서 관측 단위와 주장 단위를 분리한다.

**observation row** — 관측 단위(id = 세션/run):

```
{ session_id, brain, role, problem_type, loadout,
  joint_observed, effect_vector, evidence_grade, provenance }
```

- organum: 세션(role) + observatory(brain/model) + 피어저널이 이 row를 낸다.
- Ludex: GATED run도 같은 row (role="instrument" 고정, session_id=run id).

**`loadout` (수정 A — 매트릭스의 목적어를 row에 넣는다)**: `loadout: [organ, ...]` = 이 관측에
**붙어 있던 organ 집합**(BARE = `[]`). 매트릭스의 목적어는 *organ 유용성*인데, 이 필드가 없으면
어떤 row도 "어떤 organ이 붙었나"를 기록 못 하고 따라서 어떤 cell도 organ의 효과를 주장할 수 없다.
GATED에선 이게 정체성이다 — arm 라벨을 loadout으로 표현(BARE=`[]`, TAXIS=`["taxis"]`), 별도 arm
필드 불요. RWE 현 dogfood는 **전-organ 프리셋이라 loadout이 암묵적**이지만, 명시 필드로 두면
(a) confound가 데이터에 정직히 드러나고 (b) 미래 loadout-변주 dogfood가 스키마 변경 없이 들어온다.
**함의(정직)**: loadout 대조가 없는 등급은 organ 효과를 주장 못 한다 — 현 RWE는 loadout이 상수라
brain×role×problem_type **서술 셀**만 채우고, *organ 효과* 대조는 GATED(arm 보유)나 loadout-변주
dogfood가 나올 때까지 GATED-측이 낸다.

**claim cell** — 집계 단위(주장 키 = brain × role × problem-type × **loadout-대조**):

- rows의 집계 → 벡터 요약 + per-grade n. organ.card `task_evidence[]`가 이 claim cell의 카드 표현이다
  (task_shape ≈ problem_type, {method, n, measured_at, target_brain, role} = provenance 봉투 그대로,
  role 필드[기본 "instrument", ludex `11353f2`]; loadout 참조는 카드 organs[] 섹션과 잇는 고리 —
  Ludex가 organ-card v0에 반영 후속).
- **파생 필드 `contrast`(수정 B)**: `contrast: {vs: BARE, delta, n_a, n_b, exact_p}`. delta는 row가
  아니라 **cell의 것** — 단일 GATED run엔 raw score만 있고, delta는 같은 (brain×role×problem_type)에서
  loadout 대조(TAXIS−BARE)로 집계 때 파생된다(Ludex pre-reg +2.500, exact-p .0007이 이 모양).

## 2. 효과 = 다차원 벡터 (등급별 부분 채움)

단일 점수 아님. 등급에 따라 일부 차원이 빈다 — 그게 두 등급의 **정직한** 모습이다
(GATED row는 peer 비고, RWE row는 outcome.shipped만 채우고 score는 graded일 때만).

| 차원 | 필드 (row-level) | 원천 |
|---|---|---|
| `peer` | role_fit 축 벡터 · strength/friction 카운트 · would_pair_again(보조 플래그) | 피어저널 5필드 |
| `outcome` | `score`(raw, graded) · `shipped[]`(RWE 자기신고) | Kiln 채점 · session.shipped |
| `cost` | in/out tokens · tools · files | observatory |
| `process` | beats · human 개입(relay human→) · 복구(guard streak) | session.notes · guard |

**delta는 row 차원이 아니다(수정 B)**: `outcome.delta`를 row에 두면 안 된다 — 단일 GATED run엔
raw `score`만 있다. delta = claim cell의 `contrast`(§1)로 loadout 대조에서 파생. 같은 뿌리(arm/loadout
개념)의 두 증상이라 수정 A 없이는 B도 성립 안 한다.

## 3. peer 축 — 관측 행동으로 이름한다 (미덕 아님)

**축 = {execution, initiative, coordination, review, pacing}** (Round Two 서술에서 반복된 것).

축 이름은 **관측된 행동**을 말해야지 미덕을 말하면 안 된다. 미덕 이름은 행동 관측을 오독한다
(Ludex Forum `update_on_evidence`가 진실에서 *멀어지는* 이동에 1.0을 준 함정). 그래서:

- `initiative`: 관측된 자가시동 빈도 (❌ "leadership")
- `pacing`: 재촉↔신중 관측 위치 (❌ "patience")
- `execution`: 수행력 · `coordination`: 리드/합의 관측 · `review`: 비판적 검토 관측

**would_pair_again 포화 = 미덕-평정의 필연** (v0.1 축-명명 규율의 근거 문장). Round Two에서
would_pair_again 26건 중 True 24 / None 2 / False 0 — *의향/미덕* 평정이라 모두 예라 죽었다.
반면 execution/initiative 같은 **행동 관측 축은 변별한다**(strengths/frictions에서 세어지니까).
이는 Ludex의 명명 함정 발견과 **같은 통찰의 양면**: 축은 미덕이 아니라 관측 행동을 이름해야 산다
(우리 둘의 독립 발견이 서로의 설명이 된 사례).

실증: engine(Codex)에 대해 4 독립 평가자(tests·scribe·critic·spawner)가 "실행 강함, 리드/재촉 약함"에
수렴 → execution↑ · initiative↓ · coordination↓ · pacing=aggressive.

## 4. provenance 봉투

organ.card 규율 재사용 + 피어 버전 추가:

- `provenance 필수`(claim-level) · `null 보존`(전부-양성 셀 집계 = selection-suspect).
- `raters_n` · `convergent` — 교차-rater 수렴을 증거등급 부스터로(no-single-point의 피어 버전).
- **포화 강등 규칙**: 어떤 축이든 한 값이 >90%면 자동으로 보조 플래그로 강등(수동 발견의 규칙화).

## 5. problem-type taxonomy (+ measurable_by)

| problem-type | Ludex MUD 벽 대응 | measurable_by |
|---|---|---|
| discovery/navigation | discovery/reach (topos null 존, pre-reg) | both |
| sequential-dependency/**commit** (언제 확정하나·latch) | commit-timing 벽 (Taxis **+2.6**, v3/v4 존) | both |
| sequential-dependency/**execution-order** (어떤 순서로) | order-execution 벽 (Taxis **−0.33** 순손실, v6/v7 존) | both |
| seam/integration | (미측정 — 코딩-native) | rwe |
| spec-conformance | (미측정, MUD 필드 후보) | rwe |
| greenfield-generation | (미측정) | rwe |
| refactor/migration | (미측정) | rwe |
| action-selection (모호 상황 접근/도구 선택) | haiku-계보 벽 (**캠페인 관측만, 순수변주 존 미제작**) | **both\*** |

`both*` = **instrument-pending**(정직 플래그, Ludex GATED 리뷰): discovery·seq-dep/commit·seq-dep/order는
순수변주 존이 실존해 pre-reg 결과를 보유하지만, **action-selection은 캠페인에서 벽으로 관측만 됐고
순수변주 존이 아직 없다**. 그냥 `both`로 적으면 카드 규율의 *measured ≠ asserted*를 스키마가 어긴다.
LxM 필드 신작 큐에 등재(memory 존 다음 순번) — 존이 만들어지면 `both`로 승격.

**seq-dep 2분할이 핵심**: 병합하면 매트릭스에서 **가장 비싼 증거**(같은 organ, 반대 부호 — commit +2.6 /
order −0.33)가 지워진다. 코딩에서도 실재: /commit=조기-확정 실패(seam critic이 잡는), /execution-order=
마이그레이션 단계 순서.

## 6. joint_observed — 교란을 필드로 강제

worker 세팅에선 role이 problem-type을 함의한다(spawner→seam 등). 그래서:

- worker row `joint_observed=true` · GATED row `false`(role 고정·problem-type 순수변주).
- **집계기는 joint row에서 role 효과와 problem-type 효과를 분리 주장할 수 없다** — 주석이 아니라 필드로 강제.
- measurable_by=rwe인 유형을 both로 옮기는 경로 = MUD 필드 신작(LxM 채널).

## 7. organum 첫 조각 = brain↔role 조인 (SHIPPED · ACCEPTed)

observation row의 `role`·`brain` 연결 배관. 스키마 선-구현이 아니라 **계약된 row 필드셋의 배관**.
Codex critic 7라운드 적대 감사 통과(`c475aa0`, 2026-07-16). **동결된 조인 계약**:

- **canonical identity** — cell id는 ASCII `[A-Za-z0-9._-]` 1~40자, 선/후행 점 금지
  (format-v0 §0.1). `_forid`·`session start`·`init --agent` ingress 집행.
- **marker bridge** — transcript `ORGANUM_CELL=<id>` 마커를 **양쪽 경계 증명**(시작
  `(?<![A-Za-z0-9_])` · 종료 공백·따옴표·백슬래시)으로 잘라 raw 토큰 전체를 `valid_cell_id`로 판정.
  **direct(--for/env) · exact-unique-complete marker** 두 경로만 조인, 나머지 fail-closed.
- **cell-role-unique inference** — 한 cell의 모든 후보가 non-empty role이고 유일할 때만 role 귀속.
- **fail-closed provenance** — `join_method`(direct|marker|None) + `join_status` enum
  (joined · role-ambiguous · no-marker · marker-unknown · marker-ambiguous · scan-incomplete ·
  global-store-disabled · no-bridge). 오조인(false attribution) > 미조인이므로 애매하면 미조인.

관측 row 실물 필드: `{session_id, vendor, model, role, declared, intent, sid_declared, join_method,
join_status, in_tok, out_tok, cache, tools, skills, files_touched, origin, parent, first_ts, last_ts, …}`.
즉 **brain × role**은 이제 채워진다. 아직 emit되지 않는 계약 필드 = `loadout`·`problem_type`(다음 조각).
**첫 체크포인트(Ludex 합의)**: warren 다음 dogfood의 첫 row에 `loadout` 필드가 실려 나오는지 —
그게 v0.1.1 계약이 실사용에서 흐르는지의 검증이다.

## 8. 후속 (blocker 아님, 명시)

- `loadout` 필드 emit 배선 — 세션별 organ 집합 선언 기전(현 dogfood는 전-organ 프리셋이라 암묵 상수).
  loadout-변주 dogfood가 나와야 RWE가 *organ 효과* 대조를 낸다(그 전엔 서술 셀만).
- `problem_type` 축 배선(다음 조각) · effect_vector 집계기(claim cell `contrast` 파생) · raters_n/convergent 산출.
- OpenCode adapter-level `declared_hint`(세션-scoped 추출; 현재 global-store-disabled 안전 유지).
- roster/field ingress ID 검증 + legacy ID migration.
- Ludex 측: organ.card v0에 task_evidence↔organs[] loadout 참조 고리 반영.

---

관련: [[collaboration-template]] (§2.2 transfer-gate · §2.3 어휘) · organum-status ·
format-v0 §0.1 (cell id 계약) · ludex docs/organ-card-v0.md (GATED 면 · task_evidence.role).
