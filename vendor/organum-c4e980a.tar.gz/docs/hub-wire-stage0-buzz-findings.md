# hub wire Stage 0 — Buzz 소스 정독 결과와 wire 매핑 후보 (2026-08-15)

P1 잔여 "Nostr outer event byte 범위 대조"의 단계화(JJ 결정: Docker 상주 회피 —
소스 정독 → 컨테이너 1개 → 전체 스택) 중 **Stage 0**. 데몬 0으로 세울 수 있는 것을
전부 세웠다. 소스: `github.com/block/buzz` depth-1 클론(scratchpad, read-only —
호스트에서 빌드하지 않았다).

## 확인된 사실 (파일 근거)

1. **검증 경로**: relay는 ingest에서 `buzz_core::verification::verify_event`로
   event id 재계산 + Schnorr 서명 검증을 한다(`crates/buzz-relay/src/handlers/
   {event,ingest}.rs`, `crates/buzz-core/src/verification.rs`). CPU-bound라
   spawn_blocking로 돌리는 것까지 명시돼 있다.
2. **id 직렬화 authority**: rust-nostr **0.44** (workspace Cargo.toml). v0.44.0 태그
   원문의 `EventId::new`:
   `json!([0, public_key, created_at, kind, tags, content]).to_string()` → SHA-256.
   serde_json compact — 공백 없음·비ASCII 원문·escape는 `"` `\` + 제어문자.
3. **서명**: BIP-340 Schnorr, 메시지 = 32-byte event id 그 자체(재해시 없음).
4. **저장/재전달**: events 테이블은 분해 컬럼(`migrations/0001_initial_schema.sql`:
   content **TEXT**). event JSON bytes는 재조립돼 나가지만 content **문자열 값**은
   보존 — 검증이 값에서 id를 재계산하므로 우리 매핑이 성립한다.
5. **kind allowlist 닫힘**: `required_scope_for_kind`(handlers/ingest.rs)가 미지
   kind에 Err → 거부. 봉투 carrier는 기존 kind에서 골라야 한다.
6. **인증·수용 제어**: NIP-42 인증(사전 challenge) + rate limit admission +
   (옵션) pubkey allowlist. NIP-29 그룹 이벤트는 `#h` 태그 필수.
7. **NIP-AE engram**(kind 30174): 에이전트 메모리용 — NIP-44 암호화·HMAC d-tag.
   우리 evidence 봉투의 carrier가 아니다(암호화·replaceable·용도 불일치).

## carrier 결정 공간 (열림 — Stage 1 실측 대상)

- **30023(long-form) 부적합 확정**: addressable/replaceable(30000–39999) — 같은
  (pubkey, kind, d-tag)의 새 이벤트가 옛것을 **교체**한다. append-only 증거 위반.
- 후보: **kind 1**(TEXT_NOTE, regular — 기본 후보) 또는 **kind 9 + `#h`**(채널
  문맥이 필요할 때). ephemeral 범위(20000–29999)도 금지(저장 안 됨).
- Buzz의 kind별 태그/정책 검사가 kind 1에 뭘 요구하는지는 Stage 1 실측.

## 산출물

- `src/organum/hub_wire.py` — wire 매핑 **후보**(`organum-hub/nostr-wire-candidate/v0`):
  NIP-01 직렬화·event id·wire 서명·`extract_envelope`(wire 검증 → 봉투 bytes →
  `HubIndex.admit` 인계). **이중 서명 구조 명시**: wire 서명(NIP-01 id)은 transport
  수용의 조건, 봉투 서명(sha256(canonical bytes))은 authority의 조건 — relay가
  event를 재포장해도 봉투 authority는 불변.
- `tests/test_hub_wire.py` 15본 — 직렬화 모양(공백·비ASCII·escape 의미론)·id 결정론
  fixture(Stage 1 대조 기준점)·변조 거부·비UTF8 거부·**e2e**(봉투→wire→재직렬화
  시뮬레이션→봉투 복원→hub admit)·carrier 범위 pin.

## Stage 1이 재야 하는 것 (컨테이너 1개, on-demand)

1. **직렬화 동치의 라이브 확인**: 우리 fixture id로 만든 event를 Buzz relay가
   수용하는가(수용 = rust-nostr 재계산과 우리 계산의 일치 증명).
2. escape 경계 케이스 표본(비ASCII·제어문자·긴 content)의 수용/거부.
3. kind 1 carrier의 태그/정책 요구 + NIP-42 인증 흐름.
4. round-trip: EVENT 발행 → REQ 수신 → content 값의 byte 복원 확인(저장 재조립 경유).
5. (별도) Merkle proof 교차 대조는 Buzz가 우리 transparency log를 대체하지 않으므로
   relay 대상이 아니라 **우리 wrapping 층 구현 간 대조**다 — Buzz와 무관함을 명시.

## 정직 경계

- `hub_wire`는 **후보 라벨**이다. Python json.dumps ↔ serde_json 동치는 우리 값
  영역에서의 의미 분석이지 byte 실측이 아니다 — 실측이 Stage 1이다.
- Buzz 클론은 특정 시점 스냅샷(depth-1)이다. Stage 1 시점에 HEAD가 움직였으면
  재확인한다.
