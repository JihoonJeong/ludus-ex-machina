# graphify loadout-변주 과제 세트 v0 (warren · discovery/navigation)

*2026-07-27. organum 작성(측정 설계 소유), organum-code가 run 실행. 설계 합의:
`_relay/20260727-…-graphify-loadout-seam.md` + 그쪽 response(backend=Solar Open2 broker
경로·MCP run-scoped read-only·버전+artifact hash 핀·MVP 채점 없음·JJ_GO 게이트 $5).*

## 목적과 정직 경계 (선등록)

- 목적: ① organ-effect-matrix **첫 실제 loadout 대조**(graphify vs bare) ② Graphify
  "토큰 감소·성능 유지" 주장의 첫 독립 관측.
- **경계 1 — 소형 리포**: warren은 ~1–2K LOC. Graphify 자기 주장(20x 등)은 1M LOC 기준 —
  이 실험은 그 주장의 검증이 **아니라**, *우리 환경(소형 리포 dogfood)에서의 organ 유용성*
  측정이다. null/역효과도 정상 결과(P3 교훈: organ 효과는 환경-의존).
- **경계 2 — 관측적**: 1 brain × 1 backend × n=8, joint_observed. 인과·순위 주장 없음.
- **경계 3 — gate는 표면 사실 매칭**: required facts의 결정적 substring 매칭(대소문자
  무시)이라 judge가 없다. 심볼 나열만으로 통과 가능한 한계 명시 — 질문을 사실 나열형으로
  제한해 이 한계 안에서 정직하게 쓴다. coverage 채점은 phase 2(고정 judge).

## 프로토콜

- 두 arm 동일: 같은 질문 8개·같은 순서·같은 프롬프트 템플릿·같은 브레인(solar-open2)·
  같은 backend(Solar broker)·같은 예산. 차이는 **loadout뿐**(arm A=graphify MCP
  read-only 쿼리 가용, arm B=bare — MCP 부재).
- graph 사전 빌드: organum-code가 provisioning 시 1회(`graphify-out/` artifact hash 핀,
  두 run 공용·불변). 빌드는 결정적 AST(LLM 0)라 usage에 계상 안 됨(기록만).
- 각 run cell은 warren `.organum`에 세션 선언:
  `--loadout graphify|bare --problem-type discovery/navigation`.
- 프롬프트 템플릿(과제당 1 run, 신선한 세션):
  > warren 리포(현재 폴더)에 대한 질문이다. 코드를 탐색해 답하라. 답에는 근거가 되는
  > **파일명과 함수/클래스/심볼 이름을 반드시 명시**하라. 질문: {question}
- gate(과제당 pass/fail): 답변 텍스트에 required facts **전부** 존재(case-insensitive
  substring). 판정 스크립트는 organum이 제공(결정적).
- 측정: run별 observation/v1(usage: input/cache/requests·gate 결과를 outcome.checks로) →
  `observatory ingest` → `bench cells`가 loadout별 셀 대조 표시.

## 과제 8 (질문 · required facts — 전부 소스 실측 검증됨 2026-07-27)

| id | 질문 | required facts |
|---|---|---|
| T1 | 플레이어/몬스터 공격 데미지가 계산되는 순수 함수와 그것이 실제 적용되는 함수는? (파일·함수명) | `combat.py` · `resolve_damage` · `actions.py` · `apply_attack` |
| T2 | 몬스터 behavior 함수 세 개의 이름과 정의 파일, 그리고 매 턴 그것들을 실행하는 진입점 함수는? | `basic.py` · `idle` · `wander` · `chase` · `apply_monster_behaviors` · `game.py` |
| T3 | behavior가 반환하는 intent 타입 두 개와 그 정의 위치는? | `Move` · `Attack` · `input.py` |
| T4 | 새 몬스터 종류를 추가하려면 정의는 어디에 쓰고(데이터클래스 이름 포함), 스폰 배치는 어느 함수가 하나? | `monsters.py` · `MonsterDef` · `_populate` · `game.py` |
| T5 | 몬스터 이동 빈도와 추적 범위를 제어하는 파라미터 둘과 그것을 소비하는 함수(들)는? | `speed` · `aggro_range` · `_speed_allows_move` · `basic.py` |
| T6 | 키 입력이 게임 액션으로 변환·적용되는 경로를 함수 이름으로 추적하라 | `intent_for_key` · `input.py` · `try_move` · `actions.py` |
| T7 | 플레이어 사망 판정 함수와 그것이 턴 루프에서 확인되는 파일은? | `player_alive` · `game.py` |
| T8 | 맵은 어느 모듈의 어느 함수가 만들고, 게임 시작 시 어디서 호출되나? | `mapgen` · `generate` · `new_game` · `game.py` |

## 판정 스크립트

organum이 `scripts/graphify_task_gate.py`로 제공(결정적: 답변 파일들 + 이 표의 facts →
과제별 pass/fail + 요약 JSON). run 산출물 계약: 과제당 답변 텍스트 파일
`answers/<arm>/T<n>.md`.

## 산출 요약 (실험 후 organum이 작성)

arm별: gate pass k/8 · Σinput · Σcache · 캐시효율 · Σrequests · 소요. **나란히 표시,
합산·판결 없음** — "토큰 감소" 축은 usage 대조로, "성능 유지" 축은 gate 대조로 각각 서술.
bench cells의 varied 셀 스크린샷/출력 포함(매트릭스 첫 대조 기록).
