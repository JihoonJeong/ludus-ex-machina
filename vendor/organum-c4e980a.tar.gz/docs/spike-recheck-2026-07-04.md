# Spike 재검증 — Claude Code 비대화형 위임 (CLI 2.1.201)

*2026-07-04, Organum Cody. HANDOFF §6-5. 원본: `reference/agent-grid_spike_claude_code_wrap.md`
(2026-04-16, CLI 2.1.110 기준). 이 문서는 델타만 기록한다 — 원본 레시피는 아래 명시된 것 외에
그대로 유효하다.*

## 환경

```
claude --version  →  2.1.201 (Claude Code)
node v22.16.0 · macOS Darwin 25.5.0
```

## 결론

**레시피 유효.** 원본 표의 핵심 플래그 23종 전부 현행 CLI에 존재
(`-p/--print`, `--output-format`, `--include-partial-messages`, `--verbose`, `--input-format`,
`--max-budget-usd`, `--permission-mode`, `--allowed-tools`, `--disallowed-tools`, `--add-dir`,
`--no-session-persistence`, `--session-id`, `--resume`, `--mcp-config`, `--strict-mcp-config`,
`--bare`, `--system-prompt`, `--append-system-prompt`, `--model`, `--effort`, `--fallback-model`,
`--json-schema`, `--setting-sources`). stream-json 이벤트 타입도 원본 표와 일치
(system.init → system.status → rate_limit_event → stream_event.* → assistant → result).

## 델타 (2.1.110 → 2.1.201, 라이브 검증)

### 1. result JSON에 필드 추가

성공 응답 top-level에 추가: `uuid`, `fast_mode_state`, `ttft_ms`, `ttft_stream_ms`,
`time_to_request_ms`, `api_error_status`. `usage`에 추가: `cache_creation`(오브젝트),
`inference_geo`, `iterations`, `server_tool_use`, `speed`. — 리더는 미지 필드 관용이면 무해.

### 2. 예산 abort의 응답 구조 (위임 모듈 필수 처리)

`--max-budget-usd` 초과 시:

```json
{"subtype": "error_max_budget_usd", "is_error": true,
 "errors": ["Reached maximum budget ($0.001)"], "terminal_reason": null}
```

- **`result` 키 자체가 없다** — `.result` 접근 전에 `is_error` 분기 필수.
- organum 함의: distill/reflect 위임이 abort로 끝나면 산출물이 없거나 부분물이다 —
  **guard의 `error-fallback` 규칙이 이 경로의 영속화를 차단해야 한다** (format-v0 §7과 연결).

### 3. 콜드 캐시 비용 ≠ 웜 캐시 비용 — 캡 설정 주의

동일한 트리비얼 호출("What is 2+2?")이 **콜드 캐시 $0.12 / 웜 캐시 $0.055**로 2배 이상 차이.
원본 spike의 "$0.05"는 웜 기준이었다. 실측: 캡 $0.10이 콜드 캐시에서 트리비얼 호출을 abort시킴.
→ **캡은 콜드-캐시 기준으로 산정**: 트리비얼 위임도 최소 $0.25, distill급 작업은 $1.00+ 권장.

### 4. `--verbose` gotcha는 유지, 에러 메시지는 개선

`stream-json` + `--include-partial-messages`에 `--verbose` 누락 시 여전히 실패하지만,
메시지가 명확해짐: `Error: When using --print, --output-format=stream-json requires --verbose`
(구: "Input must be provided" 라는 오해 소지 메시지). 레시피의 "--verbose 필수"는 그대로.

### 5. stream-json 세부: `assistant` 이벤트는 블록 단위 interleave

원본 표는 `assistant`를 "완성된 message (delta 합산본)"로 기술했지만, 현행은 content block마다
`content_block_delta` 직후 `assistant` 이벤트가 끼어든다. 최종본만 원하면 `result` 이벤트를
쓰는 것이 안전.

## 재검증하지 않은 것 (P2 위임 모듈 구현 시점에)

- `--bare` + `ANTHROPIC_API_KEY` 동작 (auth 격리 — ludex `_cli_env.py` 패턴과 함께 검토;
  과금 사고 예방이 목적이므로 라이브 검증은 API 키 준비된 환경에서)
- `--json-schema` 구조화 출력 (distill 템플릿 강제에 후보)
- 멀티턴 도구 사용 시나리오 (원본 시나리오 2 상당 — 비용상 생략, 플래그 표면은 확인됨)
- `--mcp-config` / `--strict-mcp-config`

## 라이브 검증 비용

트리비얼 4회 + abort 1회 ≈ $0.35 메터링 표시 (Max 구독, 실청구 0).
