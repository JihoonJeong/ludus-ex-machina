# Loop Engineering ↔ organum — 리서치 노트

*2026-07-10, Organum Cody. 목적: 현재 loop engineering 베스트 프랙티스를 확인하고 organum에
접목할 부분을 판정. **아래 "loop engineering 사실"은 인용 출처, "매핑/판정"은 내 분석.**
빠르게 움직이는 2026 토픽이라 수치·명명은 재확인 필요.*

## 1. Loop engineering이란 (출처 검증)

2026-06 Addy Osmani(Google Chrome)가 명명, 흩어져 있던 실무를 구조화. 사다리:
**prompt → context → loop → harness**. loop = 에이전트가 그 안에서 도는 *주기*(툴콜 사이 무엇을,
언제 자기 점검, 언제 완료 판정). Cherny: "나는 이제 Claude에 프롬프트하지 않는다. 루프가 돌고,
그 루프가 Claude에게 프롬프트한다."

- **loop 타입 4종**: heartbeat(짧은 주기 연속) · cron(스케줄) · hook(이벤트: PR/CI) · goal(성공
  조건까지 반복 후 정지). 트리거로는 event / scheduled / human(`/loop`, `/goal`).
- **핵심 원리: "verifier가 병목이지 모델이 아니다."** 루프는 검증가능·결정적 목표를 요구.
  자동 검증(테스트/타입/커버리지) 없으면 LLM 자기평가에 의존 → 불신뢰.
- **Ralph Loop**: 매 반복마다 컨텍스트 리셋 + **상태를 디스크에서 읽음**(코드베이스·TODO 파일·
  git 히스토리). 토큰 누적 대신 파일시스템에 상태 지속 → 깨끗한 리셋.
- **Stop Hook**: 조기 종료 가로채기 → 완료 기준(테스트 통과·커버리지·타입) 실제 충족 검증 →
  미충족이면 태스크 재주입.
- **실패 모드**: 무한 루프 · goal drift · context overflow · silent failure(툴콜 실행되나
  진전 0) · 토큰 폭발(loopmaxxing) · 오류 전파 · local minima · **comprehension debt**(무인
  코드 수정이 인간 리뷰를 앞질러 코드베이스가 미지도화).
- **가드레일**: 하드 반복 상한 · 예산을 **실행 전** 강제 · no-progress 감지(상태 불변 시 종료) ·
  재시도 서킷브레이커 · 완료 기준은 자동검사(자기평가 아님) · 비가역 행동 전 인간 리뷰.
- **단계적 접근**: 인간-in-loop → 결정적 종료 → 정체 서킷브레이커(3연속 무진전 경보) →
  **distill and demote**(반복 행동을 확률적 프롬프트 층에서 컴파일된 스크립트로 강등).
- **CLAUDE.md 패턴**: 인간-큐레이션 지속 기억이 자동생성 기억보다 신뢰됨 — "무엇이 세션을
  넘어 남을지 인간이 결정"하기 때문.

출처: [freeacademy](https://freeacademy.ai/blog/loop-engineering-beyond-prompt-engineering-ai-agents-2026) ·
[bdtechtalks](https://bdtechtalks.com/2026/06/22/ai-loop-engineering/) ·
[datasciencedojo](https://datasciencedojo.com/blog/agentic-loops-explained-from-react-to-loop-engineering-2026-guide/) ·
[tosea.ai](https://tosea.ai/blog/loop-engineering-ai-agents-complete-guide-2026)

## 2. organum의 위치 (판정)

사다리상 organum(organism)은 loop보다 **위**다. 그러나 관계는 경쟁이 아니라 **공생**이다:
**organum은 루프가 읽고/쓰는 규율 있는 지속 상태다.** Ralph Loop의 "디스크에서 상태 읽기"는
*무엇을·어떻게*가 비어 있는 일반 원리고, organum이 그 빈칸을 채운다 — 분화된 상태(정체성·기억·
세계모델·지도·면역)와 규율(guard·형태 강제·carry-forward). loop engineering이 "verifier가
병목"이라 말할 때, organum은 그 verifier+상태 기질(substrate)이다.

## 3. 매핑

### A. 이미 organum에 있다 (수렴 = 독립 도달한 설계 검증)

| loop engineering 원리 | organum 대응 |
|---|---|
| Ralph Loop "상태를 디스크에서" | `.organum/` 자체 — cargo-bridge가 파일시스템-상태로 cross-session 지속 실증. organum은 *구조화된* Ralph 기질 |
| "verifier가 병목" | guard(저장 경계)·checkup·wm-shape(형태 강제)·측정≠주장 규율. P3 파일럿-먼저(nuisance 후 confirmatory)도 같은 본능 |
| distill and demote | 경계 규율 그 자체 — guard 규칙=데이터, 형태 템플릿, migrate를 확률층에서 결정적 코드로 강등. `distill` 명령은 문자 그대로 이것 |
| no-progress / 정체 서킷브레이커 (3연속) | streak window guard(§7.2, 연속 5회 차단→위임 거부). ludex와 독립 수렴, 이제 loop 베스트 프랙티스가 명명 |
| 예산을 실행 전 강제 | delegate.py의 콜드캐시 예산 바닥 + max-budget-usd |
| 인간-큐레이션 기억(CLAUDE.md) | carry-forward(reflect, 항목은 에이전트/인간 결정) + guard(무엇이 남을지 필터). organum은 완전-자동도 완전-수동도 아닌 규율 있는 중간 |
| context가 매 주기 보는 것 관리 | `organum context` 주입 블록이 곧 그것 |

**함의**: 이 수렴들은 organum 설계가 옳은 방향이라는 독립 증거다. loop 커뮤니티가 지금 성문화하는
원리들을 우리는 organism 렌즈에서 먼저 도출했다 (streak·distill-demote·verifier-first).

### B. 배울 갭 (organum이 채택할 수 있는 것 — 경계 안)

1. **comprehension-debt frontier (진짜 학습거리).** loop 실패 모드 "무인 수정이 리뷰를 앞질러
   코드베이스 미지도화"의 해독제가 정확히 organum의 map/frontier다 — 단 현재 map은 *에이전트가
   읽은 것*을 추적하지 *루프가 바꿨는데 인간이 안 본 것*은 추적 안 한다. checkup의 sha-drift가
   그 절반(read-marked 파일 변경 감지)이니, **"루프-수정·인간-미리뷰" frontier로 확장**하면
   loop 시대의 명명된 실패 모드에 직접 답한다. 작고, 경계 안(상태 추적이지 오케스트레이션 아님).
2. **Ralph-Loop 통합 레시피 (문서/포지셔닝).** organum이 Ralph Loop에 어떻게 꽂히는지 문서화:
   루프 시작=`organum context` 주입, 반복 경계=`organum remember`/`reflect`, stop-hook 진전
   신호=`organum checkup`(streak·drift). 새 오케스트레이션 0줄 — 트렌딩 패턴의 *상태 층*으로
   organum을 위치. P4 related-work의 강한 재료.

### C. 명시적 스코프 밖 (경계 규율 — 오케스트레이션 층)

- **루프 자체**(heartbeat/cron/hook/goal 실행·반복 상한·서킷브레이커·재시도) = 오케스트레이션.
  헌법이 금지하는 바로 그것. loop 타입 4종은 **플랫폼-네이티브**로 이미 존재한다 — Claude Code의
  `/loop`·`/schedule`·hooks. organum이 루프 러너를 지으면 **agent-grid 함정 재연**(플랫폼이
  흡수하는 층을 만듦). organum은 루프가 읽는 상태지 루프가 아니다.
- 멀티에이전트 loopmaxxing — 스코프 밖, loop engineering 스스로도 경제적으로 경고.

## 4. 판정 요약

- organum은 loop engineering을 **대체하지 않고 완성한다**: 루프의 "verifier가 병목·상태를
  디스크에서"가 organum의 존재 이유를 외부에서 재확인한다.
- **채택 권고 2 (경계 안)**: (1) comprehension-debt frontier — map을 "루프-수정·미리뷰"까지
  확장, (2) Ralph-Loop 통합 레시피 문서.
- **명시적 비-채택**: 루프 러너/스케줄러/서킷브레이커 — 플랫폼-네이티브, agent-grid 교훈.
- 전략: 트렌드가 뜨거워도 배관을 짓지 않는다. organum은 루프가 소비하는 *규율 있는 상태*로
  남는다 — 그게 흡수되지 않는 자리다.

## 5. Essay 씨앗 — Orchestration vs Coordination (JJ 2026-07-16, 미래 미션리포트/블로그)

*완성 산문 아님. 나중 필자가 펼칠 뼈대. 논지: orchestration↔coordination이 loop↔organism의
가장 큰 철학적 차이라는 주장을 세운다.*

**뿌리 = 제어(control)가 어디 사는가.**
- Orchestration: 제어가 행위자들 *위*에. 오케스트레이터 루프가 상태를 쥐고 서브에이전트를
  함수처럼 호출·await·라우팅. 에이전트 = 누군가의 루프 안 한 스텝.
- Coordination: 제어가 행위자들 *안*에. 각 셀이 자기 루프를 돌리고 가운데엔 매체+계약만.
- **파생 논증**: organism의 기관 전부(기억·분화·면역·조율)가 "coordination을 골랐다"의 귀결.
  제어가 위면 에이전트는 덧없는 함수콜 → persist·분화 불필요. 제어가 안이면 셀은 반드시
  지속(자기 상태를 자기가)·분화(지속할 self)·조율(아무도 안 라우팅)해야 함. → 여러 차이 중
  하나가 아니라 뿌리.

**기술 척추 = sync/async** (cf. [[coordination-architecture-principle]]).
- Orchestration은 본질 동기(리턴 await → 제어흐름은 루프 모양). Coordination의 기본은 비동기
  (post/pull = stigmergy)지만 **sync를 배제하지 않는다.** 핵심 구분: **sync ≠ orchestration** —
  인간도 지시는 async로 받되 전화·회의로 sync 도움을 받고, 그 sync는 오케스트레이션이 아니다
  (대화 후 각자 자기 루프로). sync는 transport 성질, orchestration은 control 거주지.
- 그래서 essay 질문은 "sync를 막나"가 아니라 **"제어를 셀 안에 둔 채 sync를 어떻게 어답트하나."**
  전략 = 표준 추적(A2A의 task+streaming · Claude Discord 채널 등)하며 굳으면 field transport로
  흡수. 답: 비동기=지속 substrate / 동기=에이전트가 고르는 fast-path(강제 아닌 선택, 대체 아닌
  추가). cf. [[coordination-architecture-principle]].

**정직한 긴장(승리주의 방지).** orchestration이 지배적인 건 효율적·명료해서(컨트롤러 하나는
추론 쉬움). coordination은 수렴 느림·표류·데드락(warren seam 버그·"셀 언제 멈추나" 갭). 그
세금을 낼 값어치 증명이 필요.

**착지(해자).** Orchestration은 플랫폼이 흡수한다(agent-grid가 그렇게 죽음 — 그 층을 플랫폼이
먹음). 축적된 coordination 상태 + **측정된 팀워크**(협업벤치)는 흡수 못 함. 오케스트레이션=커모디티,
조율-substrate=살아남는 자리. 헌법("흡수될 걸 만들지 마라")을 철학 명제로 승격.

**한 줄.** Loop engineering=하나의 루프를 더 똑똑하게. Organism engineering=루프들 사이에 무엇이
쌓이고 셀들이 시간을 건너 어떻게 응집하나. orchestration=전자의 멀티에이전트 확장(루프가 루프를
부른다), coordination=후자(루프들이 매체로 스스로 만난다). = loop↔organism의 기술적 지문.

**핵심 문장(Codex live-transport 조사 2026-07-16 다듬음, 내 것보다 정확):**
> organum의 비동기 field는 지속되는 진실이고, live transport는 cell이 선택하는 저지연 투영이다.
> 연결이 생겨도 제어는 cell 안에 남으며, 연결이 끊기면 **정확성이 아니라 속도만 잃는다**.

마지막 절이 곧 **disable test**의 시적 판본 — "끊겨도 정확성은 그대로, 지연만 는다"를 통과 못
하면 transport가 아니라 orchestrator다. essay는 "sync"를 쓰지 말고 **live delivery**로(sync=blocking
RPC/persistent conn/low-latency 세 가지 혼재, 우리 것은 뒤 둘). cf. [[coordination-architecture-principle]].
