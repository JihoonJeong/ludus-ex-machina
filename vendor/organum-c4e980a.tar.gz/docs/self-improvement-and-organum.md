# Self-Improving Agents ↔ organum — 리서치 노트 + 발전 방향

*2026-07-10, Organum Cody. 목적: self-improving/self-evolving agents 지형을 확인하고 organum의
발전 방안을 도출. **"분야 사실"은 인용 출처, "매핑/판정/방향"은 내 분석.** 빠르게 움직이는
2026 프런티어라 명명·수치 재확인 여지 있음.*

## 1. 분야 지형 (출처 검증)

**self-evolving agents taxonomy** (서베이 arxiv 2507.21046): 무엇을 진화하나 × 어떻게 구동하나.
- **무엇을 진화하나 (4 기둥):** (1) 모델 가중치(policy), (2) 컨텍스트=프롬프트+메모리,
  (3) 도구/스킬, (4) 아키텍처(멀티에이전트 구조).
- **결정적 분할 — component-level vs policy-level:**
  - **component-level (비-파라미터)**: 메모리·프롬프트·도구를 *test-time*에 진화. 재학습 없이
    "런타임 컨텍스트가 행동 생성에 직접 영향". 
  - **policy/weight-level (파라미터)**: gradient/RL로 모델 가중치 갱신 (SWE-RL 등 자가-플레이).
- **메모리 = 근본 인프라, "가장 저탐색된 기둥":** 계층 메모리(MUSE: 전략/절차/도구-사용 기억),
  구조적 망각(SAGE: Ebbinghaus 곡선), **경험 증류(ExpeL·ReasoningBank: 원시 궤적이 아니라
  일반화된 지침으로 증류)**, ADD/MERGE/DELETE 파이프라인(Mem0).
- **Voyager (2023)**: **가중치 업데이트 0으로 평생학습** — 재사용 가능한 코드 스킬을 라이브러리에
  축적. 스킬=검증된 코드 스니펫, 설명 임베딩으로 저장·검색. 루프: 생성→실행→오류 관찰→수정.
  자가진화 스킬 라이브러리 = 실행 + **자동 품질평가 + 라이브러리 유지**.
- **⚠ 안전 (서베이 §8.3 "Emergent Risks", 완화책은 희박):** 오류 누적(자기 궤적 학습이 실수를
  복리로), reward hacking(자가-생성 보상은 외부 검증 결여), **자기 메모리/목표 수정 시 오정렬**.
  완화는 "verification 의존 + 멀티에이전트 교차검증 + 점진 자율" 정도, "misalignment when
  modifying own memory/objectives"는 **명시된 미해결 갭**.

출처: [Survey (arxiv 2507.21046)](https://arxiv.org/html/2507.21046v4) ·
[Awesome-Self-Evolving-Agents](https://github.com/XMUDeepLIT/Awesome-Self-Evolving-Agents) ·
[Voyager](https://openreview.net/forum?id=ehfRiF0R3a) ·
[o-mega 2026 guide](https://o-mega.ai/articles/self-improving-ai-agents-the-2026-guide)

## 2. organum의 위치 (판정)

**organum = component-level 자기개선 인프라 — 구체적으로 메모리+경험+규율 층.** 헌법(가중치
안 건드림·오케스트레이션 없음·상태와 규율)이 곧 component-level 트랙에 대한 *원칙적 커밋*이다.
서베이가 "메모리는 가장 저탐색된 근본 인프라"라 할 때, organum은 그 빈 자리에 서 있다.

## 3. 매핑

### A. 수렴 = 설계 검증 (우리가 프런티어 핵심 수를 독립 도달)

| 분야 프런티어 | organum 대응 |
|---|---|
| component vs policy 분할 | 헌법이 component-level 선택 — "런타임 컨텍스트가 행동에 직접 영향"=`organum context` 주입 |
| 기억의 계층/분화 (MUSE 전략/절차/도구) | 1-2 기억의 분화 (선언/시간/공간/절차 다른 경로) — 이미 |
| 경험 증류 (ExpeL/ReasoningBank: 원시 궤적→일반 지침) | `distill`이 문자 그대로 이것 (세션→Map/Frontier/Claims). **+ form-first 규율**(prose=효과0)은 그들 증류에 없는 것 |
| 구조적 망각 (SAGE/Ebbinghaus) | consolidate + confidence tier — 부분 대응 (decay 정책은 아직, §4-B 학습거리) |
| Voyager: 가중치 0 평생학습, 상태 축적 | organum의 명제 그 자체 — 단 스킬만이 아니라 분화된 organ 전체로 일반화 + 돌봄 의례 |

**함의**: "메모리 인프라가 2026 자기개선의 중심 도전"이라는 분야 합의가 organum 명제를 밖에서
확증한다. 우리는 organism 렌즈에서 프런티어 핵심 수(증류·분화·상태 축적)를 먼저 도달했다.

### B. ⚠ 안전 = organum의 최강 차별점이자 진짜 진보 (분야의 명시된 갭)

서베이가 인정하는 미해결 위험 — **오류 누적(자기 궤적이 실수를 복리로)·자기 메모리 수정 시
오정렬** — 이 정확히 organum guard/immune organ의 홈그라운드다:
- "[Error: timed out]이 영속 기억이 되어 행동 오염"(우리 실사고) = 서베이의 "오류 누적" 그 자체.
  organum의 **저장 경계 guard가 그 미해결 위험의 구현된 답**이다.
- 자기개선은 이 위험을 **증폭**한다: 자기 메모리/스킬을 오염시키는 자기개선 에이전트는 세대를
  넘어 오류를 복리한다. 그래서 immune organ은 nice-to-have가 아니라 자기개선이 *요구하는데
  분야가 없다고 인정한* 바로 그 안전 인프라다.
- organum의 자세는 안전을 설계에 내장: carry-forward는 에이전트/인간 결정 + guard 필터(자율
  목표수정 아님), 돌봄 의례(인간-in-loop), streak/checkup. 서베이의 "misalignment when
  modifying own objectives" 갭을 **자율 목표수정을 안 함으로써 회피**한다.

### C. 코드 생성의 정당한 자리 (지난 논의의 재조명)

지난 턴 결론(codegen 엔진 내장=NO)은 유지. 그러나 self-improvement 렌즈가 코드생성의 *올바른*
자리를 준다: **organum이 codegen 엔진이 아니라, 자기-생성 스킬이 축적되는 규율 있는 cargo.**
- Voyager/도구-진화 = 외부(사용자 CLI=delegate)가 생성한 코드가 *상태*로 축적. organum은 생성
  안 하고 그 라이브러리를 guard·map·version·consolidate 한다.
- **cargo-bridge와 직결**: 자기개선 에이전트의 스킬 라이브러리 = `.organum`-형 축적 상태. Agent
  Skills(운송)+organum(화물) 구도가 이미 자기-생성-스킬 축적의 기질(substrate)이다.
- 서베이의 "자가진화 스킬 라이브러리 = 자동 품질평가 + 라이브러리 유지" = organum의 guard(저장
  품질 게이트) + consolidate/reflect(유지) + checkup(건강) + map(무엇이 있나/stale). organum은
  스킬-진화 문헌이 필요로 하는 **라이브러리 유지 층**이다.

### D. 스코프 밖 (경계 규율)

- **policy/weight-level (RL·SWE-RL·파인튜닝)** — 가중치는 안 건드린다. 브레인은 벤더가 개선,
  organum은 organism 상태.
- **아키텍처 진화 (MAS-Zero·AFlow 워크플로 생성)** — 오케스트레이션, 플랫폼-흡수.
- **자율 목표/보상 수정** — 의도적 비-채택(안전). caretaker가 루프에 남는다.

## 4. 발전 방향 (본 리서치의 실질 산출 — 순위)

1. **포지셔닝: "규율 있는 자기개선 — component-level, safety-first 트랙".** 분야가 패러다임을
   검증(Voyager·메모리-인프라), organum의 차별점은 *규율*(guard/immune·form-first·의례) = 분야가
   인정한 안전 갭. **개념 문서·related-work·P4의 강한 재료.** 능력 경쟁(스킬 축적)은 남들이
   하게 두고, **자기개선의 안전/규율을 소유**하는 게 가장 설득력 있는 전략 — "에이전트가 자기를
   오염시키지 않고 개선하려면?"의 레퍼런스.
2. **학습거리(경계 안): 경험 증류 + 망각 정책.** 서베이의 구조적 망각(SAGE/Ebbinghaus)·계층
   증류를 organum이 부분만 함. confidence tier가 있으니 **stale tentative 기억의 decay/강등
   정책**(consolidate 확장)이 자연스러운 in-boundary 기능. distill의 form-first에 recency/신뢰
   가중을 더하는 것도.
3. **스킬-라이브러리-as-cargo 방향.** cargo-bridge를 자기-생성 스킬 축적+큐레이션 층으로 확장
   구상 — 코드생성 실의 정당한 귀결. 설계 방향(빌드 지금 아님).
4. **P3와의 연결**: 우리 P3(organ이 코딩 실무를 돕나)의 effort-축 null 관찰조차 이 프레임에서
   값지다 — "organ 이득은 환경-의존"이 곧 "self-improvement 이득도 도메인/환경 의존"의 증거.

## 5. 판정 요약

- organum은 self-improvement 프런티어의 **중심(메모리 인프라)**에 이미 서 있고, 분야가 인정한
  **안전 갭(자기-오염/오정렬)을 guard/immune으로 메운다.** 이게 우리의 가장 큰 미개발 자산.
- 네 직관("브레인이 세지면 자동 해결")의 재확인: 분야는 policy-level(브레인)과 component-level을
  나눴고, **메모리 인프라·안전 규율은 브레인 능력과 직교하며 근본**이라 못 박았다 — 즉 흡수 안 됨.
- 코드생성의 자리 = 엔진이 아니라 자기-생성 스킬의 규율 있는 축적(cargo). 지난 결론과 정합.
- 비-채택 유지: 가중치·아키텍처 진화·자율 목표수정.
