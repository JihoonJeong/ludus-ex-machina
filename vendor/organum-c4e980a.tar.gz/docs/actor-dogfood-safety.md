# Actor/harness dogfood 안전 규율

*organum은 읽기전용 substrate다. 실행 위험은 전부 **actor(하네스)** — OpenCode·Claude Code·Grok
Build 등 — 에 있다. dogfood 안전 = actor를 격리 + organum의 core-integrity 감시로 탐지. organum은
실행자가 되지 않는다.*

발단: OpenCode 보안 리뷰(wren.wtf, 2026-07)가 actor 계층의 실행 위험을 드러냄 — Bash 권한 필터가
문자열/AST 기반이라 `echo git|bash`·python subprocess·base64·redirect로 우회(theater), remote-first
기본연결(첫 메시지에 cwd glob→POST), `curl|bash` 자체업그레이드, 과거 HTTP 서버 RCE(CVE-2026-22812),
무격리 npm(공급망). organum-code가 이 때문에 arch를 **멀티-하네스**(OpenCode → +Claude Code·Grok
Build)로 재설계 + 안전대책 중. 아래 규율은 **모든 actor**에 적용된다.

## 1. organum의 경계 (불변)

- opencode.db·transcript 접근은 **전부 읽기전용**(`?mode=ro`). 관측 경로(adapters/observatory/
  roster/web)에 subprocess/exec/eval **0** — transcript 내용을 실행하지 않는다.
- dispatch·spawn·model-client·bash-exec **0**(헌법). organum의 직접 노출은 아키텍처적으로 최소.
- **함의**: 위험은 organum이 아니라 dogfood가 태우는 **actor**에 있다. 그러니 격리 대상은 actor다.

## 2. dogfood 격리 요건 (actor마다)

- 실행 셀(solar-oc·claude-code·grok-build …)은 **OS 수준 격리**로만 돌린다: `.git` 읽기전용 ·
  프로젝트 밖 실행파일 차단 · 파일시스템 confinement(Landlock/Seatbelt/이빨 있는 컨테이너) ·
  불필요한 인터넷 접근 차단.
- **맨 머신에서 실 크레덴셜·데이터와 함께 무격리 실행 금지.**
- **문자열/AST 권한 필터를 안전장치로 신뢰하지 않는다** — OpenCode 리뷰가 우회를 실증. 격리는
  OS 수준이어야 한다(필터는 모델 유도용이지 보안 경계가 아님).
- **선례**: measurement-grade replay는 이미 샌드박스였음(localhost bind `EPERM` = 하네스 샌드박스
  작동 증거). 그 바(bar)를 유지.

## 3. organum의 보완 역할 = 탐지

- **core-integrity 감시**(observatory/checkup/inspector)가 **미귀속 core 쓰기**를 탐지 — 약한 actor
  경계가 여는 Memory Injection 벡터. `docs/memory-surveillance-v0.md`.
- **정직 경계**: 감시는 **탐지지 예방·판결 아님**(raw shell은 못 막음). 예방 = actor OS 격리 /
  탐지 = organum. **둘 다 필요**. OpenCode 리뷰가 "문자열 필터로 예방 불가"를 실증해 이 분업이 옳음.
- **실천**: dogfood 세션 후 `observatory sync`·`checkup` 실행 → 정당한 core 변경은 bless, 미귀속
  drift는 조사.

## 4. 하네스별 위험 메모 (living)

| 하네스 | 위험 | 상태 |
|---|---|---|
| OpenCode | 높음 — 문서화된 RCE·필터 theater·remote-first·npm 무격리 | organum-code 하드닝 중 |
| Claude Code CLI | 미평가 — 붙일 때 프로파일 작성 | 예정 |
| Grok Build | 미평가 — 붙일 때 프로파일 작성 | 예정 |

## 5. 헌법 리마인더

이 문서의 존재 이유: organum이 **dogfood를 편하게 하려고 actor 책임을 흡수하면 안 된다**. "사용자
대신 그냥 실행해주자"의 모든 유혹이 actor의 공격면으로 가는 한 걸음. organum은 substrate로 남는다.
관측은 읽기전용, 실행은 격리된 actor, 무결성은 감시로 — 세 역할을 섞지 않는다.
