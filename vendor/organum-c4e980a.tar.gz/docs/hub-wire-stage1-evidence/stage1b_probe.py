#!/usr/bin/env python3
"""Stage 1b — **최종 carrier profile**(kind 1 + [["t","organum-hub-v1"]])의 라이브 1건.

Orin 재판정 조건 3: AUTH의 tags 수용은 kind 1의 custom tag 정책을 대신 증명하지 않는다 —
최종 kind+tags profile 그대로 publish/round-trip 1건. build_wire_event 기본값(=carrier
profile)을 그대로 쓴다. 전 프레임 verbatim 기록.
"""
import asyncio
import hashlib
import json
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(Path.home() / "Projects" / "organum" / "src"))
import websockets  # noqa: E402

from organum import hub_envelope as he  # noqa: E402
from organum import hub_log as hl  # noqa: E402
from organum import hub_wire as hw  # noqa: E402
from organum import schnorr_pure as sp  # noqa: E402

RELAY = "ws://localhost:3000"
SEC = hashlib.sha256(b"organum-hub-stage1-experiment-key-2026-08-15").digest()
PUB = sp.public_key(SEC).hex()
EVIDENCE = HERE / "stage1b-frames.jsonl"
_frames = []


def _log(direction, frame):
    rec = {"t": time.time(), "dir": direction, "frame": frame}
    _frames.append(rec)
    with EVIDENCE.open("a", encoding="utf-8") as f:
        f.write(json.dumps(rec, ensure_ascii=False) + "\n")


async def _send(ws, msg):
    _log("out", msg)
    await ws.send(json.dumps(msg, separators=(",", ":"), ensure_ascii=False))


async def _recv_until(ws, pred, timeout=10):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            msg = json.loads(await asyncio.wait_for(ws.recv(), max(0.1, deadline - time.monotonic())))
        except asyncio.TimeoutError:
            return None
        _log("in", msg)
        if pred(msg):
            return msg
    return None


async def main():
    EVIDENCE.write_text("", encoding="utf-8")
    env = {"envelope_schema": he.ENVELOPE_SCHEMA, "event_kind": "message.read",
           "signer": {"id": "lab:organum-cody", "key_id": "stage1", "key_epoch": 1},
           "subject": {"type": "run", "id": "run:stage1b-carrier"},
           "provenance": {"lab": "lab:organum-cody", "machine": "m-stage1",
                          "platform": "darwin", "adapter": "organum-hub/0.1",
                          "cli_version": None, "capture": None},
           "idempotency_key": "stage1b-carrier-1",
           "created_at": "2026-08-15T00:00:00Z",
           "payload": {"cursor": "carrier-profile-한글-✓"}}
    raw = he.canonical_bytes(env)
    ev = hw.build_wire_event(raw, seckey=SEC, created_at=int(time.time()))
    assert hw.is_carrier(ev)

    results = {"carrier_kind": ev["kind"], "carrier_tags": ev["tags"]}
    async with websockets.connect(RELAY, max_size=2**22) as ws:
        auth = await _recv_until(ws, lambda m: m[0] == "AUTH", 5)
        if auth:
            ae = hw.build_wire_event(b"{}", seckey=SEC, created_at=int(time.time()),
                                     kind=22242,
                                     tags=[["relay", RELAY], ["challenge", auth[1]]])
            # AUTH content는 빈 문자열이 관례 — 봉투 아님. 직접 구성:
            ae = {**ae}
            from organum.hub_wire import nip01_event_id
            ae["content"] = ""
            ae["id"] = nip01_event_id(ae["pubkey"], ae["created_at"], 22242, ae["tags"], "")
            ae["sig"] = sp.sign(bytes.fromhex(ae["id"]), SEC).hex()
            ae["kind"] = 22242
            await _send(ws, ["AUTH", ae])
            results["auth_ok"] = await _recv_until(
                ws, lambda m: m[0] == "OK" and m[1] == ae["id"])

        await _send(ws, ["EVENT", ev])
        ok = await _recv_until(ws, lambda m: m[0] == "OK" and m[1] == ev["id"])
        results["publish"] = ok
        if ok and ok[2]:
            await _send(ws, ["REQ", "c1", {"ids": [ev["id"]]}])
            got = await _recv_until(ws, lambda m: m[0] == "EVENT" and m[1] == "c1")
            await _recv_until(ws, lambda m: m[0] == "EOSE" and m[1] == "c1", 5)
            if got:
                back = got[2]
                results["roundtrip_content_byte_identical"] = \
                    back["content"].encode("utf-8") == raw
                results["roundtrip_tags"] = back["tags"]
                results["roundtrip_kind"] = back["kind"]
                results["roundtrip_id_matches"] = back["id"] == ev["id"]
                # 그리고 실수신 경로 그대로: admit_wire로 authority 인계
                keys = he.KeyRegistry()
                keys.register(PUB, signer_id="lab:organum-cody", key_id="stage1",
                              key_epoch=1)
                cd = {"claims": {}}
                hub = he.HubIndex(
                    key_registry=keys,
                    claim_registry=he.ClaimRegistry(cd, expected_sha256=he.canonical_sha(cd)),
                    log=hl.TransparencyLog(), receipt_seckey=(17).to_bytes(32, "big"))
                r = hw.admit_wire(hub, back)
                results["admit_wire_from_relay_event"] = {
                    "admitted": r["admitted"],
                    "wire_event_id": r["receipt"]["body"]["wire_event_id"] if r["receipt"] else None,
                    "envelope_event_id": r["event_id"]}
    print(json.dumps(results, ensure_ascii=False, indent=1))
    print(f"frames: {len(_frames)} → {EVIDENCE}", file=sys.stderr)


if __name__ == "__main__":
    asyncio.run(main())
