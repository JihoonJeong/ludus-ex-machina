#!/usr/bin/env python3
"""hub wire Stage 1 — Buzz relay 라이브 대조 probe.

측정 항목(docs/hub-wire-stage0-buzz-findings.md의 Stage 1 목록):
  T1 직렬화 동치: 우리 event id로 만든 kind-1 event를 relay가 수용하는가
     (수용 = rust-nostr 재계산과 우리 계산의 byte 일치 증명)
  T2 escape 경계 표본 round-trip: 발행 → REQ 수신 → content 값 byte 복원
  T3 변조 id 거부 (relay가 실제로 검증한다는 실증)
  T4 변조 sig 거부
  T5 미지 kind 거부 (allowlist 닫힘 실증)
  + NIP-42 인증 흐름 관측

증거 규율: 모든 송수신 프레임을 verbatim으로 evidence JSONL에 남긴다. 판정은
관측에서만 — 기대와 다르면 그 관측이 결과다. 키는 실험 전용 신규 seed(실 lab key 0).
"""
import asyncio
import hashlib
import json
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(Path.home() / "Projects" / "organum" / "src"))
import websockets  # noqa: E402

from organum import hub_envelope as he  # noqa: E402
from organum import hub_wire as hw  # noqa: E402
from organum import schnorr_pure as sp  # noqa: E402

RELAY = "ws://localhost:3000"
SEC = hashlib.sha256(b"organum-hub-stage1-experiment-key-2026-08-15").digest()  # 실험 전용
PUB = sp.public_key(SEC).hex()
EVIDENCE = HERE / "stage1-evidence.jsonl"

_frames = []


def _log(direction, frame):
    rec = {"t": time.time(), "dir": direction, "frame": frame}
    _frames.append(rec)
    with EVIDENCE.open("a", encoding="utf-8") as f:
        f.write(json.dumps(rec, ensure_ascii=False) + "\n")


async def _send(ws, msg):
    raw = json.dumps(msg, separators=(",", ":"), ensure_ascii=False)
    _log("out", msg)
    await ws.send(raw)


async def _recv(ws, timeout=10):
    raw = await asyncio.wait_for(ws.recv(), timeout)
    msg = json.loads(raw)
    _log("in", msg)
    return msg


async def _recv_until(ws, kinds, timeout=10, *, match=None):
    """특정 프레임 타입이 올 때까지 수신·기록. match(msg)가 주어지면 그것까지 만족해야
    한다 — Buzz는 클라이언트 CLOSE에도 CLOSED 확인을 보내므로 타입만으로 매칭하면
    한 프레임씩 밀린다(1차 실사에서 실측한 desync)."""
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        remain = deadline - time.monotonic()
        try:
            msg = await _recv(ws, timeout=max(0.1, remain))
        except asyncio.TimeoutError:
            break
        if isinstance(msg, list) and msg and msg[0] in kinds:
            if match is None or match(msg):
                return msg
    return None


async def _await_ok(ws, event_id, timeout=10):
    """이 event id의 OK만 기다린다 — 다른 프레임(CLOSED 확인 등)은 기록만 하고 지나감."""
    return await _recv_until(ws, {"OK"}, timeout,
                             match=lambda m: len(m) >= 2 and m[1] == event_id)


def _event(kind, tags, content, created_at=None, *, sec=SEC, mangle_id=False,
           mangle_sig=False):
    created_at = created_at if created_at is not None else int(time.time())
    pub = sp.public_key(sec).hex()
    eid = hw.nip01_event_id(pub, created_at, kind, tags, content)
    if mangle_id:
        eid = ("0" if eid[0] != "0" else "1") + eid[1:]
    sig = sp.sign(bytes.fromhex(hw.nip01_event_id(pub, created_at, kind, tags, content)
                                if mangle_id else eid), sec).hex()
    if mangle_sig:
        sig = ("0" if sig[0] != "0" else "1") + sig[1:]
    return {"id": eid, "pubkey": pub, "created_at": created_at, "kind": kind,
            "tags": tags, "content": content, "sig": sig}


def _envelope_raw(idem):
    env = {"envelope_schema": he.ENVELOPE_SCHEMA, "event_kind": "message.read",
           "signer": {"id": "lab:organum-cody", "key_id": "stage1", "key_epoch": 1},
           "subject": {"type": "run", "id": "run:stage1-wire"},
           "provenance": {"lab": "lab:organum-cody", "machine": "m-stage1",
                          "platform": "darwin", "adapter": "organum-hub/0.1",
                          "cli_version": None, "capture": None},
           "idempotency_key": idem, "created_at": "2026-08-15T00:00:00Z",
           "payload": {"cursor": "stage1-한글-✓"}}
    return he.canonical_bytes(env)


ESCAPE_SAMPLES = [
    'ASCII plain',
    '한글과 émojis 🐝 원문',
    '따옴표 " 역슬래시 \\ 슬래시 /',
    '개행\n탭\t백스페이스\x08',
    '제어 \x1f DEL \x7f',
]


async def main():
    EVIDENCE.write_text("", encoding="utf-8")
    results = {}
    async with websockets.connect(RELAY, max_size=2**22) as ws:
        # ── NIP-42: 선제 challenge 관측 ──
        auth_frame = await _recv_until(ws, {"AUTH"}, timeout=5)
        results["nip42_proactive_challenge"] = auth_frame is not None
        if auth_frame:
            challenge = auth_frame[1]
            auth_ev = _event(22242, [["relay", RELAY], ["challenge", challenge]], "")
            await _send(ws, ["AUTH", auth_ev])
            results["nip42_auth_ok"] = await _await_ok(ws, auth_ev["id"])

        # ── T1: 직렬화 동치 라이브 확인 ──
        raw1 = _envelope_raw("stage1-t1")
        ev1 = _event(1, [], raw1.decode("utf-8"))
        await _send(ws, ["EVENT", ev1])
        ok1 = await _await_ok(ws, ev1["id"])
        results["t1_publish"] = ok1

        # round-trip: REQ by id
        if ok1 and ok1[0] == "OK" and ok1[2]:
            await _send(ws, ["REQ", "rt-1", {"ids": [ev1["id"]]}])
            got = await _recv_until(ws, {"EVENT"}, timeout=10,
                                    match=lambda m: m[1] == "rt-1")
            await _recv_until(ws, {"EOSE"}, timeout=5, match=lambda m: m[1] == "rt-1")
            await _send(ws, ["CLOSE", "rt-1"])
            await _recv_until(ws, {"CLOSED"}, timeout=3,
                              match=lambda m: m[1] == "rt-1")   # CLOSE 확인 소진
            if got:
                back = got[2]["content"].encode("utf-8")
                results["t1_roundtrip_byte_identical"] = (back == raw1)
                results["t1_returned_id_matches"] = (got[2]["id"] == ev1["id"])
            else:
                results["t1_roundtrip_byte_identical"] = None

        # ── T2: escape 경계 표본 ──
        t2 = []
        for i, content in enumerate(ESCAPE_SAMPLES):
            ev = _event(1, [], content)
            await _send(ws, ["EVENT", ev])
            ok = await _await_ok(ws, ev["id"])
            entry = {"sample": i, "accepted": bool(ok and ok[2]), "reply": ok}
            if entry["accepted"]:
                sub = f"rt2-{i}"
                await _send(ws, ["REQ", sub, {"ids": [ev["id"]]}])
                got = await _recv_until(ws, {"EVENT"}, timeout=10,
                                        match=lambda m, s=sub: m[1] == s)
                await _recv_until(ws, {"EOSE"}, timeout=5, match=lambda m, s=sub: m[1] == s)
                await _send(ws, ["CLOSE", sub])
                await _recv_until(ws, {"CLOSED"}, timeout=3,
                                  match=lambda m, s=sub: m[1] == s)
                entry["roundtrip_identical"] = bool(got and got[2]["content"] == content)
            t2.append(entry)
        results["t2_escape_samples"] = t2

        # ── T3/T4: 변조 거부 ──
        bad_id = _event(1, [], "tampered-id-probe", mangle_id=True)
        await _send(ws, ["EVENT", bad_id])
        results["t3_bad_id"] = await _await_ok(ws, bad_id["id"])

        bad_sig = _event(1, [], "tampered-sig-probe", mangle_sig=True)
        await _send(ws, ["EVENT", bad_sig])
        results["t4_bad_sig"] = await _await_ok(ws, bad_sig["id"])

        # ── T5: 미지 kind ──
        unk = _event(4242, [], "unknown-kind-probe")
        await _send(ws, ["EVENT", unk])
        results["t5_unknown_kind"] = await _await_ok(ws, unk["id"])

    print(json.dumps(results, ensure_ascii=False, indent=1))
    print(f"\nevidence: {EVIDENCE} ({len(_frames)} frames)", file=sys.stderr)


if __name__ == "__main__":
    asyncio.run(main())
