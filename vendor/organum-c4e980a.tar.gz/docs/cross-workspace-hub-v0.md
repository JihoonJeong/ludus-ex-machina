# 크로스-워크스페이스 허브 v0 — MVP 설계 (organum substrate)

*2026-07-18. JJ 결정(단계적 확장). 최애 파워유저의 Orca 셋업이 드러낸 놓친 범위: 한 persona가 여러
프로젝트에 참여 + 리더가 독립 세션들을 가로질러 핀포인트 라우팅(프로젝트 A의 X가 B의 X 소리를 안 듣게
= few-shot poisoning 방벽). organum 필드가 프로젝트-로컬이라 못 하던 것. 이 문서 = MVP 빌드 스펙 +
셀프-감사. **구현·정렬 완료**: organum-code 회신(H1~H5)을 반영해 send-시점 alias 확정+epoch·cursor
inbox·event_id·conflict를 넣었다(289 tests green). 정렬 계약은 organum-code `docs/hub-contract-v0-draft.md`.
빌드 때 Codex critic 감사 동반(계획엔 안 건다).*

## 0. 범위

- **MVP(이 문서)**: 복합 persona×workspace 식별자(additive) + 홈레벨 허브 relay(크로스-워크스페이스
  addressed 편지).
- **이후(defer)**: 크로스-site agora(개방 심의) · 크로스-site observatory(분신 whole-view) · 명시 채널 구독.
- **절대 안 함**: 런타임/PTY/터미널/디스패치(actor=organum-code). 허브는 파일기반·stdlib·무데몬 —
  `[[coordination-architecture-principle]]`의 transport/policy 층에 머문다.

## 1. 식별자 모델 — frozen `cell_key`는 안 건드린다

6라운드 적대 감사로 동결된 `cell_key`(워크스페이스-로컬 canonical id)를 **재개방하지 않는다**. 위에
**선언 차원 2개**를 additive로 얹는다:

- **`persona`** — 워크스페이스를 넘는 안정 전문성 정체성 (예: `critic`). cell id 문법과 동일 검증
  (`valid_cell_id`)을 재사용하되 의미가 다르다: cell=이 워크스페이스의 이 몸, persona=여러 워크스페이스에
  걸친 같은 전문성.
- **`workspace`** — 프로젝트 스코프 라벨. **기본값 = 프로젝트 루트 basename**(`.organum/`의 부모 디렉터리
  이름), `--workspace`로 override. registry가 **abs 프로젝트 경로**를 같이 저장해 basename 충돌을 해소.

**복합 주소 = `persona@workspace`** (예: `critic@warren`). `@`는 cell 문법 밖이지만 **허브 주소는 cell id가
아니라 별도 네임스페이스**라 무방 — 허브 `--to`의 토큰일 뿐 원장 cell_key에 안 들어간다.

**전제(명시, critic 비차단 지적)**: `cell_key`는 워크스페이스-로컬 정본이지만 허브 registry·cursor에선
사실상 **hub-global 키**로 쓰인다. actor 생성 id(`oc-<hash>`)는 충돌 확률이 무시 가능하나, **수동 cell
사용자**는 "허브 참여 cell_key는 hub 내 global-unique여야 한다"를 지켜야 한다(두 워크스페이스가 같은
cell_key를 쓰면 registry·inbox가 섞임). MVP는 이 전제를 강제하지 않고 문서화한다.

## 2. 허브 레이아웃

```
~/.organum/hub/            # ORGANUM_HUB로 override (테스트·멀티허브)
├── relay/                 # 크로스-워크스페이스 addressed 편지 (field.py substrate 재사용)
│   ├── <envelope>.md      # frontmatter: from, to, from_id, persona, workspace, ts, ...
│   ├── .join-<cell_key>   # 셀별 가입 커서 (가입 이후만)
│   └── .read-<cell_key>   # 셀별 읽음 커서 (명시 ACK)
└── registry/
    └── <cell_key>.json    # {cell_key, persona, workspace, project_path, role, last_seen}
```

프로젝트-로컬 `.organum/relay`는 **무변경**. 허브는 별도 필드(`field.py`의 `field_dir`을 허브 루트로
가리키게 하는 얇은 래퍼 `hub.py`).

## 3. registry — 등록·해소

- **등록(명시 opt-in)**: `organum join --persona <p>` 시에만 허브 registry에 `<cell_key>.json` 기록
  (`persona`, `workspace`=basename|`--workspace`, `project_path`=abs, `role`, `last_seen`). persona 없이
  join하면 허브 미가입(프로젝트-로컬이 기본).
- **해소**: 발신자가 `--to critic@warren`을 주면 registry에서 `persona=critic ∧ workspace=warren` 항목을
  찾아 대상 존재/모호성 확인(0건=에러, ≥2건 모호=에러+cell_key 요구). **direct `--to <cell_key>`도
  현재 등록된 live cell만**(미등록=fail-closed) — 모든 hub send는 registry 항목에서 nonempty epoch를
  확정한다(critic A1: 빈 epoch 봉투가 다음 registration에 wildcard로 새는 것 차단). registry는 발견·해소·
  분신 목록의 정본.

## 4. 라우팅 + 격리 불변식 (poisoning 방벽) — send-시점 확정

허브 relay는 **addressed-only, global broadcast 없음**. `hub send`는 `all`/`*`/빈 값/다중을 **거부**한다.
**alias는 send 시점에 정확히 1개 live cell로 resolve**해 `to_id`(cell_key)+`to_epoch`를 봉투에 고정한다
(inbox에서 재-resolve 안 함 = 재등록 오배송 차단). routing authority = 확정 `to_id`.

셀 C의 `hub inbox`가 돌려주는 편지 L의 조건 (모든 봉투 to_epoch는 nonempty — §3에서 send가 보장):
```
L.to_id == C.cell_key                                # 확정 to_id 정확 매칭 (all/persona 재해석 없음)
∧ L.to_epoch == C.현재_registration_epoch            # epoch **무조건** 정확 일치 (critic A1)
∧ L.ts ≥ C.hub_join_ts                               # 가입 이후만
∧ L.file ∉ C.hub_read_set                            # 안 읽음 (명시 per-file ACK)
∧ L.from_id ≠ C.cell_key                             # 자기 글 제외 (from_id로만, replay-safe)
```
빈 epoch는 wildcard가 아니라 nonempty와 안 맞아 제외(미등록 수신 C.epoch=None도 nonempty와 안 맞음).
→ **A의 `critic@warren`(cell w-crit)은 `critic@ludex`(cell l-crit)로 확정된 편지의 to_id와 안 맞는다**
= 크로스-워크스페이스 누수 없음. **rebind**: critic@warren이 새 cell로/새 epoch로 바뀌어도 과거 편지는
옛 to_id·옛 epoch라 새 generation으로 안 샌다. **ACK도 동일 exact-epoch를 무조건 요구.**

## 5. CLI 표면 (구현됨) — organum-code H1~H5 정렬

```
organum join --role <r> --for <cell> --persona <p> [--workspace <w>] [--json]   # 허브 등록(opt-in)
  → --json echo: {persona, workspace:{key,label}, registration:{epoch,registered_at,lease_expires_at}, ...}
organum hub send --to <persona@workspace|cell_key> [--for <cell>] [--from <display>] \
                 [--idem-key <k>] [--json] [body|stdin]
  → receipt: {file, event_id, from_id, idem, to:{address, cell(=확정 to_id), persona, workspace, epoch}}
organum hub inbox --for <cell> [--limit N] [--cursor <opaque>] [--all] [--json]
  → {items:[{event_id, file, from_id, from, from_persona, from_workspace, to_address, to_id,
             to_persona, to_workspace, to_epoch, ts, topic, idem, thread, in_reply_to, escalate, body}],
     next_cursor, has_more}   # 비소비 · opaque cursor · hard horizon 없음
organum hub read  --for <cell> <file> [--json]   # per-file semantic ACK
organum hub leave --for <cell>                   # deregister (슬롯 reap · rebind 전)
organum hub list  [--persona <p>] [--json]       # registry (분신 발견·주소 확인)
```
`send`는 0.2.0 계약 그대로 `--for`(canonical from_id)·`--from`(display) 분리·`--idem-key`. body는 stdin 가능.

## 6. 셀프-감사 (두 불변식)

**불변식 ① frozen `cell_key` 불변.** persona/workspace는 **새 선언 필드**이고 cell_key 계산·검증·소마
경로·자기제외는 그대로다. 허브 주소 `persona@workspace`는 cell id 원장에 안 들어간다(별도 네임스페이스).
→ 6라운드 감사분 재개방 없음. from_id 자기제외도 프로젝트 relay와 동일 규칙(cell_key 비교).

**불변식 ② 크로스-워크스페이스 격리(누수 없음).** 허브 relay는 broadcast 경로가 없다(`all`/`*`/다중 거부).
send 시점에 alias→to_id 확정, inbox는 `to_id == 내 cell_key`만 매칭 → 다른 워크스페이스의 같은 persona로
확정된 편지는 구조적으로 안 들어온다. 커서(join/read)는 프로젝트 relay와 같은 "가입 이후·명시 ACK"라
harness truncation 손실 없다(비소비 + cursor). registry 조회는 read-only 발견일 뿐 전달 경로가 아니다.

**불변식 ③ rebind no-leak.** alias가 새 cell로 rebind(옛 cell leave→새 cell register)돼도, 과거 편지는
옛 `to_id`(cell_key)에 고정돼 있고 to_epoch도 옛 generation이라, 새 cell(다른 cell_key·다른 epoch)의
inbox와 안 맞는다. (test_rebind_no_leak.)

**불변식 ④ idem exactly-once (payload conflict).** 같은 (from_id, idem-key)에 payload 지문(body +
확정 to_id/to_epoch + topic/thread/reply/escalate; event_id 제외)이 일치할 때만 기존 봉투 반환. 다르면
`PostConflict` fail-closed(조용한 옛 receipt 반환 = caller 오인 방지). field.post 레벨이라 hub·relay·agora
공통. (organum-code 종단 검증 blocker 1.)

**불변식 ⑤ ACK authorization.** `hub read`는 ① 파일 존재 + 경로 주입 가드 ② 봉투 to_id == 나 ③ to_epoch
== 내 현재 registration epoch를 검증해야 ACK. 불일치/미존재 = fail-closed. 유효 재시도만 idempotent.
(organum-code 종단 검증 blocker 2.)

**남은 위험(빌드 때 critic 초점 — hardening/backlog)**:
- registry liveness/lease — stale process가 alias 영구 점유 방지. 현재 MVP: 명시 `hub leave` + ≥2 live면
  ambiguous fail. 자동 lease/reap = hardening.
- basename 충돌 — 다른 경로의 두 workspace가 같은 key. 현재: actor가 명시 `--workspace` 권장, registry는
  abs 경로 저장. 발견은 되나 send는 ambiguous fail로 안전.
- 주소 주입 — `persona@workspace` 파싱에서 `@`·`/`·개행은 cell_key/`_fm_safe`가 흡수. 빠진 벡터?
- hub root 검증 — `ORGANUM_HUB` canonicalize + symlink/소유권/권한 검사(현재 단일유저 home 가정). actor가
  검증된 launcher 옵션으로만 전달.

## 7. 빌드 계획

1. `hub.py` — `field.py` 위 얇은 래퍼(허브 루트 = `ORGANUM_HUB` or `~/.organum/hub`), addressed를
   `cell_key | persona@workspace` 매칭으로(‘all’ 없음), registry read/write.
2. `cli.py` — `hub` 서브커맨드(send/inbox/read/list) + `join --persona` 등록.
3. registry: `<cell_key>.json` atomic write, `list`/해소.
4. 테스트: 격리(A의 X ≠ B의 X)·비소비·idem·persona 검증·basename 충돌·자기제외.
5. **빌드 후 Codex critic** — 범위를 release-blocker/hardening/backlog로 먼저 나눠 §6 남은 위험 중심.
6. 계약 shape 굳으면 `--json` 결과를 organum-code에 넘김(허브 소비 + live bridge 소스 확장).
