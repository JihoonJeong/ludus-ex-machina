# 벤더 역량 레퍼런스 (vendor-capabilities)

*조율의 숨은 변수 명시화 — organum이 관측하는 벤더/계보가 **무엇을 할 수 있나**. Ludex MTI(기질)의
organum 짝. role/lane 배정을 역량-인지적으로 하기 위한 레퍼런스.*

**정직 규율**: first-hand 관측(organum이 직접 검증)만 단언한다. 공개 벤치마크는 커모디티(stale·
gamed)라 출처·날짜 캐빗을 달고 참고용으로만. 미검증은 `?`로 남긴다. 이 레퍼런스의 차별점은
"또 하나의 리더보드"가 아니라 **first-hand 검증 + 조율 substrate와의 통합(역량-인지 배정)**이다.

마지막 검증: **2026-07-13** (Claude Opus 4.8 · Codex gpt-5.6 · agy Gemini · Grok 0.2.99).
플래그십 갱신: **2026-08-15** — Grok **grok-4.6** 출시(first-hand: `grok` CLI 1.0.3 headless
1회 실측에서 기본 모델이 `grok-4.6-build`로 확인 — **CLI 버전 불변·모델 서버측 교체**.
binary version만으로 provenance가 안 되는 실증 — hub Δ3 version.capture 규율의 근거 사례).
Gemini **3.7 flash** 출시(공개 발표 기준, first-hand 미검증 `?` — agy/gemini CLI 노출 여부 미확인).

## 역량 매트릭스

| 축 | Claude Code | Codex | agy (Antigravity/Gemini) | Grok |
|---|---|---|---|---|
| 플래그십 모델 | Opus 4.8 | gpt-5.6 | Gemini 3.x→**3.7 flash**(08-15 발표, 미검증 `?`) | grok-4.5→**grok-4.6**(08-15 실측 `grok-4.6-build`) |
| 코딩-특화 변종 | — | — | — | **composer-2.5-fast** |
| **이미지 생성** | ❌ (구독 CLI) | ✅ gpt-image-2 (`image_gen`·`$imagegen`, 구독) | ❌ (구독 CLI) | ✅ `/imagine` |
| **비디오 생성** | ❌ | ❌ | ❌ | ✅ `/imagine-video` |
| vision 입력 | ✅ | ✅ | ✅ | ? |
| subagents | ✅ | ✅ (exec) | ✅ | ✅ |
| MCP | ✅ | ✅ | ? | ✅ |
| sandbox/plan/hooks | ✅ | 부분 ? | ? | ✅ (문서 확인) |
| **organum 관측** | ✅ inspect(Vitals) | ✅ Tier-2 | ✅ Tier-1 (토큰=protobuf 후속) | ✅ Tier-2 |
| 세션 포맷 | jsonl (cwd-mangle dir) | jsonl (date-dir + line1 cwd) | jsonl + SQLite protobuf | jsonl + json (url-encode cwd) |
| 이미지 저장 위치 | — | `~/.codex/generated_images/` | — | (미확인) |

**first-hand 검증**: 이미지/비디오 생성 행(Grok 문서·Codex 웹검증), organum 관측 행·세션 포맷 행
(어댑터 구현으로 실물 검증). 나머지(vision·MCP·sandbox 일부)는 문서 유추 또는 미검증 = `?`.

## faculty 축 (추론 vs 실행 — cross-lineage, LxM 작업)

계보마다 "계획→실행" faculty가 다르다. LxM Cody의 cross-lineage 예측: organ(Taxis/commit-latch)의
가치는 **계보-조건부**다.
- **추론-first** (실행 faculty가 결핍 → latch가 공급): Claude(anthropic 계보) — LxM v3-v6 확증.
- **실행-native** (commit/실행을 native로 → latch ≈ null lift): GPT-5.6 가족 (LxM 15/15 전향 확증).
- **Grok**: 두 모델로 축을 **외부화** — grok-4.5=추론-first(latch lift 가능), composer-2.5-fast=
  실행-특화(실행-native일 가능성, latch≈null 예측). ← falsifiable, 두 모델 A/B로 검정 가능.
  (08-15: 기본 모델이 grok-4.6으로 교체 — 위 faculty 관측은 grok-4.5 기준이라 4.6에서 **재검 필요** `?`.)
- **Gemini/agy**: `?` (미측정).

## MTI / temperament (Ludex 소유 — 미기록)

Ludex가 창발 기질(MTI) 프로파일을 벤더별로 기록할 자리. 여기선 크로스-레퍼런스만 둔다.
capability(무엇을 할 수 있나, organum) + temperament(어떻게 행동하나, Ludex) + faculty(추론/실행,
공유 축)가 role 배정의 세 축.

## 역량-인지 role 배정 규칙 (초안)

- **이미지/비디오 필요** → Codex(이미지) 또는 Grok(이미지·비디오). Claude/agy는 다른 세포로 라우팅.
- **깊은 코딩 실행 레인** → composer-2.5-fast(코딩 특화) 또는 실행-native 계보.
- **적대적 추론·비평·설계** → grok-4.5 · Opus 같은 추론-first 플래그십.
- **관측 parity** → 4벤더 전부 (어댑터로 커버, 벤더-무관).
- **JSON 헤드리스 방출 의존 파이프라인** → composer-2.5-fast 플레이크(1/3) 주의, retry 가드
  (organum 관측은 온디스크 파일이라 무관).

## 후속 (organum이 스스로 probe)

정적 표는 stale해진다. 다음: organum이 **역량을 직접 관측/probe**하는 층 —
- 어댑터가 이미 세션 포맷·툴·모델을 관측 → 여기에 "관측된 역량"을 파생 (예: 이 세포가 image_gen
  툴을 실제로 호출했나).
- CLI 문서/help를 자동 스캔해 capability 표를 갱신.
- 이게 있으면 "정직한 first-hand" 층이 자기유지된다.
