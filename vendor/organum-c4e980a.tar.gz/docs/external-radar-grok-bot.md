# external radar — Grok Bot (xAI, 2026-08-11 출시)

2026-08-15 검토(JJ 발제: 설치 여부 + 프로젝트 연관성). radar 계보: Buzz(`external-radar-buzz-mattermost-outline.md`) 다음의 "채널/actor 층 상업화" 2호.

## 사실 (실측 아님 — 공개 자료)

- **무엇**: "always-on AI teammates" — 각 봇이 **xAI 클라우드의 전용 컴퓨터**를 갖고,
  사용자 도구(메일함·앱·웹사이트, API 없는 것 포함)에 **직접 로그인**해 다단계 작업을
  자율 수행. 시연 1회로 워크플로 학습. 승인은 필요할 때만 요청.
- **조율**: 봇끼리 메시지·스레드 컨텍스트 공유·그룹 채팅에서 **작업 전달과 소유권 배분**.
  공식 표현: "messaging, approvals, connectors, and routines".
- **표면**: 데스크톱(리눅스 포함)·iOS. **API·CLI·SDK·webhook·self-hosting 전부 없음**
  (docs.x.ai release notes 확인). 보안/권한 모델 문서도 공개분에 없음.
- **가격**: SuperGrok Heavy · Cursor Ultra($200/mo) · Cursor Teams Premium($120/seat)에
  번들. 엔터프라이즈는 대기열. Grok 4.6과 함께 광역 롤아웃 예고.

## 판정 — 세 축

**① 논제 검증(radar 축)**: Buzz가 채널 층을 commoditize했다면, Grok Bot은 **actor 층 +
조율 층을 수직 통합**한 첫 대형 사례다. "봇끼리 그룹 채팅에서 작업을 나눈다"는 정확히
organum이 측정하는 조직 패턴인데 — **측정 표면이 0이다**: receipt 없음, transcript 소유
없음, 조율 로그 접근 없음. open-stack 논제("채널이 늘수록 우리가 커진다 — 남는 질문은
'이 조직이 실제로 잘 돌아가는가'")를 강화한다. 다만 Buzz와 결정적 차이: Buzz는 오픈소스/
Nostr라 **감쌀 수 있고**(wrapping=스키마·정책 강제), Grok Bot은 닫힌 SaaS라 **감쌀 수
없다**. hub 기질 후보가 아니다.

**② 벤치/하네스 축**: **Grok Bot ≠ Grok Build.** 벤치의 프론티어 하네스 lane에 있는 것은
`grok` CLI(Grok Build 1.0.3, headless `-p` 실측 완료)이고 그대로 유지한다. Grok Bot은
프로그래밍 표면이 없어 cast actor·bench lane 어느 쪽으로도 편입 불가. 편입할 이유도
현재로선 없다 — 우리가 요구하는 것(관측 가능한 transcript·usage 회계·결정적 재현)을
하나도 주지 않는다.

**③ 보안 축(설치 판단의 핵심)**: 우리 규율과 정면으로 반대 방향이다.
- 우리: provider 키는 keychain reference만, secret은 operator store 밖으로 0, actor별
  HOME/config 격리, native-auth containment(키링 접근 자체를 게이트).
- Grok Bot: **사용자 credential/세션으로 제3자 클라우드에서 always-on 자율 행동.**
  로그인 범위를 준 만큼이 상시 노출 표면이 된다.
- 프로젝트 특정 위험: GitHub(dev repo는 private cut-전 원천)·메일·`~/Projects` 접근 권한을
  주면 relay/벤치 증거/키체인 인접 표면에 **우리가 계측하지 못하는 actor**가 생긴다.
  hub must-not("랩 프로세스는 허브-로그를 피험체 컨텍스트에 표면화하지 않는다")의
  data-flow 규율을 로컬에서 지켜도, 계정 층에서 우회된다.

## 권고

1. **organum 작업 계정/머신에는 설치하지 않는다.** OpenCode dogfood에 OS 격리를 요구했던
   것과 같은 원칙인데, 이건 클라우드 상주라 격리 요구가 더 높다.
2. **radar 목적 평가는 조건부로 가능**: 이미 결제 중인 tier에 번들이면 비용 0 —
   단, organum 자산에 닿지 않는 **분리 계정**(별도 Google/GitHub/메일)으로만. 관찰
   가치는 있다: 그들의 승인 UX·봇 간 작업 배분이 우리 escalation 흡수율·delivery gate
   개념의 상업화 형태다.
3. **대응할 것은 없다.** hub 설계 변경 불요(기질 후보 아님), 벤치 lane 변경 불요.

## 후기 (2026-08-15, 같은 날) — Grok 4.6 출시 실측

`grok` CLI headless 1회 실측: **CLI는 1.0.3 그대로인데 기본 모델이 `grok-4.6-build`로
서버측 교체**됐다. `modelUsage` 필드에 모델 id·토큰·비용이 나온다(관측 표면 양호).
교훈이 hub 스펙과 정확히 맞물린다: binary `--version`은 안 바뀌고 모델이 바뀌는 일이
실제로 일어난다 — **provenance는 cli_version이 아니라 provider/model route의 런타임
관측이어야 한다**(toolchain.observed의 provider_route가 그 자리, hub Δ3 규율의 실증).
vendor-capabilities의 Grok faculty 관측(grok-4.5 기준)은 4.6 재검 필요로 표기.
agy도 1.1.12→1.1.13 범프 확인(Orin scaffold가 1.1.12 표면에 pin — 통지).
