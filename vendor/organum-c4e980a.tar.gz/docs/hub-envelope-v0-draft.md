# organum hub — 봉투/이벤트 스키마 v0 초안 (2026-08-04, 크리틱 회람용)

3랩 요구(Ludex `…ludex-to-organum-hub-requirements`, Orin `…orin-…-hub-requirements-response`,
LxM `…lxm-to-organum-hub-requirements`)의 종합. **DRAFT — pin 아님.** 크리틱 후 v0 동결.
아키텍처 전제는 `open-stack-integration-v0.md`(self-hosted Buzz 기질 + organum wrapping이
스키마·정책 강제; 허브는 증거를 나르되 권한을 나르지 않는다; 해시만, 데이터는 레포).

## 1. 봉투 (모든 이벤트 공통)

```jsonc
{
  "envelope_schema": "organum-hub/envelope/v0",
  "event_kind": "artifact.attested",        // §3의 typed enum만
  "signer": {                                // 랩 principal만. namespace "lab:"
    "id": "lab:organum-cody",                // logical persona
    "key_id": "…"                            // 실제 서명 키 식별자
  },
  "subject": {                               // 이벤트가 다루는 대상. namespace가 signer와 분리
    "type": "artifact|creature|machine|run|message|route",
    "id": "run:pack-a-run-01"                // "lab:" namespace 사용 불가 → signer=subject 구조 차단
  },
  "provenance": {                            // [LxM 신규 불변식] harness 축 1급
    "lab": "organum", "machine": "m-3f9c…",  // machine=가명 안정 id (경로·계정·secret 금지)
    "platform": "darwin-arm64",
    "adapter": "claude-cli", "cli_version": "2.1.221"
  },
  "artifact": {                              // raw-byte evidence 참조 (Orin A). 해시만 — 본문 없음
    "role": "preregistration",               // typed role
    "schema_id": "organum-bench/…/v3",
    "sha256": "…", "byte_length": 12345,
    "media_type": "application/json",
    "locator": "github.com/…@commit:path"    // 선택 — 위치 힌트일 뿐 authority 아님
  },
  "bindings": [                              // digest 간 결속 (chain 질의용)
    {"relation": "prereg_of", "artifact_sha256": "…"}
  ],
  "claim": {                                 // [Ludex] "어떤 산물이 무엇을 언제까지 증거하는가"
    "type": "prereg.published",
    "scope": "walk:e2",
    "valid_from": null, "valid_until": null,
    "preservation_boundary": "hash-only; body는 repo가 보존",
    "evidence_basis": "raw-bytes-sha256"     // 검증 주장도 측정 주장과 동급 — 근거를 명시
  },
  "causal": {                                // append-only 정정 체계
    "previous_event": null, "prereg_ref": null,
    "supersedes": null, "revokes": null
  },
  "idempotency_key": "…",                    // (signer, idem) exact scope
  "created_at": "2026-08-04T…Z"              // **서술값** — 순서 authority 아님 (§4)
}
```

핵심 불변식:
- **서명 의미론(Orin)**: 허브 서명은 "artifact가 참"이 아니라 **"이 랩이 이 digest에 이
  claim을 걸었다"**만 증명한다. canonicalization을 쓰면 algorithm+version 명시; 가능하면
  실제 소비한 raw bytes의 sha256+byte_length를 그대로.
- **signer≠subject(Ludex/전원)**: typed namespace 분리로 구조적으로 동일 불가. 크리처
  provenance는 랩이 크리처에 **대해** 서명.
- **키 custody(Orin)**: logical signer identity와 private key 보관 분리 — 키는 organum
  substrate/adapter/OS keystore. **LLM/TUI/backend subprocess/model context에 절대 미전달.**
  모델이 만든 event draft는 local policy(JJ guard)가 exact scope 검증 후 substrate가 서명.
- **(signer, idempotency_key) exact scope(H 상속)**: same key+same payload=같은 event로
  수렴, same key+different payload=**conflict**(조용한 덮어쓰기 금지).
- **append-only(Orin)**: 수정·삭제 없음. correction/supersession/revocation은 causal을 가진
  새 서명 이벤트로만. UI가 최신값을 보여도 원장은 전 이력 보존.

## 2. 읽기/전달 의미론

- **읽기 ACL = 랩만(LxM 신규 불변식).** 피험체(크리처/backend/model process)는 키가 없을
  뿐 아니라 **로그를 읽을 수 없다** — 관측=개입, 자기 측정 열람은 injection/leak 표면.
- **transport admission ≠ semantic ACK(Orin D, H 상속)**: 허브 receipt는 전송 수령까지.
  실제 소비 주체가 `delivery.semantic_ack {event_id, payload_sha256, target cell/epoch,
  outcome: applied|deferred|rejected}`를 별도 발행.
- **배달/읽음 = 질의(LxM #1)**: `message.posted` + 랩별 읽음-커서로 "{랩}이 {이벤트}
  읽었나"가 고고학이 아니라 질의가 된다.
- pinpoint 유지(H 상속): send 시점 alias→`to_id+epoch` 고정, inbox 재해석·fallback
  routing·broadcast 금지, bounded non-consuming read.
- Buzz/Nostr event id와 기존 file-hub/local-relay id는 **source domain 포함 namespace 분리**.

## 3. 이벤트 kind v0 (최소 집합)

| kind | 요지 | 출처 |
|---|---|---|
| `artifact.attested` | generic raw-byte anchor. claim.type으로 세분: `prereg.published`·`battery.fired`·`verdict.published`(Ludex A) / `contract.frozen`·`producer.pinned`·`bench.pinned`·`finding.registered`·`delivery.receipted`·`lifecycle.closed`·`verification.completed`(Orin) / `run.completed`(LxM) | 전원 |
| `toolchain.observed` | `{provenance 공통 + backend id/version, provider/model route, binary/package/config digest(관측 가능시), observation_method}`. observed_at은 서술값 | Ludex B·Orin B |
| `canary.result` | toolchain payload + `{leak, act, alive, passed}`. **LxM 카나리아 게이트가 자연 발행원** — 드리프트 질의는 toolchain.observed와 합산 소비 | LxM |
| `provider.route.observed` | 전환 공지(solar-pro4류): route id·availability/pricing class·observation source·effective window·superseded route. **공지≠authority** — admission은 각 랩 local probe/gate가 재결정 | Orin C |
| `message.posted` / `message.read` | 편지 본문 해시+수신 랩; 읽음-커서 | LxM |
| `delivery.semantic_ack` | §2 | Orin D |
| `hub.anchor` | §4의 외부 공증 체크포인트(로그 Merkle root의 외부 앵커 영수증) | Ludex A |

## 4. 순서 authority (Ludex A의 폐쇄 조건)

signer timestamp·git author date·Nostr `created_at`은 전부 caller-선택 가능 → **서술값**.
순서의 authority는 층층이:

1. **relay acceptance sequence/receipt** — append 시 hub가 부여;
2. **hash chain** — 각 이벤트가 이전 anchor를 참조;
3. **주기적 Merkle root + 외부 공증**(`hub.anchor`, OpenTimestamps류) — **hub 전손·운영자
   교체에도 제3자가 digest·순서를 검증 가능**(90일 만료 없음).

## 5. 허브가 하지 않는 것 (must-not 종합)

launch authority · 자동 model/provider 선택 · 자동 JJ 승인 · diagnostic/signed 이벤트의
측정 증거 자동 승격 · 피험체에 키/secret 제공 · **피험체 로그 읽기** · git/`.organum/`/
file-relay 정본으로의 write-back · 메시지 수신만으로 workflow/webhook/tool 실행(P0/P1 전부
off/allowlist) · provider catalog/가격/가용성의 단일 authority · 랩 거버넌스(판정 절차)의
공통 workflow 강제 · "서명 존재=검증 완료" 주장 · artifact 본문 보관(해시만) · unread
horizon/alias 재해석/broadcast로 pinpoint·no-loss 약화.

## 6. 크리틱 요청 (알려진 열린 질문)

1. `canary.result`를 별도 kind로 둘지 `toolchain.observed`의 method 변형으로 접을지.
2. machine 가명 id의 파생 규칙(안정성 vs 비노출).
3. claim.type registry의 소유·확장 절차(P1a hazard registry처럼 versioned registry?).
4. 외부 공증 주기·수단 선택(비용 vs 앵커 밀도).
5. Buzz 구현 매핑 — 위 불변식 중 Buzz가 기본 제공하지 않는 것(읽기 ACL·admission/ACK
   분리·idem conflict)의 wrapping 강제 지점 실측(P1에서).

Orin 예고 반례 8종(parsed/raw split·signer=subject·runtime key exposure·caller timestamp
ordering·same-idem/diff-payload·alias rebind·admission=ACK conflation·diagnostic 승격·
revocation 이력 소실)을 v0 동결 전 시험 목록으로 채택한다.
