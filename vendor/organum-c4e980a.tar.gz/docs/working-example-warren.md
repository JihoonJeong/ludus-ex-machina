# Working Example — warren v1: 4벤더가 중앙 지휘 없이 게임을 만들다

*organum으로 **4개 벤더 CLI**(Claude·Codex·Gemini/agy·Grok)가 한 프로젝트에서 협업해 터미널
로그라이크 v1을 출하한 실전 기록. 2026-07-13, JJ 감독. 성공과 갭을 정직하게 남긴다.*

---

## 0. 무엇을 증명했나

세 코딩 레인(engine·mapgen·atelier)이 **보스 없이**, relay/agora 파일 계약만으로 병렬 수렴해
**실제로 돌아가는 게임**에 도달했다. 독립 리뷰어(critic)가 레인 *사이*의 통합 버그를 잡아
품질을 끌어올렸고, 인간(owner)은 단 두 번의 게이트(진입 타이밍·정지 선언)만 넣었다.

```
####################
#@r!..$.g..........#     @ 플레이어 · r RAT · ! POTION · $ GOLD · g GOBLIN
####################     hjkl 이동 · 몬스터(차단) 못 통과 · 결정적(seed)
```

## 1. 캐스트 — 역량-인지 배정

| 세포 | 벤더·모델 | effort | 레인 (single-writer) | 근거 |
|---|---|---|---|---|
| **engine** | Claude Opus 4.8 | — | `src/warren/*.py` + defs.py, 오케스트레이션 | systems-lead, 추론+실행 |
| **atelier** | agy / Gemini flash | medium | `src/warren/content/` + tests/ | 콘텐츠 유연성 |
| **critic** | Codex gpt-5.6 | medium | 읽기만 · agora에만 산출 | 적대적 추론 |
| **mapgen** | Grok grok-4.5 | high | 격리된 맵 생성 모듈 + 전용 테스트 | 코딩 faculty, 격리 seam |

배정은 [[vendor-capabilities]] 레퍼런스로 정당화 (이미지생성·faculty·관측 깊이 등 역량 축).

## 2. 조율 아키텍처 (soma / commons / field)

- **commons** (공유·커밋): `map/` · `worldmodel/` — 현장 지식.
- **field** (공존 매질·ephemeral): `relay/`(지향) + `agora/`(개방) + `roster/`(presence).
- **soma** (세포별 사적·ephemeral): `self.md` · `memory/` · `guard.jsonl`. owner=루트,
  게스트=`cells/<id>/`. 명령에 `--for <id>`. → **한 현장에 여러 세포가 살아도 정체성 충돌 0.**

각 세포 온보딩 시퀀스:
```
organum roster me --for <id> --name <role> --focus <focus>
organum agora join --for <id> ; organum relay join --for <id>
organum context --for <id>              # 자기 soma의 [Self] + commons [Map]/[WM]
organum agora read --for <id>           # held-out 리뷰·결정 읽기
… 레인 작업 …
organum reflect --for <id>              # 회고 → cells/<id>/self.md
# 60초 폴링으로 relay/agora 관측
```

## 3. 실전 아크 (실제로 일어난 순서)

1. **온보딩·read-first** — 넷 다 roster me + join + 지난 세션 held-out(critic v0 리뷰 + engine
   v1 결정)을 먼저 읽음. 조용한 구간.
2. **atelier 착수** — arch-v0 결정 동기화(CONTRACT Protocol 덕타이핑) + 콘텐츠 확장(ORC·TROLL·
   SWORD·SCROLL). 자기 레인만 커밋.
3. **mapgen 핸드오프 요청** — Grok이 relay+agora로 make_room seam 계약을 요청하며 **"계약 도착
   전 코드 안 씀"** (membrane 규율). engine 대기.
4. **engine이 #4 먼저 수정** — critic이 "v1 전에 #4(다중 점유) 고쳐라"고 했고 engine이 그대로:
   `entities_at` + `is_walkable=any(blocks_move)` + render z-order.
5. **seam 계약 핸드오프** (Claude↔Grok) — engine이 `generate(w,h,*,seed,rng)->World` 계약을
   relay로 넘김. mapgen이 격리 레인에 구현(16→19→22→24 tests) + world/entity/content **read-only
   유지**. 양방향 ACK.
6. **적대적 리뷰 루프** (Codex) — critic이 각 산출을 *생긴 즉시* stigmergy로 읽고 반례로 스트레스:
   Protocol 덕타이핑 구멍(`glyph=7,name=123,hp="many"`가 통과), RNG 결정성(mutable Random 변형),
   **크로스-레인 통합 갭**(mapgen candidate ≠ engine can_spawn). 빌더들이 매번 정직하게 수렴.
7. **인간 정지 게이트** — critic이 끝없이 엣지를 파자 owner(JJ)가 "critic 잔여 → v1.1, v1은
   게임 돌아가게" 선언. engine이 수렴.
8. **통합 착지** — `game.new_game` = `mapgen.generate(seed)` → `player_start` → `defs.spawn`.
   28/28 tests. 게임이 돈다.

## 4. 통한 패턴

- **single-writer per locus (membrane)** — 각 세포가 자기 파일 레인 단독 소유. 남의 레인은 읽기만.
- **soma 격리** — 개인 기관은 세포별(`cells/<id>/`). 3벤더가 동시에 각자 self.md에 써도 충돌 0.
- **stigmergy** — 세포들이 메시지 없이도 **공유 파일 흔적**(커밋·워킹트리)을 읽고 조율. critic이
  engine의 미커밋 변경을 실시간 리뷰한 게 대표 사례.
- **계약-우선 seam 핸드오프** — 인터페이스(시그니처)를 relay로 먼저 합의 → 병렬 구현. mapgen이
  계약 전 코드를 안 써서 재작업 0.
- **독립 리뷰어가 레인 *사이*를 지킴** — 각 레인은 자기 테스트를 다 통과하는데(mapgen 24, engine
  51 checks), 그 *사이* seam은 오직 두 레인을 다 읽는 critic만 잡는다. **멀티-에이전트+독립
  critic의 최대 가치.**
- **인간-in-the-loop 게이트** — 진입 타이밍 + "v1-done" 정지. 나머지는 세포들이 자기조직화.

## 5. 갭·교훈 (정직하게 — 다음 개선 대상)

- **세포는 언제 멈추나 (두 극단)** — atelier는 "완료" 선언 후 폴링을 끊어 후속 핸드오프(테스트·
  CONTRACT)를 놓쳤고, critic은 반대로 자연 정지 신호가 없어 무한 폴링(쿼타 소모). → *리뷰어는
  systems-lead/인간이 정지시키고, 빌더는 "done 후에도 inbox 감시"해야 한다.*
- **커밋 어트리뷰션** — 세포 self-커밋은 머신 기본 git 신원(JJ)으로 뭉개짐. engine이 *대행*할
  때만 `--author=<cell>`로 계보가 남았다. → organum 세포-커밋 헬퍼 후보.
- **공유 디렉토리의 레인 경계** — `tests/`를 atelier·engine·mapgen 셋이 기여해 다중-소유가 됨.
  single-writer가 폴더 단위론 흐려진다. → 파일 단위 소유 명시 필요.
- **재현성 seam** — engine이 mapgen을 import하는 코드를 커밋했는데 mapgen.py가 untracked라
  clean checkout에서 깨짐. mapgen이 `git archive HEAD`로 검증 후 자기 레인 커밋(재현 기준
  커밋)으로 봉합. → *레인-분할 커밋은 깨진 중간 상태를 만든다; 통합 후 clean-checkout 검증.*
- **관측 깊이는 벤더별로 다르다** — agy는 토큰이 protobuf 사이드카라 Tier-1(토큰 0=미측정),
  Grok은 세션에 총량만 남겨 out/cache 미제공. 렌더가 `—`(미상)와 `0`(실제)을 구분해야 정직.

## 6. 재현 기준

- **재현 커밋**: `ec6a422` (mapgen seam 커밋 — clean checkout에서 28/28 + 보드 재현 검증).
- 조율 볼륨: agora 30 + relay 15 메시지, 중앙 지휘 0.
- 4-soma: engine(루트)·atelier·mapgen(`cells/`)·critic(순수리뷰어, soma 없음).

관련: [[vendor-capabilities]] · collaboration-template §2.1(membrane)·§2.3(soma/commons/field).
