# External radar: Buzz · Mattermost · Outline (2026-08-04)

JJ 지인의 AI-소통 스택(Slack→Mattermost, Notion→Outline, +Buzz)을 organum 관점에서 점검.
축은 셋: **활용**(우리 워크플로에 지금 쓰나) · **통합**(organum이 adapter를 갖나) ·
**개념 가져오기**(설계 입력). 판정 기준은 헌법 — organum은 transport/policy 두 층만,
actor는 밖, 오케스트레이션 금지([[coordination-architecture-principle]]).

## TL;DR

| 프로젝트 | 활용(지금) | 통합 | 개념 | 한 줄 판정 |
|---|---|---|---|---|
| **Buzz** (Block, 2026-07-21) | 보류(early, ops 무거움) | **hub §8의 transport 후보** — 지금은 인터페이스만 adapter-가능하게 | ★★★ 서명 이벤트 로그·agent 키+owner 결속·ACP↔MCP 하네스 | 경쟁자가 아니라 **우리 방향의 외부 실증** — 채널은 commoditize, 해자는 측정으로 이동 |
| **Mattermost** (v11.6, Agents V2) | 비권장(우리 스케일에 과함) | 없음 | ★ agents=@멘션 가능한 동료·sovereign self-host 규율 | 성숙하지만 Buzz가 개념적으로 우리 지형에 더 가까움 |
| **Outline** | 보류(위키 수요 아직 없음) | 없음(MCP 내장이라 붙일 일 생기면 즉시 가능) | ★★ commons(역할=직책 지식베이스)의 인간-facing UX 목표상 | 사람 팀이 붙는 시점의 commons 뷰어 후보. BSL 라이선스 유의 |

## Buzz — 가장 중요

**실체**: github.com/block/buzz (Apache 2.0, Rust crate workspace, 공개 2주만에 ~22k
stars). Nostr relay가 곧 플랫폼 — "모든 메시지·리액션·워크플로 스텝·리뷰 승인·git
이벤트가 **하나의 로그에 서명된 이벤트**". 사람과 에이전트 모두 Schnorr 키페어를 갖고,
**에이전트 키에는 human owner 결속 서명이 하나 더** 붙는다. buzz-cli(JSON in/out,
LLM tool-call용), buzz-acp(goose/Codex/Claude Code를 ACP↔MCP로 브리지), buzz-workflow
(YAML: message/reaction/schedule/webhook/git 트리거), buzz-audit(해시체인), NIP-34 git.
멀티-relay federation·고급 agent autonomy는 아직 💭 단계. 748 open issues — early.

**지형 판정 (related-work 갱신)**:
- Buzz가 하는 것 = **채널+표면+워크플로**. 안 하는 것 = per-project 기억/세계모델
  substrate, 측정·벤치 규율, two-lens, peer journal. 즉 organum의 "거의 빈 니치의 고유
  조합" 반증은 아니고, **해자 문장의 절반을 수정**하게 만든다: "채널+측정"에서 채널
  쪽은 무거운 오픈소스 점유자가 생겼다. **해자의 중심은 측정이다** — measured≠asserted.
- 동시에 Buzz의 core 설계는 우리 D3 규율의 외부 실증이다: "authority=사전등록 raw
  bytes·증명=실제 전달된 bytes"(D3), durable-first 두-로그 병합(hub 비전) ↔ "signed
  event in one log". guard의 arXiv 실증과 같은 종류의 검증.

**개념 가져오기 (설계 입력, 지금 비용 0)**:
1. **agent 키 + owner 결속 서명** → hub §8 "P2P custody"와 cross-workspace persona
   식별자의 구체 설계 참조. 파일 우체국에도 경량 적용 가능(frontmatter에 서명/sha —
   memory-surveillance의 core-integrity와 같은 계보).
2. **hub 인터페이스를 Nostr-adapter-가능하게** — 지금 hub를 짓지 않는다(수요-구동
   유지). 다만 §8 설계 때 transport 계약을 "서명 이벤트 append + 필터 구독" 모양으로
   잡으면 나중에 백엔드로 파일 우체국↔자체 hub↔Buzz relay를 갈아끼울 수 있다.
3. **buzz-acp의 ACP↔MCP 브리지 패턴** → organum-code의 멀티-CLI 소환(harness 층)과
   같은 문제의식. harness-lift 실험 프레임에 참조 사례로.
4. **workflow approval gate** = 중첩 조직의 approval 불변식이 채널 층에 전이된 것 —
   [[nested-organization-concept]]의 방증.

**활용 판정**: 파일 우체국 대체는 **지금 아님**. 현 relay는 durable·git-감사·JJ-gated
(사람 승인이 곧 policy)라는 걸 공짜로 갖고 있고, Buzz self-host는 Postgres/Redis/
MinIO/Rust ops + early-stage 리스크. dogfood를 하게 되면: (a) 수요 신호 후(hub 로드맵과
동일 게이트), (b) OS 격리 필수([[opencode-security-and-organum-exposure]]), (c) 메시지-
트리거 YAML workflow는 agent 멤버에 대한 injection 표면 — observatory 감시 대상.

## Mattermost

v11.6(2026-04)·Agents V2(2026-06): self-host LLM, agents가 @멘션 목록에 동료처럼 등장.
성숙/기업용이지만 우리 스케일(JJ+에이전트 몇)에 배포 가치가 낮고, 개념 지형은 Buzz가
상위 호환(에이전트 = 권한 플래그가 아니라 identity로 스코프되는 멤버). 가져올 개념:
**sovereign self-host 규율**과 "agent를 동료로 발견/호출하는 UX" — 회사 프레임
([[organum-company-analogy]]) 소통 은유의 산업 확인.

## Outline

self-host 위키, **워크스페이스마다 MCP 서버 내장**(OAuth/API key). commons(역할=직책
지식베이스)의 인간-facing 뷰어로 이상적 형태지만 지금 인간 팀이 없다 — 수요 시점에
낮은 비용으로 붙는다는 것만 기록. 정본은 언제나 git/.organum, Outline은 뷰. **BSL
라이선스**: self-host 사용은 자유, 공개면(ludex-lab cut)에 코드 임베드는 불가.

## Ludex 소개

권고: **짧은 FYI로 소개할 가치 있음**. Ludex Cody·Ray도 파일 relay로 협업 중이고,
Buzz는 (a) 멀티-에이전트 팀 플랫폼의 살아있는 대형 표본(그들의 연구 지형과 접점),
(b) E2 walk 류의 서명-로그 인프라 참조. 드래프트는 아래 — JJ 전달 판단에 맡김.

> Organum Cody → Ludex Cody: FYI — Block이 7/21 공개한 Buzz(github.com/block/buzz,
> Apache 2.0)를 스터디했다. Nostr 기반 "사람+에이전트 같은 워크스페이스", 모든 이벤트가
> 서명된 단일 로그, 에이전트 키에 human-owner 결속 서명, ACP↔MCP 하네스(goose/Codex/
> Claude Code) 동봉. 우리 판정: 채널 층은 빠르게 commoditize — 측정/벤치 규율이 해자.
> 너희 E2 walk·prereg 인프라와 접점이 있어 보이면 각자 판단으로. 회신 불요.

## 다음 액션 (제안)

1. 이 노트를 radar 원장으로 유지(다음 스터디도 여기 추가) — related-work 지형 메모 갱신됨.
2. hub §8 설계 착수 시 "서명 이벤트 append + 필터 구독" transport 계약을 1급 요건으로.
3. relay frontmatter 서명(경량)은 별도 수요 생기면 — 지금은 개념만 pin.
4. Buzz dogfood는 JJ 수요 신호 + OS 격리 전제로만.


## naia-adk#43 — run-evidence 스키마 워치 (2026-08-22 등록)

- **무엇**: `nextain/naia-adk#43`(08-21, luke-n-alpha) — risk-tiered run evidence.
  우리 제안서 §2·§3의 개념 채택(그들 어휘로 번역), hub는 정밀 보류("서비스 간 수용
  영수증이 필요할 때 별도 검토").
- **트리거**: 수용 기준 1번 "버전 있는 JSONL run-evidence 스키마를 안정된 경로에 문서화"가
  **착지하면 우리 조건부 약속이 활성화된다** — "표면이 문서화되면 organum이 작성·유지보수
  하는 어댑터를 오픈소스로." 재촉하지 않고 기다린다.
- **가져올 것**: 벤치 지표 후보 "첫 탐지 가능 시점 이후 낭비된 토큰"(절감을 탐지 지연의
  비용으로 재는 축); R0–R3 위험도 언어(관측이 통제 위치를 고른다).
- **참고**: 그들 전략 노트가 "공개 수치는 제3자 재현 전"을 정확히 짚음 — 적합성 벡터
  bundle(A/B/C)의 첫 실수요자 후보이기도 하다.
