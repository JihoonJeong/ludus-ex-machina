# Memory surveillance v0 — core-integrity tier (observatory)

*2026-07-20. JJ와 정렬. 발단 = "sediment" 에세이(append-only ≠ memory; 코드엔 verifier가 있는데
memory엔 없다; 5번째 결정[무엇을 남길까]이 결정이 아니라 default:append). **Memory Injection**(친구
지적) = 그 sediment 문제의 **적대적 얼굴**: 검증 없는 disk를 진실로 읽는 후속 에이전트에게, core 산출물을
고의로 오염시키면 그게 명령이 된다. 이 문서 = 그 방어의 **core-integrity tier** 설계 + 정직한 경계.*

> **상태(2026-07-20): SHIPPED · 공동 Codex critic ACCEPT.** 4라운드 적대 감사(REJECT 5→2→1→ACCEPT)로
> false-clean(assume-unchanged·symlink·gitlink·삭제)·fossil 은폐(rev flapping·clock rollback)·context
> 오표기(관측시점≠변이시점)·쓰기경계(future format)·스키마/incomplete 계약을 계층별로 닫음. 커밋
> `5b46528`→`060c4a0`→`3514974`→`67d2564`→`18717ee`→`f26166b`. 350 tests. **v0.1 hardening**: 비-git
> core(soma) baseline · suspect→alarm · **manifest 파일 자체가 directory/symlink인 경계**(critic 후속 메모).

## 0. 한 줄 논제

에세이의 "missing memory verifier" = **observatory의 surveillance 렌즈**. 검사 규칙 = **모든 core 변경이
answerable한(승인된·귀속 가능한) 저자가 있는가.** 없으면 = untracked = injection **검토 신호**(evidence,
verdict 아님 — 귀속은 관측 시점 기반이라 실제 변경 주체를 단언 안 함) = memory 판의
"red test." 에세이 마지막 문장("A record becomes evidence only when someone is answerable for it")을
**bless(승인=책임 인수)** 단계로 구현한다.

## 1. 스코프 — 전부가 아니라 **정의된 core**만

전부에 무결성을 걸면 비싸고 노이즈다. 그리고 레버리지가 정확하다: **injection은 core를 노리지 sediment를
안 노린다.** 그래서 **core/canonical 산출물만** 무결성+authorization 대상:
- 자동 core: commons(`roles/`·`worldmodel/`·`CONTRACT.md`) · 최상위 confidence memory("canonical").
- 명시 core: `core-manifest`가 선언한 경로/글롭.
- **비-core(sediment)는 대상 아님**: cursor·roster·relay/agora 봉투 등 ephemeral. (커서 상속 사고는 이미
  `mark_join(reset=)`으로 수리됨 — accidental 계열.)

## 2. 어디에 사나 — observatory (+ 4분할)

surveillance = **시간축 변화 감시**라 observatory(영속 축적·월 샤드·history 밴드)의 본성. 한 시점이 아니라
스냅샷 사이의 변화를 봐야 하므로 inspector(한 방 포렌식)가 아니다.

| 도구 | 역할 (memory-integrity) |
|---|---|
| **guard** | 예방 — core 쓰기를 mediated write로 검증·귀속(가능한 범위) |
| **observatory** | **surveillance** — blessed baseline 이탈을 시간축으로 감시·declared 쓰기와 대조 ← 여기 |
| **checkup** | 시점 검사 — core hash ≠ baseline이면 WARN(advisory) |
| **inspector** | 한 방 포렌식 — 같은 substrate, 시점 무결성 리포트 |
| **git** | git-추적 core의 무결성+저자로그+bless(=commit)를 **공짜로** 제공 |

## 3. 모델

*§3.2~3.4는 **설계 vision**이다. **v0 구현(§7)은 git-추적 tier** — 별도 SHA-256 baseline 저장 없이 git이
baseline·bless(=commit)·저자·tamper-evidence를 준다. §3.5 `bless` 명령·SHA store는 비-git core(v0.1)용.
두-렌즈(§3.4)의 v0 구현은 **변이 시점이 아니라 관측(sweep) 시점** context다(overlap≠causation).*

### 3.1 core-manifest — 무엇이 canonical인가 (사용자가 answerable 소유자)
`.organum/core-manifest.json`(사용자 큐레이트) + 자동 규칙(commons·top-confidence memory). 각 항목:
`{path, authority, note}`. **누가 core인지 정하는 것 자체가 사람의 책임** — 에세이의 "gardener"를 1급으로.

### 3.2 integrity baseline — SHA-256 + last-blessed provenance
core 항목마다 **`{sha256, blessed_at, blessed_by, git_rev?}`**. **CRC 아님**(CRC는 위조 가능 —
공격자가 파일+CRC 재계산). 적대 무결성엔 암호학적 해시.

### 3.3 change detection (observatory sweep)
sweep마다 core 항목의 현재 SHA vs blessed baseline 비교 → 이탈이면 **원인 분류**:
- **authorized**: git commit(git-추적 core; commit=저자+bless) · `organum … bless`(사용자/에이전트 명시
  승인) · declared 세션 쓰기(ship/note가 그 경로 참조) → **re-baseline**(정상).
- **suspect**: 승인된 원인에 귀속 안 되는 이탈 → **flag**(누구도 답할 수 없는 변경). 사람 리뷰 대상.

### 3.4 두-렌즈 대조 (liveness two-lens의 형제)
**declared 쓰기(세션 ship·guard 이벤트·git author·bless) × observed 변이.** **v0 구현**: 변이를 처음 관측한
sweep 시점의 활성 세션을 evidence로 포착(`context_at_observation`) — **변이 시점 귀속은 주장 안 함**
(관측 시 declared 조율 0 = `no_context_at_observation`, overlap≠causation). liveness에서 "일하는데 필드
조용"을 잡은 것과 같은 구조로, memory에서 "파일은 바뀌었는데 아무도 (관측 시) 조율 안 함"을 evidence로 잡는다.

### 3.5 bless — answerable 인수
`organum … bless <path>` = 현재 SHA를 blessed baseline으로 기록(누가·언제). **사용자 변경/삭제 = 정상**
이라, bless가 없으면 정당한 유저 편집마다 알람(fatigue) → "변경 감지 → 승인 원인 있나 → 있으면 re-baseline,
없으면 flag" 루프. git-추적 core는 **commit이 곧 bless**.

## 4. 정직한 경계 (과대주장 방지 — 핵심)

1. **탐지지 예방·판결 아님.** observatory는 사후·read-only. "승인 원인에 귀속 안 되는 변경"을 **탐지**할
   뿐, "이상한 플레이어가 했다"를 **증명 못 한다**. 한 머신에선 사람·에이전트·악성스크립트가 다 같은 UID로
   같은 파일을 쓴다 → anomaly-for-review지 verdict 아님.
2. **hard-enforce 아님.** 강한 버전은 core 쓰기를 guard 경유로 강제해 "미경유=unauthorized"로 만드는
   건데, raw shell `echo > CONTRACT.md`는 못 막는다 → **탐지 + 규율**. CRC/hash는 out-of-band 변경을
   *누가 했든* 잡지만, 귀속(누구)은 best-effort.
3. **baseline 위치가 관건.** baseline이 파일과 같은 곳·같은 쓰기범위면 적대 방어 0(둘 다 고치면 무의미).
   → **git-추적 core는 git이 tamper-evident**(content-addressed·history rewrite가 흔적). 비-git core는
   baseline을 별도 보호 위치(v0.1 과제, §7).
4. **관측 vs 위협모델 분리.** 우린 **사고성 오염**(닷새 묵은 북마크·헌법 역행)은 관측했지만 **exploit은
   안 봤다**. injection은 threat-model. "우리가 해킹을 봤다"고 안 한다.
5. **귀속은 부분적.** git author·guard 로그·봉투 from_id·세션 ship으로 최대한, raw 편집은 미귀속.

## 5. surfaces — 같은 엔진(`integrity.py`), **도구별 3-모드** (순차 증분)

| 도구 | 모드 | 질문 | 상태 |
|---|---|---|---|
| **checkup** | 시점 건강검사 | "지금 core에 unblessed 변경 있나" (advisory WARN + fossil age) | ✅ v0 (5b46528) |
| **observatory** | **시간축 surveillance** | "이 core가 닷새간 unblessed로 떠 있나(fossil)" — transition 로그·drift age | ✅ v0 (060c4a0) |
| **inspector** | **한 방 포렌식 audit** | "임의 폴더를 지금 감사하면 무엇이 신뢰 가능한가"(state 불요) | ✅ v0 (3514974) |

**observatory 구현분(060c4a0 + 3514974)**: transition 로그(변화 시에만 append) + `record_integrity`(web·sync
편승) + `integrity_drift`(fossil = 비-blessed ≥5일) + `organum observatory integrity` 뷰 + checkup fossil
WARN(읽기만). **두-렌즈-for-memory(A, 3514974)**: transition에 **관측(sweep) 시점** 활성 세션
(`context_at_observation`) 포착 → `no_context_at_observation`(비-blessed인데 관측 시 declared 조율 0) =
forensic evidence(verdict 아님, overlap≠causation, 사용자 편집일 수 있음 검토). **변이 시점이 아니라 관측
시점**임에 유의(critic 재감사 B3 — 실제 변경 시점 귀속은 주장 안 함).
**inspector audit(B, 3514974)**: `inspector.core_integrity` = git report + 마지막 bless를 재구성 transcript
세션과 교차(organum provenance 없이 귀속). `--json`은 shipped 계약 유지, integrity는 text 뷰.

**남은 v0.1**: 비-git core(soma) baseline(보호 위치) · suspect→alarm 자동.

- **observatory 증분**: integrity 스냅샷을 소비-스냅샷처럼 시간축에 축적 → fossilization/drift 탐지 +
  두-렌즈-for-memory(declared 쓰기 × observed 변이). observatory 제품 스토리의 심장.
- **inspector 증분(고유 가치)**: **state 불요 — 아무 폴더나** 사후 재구성(에세이의 "유산 물려받는 순간"을
  정면으로). inspector가 이미 transcript에서 세션을 복원하므로 **git core-변경 × transcript 활동창을 교차**해
  organum provenance 없이도 귀속(두-렌즈의 재구성 버전). 단 재구성적·한 방·스냅샷(누적=observatory·예방=guard).
- **`bless`** — re-baseline(answerable 인수). v0=git commit이 bless라 명령 불요; 비-git core(v0.1) 갈 때.
- (v0.1) suspect core 변이 → `alarm` 자동 발동(사람 리뷰 강제)?

**아까 교정과 정합**: surveillance(지속 감시)=observatory / audit(한 방)=inspector / 시점 건강=checkup /
예방=guard. inspector에 붙는 건 surveillance가 아니라 **audit**이라 도구 정체성과 안 부딪힌다.

## 6. organum 매핑 — 대부분 있음, **글루가 새것**
공짜: git(무결성+저자+bless) · guard(mediated write·이벤트 로그) · observatory(축적 엔진) · checkup(WARN
프레임) · memory(confidence·supersedes). **새로 지을 것**: ① core-manifest ② integrity baseline 저장·비교
③ declared×observed 대조(귀속 분류) ④ `bless` 명령 ⑤ observatory integrity 밴드·checkup WARN.

## 7. 빌드 스코프 (v0 = git-추적 core)

**v0**: core-manifest(commons 자동 + 명시) 중 **git-추적 항목**만. git이 무결성·저자·bless를 다 주니
가장 정직·저비용. 검출 = core 경로의 `git status`/blame + observatory 축적으로 "언제 바뀌었나·commit
attributed인가·uncommitted unblessed인가". 에세이 사고(헌법 역행·CLAUDE.md scripture)는 대부분 git-추적.

**v0.1**: 비-git core(soma memory 등) baseline. **미해결: baseline 보호 위치**(soma는 gitignore·개인) —
home-level `~/.organum/integrity/`? 별도 tamper-evident 저장? §4-3의 딜레마. v0에서 안 건드림.

**빌드 후 Codex critic**: 무결성/authorization 로직 + §4 정직 경계(탐지≠판결, baseline 위치, 귀속 부분성)
반례. 계획엔 안 건다.

## 8. 제품 각도 (observatory 차기 제품)
현재 observatory 스토리 = 소비/비용 축적. 여기 memory-surveillance를 얹으면 **"얼마 썼나" 대시보드 →
"당신 멀티-에이전트 유기체의 memory가 tended되나, 표류·오염되나"의 운영-무결성 제품**. 에세이 서사("past를
tend하는 시스템")를 제품이 직접 구현 + injection 방어 보안 헤드라인. observatory 제품화의 킬러 피처 후보.

## 9. JJ 결정 대기 (v0)
1. core-manifest 형식 — 별도 파일 vs meta 섹션 vs memory confidence 재사용(자동 canonical)?
2. bless UX — `organum memory bless` vs `organum core bless` vs `checkup --bless`? git-추적은 commit이
   bless라 명령 불요일 수도.
3. v0를 git-추적 core로 좁히는 데 동의? (비-git baseline은 v0.1 — 보호 위치 미해결.)
4. suspect 변이의 alarm 자동 발동은 v0 vs v0.1?
