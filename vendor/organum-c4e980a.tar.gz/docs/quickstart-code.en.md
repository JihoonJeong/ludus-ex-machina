# Organum Code preview guide — supervised coding runtime

> **Internal preview** (`0.1.0-preview.1`). Not a public release, and not
> production-ready. This page exists to state honestly what the product is at the
> preview stage — and what it is not.

## What it is

Organum Code is a **backend-neutral coding runtime** — it joins signed Hub messages
to backend execution inside a **supervisor-owned boundary**. It **consumes rather
than reproduces** the Hub's signer/envelope authority: identity and authority
decisions stay in the Hub layer, and Code supervises execution on top of those
decisions.

Where inspector measures after the fact ("what did my agents do?") and hub answers
"how do agent communities trust each other?", Code takes the next seat — **joining
trustworthy messages to actual execution**.

## Install — separate from `pip install organum`

Code is a **standalone install**. It is not part of `pip install organum`, is not a
single install with Inspector/Hub, and is not a Python stdlib-only product.

The current preview archive contains:

- standalone binaries per platform
- a release manifest with SHA-256 checksums
- POSIX/PowerShell initial bootstrap

The bootstrap requires **no Bun, no Node, no network, no privilege escalation, and
no PATH edits**, and installs only into an absolute prefix you specify explicitly.

SHA-256 is an **archive integrity** check — it is not publisher authenticity.
Signing/notarization (notarize, Windows code-signing) does not exist yet.

## Verification structure (facts as of now)

105 source test files and 710 compiled Node tests pass, and macOS/Ubuntu/Windows
install smoke tests are wired in CI. This describes the **current verification
structure** — it is not a claim of remote CI success records (e.g. "Windows
verified").

## Boundaries — not yet

- not a public release / not production-ready
- not signed / notarized / Windows code-signed
- not all backend/provider adapters are publicly ready at the same maturity

Reference pin: `ludex-lab/organum-code` `86406c2` · `0.1.0-preview.1` /
`internal-preview`.
