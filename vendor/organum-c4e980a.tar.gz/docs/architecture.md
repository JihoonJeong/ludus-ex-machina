# organum — 아키텍처 (canonical)

*이 문서가 organum의 **현행 정체성·경계·성숙도**의 단일 기준점이다. 다른 문서와 충돌하면
이 문서가 이긴다. HANDOFF.md·plan.md는 **역사 문서**(초기 결정의 기록)이지 현행 상태가 아니다 —
§5 참조. 최종 개정 2026-07-16.*

## 1. organum이 무엇인가

organum은 **벤더-중립 공유-인지 substrate + 인간 얼굴**이다. 실무자가 이미 쓰는 코딩
에이전트(Claude Code·Codex·Gemini·Grok·OpenCode)들을 공유 기억·규칙으로 묶어 하나의 유기체처럼
움직이게 한다(관계 bond·그래프 edge는 v0 예약/미구현 — 미래 방향). 프로젝트-로컬 `.organum/`에
상태를 축적하고, 관측·조율·돌봄을 제공한다.

**한 문장 경계 서술(정본):** organum은 모델·에이전트 runtime을 소유하지 않는다(일반 subprocess는
쓴다 — `organum live` 등). LLM 추론이 필요한 의례는 **`distill` 하나뿐**이고, 사용자 CLI의
자격·예산·실행권을 빌려 서브프로세스로 위임한다(`reflect`는 caller가 준 항목을 결정적으로
carry-forward — 위임 아님). organum 자신은 추론하지 않는다.

## 2. 세 성숙도 층위 — 약속이 다르다

한 패키지(`pip install organum`)에 전부 들어 있고 전부 실제로 동작한다. 다른 것은 **코드 견고함**이
아니라 **우리가 걸 수 있는 약속**이다. 두 축으로 읽는다 — 엔지니어링 견고함 × 경험적 가치.

| 층위 | 무엇 | 약속 | 상태 |
|---|---|---|---|
| **제품 (product)** | `inspector` (사후 계측, 6벤더), 그 얼굴인 `--html` · **`hub`** (서명 증거 봉투 — admit·영수증·투명 로그·lifecycle/introduce·wire v1·drop) | 안정 지향 · 가치 자명(inspector=네 숫자를 네가 본다 / hub=위조·변조·사후부인 차단, 오프라인 검증) | inspector 배포됨(0.4.x, 매뉴얼·사례·한/영) · **hub 0.4.x 공개 배포 + 실운영**(hosted drop 위 3랩 서명 봉투 왕복·다중 랩 적대 검증 아크 종결, 2026-08 갱신) |
| **측정계기 (instrument)** | `web`(관제탑)·`observatory`·조율층(`relay`·`agora`·`roster`·`alarm`·`session`·`mcp`) | **선별된 고위험 불변조건은 적대 감사됨**(우체통·web·delegate 등 8개, critic 4라운드); 나머지 계약은 tests+dogfood 근거 · **가치는 측정 중**(협업벤치) | 동작·도그푸드 검증, 베타. 다음 제품 후보 = observatory |
| **실험 (experimental)** | core 상태층 — `memory`·`map`·`worldmodel`·`guard`·`backup` | **v0 저장 포맷은 frozen**; 기능 의미·경험적 가치가 유동 | P3: active-search 코딩에서 `[Map]`의 큰 over-anchoring 감소가 **검출 안 됨**(form 우월 전이 미지지) — map의 navigation-state 효용이나 core 전체 가치를 반증한 건 아님. 가장 큰 caveat |

**제품 경계 주석(2026-08-17, JJ 고정)**: 출시 제품은 `inspector`·`hub` 둘이다.
`organum-code`는 기능·적대 검증 자산이 크지만 package 0.0.0·private·지원 matrix
미고정이라 **제품 후보인 내부 frontier harness / integration R&D 층**으로 말한다 —
별도 productization gate(설치·업그레이드·안정 CLI·운영/실패 계약·반복 가능 사례)
판정 전까지 제3의 제품으로 세지 않는다.

**중요**: "instrument"는 "실험실"이 아니다. 다만 감사 근거를 정직히 쪼개면 — **선별된 8개
고위험 불변조건(우체통·web·delegate 등)은 4라운드 적대 감사됨**; 나머지 구성요소(observatory·
session·alarm·mcp·roster 등)의 계약 근거는 tests+dogfood다. 어느 쪽이든 미완성이 아니라
*가치가 미측정*일 뿐이고, 그 측정이 곧 협업벤치다. "experimental"은 core를 가리킨다(P3 §26).
cf. [[organum-company-analogy]](critic vs advisor 외부 role도 이 벤치가 측정).

## 3. 헌법 (경계 — 하는 것 / 하지 않는 것)

경계 유지가 이 프로젝트의 헌법이다. 플랫폼이 흡수할 것(배관·오케스트레이션)을 만들지 않고,
흡수하지 않는 것(축적되는 상태·규율·측정)을 만든다.

**한다**: 기관을 입힌다(사라지지 않는 기억) · 형태를 지킨다(저장 경계 guard) · 여럿을 맞물린다
(공유 매체·규율, 디스패처 없이) · 돌본다(checkup·backup) · 적절한 역할을 부여한다.
**하지 않는다**: 런타임/환경이 되지 않는다 · 오케스트레이션(에이전트 지휘) · 자체 LLM 추론 ·
능력 부풀리기(None은 None) · 우월 지능 추구(목표는 공존·다양성·경제성).

## 4. coordination 성장 원칙 — transport / policy / actor

조율층이 커질 때(동기 스트리밍·hierarchy·결재·A2A 등) 헌법을 지키는 하중 원칙:

- **transport**(전송: 파일·SSE·소켓·A2A…)와 **policy**(정책: directed/open·계약·결재·hierarchy)는
  organum이 소유한다. **actor**(누가 정하고 움직이나)는 **영원히 셀 안**이다.
- 그래서 sync·hierarchy·결재는 전송/정책의 추가지 "관제사 되기"가 아니다. 전례: roster=선언(배정
  아님) · alarm/chief=권고(명령 아님) · `field.directed` 플래그=전송 위 정책.
- **disable test(판정 기준):** 어떤 조율 조각이든 *꺼도 지연만 늘고 의미 결과가 같아야* 한다.
  통과 못 하면 transport가 아니라 새 orchestrator를 만든 것이다.
- transport는 열려 있다 — organum은 표준을 발명하지 않고 **어답트**한다. `sync`가 아니라
  **live delivery**로 부른다(용어 분해는 로드맵 §0). sync/async는 강제가 아니라 에이전트가
  고르는 전송 옵션. 상세: [[coordination-architecture-principle]] · docs/live-transport-roadmap.md.

## 5. 문서 지도 — 현행 vs 역사

**현행(canonical/설계):** 이 문서 · format-v0.md(포맷 계약, frozen) · observatory-design.md ·
live-transport-roadmap.md(그날의 지도) · quickstart-inspector·observe(매뉴얼) ·
case-study-inspector-duel(사례) · loop-engineering-and-organum.md §5(essay 씨앗).
**연구/근거:** p3-prereg-draft · persistence-ontology · collaboration-template · shared-cognition-harness.
**역사(초기 결정 기록 — 현행 아님):** HANDOFF.md · plan.md · spike-recheck-2026-07-04 ·
journal.md. 이들은 "왜 이렇게 시작했나"의 기록이지 "지금 무엇인가"가 아니다.

## 6. 배포

단일 PyPI 패키지 `organum`으로 제품군 전체가 함께 버전 업한다(콘솔 스크립트 `organum`·
`organum-inspector`). 공개는 언제나 public cut 경유([[organum-repo]]): dev(private
JihoonJeong/organum) → 화이트리스트 수출 → ludex-lab/organum(홈페이지+코드+PyPI 빌드 원천).
