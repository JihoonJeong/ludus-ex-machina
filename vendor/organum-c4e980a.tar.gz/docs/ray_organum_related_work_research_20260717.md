# Organum related-work 리서치 — 에이전트 메모리/상태 도구 지형 (2026-07 중순 기준)

To: JJ → (릴레이) Organum Cody / From: Ray / 2026-07-17
근거: plan §9-4 (related-work는 Ray 소유, 회피 금지). 방법: 딥 리서치 하니스 —
5개 검색 각도 → 24개 소스 fetch → 119개 클레임 추출 → 상위 25개를 3-투표
적대 검증 (25 확정 / 0 반박). **검증 통과 클레임만 단정 서술**하고, 검증
파이프라인을 통과하지 못한 것은 [미검증] 표기로 구분했다.

---

## 1. 한 줄 요약

2026 중반 지형은 두 층으로 갈린다: **(A) 새 에이전트를 만들기 위한 DB-기반
메모리 서비스/SDK** (Zep/Graphiti, Letta, mem0, A-MEM 계열)와 **(B) 이미 쓰는
에이전트 위에 얹는 파일-퍼스트 층** (Claude Code 네이티브 메모리, agentmemory,
beads 등). organum은 (B)층이고, 그 층은 비어 있지 않다 — 단, organum의 4대
차별점 중 **형태-우선 세계모델과 frontier는 출하된 경쟁자가 전무**하고, 나머지
둘도 "같은 층에서 같은 조합"은 없다. 문구 권고: "유일한 층" 대신 **"거의 빈
니치에서의 고유한 조합"**.

## 2. 도구별 카드 (검증 통과분)

### Zep / Graphiti — 시간-지식그래프 메모리 서비스
- **아키텍처**: 그래프 DB 기반 서비스 (Neo4j 주력, FalkorDB 등으로 확장;
  하이브리드 검색 = cosine + BM25 + 그래프 BFS). 인제스천에 LLM 호출.
- **분화**: 한다 — episodic(원문 무손실) / semantic entity / community 3층
  서브그래프. 논문이 심리학의 episodic/semantic 구분을 직접 인용.
  organum의 events/memories 구분과 가장 가까운 기성 구현. [arXiv:2501.13956]
- **모순 처리**: **사후 처리** — bi-temporal 모델(t_valid/t_invalid ×
  t_created/t_expired)로 모순 데이터를 일단 들여보낸 뒤 LLM이 구 edge를
  invalidate. organum guard의 "저장 시점 차단"과 기전이 다르다.
  시간축 표현력 자체는 events.jsonl보다 풍부(유효구간, 시점 질의).
- **증거**: DMR 94.8% (vs MemGPT 93.4%), LongMemEval +18.5% relative +
  레이턴시 ~90% 절감 — 단 **벤더 자기보고 프리프린트**이고, MemGPT 수치는
  타 세팅 자기보고(사과-오렌지), Zep 스스로 DMR을 부적절 벤치마크라 인정
  (풀컨텍스트 gpt-4o-mini 단독 98%), 별건 LoCoMo 주장은 커뮤니티 정정으로
  **~84% → 58.4%** (getzep/zep-papers issue #5). "Zep 보고에 따르면"으로만
  인용할 것.
- **층위**: (A). Graphiti MCP 서버로 기존 에이전트(Claude, Cursor)에 붙일 수
  있으나 여전히 DB+LLM 서비스. Apache-2.0, ~28.8k stars.

### Letta (MemGPT 계보) — 상태ful 에이전트 런타임
- **분화**: 종류(kind)가 아니라 **컨텍스트-티어**로 분화 — in-context core
  memory(블록) vs external archival(+recall=대화이력). 문서 어디에도
  episodic/semantic/procedural 분류 없음. organum 분화 축과의 직접 대비점.
  [letta.com/blog/letta-leaderboard]
- **운영 규율 유사물**: **sleep-time compute** (0.7.0, 2025-04) = reflect/
  consolidate의 최근접 유사물. 유휴 시간에 "raw context → learned context"
  변환. 구현은 2-에이전트: 메모리 편집 도구를 배타 보유한 백그라운드
  sleep-time 에이전트가 자기+주 에이전트의 메모리 블록을 재작성 (sleep-time
  활성 시 주 에이전트는 core memory 편집 불가). **차이**: 런타임 내 자동
  LLM-에이전트 vs organum의 사용자-호출 CLI 의례 + LLM은 사용자 CLI에 위임.
  도구 게이팅의 근거도 레이턴시/역할분리지 오염 차단이 아님. 시효: 서버측
  sleep-time 에이전트는 2026-03 deprecated, 클라이언트측 서브에이전트로 전환.
- **측정 문화의 균열**: 자사 대표 기능인 sleep-time 메모리 재조직이 자사
  리더보드에서 **여전히 미측정** (2025-05 "추가 예정" → 2026-03 재출시판에도
  부재). 별도 논문(arXiv:2504.13171)은 있으나 수학-추론 사전계산 측정이지
  메모리 재조직 측정이 아님. measured≠asserted 원칙의 반면교재.

### A-MEM (NeurIPS 2025) — 학계 agentic-memory 대표
- **구조**: Zettelkasten식 상호연결 노트 + memory evolution(신규 기억이 기존
  노트 속성 갱신 유발). 그러나 **분화 없음** — 모든 기억이 단일 노트 타입
  {content, timestamp, keywords, tags, context, embedding, links}, 단일
  ChromaDB 컬렉션 + cosine 검색. 이질적 메타데이터 ≠ 타입-라우팅.
  [arXiv:2502.12110]
- **증거**: LoCoMo ROUGE-L 44.27 vs 18.09 (multi-hop, GPT-4o-mini) — 저자
  보고이며 **독립 재현 실패 사례 존재** (MemoryOS, arXiv:2506.06326이 공통
  환경 재실행에서 더 낮은 수치 보고).

### Claude Code 네이티브 메모리 — organum이 얹히는 바로 그 기반층
- 문서화된 파일 기반 메모리 2종 + 세션 트랜스크립트(JSONL): 사용자 작성
  CLAUDE.md 위계 + 자기-작성 auto memory (~/.claude/projects/<p>/memory/,
  MEMORY.md 인덱스는 첫 200줄/25KB만 세션 로드, 토픽 파일은 온디맨드,
  머신-로컬). [code.claude.com/docs/en/memory]
- **분화 없음** (빌드 명령·디버깅 통찰·아키텍처 노트·선호가 한 자유형
  마크다운 저장소에 혼재, 큐레이션은 Claude 자율) · **세계모델/리포맵/
  frontier 없음** · 서드파티 생태계(mem0 MCP, 벡터/그래프 메모리 서버)가
  정확히 이 공백을 메우려고 존재.

### jayzeng/agentmemory — **사이드카 니치의 존재 증명 (organum "유일 층" 주장 기각)**
- 같은 니치: 파일-퍼스트(플레인 마크다운, "no database, no cloud"), no-LLM,
  결정론적 CLI + SKILL.md로 **기존 에이전트**(Claude Code/Codex/Cursor)에
  영속 기억 부여. npm myagentmemory v0.4.12, MIT. [github.com/jayzeng/agentmemory]
- 단 **동급 경쟁자는 아님**: ~11 stars/1 fork; 기본 **글로벌** ~/.agent-memory/
  (organum은 프로젝트-로컬); 분화는 부분적(큐레이션 MEMORY.md + SCRATCHPAD +
  append-only 일일 episodic 로그 + provenance 백링크 토픽 로그 — 파일 구성이지
  타입-라우팅 아님); **worldmodel/리포맵/frontier/저장시점 guard/reflect·
  checkup·backup 의례 전부 없음** (README 부정 확인 검증 완료).
- 함의: 나머지 3개 차별점은 이 도구 상대로도 유지. 그러나 "아무도 이 층에
  없다"는 문구는 이제 거짓.

## 3. 차별점 4개 판정 (회피 없이)

| # | organum 차별점 | 판정 | 근거 요지 |
|---|---|---|---|
| 1 | 분화된 기억 라우팅 | **부분 고유** | 분화 원리 자체는 기성(Zep 3층 그래프) + 학계 인정(47저자 서베이 arXiv:2512.13564의 factual/experiential/working — 단 분류 자체가 "심하게 파편화, 미정착"이라 명시; 'experiential'은 episodic+procedural을 묶어 organum과 불일치). **파일-퍼스트 사이드카 층에서 episodic/declarative/procedural 라우팅을 실은 도구는 없음.** "대부분 무분화 단일 저장소"라는 글로스는 쓰지 말 것 — Letta·Zep은 다른 축으로 분화한다. |
| 2 | 형태-우선 세계모델 | **고유 (출하 기준)** | 조사 도구군 전체에서 유사물 없음. |
| 3 | 명시적 frontier | **고유 (출하 기준)** | 유일한 유사물은 ToCS 벤치마크(arXiv:2603.00601, 2026-03)의 **평가 스키마** — 인지맵의 observed/inferred/unknown 상태 + "미탐색 영역 명시 리스트"를 요구. 즉 개념은 학계가 검증했으되 영속 도구로 실은 곳 없음. (ToCS 캐빗: 단독 저자, self-labeled WIP, 단일 런 예비 결과 — 개념 인용용으로만.) |
| 4 | 운영 규율 + guard | **조합 고유, 요소는 유사물 존재** | reflect/consolidate ≈ Letta sleep-time(자동 in-runtime); 모순 처리는 Zep이 사후 invalidation으로 함(들여보내고 만료) — **저장 시점 차단(admission refusal)은 조사 범위 내 organum 고유.** mem0의 업데이트-시점 모순 해소는 검증 미통과로 이번 판정 범위 밖 [미검증 — 후속 확인 필수]. |

**guard의 외부 근거 (이번 리서치 최대 수확):** 'Anatomy of Agentic Memory'
(arXiv:2602.19320, 2026-02/05)가 **write-time silent failure를 실증** — 구조화
(JSON-작성) 메모리 시스템이 약한 백본에서 포맷 오류율 17.91%(gpt-4o-mini) ~
30.38%(Qwen-2.5-3B) (malformed JSON, hallucinated keys), 에이전트는 유창하게
대화를 계속하는 동안 장기기억이 조용히 오염된다. flat-summary 시스템은
1.20-4.82%. 정확히 organum guard + **non-LLM programmatic write**가 설계로
회피하는 실패 모드다. (캐빗: 논문은 append-only JSONL을 직접 실험하지 않음 —
연결은 추론임을 문서에 명시할 것.)

## 4. 증거(벤치마크) 지형 — 경쟁자가 앞서지만, 그 잣대 자체가 흔들린다

- **경쟁자 우위는 실재**: Zep·A-MEM 등은 숫자가 있다. organum은 0이다.
  이 갭은 P3 사전등록 dogfood가 메꿔야 한다 (§9-1 그대로).
- **그러나 2026 메타연구(arXiv:2602.19320)가 잣대를 흔든다**: (a) 벤치마크
  포화 — Context Saturation Gap Δ = 메모리시스템 − 풀컨텍스트; HotpotQA·
  MemBench는 128k 윈도우 안에 들어가 메모리 층이 구조적으로 불필요;
  (b) 어휘 메트릭이 순위를 뒤집는다 — A-Mem F1 0.116(5위) vs LLM-judge
  0.480(4위); judge 점수도 프롬프트 민감; (c) 총평 — "이득은 벤치마크 간
  비일관, 백본 의존 심함", 구조화 메모리가 정확도에서 풀컨텍스트를 이긴다는
  명확한 증거 없음, 레이턴시/비용 트레이드오프 큼 (MemoryOS 32.4s vs 1.7s;
  A-Mem 기억 구축 15h).
- **벤더 벤치마크 전쟁**: Zep LoCoMo ~84% → 커뮤니티 정정 58.4%. [미검증
  참고: mem0↔Zep 상호 재실행 분쟁, LoCoMo 정답지 오류율 ~6.4% 감사(Penfield
  Labs), Letta의 "파일시스템 에이전트만으로 LoCoMo 74%" 자기보고 — 방향은
  일관되게 "이 벤치들 신뢰 불가"를 가리키나 개별 수치는 검증 미통과.]
- **P3 함의 (내 레인)**: organum eval은 LoCoMo류 재탕이 아니라 **포화-인지
  프로토콜**이어야 한다 — Δ≫0 입증 구조(풀컨텍스트 대조군 필수), semantic
  judging, 복수 백본, 그리고 non-LLM write 경로가 17-30% 오염율을 실측으로
  회피하는지 자체가 측정 대상. 이건 physis-MUD 기계(동시 대조군·사전등록·
  Fisher/perm)가 그대로 이식된다.

## 5. 외부 벤치마크 = capability card의 evidence 공급원 (JJ 제안 각도)

경쟁 분석과 별개로, 업무역량 벤치마크들은 **organum의 경쟁자가 아니라
vendor-capabilities/MTI 카드의 evidence 필드 공급원**이다 (measured≠asserted의
외부 소스):

- **Agent Mode + Agent Arena** (arena.ai; JJ가 공유한 @arena 트윗으로 확인 —
  status/2062565126600114484): Agent Mode(2026-07 발표)는 사용자가 자기 실무
  태스크(파일 업로드 포함)를 여러 모델 에이전트에 side-by-side로 던져 비교하는
  사용자-대면 서비스, Agent Arena(2026-06 런칭)는 그 세션들(105만+)에서
  causal inference로 task success/steerability/error recovery/tool
  hallucination 등 행동 신호를 재는 리더보드 짝이다. 클라우드 비교-평가
  서비스 = 태스크를 *돌리는* 층이므로 positioning-vs-ade의 Orca 논리 그대로
  organum과 층이 다르다. (인접 신호: 같은 니치의 로컬/오픈소스 대안을 만드는
  실무자 존재 확인 — 민감 데이터의 클라우드 업로드 회피 동기. 파일-퍼스트/
  로컬 철학이 organum과 같은 결; public 전환 시 후속 확인 목록에 추가.)
- **ClawArena-Team** (arXiv:2606.31174) — 오케스트레이터의 분해/위임/
  에러처리/종합을 중간 결정 노드 단위 채점.
- **WorkArena++** (ServiceNow) — 지식노동 682태스크.

agents 레지스트리 카드 스키마에 "외부 벤치마크 스코어 + 출처 링크 + 측정일"
슬롯을 두면 §7-1 카드 패턴과 그대로 합치.

## 6. 커버리지 갭 (정직 고지)

**mem0/OpenMemory, LangMem/LangGraph memory, Cognee, Cursor/Windsurf rules,
Gemini CLI, OpenAI/Codex memory, beads, 범용 MCP 메모리 서버에 대한 클레임은
3-투표 검증을 통과하지 못해 이 리포트는 침묵한다** — 검증 예산의 한계이지
그 도구들에 해당 기능이 없다는 증거가 아니다. 특히 **mem0의 모순 해소가
guard 차별점에 대한 가장 유력한 추가 도전**이고, **beads**(Yegge, git-backed
JSONL 이슈트래커 = 사이드카 기억)는 니치 인접이다. README 초안은 이 갭을
버틸 수 있게 썼지만(단정 회피), 공개 전 mem0·beads 2건은 후속 검증 권고.

## 7. README 문구 권고 (Organum Cody 반영용)

1. "유일한 층" 계열 문구 금지 → **"거의 빈 니치에서의 고유한 조합"**
   (agentmemory 존재 증명 + beads 인접).
2. 타사 벤치마크 수치는 전부 "X 보고에 따르면" 화법 (Zep 정정 사례).
3. guard 절에 arXiv:2602.19320 write-time silent failure 인용 (추론 연결임을
   명시) — 4대 차별점 중 유일하게 외부 실증 근거가 생긴 축.
4. frontier 절에 ToCS 인용 가능 (개념 검증용, WIP 캐빗과 함께).
5. 분화 절은 "우리만 분화한다"가 아니라 "**이 층에서** 분화를 실은 건
   우리뿐, 그리고 분류학은 학계도 미정착"으로.

## 8. 열린 질문 (후속)

1. mem0/LangMem/Cognee/Cursor·Windsurf의 4축 위치 — 특히 mem0 모순 해소
   vs guard (최우선 후속).
2. ToCS-스타일 프로브를 organum worldmodel/frontier의 **eval로 역이용**할 수
   있는가 (P3 설계 재료).
3. P3가 2026 잣대(Δ≫0, semantic judging, 복수 백본)를 통과하는 최초의
   사이드카 측정이 될 수 있는가 — 그 자체가 차별점 4의 실증.
4. 사이드카 니치의 통폐합 방향 — agentmemory/beads류가 성장해 남은 3개
   차별점을 잠식하는가, 하비 스케일에 머무는가.

## 주요 출처

- arXiv:2501.13956 (Zep/Graphiti) · arXiv:2502.12110 (A-MEM, NeurIPS 2025) ·
  arXiv:2506.06326 (MemoryOS 재실행) · arXiv:2512.13564 (47저자 메모리 서베이)
- arXiv:2602.19320 (Anatomy of Agentic Memory — 포화/메트릭/silent-failure) ·
  arXiv:2603.00601 (ToCS — frontier 평가 스키마) · arXiv:2504.13171 (sleep-time)
- code.claude.com/docs/en/memory · github.com/jayzeng/agentmemory ·
  github.com/getzep/graphiti · github.com/getzep/zep-papers (issue #5) ·
  letta.com/blog/{letta-leaderboard, sleep-time-compute}
- (미검증 참고선) blog.getzep.com mem0 반박문 · penfieldlabs LoCoMo 감사 ·
  steve-yegge.medium.com beads 소개 · letta.com filesystem-74% 포스트
