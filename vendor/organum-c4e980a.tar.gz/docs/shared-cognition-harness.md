# 공유 인지 하네스 — organum 제품 방향 (탐색)

*2026-07-11, JJ 발의·Cody 설계 (긴 상의의 산물). **방향/탐색 문서 — 대부분 post-v0.** 정체성·
아키텍처 원칙을 고정하고, 구현은 슬라이스로 제안한다. format v0는 FROZEN — 이 문서는 계약·패턴이지
기계가 아니다. 확정된 것과 열린 것을 §8에서 구분.*

## 0. 한 줄 정체성

> **여러 브레인, 하나의 기억 — 각자 네이티브 CLI로 일하되 같은 유기체로 기억·조율한다.**

새 에이전트도, IDE도, 오케스트레이터도 아닌 **공유-인지 하네스(shared-cognition harness).**

## 1. 왜 지금 (why now)

- **SKILL.md / Agent Skills 표준화** → 스킬 관찰·주입이 벤더-특정 해킹이 아니라 *표준 표면* 위에서
  가능. 이게 이 방향 전체의 enabler.
- 실무자가 이미 **멀티-CLI**(claude·codex·gemini)를 씀 → 벤더-중립 공유 인지의 빈자리.

## 2. 정체성 — A/B 합성

- **A**(벤더-중립 공유 substrate)와 **B**(멀티-에이전트)를 **stigmergy**로 융합: 조율이 공유
  상태에서 *창발*하지 디스패처를 통해 라우팅되지 않는다.
- **오케스트레이션 = 네이티브 CLI**(Claude subagent 등, 재발명 금지) / **organum = 공유 인지 +
  관찰 + loose ledger.** organum은 지휘하지 않고, 네이티브 지휘를 *관찰 가능·공유·영속·크로스-벤더*로
  만든다.
- **비종속성(벤더-중립)이 해자**: 각 호스트 메모리는 자기 벤더 락 → 중립 공유 인지는 *밖에 있는
  것만* 될 수 있다. RPC 디스패처는 안 됨(깨지기 쉽고 커모디티, 플랫폼 흡수).

## 3. UX — tmux 원형 + organism 스킨

- **tmux 레이아웃**(익숙 → 학습비용 0), 단 상태바·패널 = **유기체 vitals**: self(정체성)·memory(기억
  스트림)·map/frontier(claim)·world-model(신뢰도)·**guard=면역**(차단·병합)·**token/cost=대사.**
- 인스펙터 = **소환되는 앰비언트**(Sidekick 계보), destination 아님.
- "네가 아는 tmux인데, 상태바가 네 유기체의 활력징후다" — 어떤 멀티플렉서도 organ substrate가 없어
  못 하는 것. 정체성이 곧 차별점.
- **설계 계보**: Plan 9/acme(파일시스템=조율 매체 → `.organum/`) · Sidekick/TSR(앰비언트 소환) ·
  Norton/Midnight Commander(상태-보며-행동 패널) · git 3-way merge(guard-merge) · Lotus Notes 복제
  (충돌은 조용하면 독). **반면교사**: Emacs·Turbo IDE(흡수-통합 = destination 트랩), DESQview가
  Windows에 흡수됨(멀티플렉서 층=커모디티).

## 4. 지휘 패턴 (common case)

- 주 CLI = orchestrator(네이티브 subagent로 역할 에이전트 호출), 사용자는 거기서 대화.
- organum은 그 호출을 **공유 기억에 남기고 · 인스펙터에 보이고 · 크로스-벤더 참여를 ledger로.**
- peer/stigmergy의 *특수 케이스* — 한 에이전트가 주도하되 다 같은 substrate. 일반(peer)·특수
  (orchestrator) 둘 다 같은 지반 위.

## 5. 기능 — feasibility 랭크

| 기능 | 가능성 | 기반 / 비고 |
|---|---|---|
| **통합 토큰/비용 모니터링** | ✅ 쉬움·고가치 | `cost.py`가 이미 `total_cost_usd` 파싱. 각 pane usage→공유 `.organum/`→인스펙터 집계. 크로스-벤더 통합 모니터는 아무도 안 줌 = wedge |
| **스킬/하네스 관찰** | ✅ feasible | `extract.py`가 이미 stream-json `tool_use` 파싱. SKILL.md 스캔(provision이 이미 읽음) |
| **subagent 호출 공유 기억** | ✅ feasible | 주 CLI 훅 → `.organum/` 이벤트, 타 브레인 `organum context`로 읽음 |
| **크로스-터미널 가시성** | ✅ feasible | 인스펙터가 substrate+pane 워치 |
| **스킬 utility 축적 (만족도)** | ⚠️ novel·soft | **Voyager식 component 학습**(self-improvement 우리 레인). 만족도 측정 soft → 명시적 확인 + robust proxy(guard-clean·no-rework·over-anchoring)부터, 점수 과신 금지 |
| **task/skill 캐시** | ⚠️ feasible·규율 | 메모리 organ, 단 무효화·freshness=guard 몫(stale=오염, error-fallback). provenance 태그 |
| **크로스-벤더 hand-off** | ⚠️ 가능·**검증된 패턴** | **폴더 우체통(relay mailbox)** = 우리 `_relay/` 패턴(transport 뺀 버전, §6.1). RPC/send-keys 아님 — 비동기 pull |

## 6. 협력 부트스트랩 — organum coordination skill

- 런치 때 organum이 각 CLI에 **coordination SKILL.md를 설치**(=`provision` 기계 반전 재사용:
  기존 스킬 배선 대신 organum 자기 협력 스킬을 심음) → 네이티브 에이전트가 공유 substrate에 *참여*
  (공유 context 읽기 · usage/skill-call 보고 · task claim). 스킬 = 세포가 유기체에 붙는 **막(membrane).**
- 표준 SKILL.md **하나로 SKILL.md-호환 CLI 다 커버**; 미지원은 per-vendor context 주입 fallback.
- 설치 = **provision 경계**(immune 감사 · trust · allowlist · fail-closed) 재사용.

## 6.1 협력 채널 — 폴더 우체통 (relay mailbox) 【검증된 패턴】

CLI 간 비동기 소통은 새로 발명할 필요가 없다 — **우리가 이미 `_relay/` 우체통으로 검증했다**
(Cody·Ludex·Ray가 보스 없이 파일 우체통+프로토콜로 협업). 폴더 내 공유 mailbox(`.organum/relay/`)로
옮기면 transport조차 불필요(같은 폴더).

- **핵심 습관**: coordination skill이 **"항상 우체통부터 뒤진다"를 습관화** → 각 에이전트가 자기
  차례(세션 시작 · 주요 행동 전)마다 pull. 푸시·디스패처 없이 **비동기 소통이 자동 유지**된다.
- **보증 강화**: 스킬은 soft(건너뛸 수 있음) → **SessionStart 훅**이 우체통을 *결정적으로* 주입 +
  스킬이 작업 중 check/reply를 습관화. **훅=보증, 스킬=습관.**
- **주소·claim 프로토콜**: `_relay/` 파일명/frontmatter 규약 재사용(`from-X-to-Y-topic` + claim/done
  마커) → 둘이 같은 태스크를 중복해 잡지 않음.
- **immune**: 들어온 메일 = 타 에이전트 유래 → `src:` provenance + guard가 저장 경계에서 중재
  (남의 claim이 조용히 내 기억을 오염시키지 못하게). 우체통에도 면역 적용.
- **read-cursor**: 에이전트별 처리-마커(이미 읽은 메일 재처리 방지 — 이메일 read/unread).
- **정직한 성격**: **async · eventually-consistent**(세션경계+주기 latency), real-time 아님. loose
  coupling의 강건함이 지연을 대가로 받는다 — 느슨한 협업엔 feature, 촘촘한 tight 조율엔 부적합.

## 6.2 공유-인지 허브 — 웹 뷰로 수렴 (프로젝트 브레인)

우체통(§6.1)에서 한 걸음 더. 웹 뷰(localhost, stdlib http.server)는 모니터+우체통을 넘어 **공유-인지
허브**로 자란다 — 독립적으로 도는 CLI들을 *하나의 유기체*로 묶는 공유 층을, 사람이 브라우즈·큐레이션
하고 각 CLI가 관련 조각을 advisory로 *당기는* 곳. tmux 의존 없음(어느 터미널에서 돌든).

**흐름(flow) vs 비축(stock):**
- **흐름 = 우체통**(transient): 공지·편지·task claim (§6.1).
- **비축 = 공유 레퍼런스**(durable): 스펙/RFP/문서→공유 세계모델 · 규칙→공유 계약(membrane §2.1) ·
  조직도→참여자 로스터(*서술적*) · 유대→bonds(관계+provenance) · 연관성→그래프-organ(nodes not rows).

**핵심 통찰 — 그래프가 왜 필수인가**: 보드가 커지면 에이전트가 전부 읽을 수 없다(**injection budget**,
plan §2 터짐). "관련된 것만 pull"이 필수 → **relatedness 그래프가 그 선별 엔진**이다. 그래프-organ은
장식이 아니라 공유 보드를 *규모 있게 굴리는 핵심* — `organum context` 큐레이션의 멀티-에이전트·그래프 버전.

**경계 (관제탑 ↔ 관제사)**: 전부 *사람이 큐레이션하고 에이전트가 당기는 공유 컨텍스트*지 organum이
배정·강제하는 게 아니다. **조직도 = 서술적 로스터(읽기)**지 지시적 배정(dispatch)이 아니다 — "누가 뭘
맡았다더라"를 *보여주는* 것이지 organum이 *시키는* 게 아니다. 웹 뷰는 밀지(push) 않고 당긴다(pull);
사람은 공유 매체에 쓰는 또 하나의 peer.

**정체성 수렴**: organum = **벤더-중립 공유-인지 substrate + 그 인간 얼굴** — 독립 AI CLI들을 하나의
기억·규칙·관계·그래프를 공유하는 유기체로 만드는 **프로젝트 브레인.** "여러 브레인, 하나의 기억"의 구체 형태.

## 7. 빌드 슬라이스 (✅ = 진행/완료 · 이하 제안)

1. ✅ **인스펙터 (단일 벤더)** — `organum inspect` 라이브 vitals (transcript tail · stdlib · 폭-인지 + 하트비트).
2. ✅ **참여 관찰 층** — `organum inspect --all` 멀티-세포 수렴 (관점-로컬 read-only, §2.1-⑤) · `live` tmux 런처.
3. ✅ **웹 v1 — 관제탑**: localhost(stdlib http.server) 모든 세포 수렴 + live/stale + terminal/subagent
   패밀리(← 부모). tmux 탈의존 · 크로스-플랫폼 · 공개 얼굴.
4. ✅ **웹 v2 — 게시판(우체통)**: `.organum/relay/` 편지 표시(접기) + compose(chip 수신인·터미널만) +
   archive(human 소프트 정리, 수정 금지).
7. ✅ **능동 조율**: `skills/organum-coordination/SKILL.md`(pull 습관·에티켓) + `organum relay`
   (inbox/send/read, read-cursor). 세포가 우체통을 스스로 당김.
5. **웹 v3 — 공유 레퍼런스**: 스펙/규칙/로스터/bonds 브라우즈+큐레이션 (§6.2 비축). 로스터=선언적 lineage.
6. **그래프 relatedness**: nodes-not-rows 그래프-organ → "관련된 것만 pull" 선별(injection budget) +
   **relay 편지 분류·정리·관계도(JJ)** — 우체통 축적 → 엔티티 그래프(누가↔누구·주제·스레드).

## 8. 경계 · 확정/열림 · 정직한 리스크

- **경계**: 네이티브가 지휘 / organum = 공유 인지·관찰·매체. spawn은 네이티브. **디스패처 안 됨.**
  웹 뷰는 **관제탑(read-only 조망)이지 관제사(통제)가 아님** — 밀지 않고 당긴다(pull), 조직도=서술적
  로스터(읽기)지 배정 아님, 사람은 공유 매체에 쓰는 peer. "organum이 세포를 굴린다"까지 삼키면 트랩.
- **확정**: 정체성 = **벤더-중립 공유-인지 substrate + 인간 얼굴(프로젝트 브레인)** · 참여 관찰 층
  **SHIPPED**(`inspect --all`) · UX 원형(tmux+organism, 웹 뷰로 성숙) · 지휘 해법(네이티브 지휘/organum
  관찰) · 협력 채널 = 폴더 우체통(`_relay` 검증) · flow/stock 허브(§6.2) · 그래프=injection-budget 선별 엔진.
- **열림**: 우체통 프로토콜 세부(주소·claim·read-cursor) · check 빈도(latency vs 오버헤드) ·
  만족도 신호 정의 · 캐시 무효화 정책 · 크로스-벤더 스킬 지원 범위.
- **리스크**: 만족도 측정 soft(과신 금지) · 캐시 무효화=guard/provenance · SKILL.md는 Claude 생태계
  확실·범벤더는 aspirational · 스킬 설치=trust(provision immune) · stigmergy는 tight control 포기.

관련: [[collaboration-template]] · [[persistence-ontology]] · [[skill-library-as-cargo]] · plan §1(경계)
