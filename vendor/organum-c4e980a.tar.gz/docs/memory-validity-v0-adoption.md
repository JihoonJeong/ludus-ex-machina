# memory validity 계약 v0 채택 선언 (JJ 결정 2026-08-04)

organum은 Ray의 **memory validity 스키마 v0**(정본: Ludex 리포
`docs/memory-validity-schema.md`, 커밋 `f2972317`; 릴레이 2026-08-04)를 `memories.jsonl`
계약으로 **채택한다**. 경계 문서 §5-3 "형식만 공유, 거버넌스는 각자" 조건 그대로 —
채택은 형식 계약의 상속이고 거버넌스(무엇을 기억하나·guard 규칙)는 organum 것이다.

## 상속하는 것

- **top-level 선택 필드 3**: `why`(생성/승격 시점만 — 소급 기입은 거짓 provenance 제조) ·
  `outcome`(수동/amendment 경유만, 부재=추적 안 됨) · `valid_until`(문자열 기한 또는
  무효화 조건 또는 null/부재=무기한).
- **의미론 4**: why 소급 금지 · outcome 자동 추적 없음(v0) · 만료 엔트리는 삭제하지 않고
  recall이 **"expired" 태그로 신뢰 강등**(랭킹 불변, v0) · 조건형 valid_until의 판정자는
  사람.
- **규율 2**: D21(스키마만 동결·dead code 없음·변경은 v1 선언으로만) ·
  D-024(신규 writer 종류 금지 — 기존 writer가 기존 엔트리에 필드를 더할 뿐.
  organum에서 "기존 writer" = guard 경유 `memory.remember()`).

## 이행 방식 (두 동결의 교차점)

`docs/format-v0.md`는 FROZEN이고(변경=format_version 증가+migration으로만), Ray D21은
"스키마만, dead code 없음"이다. 따라서:

1. **지금(이 문서)**: 계약 상속 선언만. 코드 0, format-v0.md 무변경.
2. **다음 format_version 증가 시**: 세 필드를 memories.jsonl 스펙의 정식 선택 필드로
   편입(추가-전용이라 migration은 no-op; 부재=pre-v0 엔트리로 하위호환 완전).
3. **writer/reader 배선**(remember의 why/valid_until 인자, recall의 expired 태그)은 그
   편입과 같은 엔지니어링 레인에서 — 그 전까지 스펙 밖 필드 금지 규칙(§0 `x_` 접두)이
   그대로 유효하므로 조기 기입하지 않는다.

## v1 정렬 관찰 (Ludex Cody 관찰 공유)

`valid_until`(기억: 기한 지나도 서사는 남되 신뢰 강등)과 hub 봉투의
`claim.evidence_availability`(주장은 참이되 독립 검증 수단이 만료)는 **같은 구분의 다른
층**이다. v1에서 어휘 정렬을 검토한다 — 지금은 관찰만 pin.
