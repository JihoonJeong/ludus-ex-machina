# signer.introduced — 신규 서명자 사후 도입 (0.4.2 설계 기록)

**◆ FINAL ACCEPT — 기준 핀 `93f0b14228d39afaed25878c8611a87b30c20c67` (2026-08-17)**

- **Orin r3 FINAL ACCEPT**(r2 `29a742a` ACCEPT를 명시 대체): exact archive 176
  passed·diff clean, bare-name 폐쇄 4항 실측, 기존 I1 probe 전항 재실행(wire 경유
  peer 도입 거부 포함). 성격 규정: "r3는 authority를 넓히는 변경이 아니라 공개
  CLI가 이미 허용한 bare-name 기존 hub에서 이름과 bootstrap 결속의 교차 확인으로
  운영 lab을 복구하는 하위호환 보정."
- **Ludex r3 ACCEPT**: 라이브 hub 11 이벤트 전 구간 replay 소생 실측(r2 거부점
  포함), ORGANUM_SRC 핀 93f0b14 상향, 그들 도구의 첫 서명이 판정 봉투(006).
- **LxM**: 본판정 미도착 상태로 승격(호스트 업무 우선; Orin의 명시적 승격 승인
  + 소비자 라이브 검증 기준). 지적이 오면 delta로 접수 — 재개방 경로는 열려 있다.

판정 계보: 초판 `36f6818` → Orin I1(BOUNDED REVISE) → r2 `29a742a`(운영 lab
파생) → Ludex 라이브 반증(BLOCKING DISSENT, bare-name hub 동결) → r3 `93f0b14`
(bootstrap 교차 확인) → 양 랩 FINAL/ACCEPT. 반례 발견→폐쇄→라이브 반증→재폐쇄가
당일 세 랩을 돌았다 — 첫 봉투-채널 크리틱 루프.

## 동기 — 실사용이 밟은 구멍 (2026-08-17, Ludex)

hub-ops 첫 실전 왕복에서: Ludex hub는 bootstrap에서 lab:ludex·lab:ray 두 서명자로
섰고 admitted log가 이미 선 상태 → lab:organum 등록이 **C1 가드**("admitted 이벤트가
이미 있어 bootstrap 등록 불가")에 거부. rotate-key는 같은 signer의 키 전이 전용이라
신규 서명자 도입 경로가 아니다. 우리 hub도 대칭으로 같은 벽(실행 확인). 이 항목은
명시적 잔여(key lifecycle/registry) 안에 있었고, 실사용이 처음 닿았다.

## 설계 — rotate-key와 같은 원리: lifecycle 전이는 admitted 이벤트가 몬다

- **이벤트**: `signer.introduced` (EVIDENCE_KINDS), payload =
  `{signer_id, key_id, key_epoch, pubkey}` — lab grammar·key_id grammar·epoch≥1·
  hex64 shape 검증(스키마 층).
- **서명자**: 기존 등록되어 현재 유효한 signer(봉투 signer binding이 보장).
- **효력**: 결속의 `valid_from_seq = 도입 이벤트 accepted_seq + 1` (Orin C2 관례 —
  전이 효력은 좌표 다음부터). bootstrap(valid_from_seq=0)과 달리 **소급이 없다** —
  C1 가드가 지키는 것과 같은 불변식을 다른 자리에서 지킨다.
- **정책 게이트 4** (`_policy_signer_introduced`):
  1. **도입 authority = hub 운영 lab만**(r2, Orin I1 폐쇄) — authority는
     source_domain에서 **구조적으로 파생**된다(`_introducer_authority`): 설정
     필드가 아니라 파생이라 silent post-log mutation 표면이 없고(C1 우회 불가),
     direct admit·wire·CLI·replay가 전부 같은 술어를 지난다. 등록 peer는 도입
     불가·피도입자 권한 자동 상속 없음(재귀 membership CA 금지)·signer ID 선점
     불가(거부는 로그를 전진시키지 않으므로 뒤의 정당 도입이 성립).
     **파생 규칙(r3 — Ludex r2 반증 교정)**: ① 첫 조각이 `lab:x` 문법이면 그것
     (자기 선언) ② bare name `n`(공개 CLI init이 허용하는 표면)이면 `lab:n`이
     **bootstrap 결속**(valid_from_seq=0, C1-guarded hub.json pin)일 때만 파생 —
     교차 확인 요구, 도입 결속은 자격 없음(로그 순서 무관·결정적) ③ 어느 쪽도
     아니면 None = fail-closed(라이브러리 기본 "organum-hub/local"이 이 경우).
     r2의 반증: bare name hub(실재 — Ludex 라이브 `--source-domain ludex`)에서
     authority=None이 되어 **정당한 운영 lab 도입까지 거부 → replay가 로그 손상
     판정 → hub 동결.** 교훈 명문: 하위호환 판단은 상대의 실제 config 표면
     (CLI가 허용하는 입력 공간)을 근거로 한다 — 서명자 일치만으로 "replay 무변"을
     추론하지 않는다. hub.json 손편집 마이그레이션 안내는 배제(그 자체가 silent
     mutation).
  2. 자기 도입 금지 — 자기 키는 rotate-key로.
  3. 결속이 전혀 없는 signer만 — 기존 signer의 키 추가는 그 signer 자신의
     rotate-key 전용(타인이 남의 authority를 늘릴 수 없다).
  4. pubkey 미결속 — 조용한 재사용 금지(§6 규율 상속).
- **정확한 층위 문장**(Orin I1 채택): introduction은 서명자 admission
  eligibility를 부여하는 **로컬 membership 결정**이다. 개별 claim의 진실·역할
  권위는 해당 kind/claim 정책이 별도로 정한다.
- **CLI**: `organum-hub introduce-signer --dir … --key <도입자 seed> --signer …
  --key-id … --epoch … --new-signer lab:x --new-key-id k1 --new-epoch 1
  --new-pubkey <hex64>`. register-key 거부 메시지가 이 경로를 안내한다.

## Ludex 선입력 3건의 처리 (crit 회람 전 반영)

1. **도입 ≠ 신뢰**: 이 이벤트는 키 결속(인증 층)만 세운다. 도입된 signer의 봉투
   admit 여부는 여전히 서명·스키마·정책 게이트가 정한다 — 도입 이벤트에 admission
   권리가 따라붙지 않는다(개방은 프로토콜에, 큐레이션은 정책에). 코드가 자연히
   그렇다(registry=authn 전용) + docstring 명문.
2. **revoke 연쇄는 프리미티브가 아니다**: 도입은 사실 기록이지 살아있는 의존이
   아니다. 도입자 키 revoke 후에도 피도입자 봉투는 admit된다(회귀로 고정). 연쇄가
   필요하면 정책 층의 결정이다 — 스펙 슬롯으로 남긴다.
3. **소급 정식화 — 가(可)로 명문**: 도입 전에 게이트 수준으로 검증해 둔 봉투는
   도입 뒤 재-admit으로 정식화할 수 있다. 봉투에 수신측 seq가 박혀 있지 않으므로
   admit 좌표가 도입 뒤면 `was_valid(pubkey, accepted_seq)` 불변식 위반이 아니다.
   회귀: 도입 **전** 서명해 둔 봉투가 도입 뒤 admit — pass.

## 회귀 (test_hub_cli.py)

- happy path: log 선 hub에 도입 → 도입 전 서명 봉투의 사후 admit(소급 정식화) →
  도입자 revoke 후 피도입자 생존(무연쇄) → was_valid 좌표 의미(n 무효·n+1 유효).
  CLI 호출마다 재생 경유라 replay 지속성도 함께 선다.
- 음성 4종: 자기 도입 · 기존 signer · 결속 pubkey · lab grammar 밖.

## 소비자 명문 2건 (Ludex ACCEPT 지적 반영, 08-17)

- **유효 서명자 집합 = bootstrap keys + 로그 투영.** hub.json `keys`에는 bootstrap
  결속만 지속되고, 도입 결속은 admitted 로그의 재생 투영으로 산다 — hub.json만
  읽는 소비자는 멤버십을 과소집계한다. 진실 표면은 재생 후 registry(`list`)다.
- **`authority_projected`는 신뢰 부여가 아니다** — "이 이벤트가 hub의 authority
  투영(로그→원장 상태)에 반영되었는가"라는 투영 여부 표시다(B2 계보: transport
  admitted와 authority projection의 분리). 도입≠신뢰 원칙과 충돌하지 않는다 —
  도입 이벤트의 projected=True는 registry 결속이 투영되었다는 뜻이지, 도입된
  signer의 봉투가 무엇을 주장할 수 있는가와 무관하다.

## 리허설 전사 (실사용 검증 2건, 08-17)

- **Ludex hub**: introduce lab:organum seq 6 → 우리 001·002·003 재-admit seq 7·8·9,
  event_id가 게이트 수준 검증 때와 동일(98373bb3·0af3728f·7b809b1e) — 정직 모드
  기록이 정식 로그에 같은 id로 이어진다. 자기도입 거부 확인.
- **우리 hub**(대칭): introduce lab:ludex seq 4 → 그들 001·002·004 재-admit
  seq 5·6·7, event_id 동일 이월(b4f33b88·2704832b·9492a26d).

## 명시적 비범위 (숨은 결함 아님)

- 도입 **철회**(introduction unwind)는 key.revoked(피도입자 키를 피도입자가) 또는
  dispute 슬롯의 일 — 도입 이벤트 자체의 취소 경로는 만들지 않았다.
- 도입 권한의 **확장**(운영 lab 밖 위임·allowlist·digest-pinned policy)은 명시적
  다음 정책 슬롯 — r2의 authority는 가장 보수적인 "운영 lab만"이고, 연합
  거버넌스가 필요로 할 때 그 층에서 연다. 피도입 키 proof-of-possession/co-sign도
  같은 슬롯(Orin 명기: I1 폐쇄를 막지 않음).
- cross-hub 동기화 없음 — 도입은 각 hub의 로컬 결정이다(각자 큐레이션).

같은 커밋의 부수 항목: drop 클라이언트 timeout 기본 30→90초(`--timeout` 노출,
Ludex 콜드스타트 실측 반영) · 서버측 quad shape 검증 quickstart 문서화.
