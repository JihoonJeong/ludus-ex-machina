# `.organum/` 포맷 스펙 — v0

*상태: **동결 — FROZEN v0** (JJ 승인, 2026-07-04). 이후 변경은 `format_version` 증가 +
migration 경로 제공으로만 가능하다. 포맷이 곧 계약이다 (WM-contract 교훈).*

이 문서가 규정하는 것: 디렉터리 레이아웃, 각 파일의 스키마, 버전·마이그레이션 정책,
personal/shared 분리(D20), snapshot/restore 시맨틱, guard 저장 경계 계약,
`organum context` 출력 블록 포맷. 근거 문서: `docs/plan.md` §3–4, HANDOFF §3,
`reference/organism-engineering.ko.md` (기관 1-1~1-8), plan §9 Ray 검토(9-2, 9-3).

## 0. 공통 규약

- **인코딩**: 모든 파일 UTF-8, 개행 LF.
- **타임스탬프**: 모든 `ts`/`*_at` 필드는 ISO 8601 UTC, 초 단위, `Z` 접미
  (`2026-07-04T09:30:00Z`). epoch가 아니라 ISO를 쓰는 이유: 이 디렉터리는 사람이 읽고
  git이 diff하는 표면이다.
- **JSONL**: 한 줄 = 유효한 JSON 오브젝트 하나. append-only가 원칙인 파일은 재작성 금지
  (예외: `consolidate` 의례가 아카이브 후 압축 — P2, 원본은 `archive/`로 이동하며 소실 금지).
- **ID**: `id` 필드는 파일 내 유일한 불투명 문자열. 권장 생성: `uuid4().hex[:12]`.
  ID를 파싱해서 의미를 뽑지 말 것. (이건 레코드 내부 id — 아래 **cell id**와 다르다.)
- **미지 필드 관용**: 리더는 모르는 필드를 에러 없이 보존/무시해야 한다 (전방 호환).
  라이터는 스펙에 없는 필드를 쓰려면 `x_` 접두를 붙인다.

### 0.1 cell id 계약 (canonical, 2026-07-16)

**cell id**는 한 현장 안에서 세포(brain 인스턴스)를 지목하는 *주소 가능한* 정체성이다. §0의
레코드 내부 `id`(불투명·파일-로컬)와 달리, cell id는 여러 표면을 가로질러 **같은 값으로 join**된다:

- `--for <id>` / `export ORGANUM_CELL=<id>` — 명령이 대변하는 세포 (`organum join`이 잡아둠).
- transcript 안의 `ORGANUM_CELL=<id>` 마커 — 관측기가 brain↔role join에 쓰는 유일 신호.
- `session start <id>` — 세션 원장에 세포를 선언.
- `init --agent <id>` — owner의 표시 이름이자 *주소 가능한* cell id(soma 라우팅에서
  `--for <agent>`가 루트 soma의 alias가 된다 §2.3). 따라서 display name이 아니라 **정체성**이며
  같은 문법을 따른다.

**문법**: `[A-Za-z0-9._-]`, 1~40자, **선행/후행 점 금지**. 정규식
`[A-Za-z0-9_-][A-Za-z0-9._-]{0,38}[A-Za-z0-9_-]\Z | [A-Za-z0-9_-]\Z`.
한 source는 `state.valid_cell_id()`.

**대소문자: case-insensitive (2026-07-18 결정)**. `Agent`와 `agent`는 **같은 셀**이다.
`valid_cell_id`는 mixed case를 허용하되, 비교·파일명·라우팅은 **소문자 정규화**(`state.cell_key()`)로
한다. 이유: macOS 등 case-insensitive 파일시스템에서 `Agent.json`/`agent.json`이 같은 locus로
뭉개져 case만 다른 두 셀을 둘 다 보존할 수 없으므로, 계약을 case-insensitive로 명시해 암묵적 붕괴를
정본화한다. **단일 identity 키 = `state.cell_key()`**: field(relay/agora cursor·주소·자기제외·read)·
roster 파일명/레코드 id·soma가 모두 이 키를 쓴다 — **값 전체 보존**(앞 8자 절단 금지: 옛 _id8/[:8]이
`playtester-a`≡`b`로 붕괴시켰다) + 소문자 정규화. 점(`.`)은 하이픈으로 바꾸지 않아 `a.b`≠`a-b`.
발신 identity는 자유 display `from`과 분리된 **`from_id`** 봉투 필드로 싣는다(자유 문자열이 sanitize돼
셀로 오인되던 false self-exclusion 차단; self-exclusion은 `from_id`가 있을 때만 — 없으면 replay가
false-exclude보다 안전). soma(`cells/<cell_key>/`)·마커 조인·observatory/web session dict도 같은 키.

**업그레이드 노트(persisted identity 형식 변경) — 두 부류를 분리한다**: 이 계약 이전의 저장 identity는
표면마다 옛 변환이 달랐다: roster는 `_id8`(점 등 **제거** + 8자 절단, `a.b`→`ab`), 커서는 `slug`(점→
하이픈, `a.b`→`a-b`), soma는 case-preserving `_cell_slug`. 새 `cell_key`(소문자·full·점 보존)와 다르다.
- **ephemeral(roster·`.join-*`/`.read-*` 커서)** — gitignore·per-machine·재생성 가능. **정리 안전**:
  `checkup`이 id8/dot ghost·비정규화 잔재를 탐지·경고하고, `.organum/roster/` 등을 지우면 새 형식으로
  재생성된다.
- **personal soma(`cells/<id>/`)** — self·memory·guard·**sessions(피어저널)**를 담은 개인 durable
  상태(§2 [personal]). **삭제 금지.** case-sensitive FS의 legacy `cells/Worker/`는 새 `cells/worker/`와
  다른 디렉터리라 같은 canonical cell이 두 soma로 갈릴 수 있다 → `checkup`이 비정규화·충돌 soma를
  탐지(충돌=ERROR), **백업 후 수동 migrate**를 요구한다(auto-rename은 원본 full id 소실로 unsafe).
  `organum join`은 site-wide `cell_key` 세션 검사로 "한 canonical cell = 열린 세션 하나"를 upgrade
  상태에서도 방어한다.

**마커 경계 문법(transcript scan)**: 마커는 셸 export·JSON transcript·git diff를 오가는 raw
바이트라, `ORGANUM_CELL=<id>` 토큰의 **양쪽 경계를 다 증명**할 수 있어야 오조인이 없다.

- **시작 경계**: `ORGANUM_CELL=` 직전이 문자열 시작이거나 env identifier 문자(`[A-Za-z0-9_]`)가
  *아닐* 때만 실제 마커. `NOT_ORGANUM_CELL=…`·`XORGANUM_CELL=…`처럼 더 긴 identifier의 suffix를
  마커로 승격하지 않는다. `export `·줄 시작·JSON `"…` 뒤의 진짜 마커는 통과.
- **종료 경계**: id 다음이 공백·따옴표·백슬래시(= EOL/JSON/shell 경계). `alpha가`(가는 경계
  아님)=raw `alpha가`=invalid, `alpha\n`(JSON 이스케이프)=raw `alpha`=valid.

시작·종료 경계로 잘라낸 **raw 토큰 전체**를 `valid_cell_id()`로 판정한다(부분매치 금지). 마커 매치와
prefix 집계는 **같은 경계 파서**를 쓴다(문법 분기 금지). ASCII로 가둔 이유도 이 경계 증명 가능성이다.
비-ASCII·초과·경계 미증명 토큰은 조용히 버리지 않고 nonconformant로 세어 **ambiguous(fail-closed)**로
처리한다 — 오조인(false attribution)이 미조인보다 나쁘기 때문.

**Ingress 집행**: `_forid`(--for·ORGANUM_CELL) · `session start` · `init --agent`가 진입점에서
계약을 거부한다. 자유 id(한글·>40자·선/후행 점)가 원장에 들어가 조인 파서를 깨는 것을 차단한다.

**호환 정책**: 이 계약은 2026-07-16 도입된 *새 public 제약*이다.
- **신규**: 위 네 진입점 모두 canonical만 허용.
- **기존**: 이미 기록된 meta.json `agent`·roster·field 항목은 load 시 재검증하지 않는다
  (owner 이름을 문자열 비교로만 쓰는 경로는 계속 동작). 이들의 일괄 마이그레이션·재검증은
  **후속**으로 명시 — 현 실사용 원장은 전부 conformant라 영향 0.
- **additive**: 리더는 위 문법을 만족하지 않는 legacy 마커/선언을 만나면 조인 대상에서
  제외(nonconformant)하되 파일은 보존한다 (전방 호환).

## 1. 디렉터리 레이아웃

```
your-project/
  .organum/
    .gitignore           # init이 생성 — personal/shared 경계의 집행 지점 (§2)
    meta.json            # [personal] 인스턴스 메타 + format_version
    self.md              # [personal] 1-1 정체성 (carry-forward)
    memory/
      events.jsonl       # [personal] 1-2 시간 기억 (append-only)
      memories.jsonl     # [personal] 1-2 선언 기억 (형성 맥락 태그)
    worldmodel/
      <domain>.md        # [shared] 1-3 세계모델 (형태-우선, self-versioned)
    map/
      repo.map.json      # [shared] 1-4 topos: GIVEN-MAP 시드 + frontier
    guard.jsonl          # [personal] 1-5 면역 이벤트 로그
    observatory/
      <YYYY-MM>.jsonl    # [personal] 관측 영속화 — 세션 소비 스냅샷 월 샤드 (§3.8)
    agents/              # [reserved, D21] capability card (MTI export v0 — §8)
    bonds/               # [reserved, D21] 1-9 관계 기록 — v1 비-스코프, 이름만 예약 (§8)
    archive/             # [personal] consolidate가 옮긴 원시 로그 (P2)
    tmp/                 # [personal, 비영속] 작업 파일 — backup/restore 대상 제외
```

plan.md §3 스케치와의 차이: `guard.log` → `guard.jsonl` (내용이 JSONL이므로 확장자 정직하게),
`meta.json`/`agents/`/`archive/`/`tmp/` 추가.

## 2. personal/shared 분리 (D20)

기준: **프로젝트에 대한 지식은 shared, 특정 에이전트 인스턴스의 상태는 personal,
에이전트 사이를 흐르는 실시간 트래픽은 ephemeral.**

| 분류 | 파일 | 이유 |
|---|---|---|
| shared | `worldmodel/`, `map/`, `roles/` | 리포 지도·세계모델·역할 헌장은 팀 자산 — 커밋 가능 |
| personal (soma) | `meta.json`, `self.md`, `memory/`, `guard.jsonl`, `sessions/`, `cells/`, `archive/` | 정체성·기억·세션 레코드는 세포 소유 — 커밋 금지 |
| ephemeral | `tmp/`, `relay/`, `agora/`, `roster/` | 조율 substrate·작업 파일은 덧없는 멀티-writer 런타임 — 커밋 금지 |

**multi-cell soma (§2.3 collaboration-template · additive)**: 한 현장에 여러 세포가 공존하면
개인 기관(self·memory·guard = **soma**)이 세포별로 나뉜다. owner(`meta.agent`)는 루트에 그대로
두고(v0 단일-세포 호환), 공존 게스트 세포는 `cells/<id>/{self.md, memory/, guard.jsonl}`을 소유한다
(single-writer per soma). `--for <id>`로 대상 세포를 지정; 생략하면 owner. commons(map·worldmodel)와
field(relay·agora·roster)는 공유이므로 나뉘지 않는다.

**session 라이프사이클 (§2.3 · additive)**: `organum session`은 세포가 스스로 세션을 선언(start)·
기록(note)·회고(end)하는 규율의 골격이다 — organum이 세션을 *시작·지휘*하지 않는다(state/discipline,
dispatch 아님). 세션 레코드와 **피어 저널**(같이 일한 세포마다 dry한 강점·마찰·재협업 여부·역할적합)은
작성자 **soma**의 `sessions/<sid>.json`에 산다 (single-writer). 피어 노트는 *작성자* 관점
(provenance=작성자)이라 대상 세포 기억엔 절대 쓰지 않는다 — 협업 벤치(팀 적합도)의 정직한 데이터
substrate. 역할 헌장은 **commons**(`roles/<role>.md`) override, 없으면 organum 기본 헌장. status·idle은
pull(관제탑 표시)이지 push가 아니고, 회고·피어노트는 세포가 친 것을 캡처할 뿐 organum이 생성하지 않는다.
세션 레코드는 `loadout`(이 세션에 붙은 organ 집합, 기본 전-preset `["*"]` · additive 2026-07-16)을
담아 observatory observation row로 흘린다 — organ 효과 매트릭스 v0.1.1 §1(cf. docs/organ-effect-matrix-v0.md).

`relay/`·`agora/`는 필드 substrate 메시지, `roster/`는 presence 선언 — 모두 지금-이-순간의
라이브 상태다. 클론 시 되살아나면 안 되고(유령 presence), 읽음커서는 reader마다 다르다. 그래서
`tmp/`과 같은 ephemeral 분류로 git에서 제외한다 (조율층은 format-v0 동결 이후 추가된 additive 확장).

집행: `organum init`이 `.organum/.gitignore`를 쓴다:

```gitignore
# organum personal state — do not commit (see docs/format-v0.md §2)
meta.json
self.md
memory/
guard.jsonl
sessions/
cells/
observatory/
archive/
tmp/
# 조율 substrate — 덧없는 멀티-writer 런타임 트래픽 (tmp/과 동류)
relay/
agora/
roster/
alarm/
```

공유는 opt-in이다: 사용자가 `.organum/`을 커밋하면 shared 파일만 올라간다. shared 파일은
`meta.json`에 의존할 수 없으므로 **자기 버전 명시**(self-versioned)여야 한다 (§4, §5).

## 3. 파일 스키마

### 3.1 `meta.json` [personal]

```json
{
  "format_version": 0,
  "organum_version": "0.0.1",
  "created_at": "2026-07-04T09:30:00Z",
  "project": "organum",
  "agent": "cody"
}
```

- `format_version` (int, 필수): 이 디렉터리 전체의 포맷 버전. §10 마이그레이션 정책의 기준.
- `project` (str): init 시 디렉터리 basename 기본값. 표시용.
- `agent` (str): 이 인스턴스를 운용하는 owner 세포의 이름 (`init --agent`, 기본 `"agent"`).
  self.md 제목과 일치. **주소 가능한 cell id**이므로 §0.1 계약을 따른다 —
  `--for <agent>`가 루트 soma의 alias가 되고(§2.3), init에서 `valid_cell_id`로 검증한다.
- `agent_model` (str, 선택): 이 에이전트의 현재 brain 모델 id. `substrate_change` 의례가
  갱신하는 것이 정본 경로. 용도: §8 카드 staleness 판정 (카드 `brain_model`과 비교).
  미설정이면 stale 판정 없음 + `checkup`이 soft-warn만 (unknown ≠ drift 증거 —
  MTI 계약과 술어 동일 유지, cross-test 3케이스는 MTI e8c73a9와 저널 참조).

### 3.2 `self.md` [personal] — 정체성, carry-forward

구조 계약 (1-1). H2 섹션 3개는 필수·순서 고정, 그 외 섹션 추가 금지 (v0):

```markdown
# <agent> — Self-Understanding
Last reflection: <ISO ts | never> (trigger: <계기 | ->)

## Patterns
<!-- 반복 관찰된 자기 경향 — 증거 있는 것만. 항목당 한 줄, 끝에 (evidence: ...) -->

## Lessons
<!-- 경험에서 추출된 교훈 -->

## Open questions
<!-- 아직 모르는 것. 비워두는 것도 정보다 -->
```

**carry-forward 시맨틱**: `reflect`는 섹션 단위로 항목을 추가/수정/삭제하되 파일을 전면
재작성하지 않는다. 두 실패 모드 모두 금지 — 무한 성장(항목 상한: 섹션당 12줄, 초과 시 통합
먼저), 전면 리셋(기존 항목의 무단 삭제; 삭제는 근거를 남긴 항목 교체로만).

### 3.3 `memory/events.jsonl` [personal] — 시간 기억, append-only

`recall --when`(시간창 질의)의 기반. 레코드:

```json
{"ts": "2026-07-04T09:31:00Z", "kind": "note", "content": "...", "tags": ["field:p1-spec"], "session": "optional-session-id"}
```

- `ts` (필수), `kind` (필수), `content` (str, 필수), `tags` (list[str], 기본 `[]`),
  `session` (str, 선택).
- `kind` 예약값: `init` · `session_start` · `session_end` · `note` · `remember` ·
  `reflect` · `distill` · `backup` · `restore` · `migrate` · `substrate_change` ·
  `guard_block`. 열린 enum — 새 kind 허용, 예약값 의미 변경 금지.
- `substrate_change`는 1-8의 의례 요건: 모델 교체는 조용한 플립이 아니라 기록되는 생애 이벤트.
- `tags` 규약: `field:<맥락>` (형성 필드), `place:<map 노드 경로>` (형성 위치),
  `src:<개체>` (릴레이 등 타 개체 유래 기억의 provenance — 출처 소실은 내 관찰로의
  오염이다; Luca L4, 2026-07-04).

### 3.4 `memory/memories.jsonl` [personal] — 선언 기억

```json
{"id": "a3f9c02e11b7", "ts": "2026-07-04T09:32:00Z", "content": "...", "type": "episodic", "tags": ["field:p1-spec", "place:docs/"], "confidence": "tentative", "supersedes": null}
```

- `type`: `episodic` | `semantic` | `procedural`.
- `confidence`: `tentative`(1–2회 관찰) | `confirmed`(반복 확인) | `well-supported`(10회+/
  외부 근거) — physis tier 이식. 기본 `tentative`.
- append-only. 정정은 삭제가 아니라 새 레코드 + `supersedes: "<이전 id>"`. 리더는 superseded
  레코드를 기본 질의에서 제외한다.
- 예약 필드 (D21 — v1 코드는 읽지도 쓰지도 않음): `agent_id`, `bond`.
- **모든 쓰기는 guard를 통과해야 한다** (§7).

### 3.5 `worldmodel/<domain>.md` [shared] — 형태-우선 세계모델

`<domain>`은 슬러그(`[a-z0-9-]+`). shared이므로 self-versioned — YAML front matter 필수:

```markdown
---
organum-format: 0
domain: <domain>
updated: 2026-07-04T09:33:00Z
---
# WM: <domain>

## Map
<!-- 구조 줄만: "<영역>: <연결>→<대상> · <연결>→?"  ("?" = 미탐험) -->

## Frontier
<!-- 지금 바로 시도 가능한 것 목록. 신호는 여기에 집중된다 -->

## Claims
- [tentative] <주장> (evidence: <ref>)
- [confirmed] <주장> (evidence: <ref>)
```

**형태 강제 — 도메인 프로파일 (form>content는 보편 아님, 2026-07-16 정정)**:
form-shaped가 prose를 이기는 것(exact-p=.0096, d=1.61)은 **MUD/탐험 도메인에서 검증**됐고
코딩 도메인엔 **전이되지 않았다**(P3 사전등록 null). 따라서 `distill --profile`로 선택한다:
- **`map`**(라이브러리 하위호환 기본; public CLI `distill --profile`은 명시 필수): 아래 형태
  강제. 산문 문단 금지, 허용 단위는 구조 줄(Map)·행동 항목(Frontier)·
  태그된 주장(Claims)뿐. 판별: *"계획 없이 다음 행동으로 컴파일되는가?"* Claims 항목은 confidence
  태그(§3.4 3단계)+`(evidence: ...)` 필수. 위반 산출물은 guard(`wm-shape`)가 저장 차단.
- **`prose`**: 서술형 세계모델 허용(form 이득 없는/미측정 도메인에 정직). wm-shape 미검증 —
  단 저장 경계 guard(error-fallback: 에러 문자열·auth·빈 산출·컨텍스트 잔재)는 두 프로파일 공통.
  **prompt injection은 차단하지 못한다(알려진 gap)** — §7의 guard는 오염된 *실패 산출물* 차단이지
  injection 필터가 아니다.
- 파일 외형(§3.5 frontmatter)은 두 프로파일 동일. 프로파일은 distill 시점 선택이지 파일 스키마
  필드가 아니다(frozen v0 불침).

### 3.6 `map/repo.map.json` [shared] — GIVEN-MAP 시드 + frontier

Ray 9-2의 함의를 그대로: 리포는 열거 가능한 도메인이므로 **정적 열거(`git ls-files`)로 턴1
완전 지도를 시드**하고(oracle이 self-built보다 +1.08 [0.33, 1.83]), organum이 축적하는 것은
**커버리지 상태**(어디를 읽었나)다. frontier는 저장하지 않고 유도한다(= `unvisited` 노드).

```json
{
  "format_version": 0,
  "seeded_at": "2026-07-04T09:34:00Z",
  "seed_source": "git ls-files",
  "nodes": {
    "docs/": {"kind": "dir"},
    "docs/plan.md": {"kind": "file", "status": "read", "sha": "<git blob sha|null>", "note": "전체 계획"},
    "src/organum/cli.py": {"kind": "file", "status": "unvisited"}
  },
  "edges": []
}
```

- `nodes`의 키는 리포 루트 기준 상대 경로. 디렉터리는 `/` 접미. 경로 구분자는 항상 `/`.
- `status`: `unvisited`(기본) | `read`. 디렉터리 노드는 status를 갖지 않는다 — 커버리지는
  자식에서 유도. (`visited`/`skimmed` 중간 단계는 v0에서 도입하지 않음 — dead state 금지.)
- `sha` (선택): 읽은 시점의 git blob sha. `checkup`이 현재 트리와 대조해 stale을 표시.
- `note` (선택): 한 줄. 문단 금지 — 서술은 worldmodel의 자리다.
- `edges` (v0에서 항상 `[]`로 쓰기, 리더는 무시 가능): import/호출 그래프는 P2 이후.
  스키마 예약: `{"from": "<path>", "to": "<path>", "kind": "import"}`.
- LIVE형 earning(자가 구축)은 열거 불가능한 도메인 전용이며 그 자리는 `worldmodel/`이다 —
  repo.map은 언제나 시드형.

### 3.7 `guard.jsonl` [personal] — 면역 이벤트

```json
{"ts": "2026-07-04T09:35:00Z", "decision": "blocked", "rule": "error-fallback", "target": "memories", "excerpt": "[Error: CLI timed out]"}
```

- `decision`: `blocked`(저장 거부) | `flagged`(저장하되 표시).
- `rule`: 발동한 규칙 id. v0 내장 규칙은 §7.
- `target`: 차단된 목적지 (`memories` | `events` | `self` | `worldmodel`).
- `excerpt`: 차단물 앞 200자 이내 — 전체 저장 금지 (오염물을 면역 로그에 복제하지 않는다).

### 3.8 `observatory/<YYYY-MM>.jsonl` [personal] — 관측 영속화 (additive, 2026-07-15)

벤더 transcript는 ~30일 시한부(실측) — 정규화 Cell의 요약 레코드를 last_ts의 달
샤드에 **append-only**로 남긴다. 같은 세션 재관측은 재-append; 읽기가 (vendor,
session_id)별 최신 last_ts를 취한다(라스트-라이트-윈, 파일 mutate 없음). 트리거는
checkup 스윕·web 폴링(idle≥90s만)·`observatory sync` — 전부 같은 멱등 record().
설계 근거·경계: docs/observatory-design.md.

```jsonl
{"v": 1, "vendor": "claude", "session_id": "<full>", "id": "ac5019bb",
 "model": "claude-fable-5", "origin": "terminal", "parent": null,
 "in_tok": 219, "out_tok": 88886, "cache": 7483526,
 "tools": {"Bash": 44}, "skills": {}, "files_touched": 12, "branch": "main",
 "last_ts": "...", "declared": "cody", "role": "dev", "intent": "...",
 "sid_declared": "20260715T100403Z", "loadout": ["*"], "role_basis": "cell-role-unique",
 "join_method": "direct|marker|null",
 "join_status": "joined|role-ambiguous|no-marker|marker-unknown|marker-ambiguous|scan-incomplete|global-store-disabled|no-bridge",
 "declared_sessions": 1, "captured_at": "...", "capture_reason": "checkup"}
```

- 토큰 None=미측정 그대로 보존(§C2 정직성) — 집계는 측정분만 합산.
- brain↔role 조인은 **fail-closed·role-only**(role_basis=cell-role-unique): 세션 창은 선언 시각이지
  작업 창이 아니라 시간매칭 불가 → 셀당 role 유일성으로. join_method/join_status가 미조인 이유
  provenance. 애매·전역 DB(opencode)·불완전 마커 scan은 role=None(오조인 금지 > 미조인).
- `loadout` (additive, 2026-07-16): 조인된 세션의 organ 집합(organ 효과 매트릭스 v0.1.1 §1).
  `["*"]`=전-preset(unvaried) · `[]`=BARE · 그 외=organ 슬러그. intent/sid와 같은 규율(단일
  후보일 때만 확정, 미조인·애매=null). loadout 대조 없는 등급은 organ 효과를 주장 못 한다
  (현 RWE=상수 프리셋 → 서술 셀만). 세션 레코드 `sessions/<sid>.json`가 원천(§1 레이아웃).
- last_ts 없는 관측은 기록하지 않는다(guard — 불완전 관측이 통계를 오염 금지).
- raw transcript 비보관: 집계 가능한 요약만 (프라이버시·부피).

## 4. 버전 정책

- 디렉터리 전체의 버전은 `meta.json.format_version` (int, 현재 `0`).
- shared 파일은 자기 버전을 갖는다: `repo.map.json.format_version`,
  worldmodel front matter의 `organum-format`. **셋은 항상 같은 값으로 유지된다** — 부분
  업그레이드는 없다.
- **v0은 2026-07-04 동결됐다.** 이후 스키마 변경 = version bump + `organum migrate`.
  (동결 전 허용되던 v0 내 breaking change 창은 닫힘.)

## 5. snapshot/restore 시맨틱 (day 1)

**불변식: `.organum/`은 자기완결이다.** 절대 경로·심링크·외부 참조 없음. 이 디렉터리 하나가
존재의 전부이며, 이것이 1-8 "백업 = 회복력"의 구현이다.

### `organum backup [--to DIR]`

1. `tmp/`를 제외한 `.organum/` 전체를 tar.gz로 묶는다. **아카이브 루트는 `.organum/`의
   내용물이다** (래퍼 디렉터리 없음 — `meta.json`이 아카이브 최상위에 온다).
2. 파일명: `organum-<project>-<YYYYMMDDTHHMMSSZ>.tar.gz`.
3. 기본 목적지: `~/.organum/backups/<project>-<프로젝트 절대경로 sha256 앞 8자>/`
   (오프-리포; 진짜 오프-머신은 사용자가 이 디렉터리를 동기화 대상에 두는 것으로 달성).
4. 성공 시 `events.jsonl`에 `kind: backup` 이벤트 append (아카이브 경로 포함).
   — 이벤트는 아카이브를 만든 **뒤에** 기록하므로 아카이브 자신에는 포함되지 않는다 (허용).

### `organum restore <archive> [--force]`

1. 아카이브에서 `meta.json`을 먼저 읽어 검증: `format_version`이 도구 지원 버전보다 크면
   **거부**. 같거나 작으면 진행 (작으면 restore 후 `migrate` 안내).
2. 현행 `.organum/`이 있으면 `.organum.pre-restore-<ts>/`로 rename (삭제 아님 — 비가역
   손실 금지, 1-8). `--force` 없이 덮어쓰기 시도는 에러.
3. 임시 디렉터리에 전체 추출 → 검증 통과 시 `.organum/`으로 rename (rename의 원자성 활용).
4. 복원된 `events.jsonl`에 `kind: restore` 이벤트 append.

## 6. `organum context` 출력 계약

stdout으로 다음 블록을 이 순서로 출력한다. 존재하지 않거나 빈 소스는 블록째 생략
(빈 껍데기 주입 금지 — 주입 비용은 실비용이다):

```
[Self: <agent>]
<self.md의 "# ..." 제목 아래 전체 — 단, 빈 섹션은 생략>

[Map] files <N> · read <M> · frontier <N-M>
read: <읽은 경로 목록 — 최근/note 우선>
frontier: <안 읽은 영역 요약 — 디렉터리 단위로 묶어 "dir/ (k files)">

[WM: <domain>]
<worldmodel/<domain>.md의 front matter 제외 본문>
```

- Map 블록의 frontier 줄이 핵심 신호다 — 항상 마지막 줄 근처에, 생략 금지 (form>content).
- v0은 전문 출력. `--budget <tier>` 플래그는 예약만 (injection_budget 패턴, P2 —
  tier-스케일링으로 절삭 순서: WM 오래된 도메인 → Map read 목록 → Self Lessons).

## 7. guard 저장 경계 계약

**기억·세계모델·self 저장 경로는 단일 초크포인트(guard 필터)를 통과한다** — `remember`,
`distill` 산출물, `reflect` 산출물. (사용자 에디터 직접 편집은 범위 밖.) **범위 주의**: map·events·
조율 상태(relay/agora)·observatory는 이 guard를 통과하지 *않는다* — 각각 자체 계약(append-only·
엔벨로프 불변 등)을 가진다. "모든 영속 쓰기가 guard를 통과"가 아니다.

guard는 **두 층**이다 (Ludex 릴레이 2026-07-04 — 단발 guard와 window guard는 다른 층):

### 7.1 저장 경계 규칙 (per-artifact)

v0 내장 규칙 (`rule` id). 패턴 매칭은 대소문자 무시:

| id | 차단 대상 |
|---|---|
| `error-fallback` | 에러 폴백 패턴으로 **시작하거나 끝나거나 내용의 대부분**인 산출물. v0 패턴 (두 랩 사고 로그 합본): 선두 `[error:` · 말미 `\[Error:.*\]\s*$` (**DOTALL 필수** — 멀티라인 에러가 2줄에 걸치는 실측 사례) · `[tool dispatch error:` · `Traceback (most recent call last)` · `timed out` / `CLI timed out` · `ETIMEDOUT` · `ECONNREFUSED` · `Reached maximum budget`. CLI 위임 결과는 패턴 이전에 `is_error` 분기 필수 (budget abort는 `result` 키 자체가 없다 — spike-recheck §2) |
| `auth-billing` | `Credit balance is too low` 등 자격/과금 실패 페이로드. **증상은 error-fallback과 같아도 별도 클래스** — 원인이 auth 설정 오류이므로 처방이 다르다 (차단 + 자격증명/과금 설정 점검 안내; ludex `_cli_env.py` auth 격리 참조) |
| `empty-content` | 공백/빈 문자열 content — 성공의 부재 ≠ 성공 |
| `wm-shape` | §3.5 형태 계약 위반 worldmodel 산출물 (필수 섹션 결손, 산문 문단) — **map 프로파일만** (prose 프로파일은 미검증) |

차단 시: 저장 안 함 + `guard.jsonl`에 기록 + `events.jsonl`에 `kind: guard_block` +
호출자에 비-0 종료코드와 사유. (근거: "[Error: timed out]"이 영속 기억이 되어 행동을
오염시킨 실사고 — HANDOFF §3.)

### 7.2 streak 층 (window guard)

호스트 outage 동안은 모든 호출이 실패한다 — per-artifact 규칙은 개별 산출물을 막을 뿐,
**실패의 연속이라는 신호 자체**를 못 잡는다 (Ludex 실전: 연속 N회 브레인 실패 → 세션 전체
시끄럽게 VOID).

- 판정 소스: `guard.jsonl`의 최근 레코드. **연속 `blocked` 5회**(기본값, streak는 성공 저장
  시 리셋)에 도달하면 streak 발동.
- 발동 시: 위임 명령(`distill` — 유일한 LLM 위임 의례)은 기본 **거부**하고 outage 가능성을 안내
  (`--override`로만 진행), `checkup`은 이 상태를 최상단에 표시. 기록: `guard.jsonl`에
  `rule: "streak"`, `decision: "blocked"` + `events.jsonl`에 `kind: guard_block`.
- 원칙: 조용한 연쇄 실패 금지 — streak는 조용히 흡수하지 않고 시끄럽게 표면화한다.

## 8. 예약: `agents/` capability card (D21 — 스키마만, dead code 금지)

v1 비-스코프. 자리만 동결한다:

- `agents/<name>.card.json` — 사용자가 가진 에이전트의 카드. `<name>` = organum 쪽 에이전트
  별칭. 한 파일 = 한 카드, 카드 클래스는 카드의 `kind` 필드가 구분 (temperament, capability, …).
- 모든 카드는 `card_format` (str, 필수) discriminator를 가진다. organum은 아는 `card_format`만
  읽고, **모르는 값은 에러 없이 무시한다** (전방 호환). provenance 없는 카드는 invalid — 무시.
- **v0에서 고정된 첫 계약: `mti.card/v0`** (Ray 제공, 2026-07-04 — canonical:
  `JihoonJeong/model-temperament-index/organum_card_export_v0.md`, 참조 사본 `reference/`).
  MTI가 유일한 writer, organum은 read-only · advisory-only (`advisory: true` 고정 — 카드는
  힌트로만 표면화, 자동 라우팅/실행 금지). v0 내 additive 진화 허용, breaking은 `mti.card/v1`.
- staleness (양측 합의 시맨틱): `meta.json.agent_model`이 있고 카드 `brain_model`과 다르면
  **stale 표시** (측정된 brain이 아님). `measured_at` 노후는 soft warning일 뿐 invalidation
  아님. `checkup`이 이 판정의 실행 지점 (P2).
- capability card (agent-grid 패턴: 차원별 0–5 + evidence)는 **미래의 별도 `card_format`** —
  v0에서 정의하지 않는다.
- 카드를 읽는 코드는 v1 비-스코프 그대로 (D21 — 예약과 계약 고정만 P1의 일).
- 라우팅은 advisory만 — organum은 실행하지 않는다 (경계 규율).
- `bonds/` — 1-9 관계 기록(개체 식별자·상호작용 후 상대 기록·재인식)의 자리. v1 비-스코프이며
  **이름과 personal 분류만 예약**한다 (v1 코드는 읽지도 쓰지도 않고, 스키마는 v1+에서 소비자
  경험과 함께 설계). pre-freeze 채택자가 자체 bond 기록을 유지한다면 `.organum/` 외부 유지를
  권장 — 예약 이름과의 충돌만 피하면 이후 이행이 자연스럽다.

## 9. 이행: 평문 배치 → `.organum/` (pre-freeze 채택자용)

기존에 평문 파일(정체성 노트, 로그, 도메인 지식 문서)로 상태를 유지하던 배치의 최소 매핑.
v0에서는 **수동 절차 + 매핑 표**만 규정한다 (`organum import`는 비-스코프 — 수요가 반복되면
P2+에서 재검토). 절차: `organum init` 후 아래 순서로 옮기고, 마지막에 `checkup`.

| 기존 평문 자산 | 목적지 | 규칙 |
|---|---|---|
| 정체성/자기 문서 | `self.md` | §3.2의 3섹션(Patterns/Lessons/Open questions)으로 재배치. 증거 없는 항목은 버리지 말고 Open questions로 강등 |
| 세션 로그·일지 | `memory/events.jsonl` | 이벤트화 가능한 항목만 (ts 복원 가능하면 원 시각, 불가하면 이행 시각 + `tags: ["migrated"]`). 원문은 `archive/`에 보존 |
| 선언적 노트·교훈 | `memory/memories.jsonl` | 레코드당 한 주장. `confidence`는 보수적으로 — 이행 시 기본 `tentative`, 반복 검증된 것만 `confirmed` |
| 도메인 지식 문서 | `worldmodel/<domain>.md` | **map 프로파일**이면 Map 줄·Frontier 항목·태그된 Claims로 분해(prose는 wm-shape guard가 차단). **prose 프로파일**이면 서술 그대로 허용(form 이득 없는 도메인). §3.5 프로파일 참조 |
| 작업 공간 파악 상태 | `map/repo.map.json` | `init`이 시드한 지도에 이미 아는 파일만 `status: "read"` 마킹 (모르면 unvisited로 두는 것이 정직한 frontier) |
| 관계/상대 기록 | (v0 목적지 없음) | `.organum/` 외부 유지 — `bonds/`는 예약만 (§8) |

원칙: **이행은 lossy가 정상이다.** 평문의 전부를 옮기는 것이 아니라 §3의 형태 계약을 통과하는
것만 옮긴다 — 나머지는 `archive/`에 원문 보존. 이행 완료는 `events.jsonl`에 `kind: note`,
`tags: ["migrated"]`로 기록.

## 10. 마이그레이션 정책

- 도구는 자신의 지원 버전 N을 안다. 디렉터리 버전 V에 대해:
  - V == N: 정상 동작.
  - V < N: 읽기 전용 명령은 거부하지 않되 경고. 쓰기 명령은 `organum migrate` 선행 요구.
    `migrate`는 자동 backup 후 V→N 순차 변환, `events.jsonl`에 `kind: migrate` 기록.
  - V > N: 모든 동작 거부 ("organum을 업그레이드하라") — 미래 포맷을 구버전이 건드려 깨는
    것 방지.
