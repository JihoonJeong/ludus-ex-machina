# backend-neutral seam 계약 제안 + Cursor 최소 probe 계획 (v0, Orin 검토용)

Orin 결정(2026-08-17, JJ 확인)의 이행 문서: Cursor 전용 결합 없이, agy scaffold와
기존 cast supervisor가 함께 소비할 launch/session/outcome/usage 계약을 먼저 고정하고
Cursor는 그 seam에 최소 probe로 붙는다. 측정 중립성(우리 몫) 관점의 제안이며,
seam의 구현·최종 고정은 organum-code(Orin) 몫이다.

## 1. 계약 필드 제안 — Cursor 실측 표면과의 대조

| 계약 필드 | 의미 | Cursor 실측 원천 (2026.08.11) |
|---|---|---|
| `backend_id` | 하네스 식별 | `"cursor"` (버전: `cursor-agent -v`) |
| `model.base` / `model.effort` / `model.fast` | **E축 분리**(Ludex 선입력 — M축과 분리) | 모델 id 파싱: 접미 `-(low\|medium\|high\|xhigh\|max)`→effort, `-fast`→fast, 잔여=base. 예: `kimi-k3-low`→(kimi-k3, low, false). `auto`·`composer-*`는 effort=null |
| `auth_mode` (요청) / `observed_auth_mode` (관측) | 기합의 레인 — manifest 복사 금지 | 구독 로그인 vs `--api-key` 경로 분리. 이번 세팅 관측=native_subscription |
| `session_id` / `request_id` | 실행 신원 | headless 결과 JSON in-band ✓ |
| `outcome` | success/error + 오류 모양 | JSON `subtype`/`is_error`/`result` + 디스크 `turn_ended.status` ✓ |
| `usage` {input, output, cacheRead, cacheWrite} | 소비 실측 | **headless stdout JSON에만** — 디스크 비잔존. custody 규칙: supervisor가 stdout JSON을 원문 보존(계측 유일 원천) |
| `transcript.custody` | 사후 검증 locator | `~/.cursor/projects/<mangled>/agent-transcripts/<sid>/<sid>.jsonl` + `~/.cursor/chats/<md5(cwd)>/<sid>/` — inspector 0.4.3 어댑터가 소비 검증 완료 |
| `duration_ms` | 소요 | JSON in-band ✓ |

주의 2(기실측): bare word 인자는 프롬프트로 해석(TUI 진입) — 플래그만 · 신규
디렉터리 `--trust` 필요 · 클라이언트 타임아웃/콜드스타트는 조직 표준(90s) 무관
(Cursor는 상시 API).

## 2. 최소 probe 계획 (유료 호출 2회 이내)

- **P1 — 계약 전 필드 실채움**: `kimi-k3-low` 소형 태스크 1회(파일 1개 읽고 요약).
  검증: E축 파싱·session/request id·usage 4종 보존·outcome·transcript custody 실재.
  예상 소비(오늘 실측 외삽): input+cache ~10–40K, output <200. 크레딧 영향 미미.
- **P2 — 오류 모양**: ① 존재하지 않는 모델 id 1회(서버 거부 — 소비 0 예상, 오류
  JSON 모양 채집) ② rate limit는 **유도하지 않음** — 문서/대시보드 관측만.
- **비범위**: calibration 규모 소비 금지(Orin 결정 4). quota 소진 속도는 Cursor
  대시보드 usage 페이지 실측 병행(JJ 열람) 후 별도 보고 → 규모 실험은 별도 JJ GO.

## 3. hub의 자리 (Orin 결정 5 그대로)

hub 봉투/drop은 backend adapter가 아니라 **coordination/evidence transport seam**
후보다 — OpenCode plugin 결속을 Cursor 결속으로 치환하지 않는다. 계약 산출물
(usage receipt 등)을 봉투로 나르는 것은 seam 고정 뒤의 별도 검토.

## 4. 요청

Orin: 위 계약 필드 표를 agy scaffold `bd02852`·기존 cast supervisor 소비 형태와
대조해 좁게 판정해달라(필드 가감·이름·custody 규칙). 판정 오면 P1·P2를 그 계약
모양대로 실행해 결과를 봉투로 회신한다.
