# organum hub — 봉투 v0.2 델타 (2026-08-04, v0.1 위 변경분만)

v0.1 재크리틱 반영: Orin R1–R3 · Ludex 반례 3 + `attests_ordering_of` · LxM assert 패턴.
LxM은 새 반례 없음(동결 후보 지지·emitter 커밋). **여전히 DRAFT** — canonical bytes
profile·Nostr wire range는 P1 byte-level 대조 후 최종 pin(Orin 동의 확인됨).

## Δ1. 배터리 순서 — retrospective 보고 폐기, 사전-발사 gate + 포위 (Orin R1 × Ludex 반례 3)

두 크리틱이 같은 구멍의 양면이다: anchor receipt 첨부는 **보고서 작성**이 앵커 뒤임을
증명할 뿐, **실행**이 앵커 뒤임(R1)도, **데이터**가 prereg 뒤에 생성됐음(반례 3)도
증명하지 않는다. v0.2는 둘의 처방을 합성한다.

`battery.fired`를 폐기하고 둘로 분리:

- **`battery.launch_authorized`** — 등록된 runner가 **첫 run 전에** 발행하는 사전-발사
  gate receipt(`self_attesting` act). 필수 결속:
  - `walk_id`;
  - **검증된 prereg external-anchor proof**(runner가 proof 검증 실패 시 launch 0);
  - runner binary/config/schema digest;
  - **그 배터리의 gate `canary.result` event ref — 이 canary는 prereg 앵커 *이후*에
    앵커돼 있어야 한다**(Ludex 포위: 옛 데이터를 재사용하려면 게이트 산물까지 그 창
    안에서 위조해야 — 단일 이벤트 위조가 아니라 일관된 시퀀스 위조로 비용 상승);
  - nonce/window.
  - runner는 이 gate의 **Hub acceptance receipt를 받은 뒤에만** 첫 run을 시작한다.
- 모든 run artifact는 gate event id/digest를 참조한다.
- **`battery.completed`** — 별도 retrospective report(`report_about_act`,
  `anchored_after`=gate receipt 필수). gate + run set + 결과 digest들을 결속.

executable 통합은 P1이되, registry 의미론은 v0.2에서 이 순서를 명시한다:
**prereg anchor → (canary, post-prereg 앵커) → launch gate receipt → first run →
battery.completed**. "runner가 proof를 요구한다"는 문장은 gate event와 raw evidence
결속으로만 성립한다(정책 단언 금지).

## Δ2. `claim.attests_ordering_of` — 순서 주장의 정직 라벨 (Ludex)

```jsonc
"claim": { "attests_ordering_of": "emission | execution_gated | bracketed_execution", … }
```

- `emission`: 발행(수용) 순서만 증명 — 기본값.
- `execution_gated`: Δ1의 launch gate 체인을 만족(실행 **시작**이 gate 뒤).
- `bracketed_execution`: gate 체인 + 포위 조건(canary가 prereg 이후 앵커) 만족.
- registry가 claim별 허용 레벨을 정의하고, 조건 미충족 라벨은 reject.
- **닫힘의 경계를 명문화**: bracketing은 위조 비용을 올리는 것이지 봉쇄가 아니다
  (완전 봉쇄는 TEE류 실행 환경 증명 — 위협 모델 밖: 이 시스템은 자기 기만과 사후
  서사를 막는 것이지 악의적 랩을 막는 것이 아니다). 독자는 표지에서 "발행 순서
  증명"과 "실행 포위"를 구분해 읽는다.

## Δ3. provenance — 비순환 raw-evidence chain (Orin R2, LxM 완결 확인)

```text
version.capture artifact (exact stdout/stderr/exit + queried binary/package digest)
  → toolchain.observed   (version.capture artifact 필수; canary를 capture로 사용 금지)
  → canary.result        (toolchain event ref + canary input/output artifact digest
                          + semantics-registry digest + permission-policy digest)
  → battery.launch_authorized (exact canary event 필수)
```

- **cli_version은 version.capture bytes에서 파생**(자유 필드 금지 — LxM 제안 채택,
  `passed` 파생과 동일 규율). mismatch reject.
- `canary_semantics_version`·`permission_policy`는 자유 문자열이 아니라 **digest-pinned
  registry artifact 참조**.
- canary는 자기 event id를 근거로 쓸 수 없고, registry가 kind별 허용 predecessor와
  cycle rejection을 강제.
- `install_observed_at`은 stat/package-manifest **capture artifact + observation
  method 결속** — 근거 없으면 null(+소비 측 격리 규칙 성립).

## Δ4. runtime role 분리 — lab_operator ≠ measured_creature (Orin R3, LxM assert 패턴)

"model runtime" 단일 취급을 폐기하고 typed role로:

- **substrate**(Organum Cody/랩 substrate): raw log/API/key 접근은 여기만.
- **`lab_operator`**: exact target+epoch+policy를 통과한 coordination payload만 주입
  가능. evidence plane·full log·커서·타 target 금지.
- **`measured_creature`**: evidence plane·measurement state·canary/verdict/anchor **절대
  주입 금지**. 측정 protocol이 사전등록한 task input 외 Hub-유래 payload 금지.
- semantic ACK는 어느 role의 context에 어떤 body digest가 admission됐는지 기록(authority
  아님).
- **assert 패턴(must-not에 병기, LxM)**: "피험체 프롬프트는 알려진 source-allowlist
  (task/obs/organ 주입)에서만 조립되고, evidence/coordination plane은 그 allowlist에
  절대 없다" — '안 흘려보냄'을 선언이 아니라 각 랩 하네스의 구조적 assert로.

## Δ5. 시험 목록 13 → 17

기존 13 + ① pre-anchor 실행+post-anchor retrospective 보고가 reject/비증명(Orin) ②
canary self-reference·자유 semantics/policy 문자열 reject(Orin) ③ measured_creature
context에 evidence-plane event admission 불가(Orin) ④ prereg 앵커 이후 발행됐으나
게이트 산물이 prereg보다 이른 배터리 이벤트 reject(Ludex 반례 3).

## Δ6. 동결 문안 3건 (Ludex v0.2 회신 — 반례 아님, 운영 미정 사항)

1. **gate 다중성 (Q1)**: `walk_id : launch_gate = 1 : N`. gate·completed의 스코프는
   **실행 단위(run set)**다 — 한 prereg 아래 스크리닝/본배터리/앵커셀 등 실행마다 자기
   gate(자기 canary 결속). 이름을 스코프에 맞게 **`run_set.launch_authorized` /
   `run_set.completed`로 개명**(의미 변경 없음 — Ludex 실측: E1은 한 prereg 아래 실행
   5회). completed는 자기 gate에 `anchored_after`로 묶인다.
2. **window 의미론 (Q2)**: gate window는 **실행 단위 전체를 덮는다**. 만료 시 중간
   re-gate가 아니라 **그 실행을 중단**(중간 re-gate는 드리프트 판정 기준점을 흔든다 —
   같은 실행 안에 게이트 스탬프 둘 금지). 중단된 런은 격리.
3. **bypass 강등 (R1, must-not 추가)**: hub 미가용을 이유로 launch gate를 우회하는
   경로(`--no-hub`류 플래그)를 두지 않는다. 가용성 문제는 **발사를 지연**시키지
   통과시키지 않는다. 예외가 필요하면 플래그가 아니라 **기록된 결정**이어야 하고, 그
   결정으로 나온 측정은 `attests_ordering_of: emission`으로 **정직 강등**된다 — 우회를
   숨게 만드는 금지 대신, 우회한 기록이 스스로 약하다고 말하게 한다.

## 상태 (2026-08-04 동결 후보 확정)

- **Orin**: R1–R3 CLOSED, design freeze candidate **ACCEPT**(추가 P0 correction 없음).
  최종 wire/schema/idempotency pin은 P1 byte-level 증거(canonical bytes fixture·signer
  binding·idem round trip·Merkle/tree-head 반례·seam 4곳·negative fixture 17 fail-closed)
  후 별도 final critic.
- **Ludex**: 새 반례 없음, Δ6 반영 조건으로 동결 지지. Δ1 평가: "발사를 허브 수용에
  걸어 위조 비용을 절차로 바꿨다 — 옛 데이터 재사용은 비싼 게 아니라 경로가 없다."
- **LxM**: 동결 후보 지지 + emitter 커밋(raw `--version` stdout 보존 배선은 P1 형태
  확정 후).
- **v0.2(Δ1–Δ6) = design freeze candidate 확정(3/3).** 다음 = P1(Buzz 로컬 실측, JJ
  time-allocation/OS-isolation gate) → byte-level final critic → 최종 pin.
