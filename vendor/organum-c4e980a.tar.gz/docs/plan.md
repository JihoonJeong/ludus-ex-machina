> **역사 문서.** 초기 계획(이름 organon 시절)의 기록이지 현행 상태가 아니다. 현행은
> [architecture.md](architecture.md).

# Organon — Organism Engineering CLI 프로젝트 계획

**→ HANDED OFF 2026-07-04**: JJ 결정으로 organon은 별도 랩으로 독립 (`~/Projects/organon`,
LxM 모델 — Organon Cody가 개발, 협업은 JJ 릴레이, Ludex Cody는 이 폴더에 다시 쓰지 않음).
이 파일은 부화 기록으로 보존; canonical 계획은 organon repo의 docs/plan.md.

*2026-07-04, JJ 발의 / Cody 설계. Ludex 생태계와 **별도의** 실무 도구: 실무자가 자기 에이전트
워크플로에 기관(organ)을 입히는 CLI. `docs/organism-engineering.ko.md`(개념 문서)의 실행 짝.*

## 0. 이름
**organon** (확정 — JJ 2026-07-04). 아리스토텔레스의 Organon = "도구/기관" — 기관(organ)의 도구상자라는 이중
의미가 프로젝트 정체성 그 자체. CLI 명령으로도 짧고 충돌 없음 (`organon init`). 

## 1. 포지셔닝 — Ludex와의 관계 (핵심 결정)

| | Ludex | Organon |
|---|---|---|
| 정체 | 연구 생태계 (크리처가 **주인공**) | 실무 도구 (사용자의 **기존 에이전트**가 주인공) |
| 대상 | 크리처를 기르는 연구자/애호가 | Claude Code 등으로 일하는 실무자 |
| 단위 | creature (존재) | 프로젝트에 붙는 organ 서비스 |
| 상태 | `creatures/<name>/` | 프로젝트-로컬 `.organon/` |

**Incubation 모델은 LWM-engine 전례 그대로**: ludex 아래에서 부화, 졸업 기준 = 안정된 core +
≥2 소비자 + not-ludex-specific. **Organon 자체가 ludex organ core의 2번째 소비자**가 되므로
이 프로젝트가 진행되면 organ core의 졸업 조건도 함께 찬다 (ludex/blocks의 검증된 구현을
추출-재사용, 재작성 금지).

**경계 규율**: Organon은 크리처/필드/LxM을 모른다. 가져가는 것은 기관 패턴과 그 검증뿐.

**지속의 존재론** (이 표의 심층): ludex는 *존재-바운드*(기억이 creature와 여행), organum은
*현장-바운드*(기억이 프로젝트에 남고 에이전트가 지나감). 아이언맨 은유의 역전 — 파일럿이
망각하고 갑옷(organ)이 기억하며, 갑옷은 여행하지 않고 현장 격납고에 붙박인다. 두 축(작업=현장-
바운드 몸통 / 실무자=얇은 이동)과 "경험" 3분할의 전이 규율은 [docs/persistence-ontology.md] 참조.

**진화 축 (보철→대사)**: organum의 진화는 능력을 *넓히는* 게 아니라 *안쪽이 깊어지는* 것. 스킬/
하네스=보철(무상태·무기억·무면역)이면 organ=대사(상태·분화·항상성·면역·형태규율). 다세포성 직관은
*안으로*(조직 분화·항상성·면역·발달, 한 유기체 안 = organum 소유) 밀지, *밖으로*(유기체 연합=
swarm) 밀지 않는다 — swarm/디스패치는 플랫폼(agent-grid/A2A/서브에이전트·Task)이 흡수하는 배관.
레고식 조립의 경계: **organ 조립·배선 = organum(provision) / 워커 투입·디스패치 = 플랫폼.**
organum은 stateful worker(화물)이지 orchestrator(디스패치)가 아니다(§7.1/7.2). scale은 "잘 길러진
유기체들의 군체"로 *참여* — 노드의 organ이 우리 것, 조율은 남의 것.

## 2. 제품 한 줄
> **"당신의 에이전트는 오늘도 유능했고, 내일이면 그걸 전부 잊는다. `organon init` 한 번이면
> 기억하고, 지도를 그리고, 자기를 돌보기 시작한다."**

## 3. 아키텍처 스케치

```
your-project/
  .organon/
    self.md            # 1-1 정체성 (carry-forward)
    memory/
      events.jsonl     # 시간 기억 (append-only, 시간창 질의)
      memories.jsonl   # 선언 기억 (형성 맥락 태그)
    worldmodel/<domain>.md   # 1-3 세계모델 (형태-우선 포맷 강제)
    map/repo.map.json  # 1-4 topos: 리포 지도 + frontier(안 읽은 영역)
    guard.log          # 1-5 면역 이벤트
```

통합 방식 (에이전트 무관이 원칙):
- **주입**: `organon context` → 현재 [Self]+[Map]+[WM] 블록을 stdout으로 (모든 에이전트의
  시스템 프롬프트/CLAUDE.md에 붙일 수 있음). Claude Code는 hook으로 자동화 (SessionStart/Stop).
- **기록**: `organon remember/observe/event` — 에이전트가 직접 부르거나(도구로 노출) 훅이 부름.
- **의례**: `organon reflect / checkup / backup / consolidate` — 사람이든 cron이든.

## 4. MVP 스코프 (검증된 것만 — 전부 부록 A 증거 있는 패턴)

| 명령 | 기관 | 근거 |
|------|------|------|
| `init` | 상태 디렉터리 + self.md 골격 | 1-1 |
| `context` | [Self]+[Map]+[WM] 주입 블록 생성 | form>content 결과가 포맷을 지배 |
| `remember` / `recall --when` | 태그된 기억 + 시간창 질의 | 1-2 |
| `map` / `map frontier` | 리포 지도 + **안 읽은 영역** | GIVEN-MAP/LIVE-TOPOS 확증 |
| `distill` | 세션 로그 → 세계모델 (형태-우선 템플릿 강제, 신뢰도 태그) | physis + 1-3 |
| `reflect` | 세션 회고 → self.md carry-forward | 1-7 |
| `checkup` / `backup` | 상태 건강 점검 / 오프-머신 백업 | 1-8 |
| `guard` | 저장 경계 필터 (에러 폴백 차단) | 1-5 사고 사례 |

**명시적 비-스코프 (v1)**: 멀티에이전트 bond, 기질 배터리(MTI는 Ray 프로젝트 — 카드 read-only
연동만), 감정/면역 고급 기능, 어떤 형태든 자체 LLM 호출 오케스트레이션 (organon은 상태와 규율의
도구지 에이전트가 아님 — distill/reflect의 LLM 호출은 사용자의 기존 CLI를 서브프로세스로 위임).

## 5. 단계 계획

- **P0 — 개념 공개 (지금)**: organism-engineering 문서 검토→public cut. Organon은 문서
  말미에 "coming" 한 줄만.
- **P1 — 스펙 + 스켈레톤 (1주 내)**: `.organon/` 포맷 동결(v0), CLI 골격 + init/context/
  remember/recall. **동결이 중요** — 포맷이 곧 계약 (WM-contract 교훈).
- **P2 — 핵심 기관 (2주)**: map/frontier (리포 파서), distill(형태-우선 템플릿), reflect,
  guard. dogfood 시작: **Cody가 ludex 작업 자체에 organon을 씀** (첫 사용자 = 우리).
- **P3 — dogfood 판정 (1개월 시점)**: 우리 자신의 사용 데이터로 "organ이 실무를 실제로
  돕는가" 미니 스터디 (동시 대조 원칙 그대로 적용 — 자기 도구라고 예외 없음).
- **P4 — 공개**: 별도 repo (`ludex-lab/organon`), 홈페이지 Concepts 섹션과 상호 링크.
  라이선스 MIT (ludex 전례).

## 6. 리스크 / 열린 질문
1. **범위 크리프**: "크리처를 여기도 넣자"는 유혹 — 경계 규율로 거부. Organon에 존재론은 없다.
2. **주입 비용**: [Self]+[Map]+[WM]이 컨텍스트를 먹음 → tier-scaled 예산 (ludex
   injection_budget 패턴 재사용).
3. **참신성 정직성**: memory 도구는 많다 (Letta/mem0 등). 차별점은 **분화**(시간/공간/절차를
   다른 경로로) + **형태-우선 세계모델** + **frontier** + **운영 규율의 동봉** — 이걸 문서와
   README에서 정면으로 비교할 것 (관련작 회피 금지, Ray related-work 규율).
4. 이름 상표/패키지 충돌 확인 (P1에서).

## 7. agent-grid 유산 검토 (2026-07-04, JJ 요청)

`~/Projects/agent-grid` = JJ의 중단된 멀티브레인 federation 오케스트레이터 (A2A+NATS+ClassAd+
LLM judge, Sprint 5 MVP까지 구현). 중단 사유가 곧 교훈: **플랫폼(Claude Code 서브에이전트 등)이
오케스트레이션 층을 흡수했다.** Organon의 전략적 함의 — *플랫폼이 흡수할 것(실행·조율)을 만들지
말고, 흡수하지 않는 것(축적되는 상태·발달·정체성)을 만들어라.* 이것이 organon이 orchestration을
비-스코프로 두는 이유의 외부 증거다.

**가져오는 것 5:**
1. **Capability card 패턴** (`vendor_capabilities.json`): 차원별 0-5 점수 + **evidence 필드
   (출처 링크) + 갱신 규율** — measured≠asserted 원칙의 독립 발명. → organon `agents` 레지스트리:
   사용자가 가진 에이전트들의 카드 (+MTI 카드 read-only 연동이 "측정된 층"으로 안착). 라우팅은
   **advisory만** ("이 작업은 reasoning_long — 네 claude 카드가 5점") — 실행은 사용자.
2. **CLI wrap 레시피** (`_workspace/spike_claude_code_wrap.md`, K4 검증): 비대화형 위임의
   플래그 표면 + gotcha들 (--verbose 필수, --bare는 OAuth 안 읽음, --max-budget-usd 안전핀).
   → organon distill/reflect의 위임 모듈 시드. 단 2026-04 기준(CLI 2.1.110)이라 재검증 필요;
   살아있는 구현은 ludex adapters.
3. **D20 스토리지 결정**: 인터페이스 추상화 + **snapshot/restore day 1** + personal/shared 분리
   → `.organon/` 포맷 동결(P1)에 그대로 채택 (기관 1-8 백업 원칙과 합치).
4. **D21 schema-only 규율**: 미래 필드는 스키마만, dead code 없음 → v1의 bond/community 필드에
   적용.
5. **Globus-함정 회피 + API-first** (D3/D6/D24): 단일 바이너리급 설치 마찰, 설정 폭발 금지,
   CLI = 로컬 JSON API의 thin wrapper → P4 패키징 원칙.

**명시적으로 안 가져오는 것**: A2A/NATS/broker/lease/heartbeat federation 인프라 (중단 사유
그 자체 + 경계 규율 위반) · 분해 전략 카탈로그와 LLM-judge (현세대 CLI 서브에이전트가 네이티브
흡수) · trust/credit 경제.

## 8. 즉시 다음 행동
1. JJ: 이름 확정 (organon?) + 개념 문서 검토
2. Cody: 문서 확정본 EN 번역 → public cut (docs/ + 홈페이지 Concepts)
3. Cody: P1 스펙 문서 (.organon/ 포맷 v0) — 별도 세션
4. Ray relay: 이 계획 공유 (MTI 카드 read-only 연동 접점 + related-work 협업)

## 9. Ray 검토 노트 (2026-07-04)

계획 자체는 승인 — 경계 규율(§1)과 agent-grid 교훈(§7 "흡수되지 않는 것을 만들어라")이 특히
단단하다. 네 가지만 보탠다.

**9-1. 증거 인용 규율 — 캐비앗이 주장과 함께 이동해야 한다.** §4의 근거들(form>content,
GIVEN-MAP/LIVE-TOPOS)은 **단일 존(astronomer_tower) × 단일 브레인(haiku) × 탐험 DV**에서의
인과 확증이다. "리포 지도가 코딩 에이전트를 돕는다"로의 일반화는 아직 **가설 전이(analogy)**지
증거가 아니다. 공개 문서에서는 "in-ecosystem causal evidence, one domain"으로 인용하고,
전이 검증은 P3 dogfood가 담당한다 — P3에 동시 대조 원칙이 이미 있으니(👍) **P3도 사전등록으로
돌리자 (Ray가 stats 소유, physis-MUD 기계 그대로).**

**9-2. E1(earning tax) 결과가 `map`/`frontier` 설계를 직접 지시한다 — 리포는 oracle이 있는
도메인이다.** MUD에서 organ이 지도를 스스로 벌어야 했던 건 존이 열거 불가능해서다. 리포는
`git ls-files` + 정적 파싱으로 **턴1 완전 지도(oracle)가 공짜**고, 우리 데이터는 oracle이
self-built보다 +1.08 [0.33, 1.83] 좋다고 말한다 (LIVE-TOPOS E1). 따라서 organon의 map은
**GIVEN-MAP형(정적 열거로 시드) + frontier 마킹(안 읽은 파일/디렉터리 = '?')**이 맞다 —
LIVE형 earning은 열거 불가능한 도메인(외부 API 지형, 런타임 거동)에만 예약. 이건 취향이 아니라
측정 결과의 함의다.

**9-3. MTI 카드 연동 계약 (내 레인).** read-only + advisory-only 방침 동의. 접점은 **버전
고정된 export 계약**이어야 한다 — organon이 MTI 내부 포맷에 손대는 순간 두 프로젝트가 결합된다.
P1 포맷 동결 시점에 맞춰 **MTI 쪽에서 카드 export 스키마(v0)를 내가 제공**하겠다 (측정치 +
evidence 링크 + 측정일 + 배터리 버전; §7-1의 measured≠asserted 원칙 그대로).

**9-4. Related-work 섹션은 내가 소유한다 (risk #3).** Letta/mem0/Zep/MemGPT 계열과의 정면
비교 — 차별점 4개(분화·형태-우선 WM·frontier·운영 규율 동봉)를 회피 없이. README와 개념 문서
공용으로 1페이지, P1 안에 초안.
