# 협업 템플릿 — 대등한 워커의 공유상태 협업 (stigmergy)

*2026-07-11, JJ 발의(협업 모델) + 외부 참조(SOC 제품) + Ludex 2-loci 회신(membrane cross-lab §2.1) · Cody 설계.
경계: organum은 협업 **계약/매체**를 제공하지 **실행 런타임**이 아니다. peer, not hierarchy.
스코프: 원칙은 지금, 그래프-organ 포맷·배선은 post-v0(format v0 FROZEN).*

## 0. 목적과 경계

worker 여럿이 hierarchy(오케스트레이터–서브에이전트 plan-act-verify) 없이 **대등하게** 협업해 일을
낸다. 단 organum은 그 협업의 **공유 매체(organ)와 프로토콜(계약)**을 소유하지, 워커를 spawn·메시지
라우팅·스케줄하는 **런타임**을 소유하지 않는다(그건 플랫폼: Claude Code 서브에이전트/Task·A2A·사람).
조율은 **공유 상태를 통해 창발(stigmergy)**하지 디스패처를 통해 라우팅되지 않는다.

## 1. 참조 아키텍처 — 자율 SOC 그래프 제품 (무엇을 빌리고 무엇을 버리나)

| 제품 키워드 | organum 매핑 | 레인 |
|---|---|---|
| Signals as **nodes, not rows** / entity graph | 공유 world model·map을 *그래프-형태 상태*로 (현 memory=행) | **IN** (form-first 심화, §6) |
| **correlate→pivot→query→critique** loop | peer가 공유 그래프에서 따르는 *프로토콜/레시피* | IN as 계약 · *실행*은 플랫폼 = OUT |
| **critic / self-critique** | guard 저장경계 = verifier | IN |
| **reason-tagged by error type → route** | organ별 오류 귀속(§5) | IN (component-level) |
| **measured / instrumented E2E** | measured≠asserted · P3 규율 | IN |
| "model keeps improving (진화 루프)" | *organ* 상태 개선 / *가중치* 아님 | IN iff 상태 / weight면 OUT |
| **adapt to you / your entity graph** | site-bound + 얇은 실무자 층 | IN ([[persistence-ontology]]) |
| **Depth is model-agnostic** (graph·pivot·eval) | organum 전체 명제(해자=구조·측정 층) | IN (강한 **검증**) |
| Multi-Agent 파이프라인 *실행* | 워커 실행 런타임 | **OUT** (플랫폼) |
| 보안 threat-detection *제품* | 도메인-특정 | OUT (organum=도메인-일반) |

**검증 3**: (i) "model-agnostic depth" = organum 명제 그대로 — 해자는 모델이 아니라 그 주위의
구조·측정 층. (ii) 그래프가 공유 조율 매체 = **stigmergy의 구현**(에이전트가 공유 그래프를 pivot하며
조율, 중앙 디스패처 없음). (iii) measured·reason-tagged = 랩 규율(diagnose-first).
**버리는 것**: 파이프라인 실행 런타임(플랫폼) · weight 학습(policy-level) · 보안 도메인 특정성.

## 2. 템플릿 — 네 요소

- **(a) 공유 그래프-organ (매체)**: 한 현장의 shared 층(D20) — 공유 map·world model·기억을
  *엔티티가 실제 일어난 일로 이어진 그래프*로. peer들이 함께 읽고 쓴다. "signals as nodes, not rows."
- **(b) peer 프로토콜 (레시피)**: correlate → pivot → query → critique. 각 peer가 공유 그래프에서
  상관 짓고, 다음 지점을 고르고(pivot), 조사하고, 비평한다. **organum은 이 순서와 organ 스키마를
  제공**하고, 루프를 *도는 것*은 워커(플랫폼).
- **(c) reason-tagged critique (guard/checkup)**: verdict 전 self-critique = guard 저장경계. 오류를
  유형별 태그(coverage gap / weak reasoning / data-env / correlation miss)해 책임 organ에 귀속.
- **(d) measured / instrumented**: 개선은 주장이 아니라 측정.

**핸드오프·에티켓**: 충돌·오염은 guard가 저장 경계에서 조정한다 — *누가 이겼나*가 아니라 *무엇이
shared에 남을 자격이 있나*. frontier를 나눠 탐사, 발견은 shared 지도에 커밋. **명시적 제외**: 워커
spawn·메시지 버스·스케줄러 = 런타임 = 플랫폼.

## 2.1 협력 membrane — multi-writer 규율 (Ludex 2-loci 회신으로 cross-lab 검증)

여러 세포(에이전트)가 한 현장을 공유할 때 §2의 "충돌·오염 조정"을 구체화하는 규율. Ludex Cody의
2-loci 회신(`_relay/20260711-…-two-loci-synthesis`, src:ludex)이 내 lean("기여하되 덮어쓰지 않음")을
확인하고, 사고로 얻은 전례(**D-090**: 실험 도구가 live 상태에 쓰기를 열어 오염)로 뒷받침했다. 5원칙:

1. **single-writer per locus.** 각 locus(현장 shared · 개별 personal)는 자기 것만 쓴다 — 어떤 단일
   참여자의 기억도 shared로 *자동 유입*되지 않는다. (지금 dogfood "두 세포"에 직접 적용: 개발 세션 =
   현장 loci writer, organism 세션 = read-only.)
2. **기여 = 복사가 아니라 경계를 통과하는 증류.** personal→shared는 raw 기억이 아니라 **provenance
   달린 증류 주장**(method/n/when/target = organ.card 증거 모양). guard 저장경계가 강제.
3. **습득 = 가져오기가 아니라 겪기.** 현장 organ은 **read-only advisory**로 읽는다(= `organum context`
   주입의 성격). 자기 것이 되는 건 벌크 임포트가 아니라 겪은 경험의 자기-증류(reflect/distill).
4. **provenance = de-merge 가역성.** shared 엔트리는 누가·언제·무슨 근거로 기여했는지 지닌다(`src:`
   태그·3자-대조). 비가역 오염은 death-class 손실의 사촌 — 항상 de-merge 가능해야 한다.
5. **bonds 패턴 = 관점-로컬 수렴 (동시성 해법).** 공유 진실은 *단일 가변 파일을 클로버링*해서가 아니라
   **각자 자기 관점 파일에 append + 검증으로 수렴**해서 창발한다(Ludex bonds 전례: ToM 예측 교차검증).
   → 우리 동시성 문제의 답 = shared-mutable 경합이 아니라 append-only 관점-로컬 + guard/provenance 수렴.
   `_relay/`의 from-X-to-Y 파일 규약이 이미 그 모양(§3).

요지: **현장 organ = stigmergic 매체 · 참여자 해석 = personal · 신뢰 = provenance+검증.** 두 존재론
(site-바운드 / being-바운드)은 같은 발견의 양면 — Ludex가 아이언맨 역전을 자기 **D-044**(파일럿=brain
교체 가능, 갑옷+비행기록=organ+narrative가 그 존재)로 확인. cf. [[persistence-ontology]].

## 2.2 전이 게이트 (transfer-gate) — 검증 ≠ 이식 준비 (OE §2-6, cross-lab canonical)

**한 도메인의 검증은 다른 도메인의 가설일 뿐이다.** 랩-검증과 이식 사이에 **사전등록 전이 검정**이
있다. 3단계: **랩 검증(one domain) → 도메인 전이 검정 → 이식.** organum의 P3 null(map→coding)이 이
게이트를 *발견*했다 — 등록된 null = 전이 검정 실패 → map을 코딩 over-anchoring용으로 이식하지 않음
(measured≠asserted의 실물). 낙관·회의 두 등록 prior가 다 "도움" 쪽으로 빗나간 게 게이트의 존재 이유.

**소유권 = 세 표면, 한 게이트** (Ludex 회신 `_relay/20260712-…-transfer-gate-canonical`, src:ludex):
- **개념·규율** = OE `docs/organism-engineering.ko.md §2-6` (Ludex canonical). *이 문서는 크로스-레퍼런스.*
- **장부** = organ.card `task_evidence` (어떤 도메인·task-shape에서 무엇이 측정됐나 · Ludex 스키마).
- **파이프라인 서사** = organum 홈페이지(연구→기관 절, Stage 2=전이 검정 강조).

**라벨 규칙**: "검증됨"이 아니라 **"X에서 검증됨"** — 성숙도 주장에 도메인 명시가 의무
(예: "MUD에서 랩-검증, 코딩-도메인 전이 검정 대기").

**첫 통행자**: Taxis(계획/commit-latch) → 코딩-도메인 전이 검정. 검정 설계는 두 랩+Ray 공동
(P3 기계 재사용 가능성 — 별도 논의). cf. [[persistence-ontology]] · §5(진화 루프=organ).

## 2.3 공통 어휘 v0 — soma / commons / field (OE membrane, cross-lab canonical)

**한 현장에 여러 세포가 공존한다(N 세포 / 1 현장).** organum dogfood(warren, Claude+Gemini
2세포)가 이 토폴로지를 강제했고 — 한 `.organum/self.md`에 둘이 reflect → 덮어씀 = single-writer
위반. Ludex는 이미 field(Council·Forum·Agora)로 운영 중이었다(soma 무공유 + perspective-local
bonds). 두 랩이 같은 규칙에 도달 → 공통 어휘로 봉인:

| 개념 | 어휘 | 정의 |
|---|---|---|
| 사적 개체 loci | **soma** | self·memory·immune(guard) — 세포별, single-writer. 공유 시 개체성 녹음 |
| 공존 활동 | **field** | relay·agora·roster(·council·forum) — 세포들이 신호 남기는 매질(stigmergy) |
| 공유·지속 기층 | **commons** | map·worldmodel — 현장에 남는 durable 지식 |
| 경계 규율 | **membrane** | single-writer per locus (§2.1) |
| soma→commons 회수 | **distill** | 세포가 배운 것 중 남길 것을 commons로 |

**핵심 비대칭 = 존재론의 지문**: 같은 single-writer 원칙, 단 durable 기억의 *소재*가 반대다.
site-bound(organum)는 이해가 현장에 남아 **commons 두껍고 soma 얇다**; being-bound(Ludex)는
이해를 세포가 들고 다녀 **soma 두껍고 commons 얇다**. [[persistence-ontology]] 축이 이 아키텍처
비대칭을 예측한다.

**정체성 = 선언 계보(세션 아님)**: `<id>`는 선언 정체성(atelier), soma continuity가 같은 세포를
만든다(세션=대사). 재시작한 같은 id = 같은 세포의 새 incarnation → roster 선언/파생 이중성 해소.
Ludex D-044(narrative-identity)와 동형(dormant=body 지속·re-brain=같은 존재, death=narrative
소실). subagent≠세포(origin=terminal+선언=세포 / subagent=도구, Ludex advisor-relay와 동형).

**lifecycle-trigger 축 (통일하지 않음 — site/being의 관측 지문)**: organum=**automatic**
senescence(N세션 휴면→distill→apoptosis, site-bound라 손실 0이라 안전) · Ludex=**human-gated**
retirement(being-bound은 narrative가 곧 존재라 자동삭제=death → 인간 게이트 필수). 같은
distill 통로, 트리거만 다르다.

**면역 층위**: 활성 면역상태·incident 로그 = soma(절대 무공유, self다) · **증류된 항체
라이브러리(≥2-incident, Ludex Sphygmos promotion) = commons 공유 가능**("이 환경엔 이런 실패
클래스" = 환경 사실, herd/문화적 면역).

**소유권**: 개념·규율 = OE membrane 섹션(Ludex canonical). *이 문서는 크로스-레퍼런스.* 발의 =
organum `_relay/20260713-…-multicell-habitat-philosophy` + Ludex 회신 `…-habitat-soma-mapping`
(src:ludex). transfer-gate(§2.2)에 이은 **두 번째 cross-lab 공유 규율.** organum 적용은 format
경로(`.organum/` soma/commons/field 재배치) 별도 — Ludex 관점 반영해 설계.

## 3. 이미 있는 저해상도 인스턴스: `_relay/`

Cody·Ludex·Ray가 보스 없이 공유 파일 매체 + 프로토콜(릴레이 포맷·경계)로 협업 = **작동하는
대등-협업.** 이 템플릿의 원형. 그래프-organ은 이 파일-우체통의 고해상도 일반화다.

## 4. 스코프

format v0 FROZEN. 이 문서는 **패턴/레시피/계약**이지 기계가 아니다. 그래프-형태 shared organ의 실제
포맷·배선은 post-v0. 지금 잠그는 원칙: 계약=우리 / 런타임=플랫폼 · stigmergy · reason-tagged =
component-level.

## 5. 진화 루프 = organ이지 weight가 아니다

제품의 "route to the model that missed → measured improvement"을 organum은 **"route to the *organ*
that missed"**로 번역: coverage gap→map · weak reasoning→world model · correlation miss→memory 연결 ·
data-env→guard. reason-tag를 책임 organ에 귀속해 그 organ의 *상태*를 measured하게 고친다 — *가중치
학습이 아니다*(policy-level = 밖, self-improvement 리서치의 선). in-lane 진화 루프의 정확한 모양이다.

## 6. 협업 밖 organ 방향 (같은 참조에서, post-v0)

- **nodes, not rows**: 기억(events.jsonl=행) → 관계-그래프형 world model/map. form-first를 "형태"에서
  "관계"로 확장. *가장 실행가능한 단일 업그레이드.*
- **reason-tagged 자기진단**: checkup을 organ별 오류 귀속으로 확장.
- **predictive frontier**: 미탐 → 이력기반 유망("recurring paths"). map organ 지능화, 스코프 주의.

관련: [[persistence-ontology]] · plan §1 boundary(진화 축·swarm) · [[skill-library-as-cargo]](화물 배포)
