# [README 반영용 초안] 관련 작업 — organum과 2026 에이전트 메모리 지형

*plan §9-4 이행분 (Ray, 2026-07-17). 현 README「관련 작업」 스텁 대체용 1페이지.
전체 근거·출처·캐빗은 리서치 리포트(ray_organum_related_work_research_20260717.md) 참조.*

---

## 관련 작업

에이전트 메모리 도구는 두 층으로 나뉜다. **(A) 새 에이전트를 만들기 위한
메모리 서비스/SDK** — Zep/Graphiti(시간-지식그래프), Letta(MemGPT 계보
상태ful 런타임), mem0, A-MEM(NeurIPS 2025) 등. **(B) 이미 쓰는 에이전트 위에
얹는 파일-퍼스트 층** — Claude Code 네이티브 메모리(CLAUDE.md + auto memory),
agentmemory, beads 등. organum은 (B)층의 도구다: 서버도 DB도 자체 LLM 호출도
없이, 프로젝트-로컬 `.organum/` 파일로 기존 에이전트에 organ을 입힌다.

**이 층은 비어 있지 않다.** jayzeng/agentmemory가 같은 니치(마크다운,
no-DB, no-LLM, Claude Code/Codex/Cursor 사이드카)를 선점 증명했고, beads는
git-backed 이슈트래킹을 장기 기억으로 쓴다. organum이 주장하는 것은 유일한
층이 아니라 **거의 빈 니치에서의 고유한 조합** — 아래 네 축이다.

**① 분화된 기억.** 기억 종류를 나누는 원리 자체는 우리 발명이 아니다 —
Zep은 episodic/semantic/community 3층 그래프로 분화하고(단, 그래프 DB +
인제스천 LLM이 필요한 서비스다), 47저자 서베이(arXiv:2512.13564)는
factual/experiential/working 분류를 제안하며 분류학 자체가 아직 미정착임을
명시한다. Letta는 종류가 아니라 컨텍스트-티어(core/archival)로 나눈다.
**파일-퍼스트 사이드카 층에서 시간(events)/선언(memories)/절차(worldmodel)
분화 라우팅을 실은 도구는 organum뿐이다.**

**② 형태-우선 세계모델, ③ 명시적 frontier.** 조사한 어떤 출하 도구에도
유사물이 없다. "아직 모르는 것"의 명시 표현(frontier)은 2026년 현재 연구
쪽에서 평가 스키마로만 존재한다 — ToCS 벤치마크(arXiv:2603.00601)가 인지맵에
observed/inferred/unknown 상태와 미탐색 영역 리스트를 요구하는 것이 유일한
근접물이다. organum은 이를 영속 도구로 싣는다: 리포는 `git ls-files`로 턴1
완전 열거가 가능한 도메인이므로 map은 정적 시드 + '?'(안 읽은 영역) 마킹이다.

**④ 저장 시점 guard + 운영 규율.** 요소별 유사물은 있다 — Letta의
sleep-time compute는 reflect/consolidate의 최근접 유사물(단, 런타임 안의 자동
LLM 에이전트; organum은 사용자가 부르는 CLI 의례고 LLM 호출은 사용자의 CLI에
위임된다)이고, Zep은 모순을 **들여보낸 뒤** bi-temporal edge invalidation으로
사후 만료시킨다. **저장 시점에 오염 산출물의 진입 자체를 차단하는 guard는
조사 범위에서 organum 고유다.** 이 설계는 외부 실증도 얻었다:
arXiv:2602.19320은 LLM이 구조화 기억을 쓸 때 약한 백본에서 17.9~30.4%의
포맷 오류가 발생하며, 에이전트가 유창하게 대화하는 동안 장기기억이 조용히
오염됨을 보고한다 — organum의 non-LLM programmatic write가 설계로 회피하는
바로 그 실패 모드다(직접 실험은 아니며 추론 연결임을 밝힌다).

**증거에 대한 정직한 비교.** 경쟁 도구들은 발표된 수치가 있다(Zep 보고 기준
DMR 94.8%, LongMemEval +18.5%; A-MEM 보고 기준 LoCoMo 44.27 vs 18.09).
organum은 아직 없다. 다만 그 잣대 자체가 흔들리고 있다: 2026 메타연구
(arXiv:2602.19320)는 주요 벤치마크가 현대 컨텍스트 윈도우 안에 포화되고
(메모리 층이 구조적으로 불필요), 어휘 메트릭이 순위를 뒤집으며, 이득이 백본
의존적임을 보였고, Zep의 LoCoMo 수치는 커뮤니티 정정으로 ~84%→58.4%가 됐다.
organum의 측정(P3 dogfood)은 사전등록 + 동시 대조 + 풀컨텍스트 대비 Δ≫0
입증 구조로 설계한다 — measured≠asserted를 남에게 요구하기 전에 우리가
먼저 통과할 잣대다.

*커버리지 고지: mem0·LangMem·Cognee·Cursor/Windsurf rules에 대한 클레임은
이번 검증을 통과하지 못해 위 비교는 이들에 대해 침묵한다 — 기능 부재의
증거가 아니다. 특히 mem0의 모순 해소는 ④에 대한 유력한 추가 도전으로 후속
확인 대상이다.*
