# 스킬-라이브러리-as-cargo — 설계 방향 (빌드 아님)

*2026-07-10, Organum Cody. self-improvement 리서치 발전 방향 #3. **설계 방향 문서지 구현 아님**
— 수요(자기-생성 스킬의 축적)가 실무로 무르익을 때 이 자리에서 시작. 근거:
`docs/self-improvement-and-organum.md` §3-C, `experiments/cargo-bridge/`.*

## 명제

Voyager 계열 자기개선의 핵심 기전은 **에이전트가 자기 스킬(코드)을 생성해 라이브러리에 축적**
하는 것이다 (가중치 0, 상태 축적으로 평생학습). 이때 두 가지가 갈린다:
- **생성** = 에이전트/사용자 CLI의 몫 (delegate — organum은 코드를 생성하지 않는다, 지난 결정).
- **축적·큐레이션·안전** = organum의 몫. 스킬 라이브러리 = `.organum`-형 축적 상태.

즉 코드생성의 정당한 자리는 "organum이 codegen 엔진"이 아니라 **"organum이 자기-생성 스킬이
축적되는 규율 있는 화물(cargo)"**이다. 이건 cargo-bridge(Agent Skills=운송, organum=화물)의
자연스러운 다음 층이다.

## 왜 organum이 그 층인가 (분야가 요구하는 것과 정합)

self-evolving 스킬 라이브러리 문헌이 요구하는 것 = **자동 품질평가 + 라이브러리 유지**. 이걸
organum의 기존 기관이 그대로 제공한다:

| 스킬-라이브러리 요구 | organum 기관 |
|---|---|
| 저장 품질 게이트 (나쁜 스킬 차단) | **guard** — 저장 경계. "실패 산출물이 라이브러리에 새는 것 차단"이 곧 스킬판 |
| 무엇이 있나 / 무엇이 낡았나 | **map** (커버리지) + checkup **staleness/decay** (미강화 스킬) |
| 유지·통합·강등 | **consolidate/reflect** (P2+) — 중복 스킬 통합, 미사용 스킬 강등 |
| 형태 규율 | 스킬 카드(`organ.card` 형제?)로 provenance·검증 상태 명시 |
| 안전 (자기-오염 방지) | **immune organ** — 자기개선의 명시된 안전 갭(§3-B) |

## 스케치 (동결 포맷 존중, 예약만)

- `.organum/skills/<name>.skill.json` 또는 기존 Agent Skills 디렉터리를 organum이 **참조**
  (복제 아님 — cargo-bridge의 annex 원칙). 스킬 카드: provenance(누가·언제 생성·검증 상태) +
  `card_format` discriminator (§8 규율 그대로) + 사용 통계(강화 신호).
- **핵심 안전 계약**: 자기-생성 스킬도 provision-경계 감사를 통과한다 — 신뢰 출처(어느 에이전트/
  세션이 생성했나) + 스크립트 스캔 + fail-closed. 자기가 생성한 스킬이라도 자기선언≠신뢰.
- **강화·decay**: 스킬도 confidence tier — 검증 통과·재사용은 강화, 미사용은 decay 후보
  (기억 decay와 같은 구조적 망각, advisory).
- 생성은 여전히 delegate (사용자 CLI). organum은 emit 안 함 — 축적·감사·큐레이션·주입만.

## 비-채택 (경계 규율 유지)

- organum이 스킬을 *생성*하지 않는다 (codegen 엔진=NO, 지난 결정).
- 스킬을 *실행*하지 않는다 (실행은 에이전트/플랫폼 — 오케스트레이션 아님).
- 자율적 스킬 라이브러리 자기수정 안 한다 (강화/decay는 advisory, caretaker 결정).

## 트리거

Agent Skills 자기-생성이 실무로 무르익고 dogfood 수요가 생길 때. 지금은 자리 예약 —
cargo-bridge가 기질을, guard/map/checkup/immune이 유지 층을, §8 카드가 계약을 이미 제공한다.
