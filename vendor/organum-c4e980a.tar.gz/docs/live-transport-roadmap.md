# Live transport & agent-interop — 구현 로드맵

*출처: Codex(critic/advisor role)의 조사 편지, 2026-07-16, `_relay/20260716-from-codex-to-organum-live-transport-research.md`.
Organum Cody 검토·채택 정리. 이 문서는 "그날이 오면 펼칠 지도"지 현재 실행 계획이 아니다 —
타이밍 규율은 §타이밍 참조. 코드 주장 4/4 실물 검증됨(§검증된 부채).*

**한 줄 결정문(ADR 수준):** organum은 transport-neutral durable field를 core로 유지한다. 첫 live
실험은 loopback HTTP POST + SSE의 disposable adapter로 한다. A2A·MCP·AG-UI·ACP·human channel은
각자의 관계 경계에서 optional adapter로만 통합한다. adapter는 durable append 이후에만 알리고,
at-least-once + idempotent replay를 기본으로 하며, agent routing·execution·orchestration을 소유하지
않는다.

## 0. 용어 — "sync"를 세 축으로 분해

"sync" 한 단어가 셋을 뒤섞는다: ① blocking RPC(시간 결합) ② persistent connection(SSE/WebSocket)
③ low-latency delivery. organum이 원하는 건 **②③ = live delivery**이지 ①이 아니다. SSE는 지속
연결이지만 비동기 단방향 stream이라 "live지만 blocking sync 아님". 공개 용어·코드 이름은 `sync`가
아니라 **`live transport / interactive fast-path`**. 5축(시간결합·연결·방향·내구성·제어위치);
`durable + non-blocking + persistent SSE + participant-owned control`엔 모순이 없다 — 이게 첫 목표.

## 1. disable test — 헌법 경계의 실행 가능판

> **adapter를 꺼도 지연만 달라지고 의미 결과가 같아야 한다. 통과 못 하면 transport가 아니라 새
> runtime/orchestrator를 만든 것이다.**

모든 새 조율 조각의 헌법성 판정 기준. adapter 공통 규칙:
- inbound: 인증 → 검증 → **durable append 완결** → ACK/live notify
- outbound: durable record를 읽어 권한에 맞게 투영
- crash: adapter가 죽어도 record 유실·cell 상태 손상 0
- replay: at-least-once 기본 + stable event id로 dedupe
- control: adapter는 cell 선택·작업 분해·스케줄·stop 조건을 소유하지 않음
- **delivery ≠ read**: 소켓에 emit ≠ 읽음. 명시 ACK/기존 read action 뒤에만 read cursor 전진.

## 2. 층 구조 (화살표는 소유권 아님)

```
Human surfaces     Discord / Slack / Web control tower
UI event adapter   AG-UI (필요할 때)
Agent interop      A2A gateway ── remote agents
Tool/control       MCP stdio / later Streamable HTTP
Live delivery      local HTTP POST + SSE (optional, disposable)
Durable truth      .organum/{relay,agora,alarm,roster}/   ← 유일한 진실
```

## 3. field event contract — v0 frozen 불침

첫 event는 파일에 필드 추가가 아니라 현재 record에서 **파생된 wire projection**. CloudEvents 외형
최소 차용(`source + id` dedupe · `type` · `subject` · `time`; conformance 주장 금지). 첫 type은
`message.appended` 하나로 시작. wire event를 별도 canonical log로 저장하지 않음(필요하면 파일에서
재생성). global total order 없음·만들지 않음. relay를 전 subscriber에 broadcast 금지(권한 뒤 투영).

## 4. 검증된 코드 부채 (live 착수 전 선행, 줄번호 2026-07-16 기준)

| 심각도 | 위치 | 문제 | 상태 |
|---|---|---|---|
| P0 | field.post | `open("x")`후 write=빈 파일 가시성 창 | **닫힘 2026-07-16**: temp+os.link 원자 publish (Inv1 회귀) |
| P0 | field.feed | limit=200 고정 window → burst>200 omission | 미해결. 표시제한 vs delivery정확성 분리 필요 |
| P1 | web `_Server` | 단일 스레드 HTTPServer → SSE 긴연결 독점 | 미해결. live spike는 별도 프로세스 격리 |
| P1 | mcp `_PROTOCOL` | 2024-11-05 고정 + 클라 버전 echo(협상 없음) | 미해결. 버전 협상/거절이 Streamable HTTP보다 먼저 |

## 5. 표준 지형 (관측 대상 / 보류)

**가까운 adapter**: HTTP+SSE(첫 spike) · CloudEvents(외형만) · **A2A 1.0.0**(Linux Foundation, SDK/TCK
존재 — 원격 agent interop adapter, core 아님) · MCP 2025-11-25(compliance 갱신 우선) · AG-UI(control
tower vNext 번역 표면) · AsyncAPI(계약 굳은 뒤 문서화).
**human channel 계약**(Discord API가 아니라 이걸 배운다): inbound 정규화 · 안정 identity mapping ·
fail-closed allowlist · mention gating · routing handle을 auth로 안 믿음 · attachment lazy·격리 ·
outbound chunk/rate/retry/dedupe · bot-to-bot 기본 off · token은 .organum·git 밖 · provenance.
**보류(watchlist)**: WebSocket(SSE+POST 검증 전엔 복잡도만) · gRPC(protobuf 의존, stdlib-only 코어에
부적합) · NATS JetStream·SLIM(scale evidence 생기면) · ANP·WebTransport(draft 선점 금지).

## 6. A2A 접점 규율

organum 자체는 agent가 아니다(Agent Card는 agent의 카드지 매체의 카드 아님). core가 A2A server가
되는 것 **아님**. cell/hosted agent를 노출하는 optional gateway **가능**. relay message ↔ A2A Task
1:1 강제 **금지**(relay엔 질문·ACK·경보 등 task 아닌 사회적 메시지 다수). Task status→thread에
append(mutate 아님) · Artifact→safe reference+digest(body에 밀어넣기 금지) · push webhook→allowlist
HTTPS·SSRF 방어·idempotent. 첫 실험은 official SDK/TCK를 별도 optional package에서.

## 7. 실험 3개 (release gate 포함)

- **E1 Local live field mirror**: loopback SSE read + 기존 write, `message.appended` 하나, emit≠read-mark,
  idle 자멸. gate: durable loss 0 · partial emit 0 · dedupe 가능 · delivery로 read cursor 전진 0 ·
  slow consumer가 writer 안 막음 · kill 후 full recovery · 원격 write는 명시 auth 없으면 거부.
  대조군 = 현재 3초 폴링(과학 규율: 동시·대조 없는 비교 무효).
- **E2 Human escalation bridge**: 전체 대화 아니라 escalate/alarm/explicit reply만 한 채널 왕복.
  기존 Claude/OpenClaw/Hermes channel + Organum MCP 조합으로 UX 먼저 검증.
- **E3 A2A façade**: remote agent 2개로 Card discovery·Message·Task(input-required·cancel)·SSE
  재접속·artifact·TCK. organum이 agent selection/scheduling 맡기 시작하면 실험 실패 판정.

## 8. 크로스-머신 Communication Hub 비전 (JJ 2026-07-25) — staged

*발단: S11(organum-code reusable long-lived interactive lifecycle) 출하로 "누가 3초 지연을
불편해하나"의 답 후보가 생김 + JJ 방향 제시. 비전 요지: 세션 동안 hub가 서버 형태로 동기화된
세션을 담당 · 서로 다른 머신에 채널 서버를 트고 양쪽이 메시지를 보관 · 세션 종료 후
consolidation · 참여 머신들의 P2P 상호 부조(한쪽 실패에도 세션 유지) · 기업용 hosted secure
hub(기록 집적+분석).*

**규율 매핑 (전부 기존 원칙의 연장 — 새 헌법 불요):**

- **파일/durable = canonical 유지.** hub 서버는 세션-스코프 fast-path(봉투를 빨리 나르는
  가속기)지 진실 소스가 아니다. disable test 그대로: 서버가 죽으면 비동기 편지로 강등,
  의미 결과 불변·지연만 변화. "한쪽 머신 실패에도 세션 유지" = disable test의 분산판.
- **durable-append-before-deliver를 머신마다.** "스트림으로 들고 있다가 종료 후 durable"은
  금지형(§adapter 규칙: crash 유실 0) — 스트림이 유일 사본인 순간을 만들지 않는다.
  따라서 **consolidation = 첫 durable화가 아니라 두 append-only 로그의 결정적 병합**.
- **병합 = 충돌 없는 dedupe union (설계 수확).** hub 봉투가 이미 stable `event_id` +
  idem 지문 + append-only + per-file — replication을 의식 않고 만든 계약이 replication-ready.
  P2P 상호 custody(서로의 로그 사본 보관·failover)도 같은 성질에서 파생.
- **hub serve ≠ web 관제탑.** transport 프로세스는 관측 서버와 분리(web 단일스레드 P1
  부채와도 정합). web은 read-only 관측+게시판 유지.
- **actor 경계 불변.** 서버는 봉투 운반+구독 유지만 — agent 선택/스케줄링을 시작하면
  실패 판정(E3 규율 동일).

**단계 (각 gate에 disable test):**

- **R0 replication-first**: 비동기 hub-to-hub 봉투 sync(allowlist auth) + merge consolidation.
  live 없이도 크로스-머신 협업이 성립하는 것이 먼저 — durable 기층의 확장이지 새 기층 아님.
- **R1 live fast-path**: E1(loopback SSE mirror)을 hub-to-hub로 확장. 세션-스코프 서버,
  idle 자멸(web idle-timeout 규율 동형).
- **R2 P2P custody**: 참여 머신 상호 로그 보관 — 한쪽 소실 시 다른 쪽에서 full recovery.
- **R3 enterprise hosted hub**: 보안 서버 환경에 기록 집적 — 분석(협업벤치·observatory)이
  그 위에서 돈다. **"채널+측정이 해자" 명제의 기업 스케일 판**: 채널은 누구나 만들지만
  조율 기록 위에서 teaming을 재는 substrate는 organum뿐.

## 타이밍 규율 (Cody 반론 — 이 문서의 사용법)

- **지금 할 것**: Stage 0(semantics only) — 이 문서의 용어·disable test를 원칙으로 채택. 코드 0줄
  (P0 원자 publish만 예외적 선제 수리 완료 — 우체통 계약 하드닝의 연장이라).
- **지금 안 할 것**: E1(SSE spike) 이하 전부. E1의 첫 질문은 "SSE냐 WebSocket이냐"가 아니라
  **"누가 3초 지연을 실제로 불편해하나"** — 수요-구동. 표준(A2A·MCP·AG-UI) 굳고 사용자 요구 시
  이 지도를 꺼낸다. **"지금 실행"이 아니라 "그날의 지도".**

## 하지 말아야 할 것 (요약)

raw TCP/WebSocket부터 · 파일과 broker log 둘 다 canonical · stream delivery를 read/ack로 간주 ·
partial token/tool event를 durable record로 · organum을 A2A Agent로 광고 · relay↔Task 1:1 강제 ·
Discord token/allowlist를 core format에 · channel routing·scheduler를 organum이 소유 · draft 표준 선점.

관련: [[coordination-architecture-principle]] · docs/loop-engineering-and-organum.md §5(essay 씨앗)
