---
organum-format: 0
domain: organum-arch
updated: 2026-07-05T07:34:35Z
---
# WM: organum-arch

## Map
- organum: 입힌다→기존 에이전트 · 위임한다→사용자 CLI(delegate.py) · 자체오케스트레이션→없음
- 상태: 산다→.organum/ · 동결→v0(2026-07-04)
- .organum/: 정체성→self.md · 시간기억→memory/events.jsonl · 선언기억→memory/memories.jsonl · 세계모델→worldmodel/<domain>.md · 지도→map/repo.map.json · 면역→guard.jsonl
- guard: 초크포인트→모든 영속 쓰기 · 1층→저장경계(per-artifact) · 2층→streak-window(연속5) · 규칙출처→guard_rules.json(데이터)
- 저장경계: 규칙→error-fallback · 규칙→auth-billing · 규칙→context-residue · 규칙→empty · 규칙→wm-shape
- delegation: 선분기→is_error(budget=result키부재) · 게이트→콜드캐시예산바닥 · 게이트→streak · 격리→auth(ANTHROPIC_API_KEY 미주입)
- 명령: 상태→init/context · 기억→remember/recall --when · 지도→map view/frontier/mark/sync · 세계모델→distill · self→reflect · 건강→checkup · 스냅샷→backup/restore · 미구현→migrate?
- 협업: 채널→_relay/ 파일우체국 · ludex→guard fixture 교차검증 · Ray→mti.card/v0 §8 카드계약 · Luca→소비자 피드백 · 이후→P3 dogfood 전이가설?

## Frontier
- migrate 명령 구현 — 남은 마지막 명령 하나
- guard rules v2를 ludex fixture와 교차검증 실행
- Ray의 mti.card/v0 §8 카드계약을 map/repo.map.json 시드 포맷에 대조
- rules v2 앵커/키워드 재설계에 대한 CJK 편향·정당기억보호 회귀 케이스 측정
- P3 dogfood 스터디 프로토콜 설계 (전이가설 검증 대상·측정지표 정의)

## Claims
- [confirmed] organum은 자체 LLM 오케스트레이션이 없고 내용 생성을 사용자 CLI 서브프로세스로 위임한다 (evidence: delegate.py, "상태와 규율의 도구지 에이전트가 아니다")
- [confirmed] guard는 모든 영속 쓰기의 단일 초크포인트다 (evidence: 자료 명시)
- [confirmed] 포맷은 2026-07-04 v0로 동결됐고 남은 명령은 migrate 하나다 (evidence: 자료 명시)
- [confirmed] rules v2는 길이 문턱을 폐기하고 앵커=차단/키워드=표시로 재설계했다 (evidence: 자료 명시)
- [well-supported] guard 규칙이 코드 아닌 데이터(guard_rules.json)여서 랩 간 fixture 교환이 가능하다 (evidence: 데이터화 설계 + ludex 교차검증 협업 존재)
- [well-supported] auth 격리(ANTHROPIC_API_KEY 미주입)는 위임이 과금 경로를 바꾸는 사고를 막는다 (evidence: delegation 모듈 격리 설계)
- [tentative] 앵커/키워드 재설계가 실제로 CJK 편향을 제거하고 정당 기억을 보호한다 (evidence: 설계 의도로만 서술, 소비 측정 결과 미제시)
- [tentative] streak window 연속5 차단→위임거부가 폭주 실패를 정지시킨다 (evidence: 2층 guard 설계, 실측 미제시)
- [tentative] budget abort는 result 키 부재로 is_error보다 먼저 식별된다 (evidence: delegation 선분기 서술, 경로 실행 근거 미확인)
- [tentative] P3 dogfood가 전이 가설을 검증할 것이다 (evidence: 다음 단계로 예고됨, 미실행)
