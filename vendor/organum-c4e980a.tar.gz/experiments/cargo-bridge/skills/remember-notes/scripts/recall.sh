#!/usr/bin/env bash
# remember-notes skill — recall notes from organum's memory organ.
set -euo pipefail
organum recall --when "${1:-7d}"
