#!/usr/bin/env bash
# remember-notes skill — persist a note via organum's memory organ.
set -euo pipefail
if [ "$#" -eq 0 ]; then
  echo "usage: remember.sh <note text>" >&2
  exit 2
fi
organum remember "$*" --tags "field:remember-notes,src:skill"
