---
name: remember-notes
description: Persist and recall short notes across sessions. Use when the user wants an agent to remember notes between separate conversations, not just within one session.
compatibility: Requires the organum CLI and a provisioned .organum/ stateful annex (see cargo-bridge).
metadata:
  organum-requires: memory
  organum-annex: .organum
  ludex_source: creature:cody   # provenance 주장 (운송 스탬프) — 신뢰는 외부 레지스트리가 판정
allowed-tools: Bash(organum:*)
---
# remember-notes

This skill gives an otherwise stateless agent **cross-session memory** through
organum's memory organ. It is a *converted* skill: the transport (SKILL.md) is
standard Agent Skills; the cargo (persistent state) is provisioned by organum.

## Remember a note
Run `scripts/remember.sh <note text>` — wraps `organum remember`, which routes
the note through organum's save-boundary guard before persisting it.

## Recall recent notes
Run `scripts/recall.sh [window]` — wraps `organum recall --when` (default `7d`).

## Why this persists
The notes live in the provisioned `.organum/` annex — plain files on disk. They
survive across sessions because the state is on the filesystem, not in the
model's context. The agent that runs session 2 need not be the one that ran
session 1; the annex is the continuity.
