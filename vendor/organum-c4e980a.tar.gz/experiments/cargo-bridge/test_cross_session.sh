#!/usr/bin/env bash
# cargo-bridge POC — the open experiment: does statefulness work by FORMAT ALONE?
#
# Setup: a converted skill (remember-notes) is provisioned into a fresh workdir.
# SESSION A writes a note via the skill. A SEPARATE process (SESSION B) — a
# different "agent" invocation — recalls it. If the note survives, statefulness
# is achieved by the bundled .organum/ annex alone (filesystem state), with no
# in-context continuity.
set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
REPO="$(cd "$HERE/../.." && pwd)"
SKILL="$HERE/skills/remember-notes"

WORK="$(mktemp -d)"
BIN="$(mktemp -d)"
trap 'rm -rf "$WORK" "$BIN"' EXIT

# organum shim on PATH (no install needed — points at repo source)
cat > "$BIN/organum" <<EOF
#!/usr/bin/env bash
exec env PYTHONPATH="$REPO/src" python3 -m organum "\$@"
EOF
chmod +x "$BIN/organum" "$SKILL/scripts/"*.sh
export PATH="$BIN:$PATH"

cd "$WORK"
git init -q  # organum map은 git 열거를 시드 (없어도 동작하나 리포가 자연스러움)

NOTE="cargo-bridge marker $(git rev-parse --short HEAD 2>/dev/null || echo poc)-persist-across-sessions"

echo "== PROVISION (organum provision, 감사 포함) =="
# --trust = 운영자 명시 신뢰. provenance 주장(ludex_source)은 self-declared라 신뢰 근거가
# 아니고, 외부 크리처 신뢰 레지스트리는 아직 미도착이므로 fail-closed → 운영자가 명시 신뢰.
organum provision "$SKILL" --into "$WORK" --trust

echo
echo "== SESSION A (프로세스 1): skill로 기억 =="
"$SKILL/scripts/remember.sh" "$NOTE"

echo
echo "== SESSION B (별도 프로세스: 다른 '에이전트' 호출): skill로 회상 =="
# 완전히 새 셸 — 세션 A의 컨텍스트/메모리 없음. 오직 디스크의 .organum/ annex만.
# PATH는 부모에서 export되어 상속된다 (별도 프로세스, 같은 파일시스템 = 세션 교차 모델).
RECALL_OUT="$(bash -c "cd '$WORK'; '$SKILL/scripts/recall.sh' 7d")"
echo "$RECALL_OUT"

echo
if echo "$RECALL_OUT" | grep -qF "$NOTE"; then
  echo "RESULT: ✅ 세션 교차 지속 확인 — statefulness는 포맷(번들 .organum/)만으로 달성된다."
  echo "        세션 B는 세션 A와 컨텍스트를 공유하지 않았다. annex(디스크 상태)가 연속성이다."
  exit 0
else
  echo "RESULT: ❌ 노트가 세션을 넘지 못함 — 포맷 외 추가 메커니즘 필요."
  exit 1
fi
