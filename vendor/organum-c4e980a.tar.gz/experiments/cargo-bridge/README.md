# cargo-bridge — Skills = 운송, organum = 화물

*실험 (2026-07-05). 열린 질문에 답하는 POC.*

> **졸업 완료 (2026-07-05)**: POC 검증 후 로직이 `organum provision` 코어 명령으로 승격됐다
> (`src/organum/provision.py`, `tests/test_provision.py` 9 테스트). 이 디렉터리는 이제 그
> 명령의 **통합 테스트 + 답 기록**이다 — 두 셸 테스트가 실제 `organum provision`을 구동한다.
> 프리즈된 v0 포맷은 안 건드렸다 (provision은 기존 조직을 오케스트레이션하고, 감사는 §3.3의
> 열린 kind `provision` 이벤트로 기록 — 스키마 변경 없음).

## 명제

**Agent Skills**(agentskills.io, 2025-12-18 공개; 2026-03까지 32개 툴 채택 — Gemini CLI,
Junie, Kiro, Goose 등)는 절차적 능력을 실어 나르는 **이식 가능한 운송 포맷**이다. 그러나
스펙이 명시적으로 **다루지 않는 것**이 둘 있다:

1. **cross-session statefulness** — Skill은 세션을 넘는 상태 지속 메커니즘이 없다.
2. **tool/state 의존성 선언** — Skill이 요구하는 지속 상태를 선언할 방법이 없다.

이 공백이 정확히 **organum이 화물로 채우는 자리**다. Skill은 운송(이식 가능·무상태),
organum은 화물(지속하는 조직). cargo-bridge가 둘을 잇는다.

> agent-grid 교훈의 재확인: 플랫폼이 흡수하는 것(운송 표준 — 32개 툴이 SKILL.md를 읽는다)이
> 아니라 흡수하지 않는 것(축적되는 상태 — 스펙이 명시적으로 비워둔 자리)을 만들어라.

## 통합 훅 (스펙에 이미 있다)

Agent Skills frontmatter가 확장점을 sanctioned로 제공한다 (스펙 §Frontmatter):
- `metadata` — "스펙 외 클라이언트 정의 속성"용 임의 key-value 맵. **여기에
  `organum-requires: memory`를 선언** (namespace 권장 규칙에 부합).
- `allowed-tools` — Skill이 호출하는 tool 표면 (여기선 `Bash(organum:*)`).

변환된 Skill(`skills/remember-notes/`)이 이렇게 선언하면, cargo-bridge가 읽어 조직을 provision한다.

## 열린 실험과 그 답

**질문: statefulness가 포맷만으로 되나 (번들 `.organum/` annex가 세션을 넘어 지속),
아니면 더 필요한가?**

**답 (POC로 측정): 지속은 포맷만으로 달성된다. 단, 사용 가능하려면 그 둘레에 두 가지가 붙는다.**

- **`test_cross_session.sh` → ✅**: 세션 A(프로세스 1)가 skill로 노트를 기억하고, **세션
  B(별도 프로세스, 컨텍스트 공유 없음)가 회상**한다. 연속성은 디스크의 `.organum/` annex뿐 —
  in-context carry-forward 0. **statefulness는 파일시스템 상태이지 컨텍스트 상태가 아니다.**
  세션 B를 돌린 에이전트가 세션 A의 것과 같을 필요도 없다 — annex가 곧 존재의 연속이다(1-8).
- 그러나 "포맷만으로"가 **낯선 에이전트에서 실제로 작동**하려면:
  1. **provisioning** — annex와 organum CLI가 대상에 존재해야 한다 (cargo-bridge가 선언된
     의존성을 읽어 annex init + 조직 배선 검증).
  2. **security** — provision은 공격면을 넓힌다 (아래). immune 감사가 provision 경계에 필수.

한 줄: **포맷이 지속을 주고, bridge가 provisioning + immune 감사를 더한다.** Skill은 운송,
annex는 화물, bridge는 화물을 운송에 안전하게 싣는 크레인.

## 보안 — provision 경계의 immune 규율

Anthropic Agent Skills 가이드: *"신뢰 출처의 Skill만 설치하라."* 변환기가 낯선 에이전트용
Skill을 emit하고 cargo-bridge가 조직을 provision하면 **공격면이 늘어난다.** 두 랩 실측이
통제의 역할을 갈랐다 (Ludex 정렬 2026-07-05):

- **주 통제 = trusted-SOURCES-only.** 신뢰는 skill 파일이 아니라 **외부 레지스트리**에서 온다.
  frontmatter의 `ludex_source: <creature>`는 provenance *주장*일 뿐 검증된 신뢰가 아니다 —
  **자기선언은 스푸핑 가능**(악성 skill이 `ludex_source: creature:trusted`를 스스로 박으면
  통과). audit는 주장을 레지스트리에 **대조**한다 (organum은 읽기만, 판정 안 함). 레지스트리
  미도착 → **fail-closed** (운영자 `--trust` 명시 신뢰 없으면 거부).
- **보조(심층방어) = 스크립트 스캔.** curl/base64·annex-반출 같은 명백한 exfil 패턴만. `--trust`
  로도 못 뚫는다. **injection(명령 override) 탐지기가 아니다** — 두 랩 실측: content-scan은
  "Ignore all previous instructions…"를 통과시킨다(우리 guard도 동일 확인). 그래서 주 통제가
  content-scan이 아니라 source-trust인 것이다. injection 규칙 클래스는 다음 fixture 라운드
  후보(실측 후 규칙, L1과 같은 규율).
- **organ allowlist (blast-radius)**: 알려진 조직(memory/map/worldmodel)만. 미지 조직 요구 거부.
- **감사 이벤트**: 모든 provision(허용/거부)이 annex의 events.jsonl에 `kind: provision`으로 기록
  (§3.3 열린 kind, 면역 이벤트).

`test_audit_refuses.sh` → ✅ 4/4: 자기선언(--trust 없음) 거부 · 미지 조직 거부 · exfil
스크립트(--trust여도) 거부 · 운영자 신뢰+청정 허용.

## 실행

```bash
# 코어 명령 (졸업본):
organum provision <skill-dir> --into <workdir> [--trust]

# 통합 테스트 (실제 organum provision 구동, shim 자동 배선):
bash experiments/cargo-bridge/test_cross_session.sh   # 지속: 포맷만으로 되나  → ✅
bash experiments/cargo-bridge/test_audit_refuses.sh   # 감사: 경계를 지키나    → ✅ 5/5
```

## 함의 / 다음

- POC가 명제를 검증했다: 표준 Skill 운송 + organum 화물 = 낯선 에이전트에서 stateful Skill이
  실제로 작동. 이식 단위는 규칙이 아니라 **annex(상태) + provision 경계의 검증 초크포인트**다.
- ✅ **졸업 완료**: `organum provision`이 코어 명령으로 승격 (위 배너).
- Ludex 접점 (미결): `organum-source-trust`의 신뢰 출처를 **크리처 레지스트리**로 하는 버전
  고정 계약 (Ray의 mti.card/v0 read-only 연동과 같은 패턴 — 측정된 신뢰). 현재는 `creature:*`
  접두 스텁; 실제 레지스트리 계약은 Ludex 쪽 제공 대기.

## 출처

- [Agent Skills 스펙](https://agentskills.io/specification) — frontmatter 필드(metadata/
  allowed-tools), scripts/references/assets, progressive disclosure
- [Anthropic — Equipping agents with Agent Skills](https://www.anthropic.com/engineering/equipping-agents-for-the-real-world-with-agent-skills) — "trusted sources only", 감사 지침
- [SKILL.md 오픈 표준 개요](https://www.anthropic.com/engineering/equipping-agents-for-the-real-world-with-agent-skills) · [스펙 채택 현황](https://agentskills.io/specification)
