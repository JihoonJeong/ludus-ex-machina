"""P3 파일럿 — stream-json 툴 로그 → over-anchoring proxy 추출 (Cody lane).

추출 계약 (사전등록 §5, 측정은 주입 텍스트가 아니라 실제 툴 행동에서):
- coverage = |정답키 관련-파일 중 Read/Edit/Write 행동을 받은 파일| / |정답키 관련-파일| ∈[0,1]
- redundant_re_read = 같은 run에서 이미 Read한 파일을 재-Read한 횟수 (순수 over-anchoring)
경로는 repo-루트 상대로 정규화해 정답키와 대조. Grep/Bash 접근은 계약상 coverage에 안 셈
(coverage='관련 파일을 실제로 열었나'; grep은 탐색이지 파일 조사 아님) — 파일럿이 이 정의의
과소계수 여부를 드러낸다.
"""

from __future__ import annotations

import json
from pathlib import PurePosixPath

# 파일 접근으로 세는 툴 (file_path 인자를 가짐)
FILE_TOOLS = {"Read", "Edit", "Write", "NotebookEdit"}


def _iter_tool_uses(log_lines):
    """stream-json 라인들 → (tool_name, tool_input) 시퀀스 (순서 보존)."""
    for line in log_lines:
        line = line.strip()
        if not line:
            continue
        try:
            ev = json.loads(line)
        except json.JSONDecodeError:
            continue
        # 완성된 assistant 메시지의 content 블록에서 tool_use 추출
        if ev.get("type") == "assistant":
            content = (ev.get("message") or {}).get("content") or []
            for block in content:
                if isinstance(block, dict) and block.get("type") == "tool_use":
                    yield block.get("name", ""), block.get("input") or {}


def _norm(s: str) -> str:
    """macOS /private 심링크 정규화 — tempfile은 /var, 서브프로세스는 /private/var로 보고한다."""
    return s[len("/private"):] if s.startswith("/private/") else s


def _rel(path: str, repo_root: str) -> str | None:
    """절대/상대 경로를 repo-루트 상대 posix 경로로. repo 밖이면 None."""
    if not path:
        return None
    p = PurePosixPath(_norm(path))
    root = PurePosixPath(_norm(repo_root))
    if p.is_absolute():
        try:
            return str(p.relative_to(root))
        except ValueError:
            return None
    return str(p)  # 이미 상대로 간주


def _norm_pattern(p: str) -> str:
    return " ".join((p or "").split()).lower()


def _abort_subtype(log_lines) -> str:
    """result 이벤트 subtype → 'budget'|'complete'|<raw> (§16b-3 metadata)."""
    sub = None
    for line in log_lines:
        line = line.strip()
        if not line:
            continue
        try:
            e = json.loads(line)
        except json.JSONDecodeError:
            continue
        if e.get("type") == "result":
            sub = e.get("subtype")
    if sub == "success":
        return "complete"
    if sub and "budget" in sub:
        return "budget"
    return sub or "unknown"


def extract(log_lines, answer_key, repo_root: str) -> dict:
    """coverage(secondary, 포화 예상) + effort DV 성분들 (Ray §13 새 primary 재료).

    effort 성분 (map이 노리는 '낭비된 노력'): redundant_re_read + redundant_grep +
    tool_calls_within_budget. 정규화·가중은 2차 파일럿 후 Ray가 잠금.
    """
    answer = {str(PurePosixPath(f)) for f in answer_key}
    read_counts: dict[str, int] = {}
    accessed: set[str] = set()
    seen_greps: set[str] = set()
    redundant_grep = 0
    total_greps = 0
    total_tool_calls = 0

    for name, inp in _iter_tool_uses(log_lines):
        total_tool_calls += 1
        if name in FILE_TOOLS:
            rel = _rel(inp.get("file_path", ""), repo_root)
            if rel is not None:
                accessed.add(rel)
                if name == "Read":
                    read_counts[rel] = read_counts.get(rel, 0) + 1
        elif name == "Grep":
            total_greps += 1
            pat = _norm_pattern(inp.get("pattern", ""))
            if pat and pat in seen_greps:
                redundant_grep += 1  # 이미 검색한 패턴 재검색 = 낭비된 재탐색
            seen_greps.add(pat)

    covered = answer & accessed
    coverage = round(len(covered) / len(answer) if answer else 0.0, 4)
    redundant_read = sum(max(0, c - 1) for c in read_counts.values())
    abort_subtype = _abort_subtype(log_lines)  # §16b-3 metadata

    return {
        # --- effort DV 성분 (primary 재료, §16b-1: within-budget 우측 censored @$1) ---
        "redundant_re_read": redundant_read,
        "redundant_grep": redundant_grep,
        "tool_calls_within_budget": total_tool_calls,  # §16b-1 재라벨 (구 _to_completion), 우측 censored @$1
        # --- coverage (secondary) + censoring metadata (§16b-3) ---
        "coverage": coverage,
        "abort_subtype": abort_subtype,          # budget|complete|<raw>
        "coverage_at_abort": coverage,           # =abort 시점 coverage (1.0 미만 = censored)
        # --- 진단 ---
        "answer_key_size": len(answer),
        "answer_covered": sorted(covered),
        "answer_missed": sorted(answer - accessed),
        "distinct_files_read": len(read_counts),
        "total_reads": sum(read_counts.values()),
        "total_greps": total_greps,
    }


def extract_file(log_path: str, answer_key, repo_root: str) -> dict:
    with open(log_path, encoding="utf-8") as f:
        return extract(f.readlines(), answer_key, repo_root)
