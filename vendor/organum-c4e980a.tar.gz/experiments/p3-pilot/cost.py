"""청크 비용 리포트 — stream-json 로그의 total_cost_usd 집계 (over-anchoring 성분과 별개).

total_cost_usd는 **메터링 등가 가격**이다 (Max/구독 사용자엔 실 청구 0 — spike-recheck §1).
청크당 쿼타 감을 잡는 용도. 사용: python3 cost.py <logdir>
"""

from __future__ import annotations

import glob
import json
import os
import sys


def run_costs(logdir: str) -> list[dict]:
    out = []
    for path in sorted(glob.glob(os.path.join(logdir, "*.jsonl"))):
        name = os.path.basename(path)[:-6]  # {task}__{arm}
        cost = None
        subtype = None
        for line in open(path, encoding="utf-8"):
            line = line.strip()
            if not line:
                continue
            try:
                e = json.loads(line)
            except json.JSONDecodeError:
                continue
            if e.get("type") == "result":
                cost = e.get("total_cost_usd")
                subtype = e.get("subtype")
        out.append({"run": name, "cost_usd": cost, "subtype": subtype})
    return out


def report(logdir: str) -> str:
    runs = run_costs(logdir)
    costs = [r["cost_usd"] for r in runs if isinstance(r["cost_usd"], (int, float))]
    total = sum(costs)
    lines = [f"청크 비용 리포트 ({logdir}):"]
    for r in runs:
        c = f"${r['cost_usd']:.4f}" if isinstance(r["cost_usd"], (int, float)) else "?(no result)"
        lines.append(f"  {r['run']:24} {c:>12}  {r.get('subtype') or ''}")
    n = len(costs)
    lines.append(f"— {n} run · 합계 ${total:.4f} · 평균 ${total / n:.4f}/run" if n else "— run 없음")
    lines.append("  (메터링 등가; 구독 사용자 실청구 $0. rate-limit 쿼타 소모는 run 수 기준.)")
    return "\n".join(lines)


if __name__ == "__main__":
    print(report(sys.argv[1]))
