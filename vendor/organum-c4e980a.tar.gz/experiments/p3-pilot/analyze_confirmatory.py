"""P3 confirmatory analysis — FROZEN pre-reg (docs/p3-prereg-draft.md §16/§16b, Ray).

PRIMARY = B - A on effort_composite = z(redundant_re_read) + z(tool_calls_within_budget),
grep dropped (degenerate: all 0). PAIRED/BLOCKED by task: exact sign-flip permutation
(2^12 = 4096) + bootstrap CI (resample task-pairs) + LOO. Single contrast -> no Holm.
Estimation-only: C-A, C-B (H2 form>content), coverage (secondary). Boundary subgroup:
the 4 cells, B-A stratified (n=3/cell, non-confirmatory). DV right-censored @ $1
(within-budget, §16b); familiar (click) cell heavily censored -> effort is a lower bound.
Reads results_confirmatory.jsonl. Pure stdlib, deterministic.
"""
import json
from itertools import product
from pathlib import Path

DATA = Path(__file__).resolve().parent / "results_confirmatory.jsonl"
rows = [json.loads(l) for l in open(DATA, encoding="utf-8")]
mean = lambda xs: sum(xs) / len(xs)
def sd(xs):
    m = mean(xs); return (sum((x - m) ** 2 for x in xs) / (len(xs) - 1)) ** 0.5

RR = [r["redundant_re_read"] for r in rows]
TC = [r["tool_calls_within_budget"] for r in rows]
sd_rr, sd_tc = sd(RR), sd(TC)
mu_rr, mu_tc = mean(RR), mean(TC)
assert all(r["redundant_grep"] == 0 for r in rows), "grep not degenerate!"
print(f"pooled SD: re_read={sd_rr:.3f} tool_calls={sd_tc:.3f}  (grep dropped: all 0)")

def composite(r):
    return (r["redundant_re_read"] - mu_rr) / sd_rr + (r["tool_calls_within_budget"] - mu_tc) / sd_tc

by_task = {}
for r in rows:
    by_task.setdefault(r["task"], {})[r["arm"]] = r
tasks = sorted(by_task)
assert all(set(by_task[t]) == {"A", "B", "C"} for t in tasks), "unbalanced pairing"
print(f"tasks: {len(tasks)} (each with A/B/C)\n")

def paired_diffs(hi, lo, val):
    return [val(by_task[t][hi]) - val(by_task[t][lo]) for t in tasks]

def exact_sign_perm(diffs):
    n = len(diffs); obs = mean(diffs); hits = 0
    for signs in product((1, -1), repeat=n):
        if abs(mean([s * d for s, d in zip(signs, diffs)])) >= abs(obs) - 1e-12:
            hits += 1
    return obs, hits / (2 ** n)

def boot_ci(diffs, n_boot=10000, seed=20260710):
    n = len(diffs); s = seed; out = []
    for _ in range(n_boot):
        samp = []
        for _ in range(n):
            s = (1103515245 * s + 12345) & 0x7FFFFFFF
            samp.append(diffs[s % n])
        out.append(mean(samp))
    out.sort()
    return out[int(0.025 * n_boot)], out[int(0.975 * n_boot) - 1]

def loo(diffs):
    ds = [mean(diffs[:i] + diffs[i+1:]) for i in range(len(diffs))]
    return min(ds), max(ds)

def report(label, hi, lo, val):
    d = paired_diffs(hi, lo, val)
    obs, p = exact_sign_perm(d); lo_ci, hi_ci = boot_ci(d); l_lo, l_hi = loo(d)
    dz = obs / sd(d) if sd(d) > 0 else 0.0
    print(f"{label}: mean_diff={obs:+.3f}  exact-p={p:.4f}  dz={dz:+.3f}  "
          f"boot95CI=[{lo_ci:+.3f},{hi_ci:+.3f}]  LOO[{l_lo:+.3f},{l_hi:+.3f}]")

print("=== PRIMARY confirmatory: B - A on effort_composite (paired, exact sign-perm) ===")
report("  composite B-A", "B", "A", composite)
print("\n=== component decomposition (paired B-A) ===")
report("  re_read   B-A", "B", "A", lambda r: r["redundant_re_read"])
report("  tools     B-A", "B", "A", lambda r: r["tool_calls_within_budget"])
print("\n=== estimation-only (paired) ===")
report("  composite C-A (H2)", "C", "A", composite)
report("  composite C-B (H2)", "C", "B", composite)
report("  coverage  B-A     ", "B", "A", lambda r: r["coverage"])
print("\n=== boundary subgroup: composite B-A by cell (non-confirmatory, n=3/cell) ===")
cells = {}
for t in tasks:
    c = by_task[t]["A"]["cell"]; cells.setdefault((c["familiarity"], c["bound"]), []).append(t)
for (fam, bnd), ts in sorted(cells.items()):
    diffs = [composite(by_task[t]["B"]) - composite(by_task[t]["A"]) for t in ts]
    rr = [by_task[t]["B"]["redundant_re_read"] - by_task[t]["A"]["redundant_re_read"] for t in ts]
    cens = sum(1 for t in ts for a in "AB" if by_task[t][a]["coverage"] < 1.0)
    print(f"  {fam:10} x {bnd:7} (n={len(ts)}): composite B-A={mean(diffs):+.3f}  "
          f"re_read B-A={mean(rr):+.2f}  censored={cens}/{2*len(ts)}")
print("\n=== censoring (within-budget DV; familiar = lower bound) ===")
for fam in ("unfamiliar", "familiar"):
    sub = [r for r in rows if r["cell"]["familiarity"] == fam]
    print(f"  {fam:10}: {sum(1 for r in sub if r['coverage']<1.0)}/{len(sub)} censored")
print(f"  TOTAL: {sum(1 for r in rows if r['coverage']<1.0)}/{len(rows)} censored")
