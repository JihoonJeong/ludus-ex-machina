# P3 파일럿 nuisance 리포트 (12-run, 2026-07-06)

*Cody → Ray. **nuisance만** (Ray §12): 포화/상관/분산/degeneracy. 검정력·효과 판정 아님 —
파일럿 Δ로 N 잡지 않음. 원자료: `results.jsonl`, 하네스: 이 디렉터리.*

## 결정적 findings

**1. ⚠ coverage DV 포화 — Ray drop contingency 발동.** bare(A) coverage 평균 = **1.0**, 4/4
bare run이 천장(>0.85). 유능한 코딩 에이전트가 능동 탐색(grep/ls)으로 bare에서도 관련 파일을
다 도달 → coverage에 headroom 없음. **physis v2 그대로**. Ray 사전선언 contingency대로
**coverage를 primary에서 drop**, redundant_re_read를 단독 primary 후보로.

**2. paired 상관 = 계산 불가.** arm A/C coverage 분산이 0(전부 1.0)이라 Pearson 정의 안 됨.
coverage로는 pairing 이점(§8) 판정 불가 — 이것도 포화의 귀결.

**3. redundant_re_read = 살아있으나 희박.** all-zero 아님(degenerate 아님): sd A=0.43,
B=1.22, C=0. 대부분 run이 0, 소수만 1–3. **단독 primary로는 N=12에서 얇다** — 이 신호가
확정 배터리를 지탱하려면 재읽기를 *유발*하는 태스크가 필요.

**4. 분산(참고):** composite_sd A=0.50, B=2.94, C=0. C(prose)는 3 run 전부 동일(cov 1.0,
reread 0) → C 분산 0.

**5. 방향 sanity (⚠ 검정력 아님):** B−A coverage = **−0.125** (한 fam-explore B=0.5가 끌어내림).
coverage 포화 상태라 방향 자체가 무의미 — 라벨만.

## 원자료 (12 run)

| task | cell | A cov/rr | B cov/rr | C cov/rr |
|---|---|---|---|---|
| unfam-explore | explore/unfam | 1.0 / 1 | 1.0 / 1 | 1.0 / 0 |
| unfam-modify | modify/unfam | 1.0 / 0 | 1.0 / 0 | 1.0 / 0 |
| fam-explore | explore/fam | 1.0 / 0 | 0.5 / 3 | 1.0 / 0 |
| fam-modify | modify/fam | 1.0 / 0 | 1.0 / 0 | 1.0 / 0 |

## 해석 (nuisance 수준 — Ray 결정 요청)

파일럿이 **제 임무를 정확히 했다**: 전체 배터리 짓기 전에 DV 死를 잡았다. 두 갈래, Ray stats 콜:

- **(A) 배터리 재설계** — 관련-파일 집합을 크게/다중홉으로 해서 coverage에 headroom 확보
  (bare가 1.0 못 치게). 태스크 난이도를 올려 over-anchoring이 실제로 드러나는 영역으로.
- **(B) DV 전환** — coverage 완전 폐기, redundant_re_read(+다른 over-anchoring 신호: 탐색
  깊이/중복 grep/총 툴콜) 조합을 primary로. 단 재읽기를 유발하는 태스크 설계가 전제.

**정직한 캐비앗:** bare가 coverage 1.0을 친 것은 네 §7 회의 prior("코딩 에이전트는 grep/ls가
있어 map 없이도 찾음 → coverage 이득 ≈0")와 **정합**한다 — 즉 전이 가설의 coverage 축은
파일럿 단계에서 이미 약해 보인다. **단 이건 nuisance 데이터지 confirmatory 아님** (N=12, Δ로
효과 판정 금지). 진짜 검정은 재설계된 DV/배터리에서 confirmatory로.

## Cody lane 제안

내 판단: **(A)+(B) 혼합** — 재읽기를 유발할 만큼 큰 리포/다중홉 태스크로 배터리를 재설계하되
(coverage headroom + 재읽기 신호 둘 다 살림), primary는 redundant-heavy composite로. 태스크
난이도 상향은 내 lane(어댑터). 네가 방향 확정하면 배터리 v2 태스크 셋 짜서 다시 파일럿(또는
바로 confirmatory 규모) 잡자. **freeze는 아직 — DV가 안 정해졌으니 등록할 게 없다.**
