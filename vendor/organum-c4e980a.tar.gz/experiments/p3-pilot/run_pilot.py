"""P3 파일럿 러너 — 4 태스크 × 3 arm = 12 신선 위임 세션 (Cody lane). 실행은 --go 필요.

각 run: 리포 **사본**(immune 1-5: 실험은 사본에서)에서 신선 claude -p 세션을 조건별 주입으로
돌리고, stream-json 툴 로그 → extract.py로 proxy 추출. 조건은 태스크-블록 내 인터리브(§2-3),
seed 고정(Ray seed 규율).

arm 주입 (§3):
  A 대조    : 태스크만
  B map     : 태스크 + organum [Map] 블록 (사본에 organum init 후 organum context의 [Map])
  C prose   : 태스크 + 같은 파일 목록의 산문 요약 (frontier 없음)

⚠ 실제 실행은 12개 멀티턴 코딩-에이전트 세션 = 실 쿼타. 빌드·검증 후 승인 시에만 --go.
파일럿 데이터는 disclosed, confirmatory 분석에 재사용 안 함 (Ray §12).
"""

from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

import extract

HERE = Path(__file__).parent
ARMS = ("A", "B", "C")
# 인터리브 순서 (seed 고정 — 재현 가능; 실제 배치는 Ray와 seed 확정)
INTERLEAVE_SEED = 20260706


def load_tasks(path=None):
    f = Path(path) if path else (HERE / "tasks.jsonl")
    tasks = [json.loads(l) for l in f.read_text().splitlines() if l.strip()]
    pending = [t["id"] for t in tasks if not t.get("answer_key")]
    if pending:
        raise SystemExit(
            f"pilot: 정답키 미동결 태스크 {pending} — 셋업 단계(공개 리포 선정+정답키 동결) 먼저.")
    return tasks


def _prep_repo_copy(repo_path: Path, workroot: Path) -> Path:
    """리포를 사본으로 (실험은 라이브 상태 오염 금지, 1-5). .git/.organum 제외."""
    dst = workroot / repo_path.name
    shutil.copytree(
        repo_path, dst,
        ignore=shutil.ignore_patterns(".git", ".organum", "__pycache__", "*.egg-info", ".venv"),
    )
    subprocess.run(["git", "init", "-q"], cwd=dst, check=True)
    subprocess.run(["git", "add", "-A"], cwd=dst, capture_output=True)
    return dst


def _map_block(repo_copy: Path) -> str:
    """B arm 주입 = organum context의 [Map] 블록 (도구가 실제 내보내는 것)."""
    env = {"PYTHONPATH": str(Path(__file__).parents[2] / "src")}
    import os
    e = {**os.environ, **env}
    subprocess.run(["python3", "-m", "organum", "init", "--agent", "pilot"],
                   cwd=repo_copy, env=e, capture_output=True)
    out = subprocess.run(["python3", "-m", "organum", "context"],
                         cwd=repo_copy, env=e, capture_output=True, text=True)
    block = "\n".join(l for l in out.stdout.splitlines() if l.startswith("[Map]") or l.strip())
    shutil.rmtree(repo_copy / ".organum", ignore_errors=True)  # 주입만 쓰고 annex 제거(A/C와 공정)
    return out.stdout


def _prose_block(repo_copy: Path) -> str:
    """C arm 주입 = 같은 파일 목록의 산문 요약 (form 없음 — form>content 대조)."""
    files = subprocess.run(["git", "ls-files"], cwd=repo_copy, capture_output=True, text=True).stdout.split()
    return "이 저장소에는 다음 파일들이 있습니다: " + ", ".join(files) + ". 필요한 것을 찾아 작업하세요."


def build_prompt(task: dict, arm: str, repo_copy: Path) -> str:
    base = task["prompt"]
    if arm == "A":
        return base
    if arm == "B":
        return f"{_map_block(repo_copy)}\n\n---\n{base}"
    if arm == "C":
        return f"{_prose_block(repo_copy)}\n\n---\n{base}"
    raise ValueError(arm)


def run_one(task: dict, arm: str, workroot: Path, budget: float, logdir: Path) -> dict:
    rundir = workroot / f"{task['id']}__{arm}"  # run별 격리 (같은 리포 반복 복사 충돌 방지)
    rundir.mkdir(parents=True, exist_ok=True)
    repo_copy = _prep_repo_copy(Path(task["repo_path"]), rundir)
    prompt = build_prompt(task, arm, repo_copy)
    log_path = logdir / f"{task['id']}__{arm}.jsonl"
    cmd = [
        "claude", "-p", "--output-format", "stream-json", "--include-partial-messages", "--verbose",
        "--no-session-persistence", "--max-budget-usd", f"{budget:g}",
        "--permission-mode", "acceptEdits",
        "--allowed-tools", "Read Grep Glob Edit Write Bash",
        "--add-dir", str(repo_copy),
    ]
    proc = subprocess.run(cmd, input=prompt.encode(), cwd=repo_copy, capture_output=True)
    log_path.write_bytes(proc.stdout)
    proxies = extract.extract(proc.stdout.decode("utf-8", "replace").splitlines(),
                              task["answer_key"], str(repo_copy))
    return {"task": task["id"], "arm": arm, "cell": task["cell"], **proxies}


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--go", action="store_true", help="실제 실행 (실 쿼타 — 12 멀티턴 세션)")
    ap.add_argument("--budget", type=float, default=1.0, help="run당 예산 캡 (콜드캐시)")
    ap.add_argument("--tasks", default=None, help="태스크 파일 (기본 tasks.jsonl; v2는 tasks_v2.jsonl)")
    ap.add_argument("--out", default=str(HERE / "results.jsonl"))
    ap.add_argument("--max-tasks", type=int, default=None,
                    help="이번 실행에서 돌릴 **완결 태스크** 수 (쿼타 청크). 한 태스크의 3 arm은 "
                         "항상 같은 청크 = 시간근접(§2-3 paired 보존). 반복 호출로 이어감")
    args = ap.parse_args(argv)

    tasks = load_tasks(args.tasks)
    out_path = Path(args.out)

    # 완료된 (task,arm) — out 있으면 항상 로드 (청크/resume 안전). 자동 append·skip.
    done: set[tuple[str, str]] = set()
    if out_path.is_file():
        for line in out_path.read_text().splitlines():
            if line.strip():
                r = json.loads(line)
                done.add((r["task"], r["arm"]))

    # 청크 = **완결 안 된 태스크 단위** (arm 쪼갬 금지 → 한 태스크 A/B/C 시간근접, paired 보존)
    def pending_arms(t):
        return [a for a in ARMS if (t["id"], a) not in done]
    incomplete = [t for t in tasks if pending_arms(t)]
    chunk_tasks = incomplete[: args.max_tasks] if args.max_tasks is not None else incomplete
    plan = [(t, a) for t in chunk_tasks for a in pending_arms(t)]
    # 청크 *내부* 인터리브 (조건 배칭 방지) — seed 고정
    import random
    random.Random(INTERLEAVE_SEED).shuffle(plan)

    total = len(tasks) * len(ARMS)
    if not args.go:
        print(f"[dry-run] 이번 청크 {len(plan)} run ({len(chunk_tasks)} 태스크) · "
              f"누적 완료 {len(done)}/{total} · 청크 후 남는 태스크 {len(incomplete) - len(chunk_tasks)}")
        print(f"  예상 쿼타(이 청크): {len(plan)} 멀티턴 세션 (run당 캡 ${args.budget:g}).")
        for t, arm in plan:
            print(f"    {t['id']:20} arm {arm}  cell={t['cell']}")
        return 0

    logdir = Path(tempfile.mkdtemp(prefix="p3pilot-logs-"))
    with tempfile.TemporaryDirectory() as work, \
            out_path.open("a" if out_path.is_file() else "w", encoding="utf-8") as out:
        for i, (t, arm) in enumerate(plan, 1):
            print(f"[{i}/{len(plan)}] {t['id']} arm {arm} …", file=sys.stderr)
            r = run_one(t, arm, Path(work), args.budget, logdir)
            out.write(json.dumps(r, ensure_ascii=False) + "\n")
            out.flush()  # run 단위 내구성 — 중단돼도 완료분은 파일에
    remaining = len(incomplete) - len(chunk_tasks)
    print(f"청크 완료: 이번 {len(plan)} run · 누적 {len(done) + len(plan)}/{total} · "
          f"남은 태스크 {remaining}{' → 전부 완료!' if remaining == 0 else f' (이어서: --max-tasks N 반복)'}")
    print(f"  results → {args.out} (logs: {logdir})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
