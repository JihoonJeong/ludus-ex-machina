# P3 confirmatory 수집 완료 — descriptive 요약 (36/36, 2026-07-10)

*Cody → Ray. **descriptive/서술만** — 확정 판정은 Ray 레인(paired/blocked permutation, frozen
composite). 방향 sanity를 검정력으로 읽지 않는다(§12/§16 라벨). raw: `results_confirmatory.jsonl`.
사전등록 FROZEN §16/§16b, 배터리 anti-fishing pre-commit §15.*

## 수집 조건
- 36 run (12 태스크 × 3 arm), 4청크(9+9+9+9), task-block 단위 청크(각 태스크 A/B/C 시간근접, §2-3).
- **전 run budget-abort @$1** → DV = within-$1 over-anchoring, 우측 censored (§16b-1/-2).
- 비용 ≈ $38 메터링 (구독 실청구 $0). abort_subtype/coverage_at_abort 로깅됨(§16b-3).

## 셀별 집계 (2×2, arm A=bare / B=map)

| 셀 | A re-read | B re-read | A tools | B tools | censored (cov<1) |
|---|---|---|---|---|---|
| 비친숙×explore (organum, **primary**) | 0.00 | 0.00 | 10.7 | 9.0 | **1/9** |
| 비친숙×modify (organum) | 0.00 | 0.33 | 14.3 | 14.3 | 0/9 |
| 친숙×explore (click) | 3.00 | 3.00 | 13.3 | 12.7 | 7/9 |
| 친숙×modify (click) | 1.33 | 1.00 | 10.7 | 11.0 | 9/9 |

방향 sanity (⚠ 검정력 아님) B−A: **re-read +0.00**, tools −0.50 (n=12 task). 전체 censored **17/36**.

## 서술 관찰 (Ray 확정 전)

1. **re-read에서 B≈A 전 셀 일관.** map(B)이 bare(A) 대비 재읽기를 어느 셀에서도 안 줄인다.
   전체 B−A re-read = +0.00. §14-3 환경-의존 null 방향 그대로 (파일럿 1·2와 정합).
2. **over-anchoring 자체의 환경 대비**: 비친숙(organum) re-read ≈ 0 (에이전트가 map 없이 잘
   찾음), 친숙(click)엔 re-read 존재(explore 3.0). **그런데 있는 곳에서도 map이 안 줄임** —
   "없어서 무의미"가 아니라 "있어도 못 고침"이라는 더 강한 null 방향.
3. **⚠ censoring 비대칭 (Ray 하한 해석에 중요)**: 비친숙 셀 **1/18** censored(거의 완결 →
   primary null 깨끗, §16b validity 로직), 친숙(click) **16/18** censored(태스크가 어려워
   $1 내 탐색 미완결 → **친숙 셀 effort는 하한**). 친숙 셀을 "완결 effort"로 읽으면 안 됨.
4. primary 셀(비친숙×explore)에서 tools B−A = −1.7 (A 10.7 → B 9.0)이나 re-read 0=0 — 방향
   sanity, Ray 정량.

## Ray 레인
frozen composite = z(redundant_re_read) + z(tool_calls_within_budget) (grep drop) → B−A
paired/blocked permutation 10k + exact + bootstrap CI + LOO. estimation-only: C−A/C−B(H2),
coverage(secondary), 성분별 raw. 경계 subgroup(4셀) 사전지정 층화. honest-null §14-3/§16b:
B−A≈0 = "within-$1 over-anchoring 대폭 감소 없음"(commit-bound/능동탐색 task-class 조건부, 친숙
셀은 censored 하한).

## Ray VERDICT (2026-07-10, 사전등록 §16/§16b 확정)

*paired/blocked exact sign-flip permutation (2^12=4096) on the frozen composite. 재현: `analyze_confirmatory.py`.*

**PRIMARY (확정): B − A on effort_composite = −0.159, exact-p = .53, dz = −0.22, boot95CI [−0.38,+0.06] → NULL.**
- 핵심 성분 **`redundant_re_read` B−A = 정확히 0.000 (exact-p=1.0)** — map이 순수 over-anchoring 신호를
  **한 톨도** 안 줄임. `tools_within_budget` B−A = −0.50 (exact-p=.29)뿐.
- N=12는 d≥0.80 검정력; 관측 dz=−0.22 (small) → 등록된 **honest-null**(§16-3): "큰 within-$1
  over-anchoring 감소 없음."

**등록 해석 (§14-3):** organum의 map은 능동-탐색 코딩 태스크에서 코딩 에이전트 over-anchoring을
크게 줄이지 않는다 — over-anchoring은 tier-universal이 아니라 **환경-의존.** 더 강한 형태: over-anchoring이
*존재하는* 친숙(click) 셀에서도 (re-read~3) map의 re_read B−A≈0 → "없어서 무의미"가 아니라 **"있어도 못 고침".**

**declared prior 정직 채점:** Ray §7 회의 prior — 방향(null) 적중, 단 "proxy에선 moderate 감소" 예측은
miss (re_read=0, 감소 자체가 없음 — null이 내 회의보다 강함). Cody §6 낙관 prior — miss (더 멀리). 두
등록 prior 다 성능↓ 쪽으로 빗나감 = 등록의 값.

**H2 form>content (estimation-only) = 역전.** C(prose)가 최저 effort: C−A = −0.84 (exact-p=.028),
C−B = −0.68 (.12). effort 순서 **prose < map ≈ bare.** MUD의 form>content(p=.79 null)가 코딩엔 **전이 안 됨** —
오히려 content(prose) 근소 우위 (아래 censoring 캐비앗 하 estimation).

**캐비앗(정직):** within-$1 우측-censored DV. 비친숙(primary) **1/18 censored → primary null 깨끗**(§16b
validity 성립). 친숙(click) **16/18 censored → 친숙 셀 effort는 하한**(태스크가 $1 내 미완결). n=12
paired(d≥0.80 검정력). task-class 조건부: commit-bound/능동탐색; cross-episode transfer(표상-병목) 미검증.

**공개 문서 정직 인용 문구:** *"organum's injected [Map] does not reduce coding-agent over-anchoring in
active-search coding tasks (B−A effort-composite null, exact-p=.53; redundant re-reads B−A=0.00). Over-anchoring
is environment-dependent, not tier-universal — the map's antidote is domain-specific to active-search-absent
agents (the MUD result was an artifact of that setting). A registered null (§14-3), not a tuning failure.
form>content does not transfer here (prose marginally lower effort, estimation-only)."*
