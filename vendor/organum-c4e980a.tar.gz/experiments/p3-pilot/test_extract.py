"""추출기 테스트 — 합성 stream-json 로그 (쿼타 0, 결정적). 추출 논리만 검증."""

import json
import unittest

import extract


def _log(*tool_uses):
    """tool_uses = [(name, {input}), ...] → assistant 이벤트 stream-json 라인들."""
    lines = [json.dumps({"type": "system", "subtype": "init"})]
    for name, inp in tool_uses:
        lines.append(json.dumps({
            "type": "assistant",
            "message": {"content": [{"type": "tool_use", "name": name, "input": inp}]},
        }))
    lines.append(json.dumps({"type": "result", "subtype": "success"}))
    return lines


ROOT = "/repo"
KEY = ["src/guard.py", "src/guard_rules.json"]


class TestExtract(unittest.TestCase):
    def test_full_coverage_no_redundancy(self):
        log = _log(
            ("Read", {"file_path": "/repo/src/guard.py"}),
            ("Read", {"file_path": "/repo/src/guard_rules.json"}),
        )
        r = extract.extract(log, KEY, ROOT)
        self.assertEqual(r["coverage"], 1.0)
        self.assertEqual(r["redundant_re_read"], 0)

    def test_partial_coverage(self):
        log = _log(("Read", {"file_path": "/repo/src/guard.py"}))
        r = extract.extract(log, KEY, ROOT)
        self.assertEqual(r["coverage"], 0.5)
        self.assertEqual(r["answer_missed"], ["src/guard_rules.json"])

    def test_redundant_reread_counted(self):
        log = _log(
            ("Read", {"file_path": "/repo/src/guard.py"}),
            ("Grep", {"pattern": "x"}),
            ("Read", {"file_path": "/repo/src/guard.py"}),   # 재읽기 1
            ("Read", {"file_path": "/repo/src/guard.py"}),   # 재읽기 2
        )
        r = extract.extract(log, KEY, ROOT)
        self.assertEqual(r["redundant_re_read"], 2)  # 3회 Read = 재읽기 2
        self.assertEqual(r["coverage"], 0.5)

    def test_edit_counts_as_coverage_not_reread(self):
        log = _log(
            ("Edit", {"file_path": "/repo/src/guard.py"}),
            ("Write", {"file_path": "/repo/src/guard_rules.json"}),
        )
        r = extract.extract(log, KEY, ROOT)
        self.assertEqual(r["coverage"], 1.0)       # Edit/Write도 접근으로 카운트
        self.assertEqual(r["redundant_re_read"], 0)  # 재읽기는 Read만

    def test_relative_paths_and_out_of_repo_ignored(self):
        log = _log(
            ("Read", {"file_path": "src/guard.py"}),           # 이미 상대
            ("Read", {"file_path": "/etc/passwd"}),            # repo 밖 → 무시
            ("Read", {"file_path": "/repo/src/guard_rules.json"}),
        )
        r = extract.extract(log, KEY, ROOT)
        self.assertEqual(r["coverage"], 1.0)

    def test_grep_bash_not_counted_as_coverage(self):
        # 계약: coverage='파일을 실제로 열었나'. grep/bash는 안 셈 (파일럿이 과소계수 여부 드러냄)
        log = _log(
            ("Grep", {"pattern": "guard", "path": "/repo/src"}),
            ("Bash", {"command": "cat /repo/src/guard.py"}),
        )
        r = extract.extract(log, KEY, ROOT)
        self.assertEqual(r["coverage"], 0.0)


class TestEffortSignals(unittest.TestCase):
    def test_redundant_grep_counted(self):
        log = _log(
            ("Grep", {"pattern": "streak"}),
            ("Grep", {"pattern": "STREAK"}),      # 같은 패턴 재검색(대소문자/공백 정규화) → redundant
            ("Grep", {"pattern": "other"}),
        )
        r = extract.extract(log, KEY, ROOT)
        self.assertEqual(r["redundant_grep"], 1)
        self.assertEqual(r["total_greps"], 3)

    def test_tool_calls_within_budget(self):
        log = _log(
            ("Read", {"file_path": "/repo/src/guard.py"}),
            ("Grep", {"pattern": "x"}),
            ("Edit", {"file_path": "/repo/src/guard.py"}),
            ("Bash", {"command": "pytest"}),
        )
        r = extract.extract(log, KEY, ROOT)
        self.assertEqual(r["tool_calls_within_budget"], 4)


if __name__ == "__main__":
    unittest.main()
