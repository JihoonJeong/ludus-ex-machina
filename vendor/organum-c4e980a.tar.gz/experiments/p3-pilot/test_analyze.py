"""분석기 테스트 — 합성 proxy 데이터 (쿼타 0). nuisance 리포트 논리 검증."""

import unittest

import analyze_pilot as ap


def _runs(spec):
    """spec = {task: {arm: (coverage, redundant)}} → runs 리스트."""
    return [
        {"task": t, "arm": a, "coverage": c, "redundant_re_read": r}
        for t, arms in spec.items() for a, (c, r) in arms.items()
    ]


class TestAnalyze(unittest.TestCase):
    def test_healthy_composite_and_positive_pairing(self):
        # A는 낮은 coverage·높은 재읽기, B 높은 coverage·낮은 재읽기 (개입 방향) + task 난이도 공유
        spec = {
            "t1": {"A": (0.4, 3), "B": (0.7, 1), "C": (0.5, 2)},
            "t2": {"A": (0.5, 2), "B": (0.8, 0), "C": (0.6, 1)},
            "t3": {"A": (0.3, 4), "B": (0.6, 2), "C": (0.4, 3)},
            "t4": {"A": (0.6, 1), "B": (0.9, 0), "C": (0.7, 1)},
        }
        rep = ap.analyze(_runs(spec))
        self.assertFalse(rep["degeneracy"]["coverage_saturated_bare"])
        self.assertFalse(rep["degeneracy"]["redundant_all_zero"])
        self.assertTrue(rep["degeneracy"]["coverage_z_ok"])
        # A/B coverage가 task 가로질러 양의 상관 (난이도 공유) → pairing 이점
        self.assertGreater(rep["paired_correlation"]["pearson_A_B_coverage"], 0)
        self.assertGreater(rep["direction_sanity_NOT_power"]["mean_B_minus_A_coverage"], 0)

    def test_coverage_saturation_flagged(self):
        # 유능 에이전트가 bare로도 관련 파일 다 커버 → coverage 천장 (Ray v2 위험)
        spec = {
            f"t{i}": {"A": (1.0, 0), "B": (1.0, 0), "C": (1.0, 0)} for i in range(1, 5)
        }
        rep = ap.analyze(_runs(spec))
        self.assertTrue(rep["degeneracy"]["coverage_saturated_bare"])
        self.assertIn("포화", rep["degeneracy"]["note"])

    def test_redundant_degenerate_flagged(self):
        # 재읽기가 항상 0 → 성분 degenerate → coverage 단독 primary contingency
        spec = {
            "t1": {"A": (0.4, 0), "B": (0.7, 0), "C": (0.5, 0)},
            "t2": {"A": (0.5, 0), "B": (0.8, 0), "C": (0.6, 0)},
            "t3": {"A": (0.3, 0), "B": (0.6, 0), "C": (0.4, 0)},
            "t4": {"A": (0.6, 0), "B": (0.9, 0), "C": (0.7, 0)},
        }
        rep = ap.analyze(_runs(spec))
        self.assertTrue(rep["degeneracy"]["redundant_all_zero"])
        self.assertFalse(rep["degeneracy"]["redundant_z_ok"])
        self.assertIn("redundant drop", rep["degeneracy"]["note"])


if __name__ == "__main__":
    unittest.main()
