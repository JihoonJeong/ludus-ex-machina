"""P3 파일럿 nuisance 분석 — Ray가 요구한 3종 + composite degeneracy (Cody lane).

⚠ 파일럿 Δ로 검정력을 잡지 않는다 (Ray §12: physis 낙관 함정). 이 리포트는 **nuisance만**:
  (i) 포화 체크 — bare(A) coverage가 1(>0.85)에 몰리나? (DV가 죽나)
  (ii) paired 상관 — 조건 간 task-block 상관 (pairing이 실제 검정력을 주나)
  (iii) composite 분산 — N 계산 분모
  + composite 성분 degeneracy (re-read 항상 0 / coverage 포화) → Ray의 drop contingency 트리거.
방향 sanity로 B−A Δ도 보고하되 "검정력 근거 아님" 라벨.

주 DV composite (Ray §12 잠금): z(coverage) − z(redundant_re_read), 등가중, arm-across pooled SD.
"""

from __future__ import annotations

import json
import statistics as stats
from collections import defaultdict

SATURATION_THRESHOLD = 0.85  # Ray §12: coverage 포화 판정


def _z(values):
    """arm-across pooled 표준화. sd=0이면 None(degenerate)."""
    if len(values) < 2:
        return None, "n<2"
    sd = stats.pstdev(values)
    if sd == 0:
        return None, "sd=0 (degenerate)"
    mean = stats.mean(values)
    return [(v - mean) / sd for v in values], None


def analyze(runs: list[dict]) -> dict:
    """runs: [{task, arm, coverage, redundant_re_read}, ...] (4 task × 3 arm = 12)."""
    cov = [r["coverage"] for r in runs]
    rr = [r["redundant_re_read"] for r in runs]

    # composite 성분 degeneracy (Ray drop contingency)
    z_cov, cov_deg = _z(cov)
    z_rr, rr_deg = _z(rr)
    bare = [r["coverage"] for r in runs if r["arm"] == "A"]
    cov_saturated = bool(bare) and stats.mean(bare) > SATURATION_THRESHOLD
    rr_all_zero = all(v == 0 for v in rr)

    degeneracy = {
        "coverage_saturated_bare": cov_saturated,
        "coverage_bare_mean": round(stats.mean(bare), 4) if bare else None,
        "redundant_all_zero": rr_all_zero,
        "coverage_z_ok": z_cov is not None,
        "redundant_z_ok": z_rr is not None,
        "note": _degeneracy_note(cov_saturated, rr_all_zero, cov_deg, rr_deg),
    }

    # composite (성분 살아있으면)
    composite_by_run = None
    if z_cov is not None and z_rr is not None:
        composite_by_run = [zc - zr for zc, zr in zip(z_cov, z_rr)]

    # (i) 포화 분포
    saturation = {
        "bare_coverage_values": sorted(bare),
        "n_bare_at_ceiling(>0.85)": sum(1 for v in bare if v > SATURATION_THRESHOLD),
    }

    # (ii) paired 상관 — task-block 내 조건 상관 (arm 간, task 가로질러)
    by_task = defaultdict(dict)
    for r in runs:
        by_task[r["task"]][r["arm"]] = r
    paired_corr = _condition_correlation(by_task, composite_by_run, runs)

    # (iii) 분산 — arm별 composite/성분의 within-arm 분산
    variance = _within_arm_variance(runs, composite_by_run)

    # 방향 sanity (검정력 근거 아님)
    direction = _direction_sanity(by_task)

    return {
        "n_runs": len(runs),
        "degeneracy": degeneracy,
        "saturation": saturation,
        "paired_correlation": paired_corr,
        "variance": variance,
        "direction_sanity_NOT_power": direction,
    }


def _degeneracy_note(cov_sat, rr_zero, cov_deg, rr_deg):
    if cov_sat:
        return "⚠ coverage 포화(bare>0.85) — Ray contingency: coverage drop, redundant 단독 primary 검토"
    if rr_zero or rr_deg:
        return "⚠ redundant 항상 0/degenerate — Ray contingency: redundant drop, coverage 단독 primary 검토"
    return "성분 둘 다 non-degenerate — composite 그대로 사용 가능"


def _condition_correlation(by_task, composite_by_run, runs):
    """task 가로질러 arm A vs B의 coverage 상관 (양수면 pairing이 task 분산 제거 → 검정력↑)."""
    tasks = sorted(by_task)
    a = [by_task[t]["A"]["coverage"] for t in tasks if "A" in by_task[t] and "B" in by_task[t]]
    b = [by_task[t]["B"]["coverage"] for t in tasks if "A" in by_task[t] and "B" in by_task[t]]
    result = {"n_task_blocks": len(a), "arms_A_B_coverage": {"A": a, "B": b}}
    if len(a) >= 2 and stats.pstdev(a) > 0 and stats.pstdev(b) > 0:
        result["pearson_A_B_coverage"] = round(stats.correlation(a, b), 4)
        result["interpretation"] = (
            "양수 = task 난이도 공유 → pairing이 검정력 준다 (Ray §8 이점 확인)"
            if stats.correlation(a, b) > 0 else "≤0 = pairing 이점 약함 → Ray 재검토"
        )
    else:
        result["pearson_A_B_coverage"] = None
        result["interpretation"] = "상관 계산 불가 (분산 0 또는 n<2) — 파일럿 확대 필요할 수 있음"
    return result


def _within_arm_variance(runs, composite_by_run):
    out = {}
    for arm in ("A", "B", "C"):
        idx = [i for i, r in enumerate(runs) if r["arm"] == arm]
        cov = [runs[i]["coverage"] for i in idx]
        rr = [runs[i]["redundant_re_read"] for i in idx]
        entry = {
            "n": len(idx),
            "coverage_sd": round(stats.pstdev(cov), 4) if len(cov) >= 2 else None,
            "redundant_sd": round(stats.pstdev(rr), 4) if len(rr) >= 2 else None,
        }
        if composite_by_run is not None:
            comp = [composite_by_run[i] for i in idx]
            entry["composite_sd"] = round(stats.pstdev(comp), 4) if len(comp) >= 2 else None
        out[arm] = entry
    return out


def _direction_sanity(by_task):
    """B−A coverage 평균차 — 방향 sanity만, 검정력 근거 아님 (Ray ⚠)."""
    tasks = [t for t in by_task if "A" in by_task[t] and "B" in by_task[t]]
    if not tasks:
        return {"note": "A/B pair 없음"}
    deltas = [by_task[t]["B"]["coverage"] - by_task[t]["A"]["coverage"] for t in tasks]
    return {
        "mean_B_minus_A_coverage": round(stats.mean(deltas), 4),
        "label": "⚠ 방향 sanity 전용 — 이 Δ로 검정력/N 잡지 않음 (Ray §12)",
    }


EFFORT_METRICS = ("redundant_re_read", "redundant_grep", "tool_calls_within_budget")


def effort_nuisance(runs: list[dict], metrics=EFFORT_METRICS) -> dict:
    """2차 파일럿용 — 새 effort DV 성분들의 밀도/포화/분산/degeneracy (Ray §13).

    각 성분: 전체 all-zero면 degenerate; 분산 0이면 non-informative; arm별 평균/sd로 밀도 확인.
    tool_calls는 포화 없음(무한대 열림)이라 spread만; 재읽기/재grep은 all-zero 위험.
    """
    out = {}
    for m in metrics:
        vals = [r.get(m, 0) for r in runs]
        by_arm = {}
        for arm in ("A", "B", "C"):
            av = [r.get(m, 0) for r in runs if r["arm"] == arm]
            by_arm[arm] = {
                "n": len(av),
                "mean": round(stats.mean(av), 3) if av else None,
                "sd": round(stats.pstdev(av), 3) if len(av) >= 2 else None,
                "values": av,
            }
        all_zero = all(v == 0 for v in vals)
        overall_sd = stats.pstdev(vals) if len(vals) >= 2 else 0.0
        out[m] = {
            "all_zero_degenerate": all_zero,
            "overall_sd": round(overall_sd, 3),
            "informative": (not all_zero) and overall_sd > 0,
            "by_arm": by_arm,
            "verdict": (
                "⚠ all-zero degenerate — 이 성분 drop" if all_zero else
                "⚠ 분산 0 — non-informative" if overall_sd == 0 else
                "✓ 밀도 있음 (composite 재료로 사용 가능)"
            ),
        }
    # 방향 sanity (⚠ 검정력 아님): effort는 map이 낮추길 기대 → B < A 이면 가설 방향
    dir_ = {}
    for m in metrics:
        a = stats.mean([r.get(m, 0) for r in runs if r["arm"] == "A"]) if runs else 0
        b = stats.mean([r.get(m, 0) for r in runs if r["arm"] == "B"]) if runs else 0
        dir_[m] = round(b - a, 3)
    return {
        "effort_components": out,
        "direction_sanity_B_minus_A_NOT_power": dir_,
        "note": "effort는 map이 *낮추길* 기대 (낭비 노력↓) → B−A 음수면 가설 방향. ⚠ Δ로 검정력 안 잡음(Ray §12).",
    }


def render(report: dict) -> str:
    return json.dumps(report, ensure_ascii=False, indent=2)


if __name__ == "__main__":
    import sys
    runs = [json.loads(l) for l in open(sys.argv[1]) if l.strip()]
    report = {"coverage_secondary": analyze(runs)}
    if any("tool_calls_within_budget" in r for r in runs):  # v2 effort DV 있으면
        report["effort_primary"] = effort_nuisance(runs)
    print(render(report))
