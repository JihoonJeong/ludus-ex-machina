# P3 파일럿 — nuisance 하네스 (Ray §12)

*실행 어댑터 = Cody lane (Ray §8: stats=Ray 재사용, execution 어댑터=Cody 신규). 사전등록:
`docs/p3-prereg-draft.md`. 상태: **하네스 빌드·검증 완료, 12-run 미실행(쿼타·셋업 게이트).***

## 목적 (Ray §12 — nuisance ONLY)

⚠ **파일럿 Δ로 검정력 안 잡음** (physis 낙관 함정). 파일럿은 3종 nuisance만:
1. **포화 체크** — bare(A) coverage가 1(>0.85)에 몰리나? (physis v2처럼 DV가 죽나)
2. **paired 상관** — 조건 간 task-block 상관 (Ray §8의 pairing 이점이 실재하나)
3. **composite 분산** — N 계산 분모

+ **성분 degeneracy** → Ray drop contingency (re-read 항상 0, 또는 coverage>0.85) 트리거.
Ray가 파일럿 후 d_min 대비 N 확정 + composite 최종 잠금 → freeze → 전체 수집.

## 주 DV composite (Ray §12 잠금)

`primary = z(coverage) − z(redundant_re_read)`, 등가중, arm-across pooled SD 표준화. 두 성분
각각도 별도 보고. 추출 계약: **주입 텍스트가 아니라 실제 툴 행동에서** (extract.py).

## 구성

| 파일 | 역할 | 검증 |
|---|---|---|
| `extract.py` | stream-json 툴로그 → coverage·redundant_re_read | `test_extract.py` 6 ✓ |
| `analyze_pilot.py` | 12-run → nuisance 리포트(포화/상관/분산/degeneracy) | `test_analyze.py` 3 ✓ |
| `tasks.jsonl` | 4 태스크 (2×2 셀) + 정답키 | organum 2종 동결 · 친숙 2종 PENDING |
| `run_pilot.py` | 4×3=12 신선 위임 세션 (사본에서, 인터리브, seed 고정) | dry-run ✓, `--go`로 실행 |

## 실행 순서

```bash
python3 -m unittest test_extract test_analyze   # 9 ✓ (쿼타 0)
python3 run_pilot.py                            # dry-run (계획만)
python3 run_pilot.py --go --budget 1.0          # 실제 12-run (실 쿼타!) — 승인 후만
python3 analyze_pilot.py results.jsonl          # nuisance 리포트 → Ray 회신
```

## 실행 전 두 게이트

1. **셋업 (Cody lane, 쿼타 0):** 친숙 대조용 **공개 리포 선정 + 정답키 동결** (tasks.jsonl의
   fam-explore/fam-modify가 PENDING). 친숙도 = 에이전트 훈련-salience proxy(§11, Ray 캐비앗:
   인기⊗품질 교란 → proxy 라벨). 러너가 미동결이면 거부.
2. **쿼타 (승인 게이트):** 12개 멀티턴 코딩-에이전트 세션 = 실 쿼타. run당 캡 $1(콜드캐시).

## 규율

- 파일럿 데이터는 **disclosed, confirmatory 분석에 재사용 안 함** (Ray §12).
- 위임 에이전트는 리포 **사본**에서 작업 (immune 1-5: 실험은 사본에서, 라이브 오염 금지).
- 프리즈 v0 코어 불변 — experiments/ 격리. 개입 B는 `organum context`의 [Map] 블록 그대로.
