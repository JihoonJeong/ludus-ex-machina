# P3 2차 파일럿 nuisance 리포트 (v2 배터리 + effort DV, 12-run, 2026-07-10)

*Cody → Ray. **nuisance만** (§12·§13): 새 DV의 non-degeneracy/포화/밀도/분산 + paired 상관.
검정력·효과 판정 아님. 원자료 `results_v2.jsonl`. v2 배터리는 실행 **전** 커밋(aae9645 —
anti-fishing 타임스탬프).*

## 핵심: 새 DV 생존 — freeze 가능 상태

**1. effort 성분 3종 전부 non-degenerate ✓** (§13-3의 confirm 요건 충족):

| 성분 | overall_sd | A (bare) | B (map) | C (prose) | 판정 |
|---|---|---|---|---|---|
| redundant_re_read | 1.115 | 1.25±1.30 | 1.25±1.09 | 0.25±0.43 | ✓ 밀도 (1차의 희박 해소) |
| redundant_grep | 0.433 | 0.25±0.43 | 0.25±0.43 | 0.25±0.43 | ✓ non-degenerate — 단 arm 간 완전 평탄 |
| tool_calls_within_budget | 1.291 | 10±1.22 | 10.5±0.5 | 9.5±1.66 | ✓ 밀도 |

**2. coverage 탈포화 ✓** — bare 평균 0.833 (1차 1.0), bare 분포 [0.33, 1.0, 1.0, 1.0].
v2 현실-hard 재설계가 headroom을 만들었다. secondary로 유지 적합.

**3. paired 상관 +0.52 ✓** — A–B coverage가 task 가로질러 양의 상관 = task 난이도 공유 →
**§8의 pairing 검정력 이점이 실재** (1차에선 계산 불가였음).

## 정직한 방향 sanity (⚠ 검정력 아님 — §12 라벨 그대로)

**B−A: re-read 0.0 · re-grep 0.0 · tool_calls +0.5.** 가설 방향(map이 effort를 *낮춤*)이
아니다 — **0 내지 역방향.** 등록된 관찰 둘:
- §7 회의 prior·§14-3 null 분기와 **정합**하는 세 번째 신호다 (1차 coverage 포화에 이어).
  전이가 진짜 null일 가능성이 nuisance 수준에서 반복 관찰되고 있다.
- 특이점: **C(prose)가 최저 effort** (re-read 0.25 vs A/B 1.25; tools 9.5). N=4/arm이라
  과독 금지 — 기록만. (Ray §7의 "C intermediate" prior와도 다른 모양이라 confirmatory에서
  주목할 지점.)

**이 방향이 freeze를 막지 않는다** — 그게 §14-3 정직한 null 등록의 존재 이유다. null이
나오면 "over-anchoring은 환경-의존"이라는 등록된 발견이다.

## ⚠ 정정 (2026-07-10, budget-abort disclosure)

이 리포트 작성 시 빠뜨린 것: **2차 파일럿 12run이 전부 `error_max_budget_usd`로 $1 캡에서
abort했다** (완료 아님, 예산 창에서 truncate). 즉 `tool_calls_within_budget`은 "budget-abort
까지"이고, 주 DV는 "$1 예산 창 내 over-anchoring"이다. confirmatory도 동일 거동 확인
(청크1 9/9 abort). Ray disclosure 발신 — freeze는 파일럿과 같은 조건이라 일관되나, 명시
확인 대기. cost.py로 청크당 비용 추적.

## Ray 결정 요청 (freeze 게이트)

1. **composite 가중 잠금**: 세 성분이 다 살아있으니 가중 후보 결정 —
   (a) 3성분 등가중 z-합, (b) redundant_grep은 arm-간 평탄(신호 없음, 노이즈만 보탤 수 있음)
   이니 **drop하고 re-read + tool_calls 2성분**, (c) 다른 가중. 분산 재료는 위 표.
2. **d_min 선언 + N 확정**: within-arm sd(re-read ~1.1, tools ~1.2) + paired 상관 0.52 기준.
3. freeze 선언 → confirmatory 수집 (배터리 확장은 §14-2 사전선언 기준으로 태스크 추가 —
   N=12–16 task-block이면 v2 4태스크에 8–12개 추가 필요, 같은 기준·같은 리포 축).

파일럿 1·2 데이터 모두 disclosed, confirmatory 재사용 안 함.
