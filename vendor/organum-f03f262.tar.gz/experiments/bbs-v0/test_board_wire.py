"""wire 층 시험 — 실제 drop 서버·실제 CLI 루프로 board 왕복.

합성이 아니다: keygen→init→message→export→push→pull→verify-envelope 전부
출하된 기계를 서브프로세스로 돈다. 여기서 green이면 "참여자는 0.4.17만으로
게시할 수 있다"가 실측이 된다."""

import json
import subprocess
import sys
import threading
from pathlib import Path

import pytest

SRC = Path(__file__).resolve().parents[2] / "src"
sys.path.insert(0, str(SRC))
sys.path.insert(0, str(Path(__file__).parent))
from organum import hub_drop as hd  # noqa: E402
import wire  # noqa: E402

CLI = [sys.executable, "-m", "organum.hub_cli"]


def _cli(args, cwd):
    r = subprocess.run(CLI + args, cwd=cwd, capture_output=True, text=True,
                       timeout=120, env={**__import__('os').environ, 'PYTHONPATH': str(SRC)})
    assert r.returncode == 0, f"CLI 실패 {args}: {r.stderr}"
    return json.loads(r.stdout) if r.stdout.strip().startswith("{") else r.stdout


@pytest.fixture
def drop(tmp_path):
    tok = tmp_path / "tokens.txt"
    tok.write_text("# t\nsecret-t0ken\n", encoding="utf-8")
    root = tmp_path / "drops"
    srv = hd.make_server(root, tok, bind="127.0.0.1", port=0)
    t = threading.Thread(target=srv.serve_forever, daemon=True)
    t.start()
    yield (f"http://127.0.0.1:{srv.server_address[1]}", tok, root)
    srv.shutdown()


def _lab(tmp_path, name):
    """실제 랩 하나: keygen + hub init + 자기 키 bootstrap 등록."""
    home = tmp_path / f"{name}-home"
    home.mkdir()
    _cli(["keygen", name], home)
    pub = (home / f"{name}.pub").read_text().strip()
    _cli(["init", "--dir", "hub", "--source-domain", f"lab:{name}/hub"], home)
    _cli(["register-key", "--dir", "hub", "--signer", f"lab:{name}",
          "--key-id", "k1", "--epoch", "1", "--pubkey", pub], home)
    return home, pub


def test_보드_왕복_두_랩이_출하된_CLI만으로_게시하고_호스트가_투영한다(drop, tmp_path):
    url, tok, root = drop
    host_home, host_pub = _lab(tmp_path, "naru")
    guest_home, guest_pub = _lab(tmp_path, "organum")
    # 호스트가 게스트 키를 자기 hub에 등록해야 verify-envelope 결속이 선다
    _cli(["register-key", "--dir", "hub", "--signer", "lab:organum",
          "--key-id", "k1", "--epoch", "1", "--pubkey", guest_pub], host_home)

    care = {"lab": "lab:naru", "id": "Cody"}
    send = wire.send_board_event
    # 호스트: 개설 + 두 멤버 admit + 개시글
    for ev in [
        {"kind": "board.created", "board": "bbs-t", "caretaker": care,
         "at": "t01"},
        {"kind": "board.member.admitted", "board": "bbs-t",
         "member": care, "acting_agent": care, "at": "t02"},
        {"kind": "board.member.admitted", "board": "bbs-t",
         "member": {"lab": "lab:organum", "id": "Cody"}, "acting_agent": care,
         "at": "t03"},
        {"kind": "board.post", "board": "bbs-t", "post_id": "p1",
         "author": care, "reply_to": None, "at": "t10", "text": "회차 개시"},
    ]:
        ev["signer_lab"] = "lab:naru"
        r = send(host_home, "naru", "lab:naru", ev, board="bbs-t",
                 to_lab="lab:naru", to_id="board", url_base=url,
                 token_file=tok)
        assert r["stored"]
    # 게스트: 답글 하나 + **다른 board 좌표로 서명된 글 하나(§3 반례)**
    ok = {"kind": "board.post", "board": "bbs-t", "post_id": "p2",
          "author": {"lab": "lab:organum", "id": "Cody"},
          "signer_lab": "lab:organum", "reply_to": "p1", "at": "t11",
          "text": "칸 1 제출"}
    smuggled = {"kind": "board.post", "board": "other", "post_id": "px",
                "author": {"lab": "lab:organum", "id": "Cody"},
                "signer_lab": "lab:organum", "reply_to": None, "at": "t12"}
    for ev in (ok, smuggled):
        r = send(guest_home, "organum", "lab:organum", ev, board="bbs-t",
                 to_lab="lab:naru", to_id="board", url_base=url,
                 token_file=tok)
        assert r["stored"]          # 운반은 dumb — 거부는 투영층의 일이다

    st = wire.read_board(url, "bbs-t", ["naru", "organum"],
                         workdir=host_home, token_file=tok,
                         hub_dir=host_home / "hub")
    assert st["transport_problems"] == []           # 서명·digest 전부 유효
    assert [p["post_id"] for p in st["posts"]] == ["p1", "p2"]
    assert st["threads"] == {"p1": ["p2"]}
    assert len(st["members"]) == 2
    # §3: 좌표 불일치 글은 서명이 참이어도 효력이 없다 — 사유가 남는다
    assert any("재운반 금지" in r["why"][0] for r in st["rejected"])


def test_채널은_push가_만든다_새_보드에_서버_변경이_없다(drop, tmp_path):
    """운용 성질: board 개설=첫 push. 서버는 dumb carrier 그대로다."""
    url, tok, root = drop
    home, _ = _lab(tmp_path, "naru")
    ev = {"kind": "board.created", "board": "bbs-fresh", "at": "t1",
          "caretaker": {"lab": "lab:naru", "id": "Cody"},
          "signer_lab": "lab:naru"}
    r = wire.send_board_event(home, "naru", "lab:naru", ev, board="bbs-fresh",
                              to_lab="lab:naru", to_id="board", url_base=url,
                              token_file=tok)
    assert r["stored"] and (root / "bbs-fresh" / "from-naru").is_dir()
