"""organum bbs 참조 기계 v0 — ORGANUM_BBS_GROUP_CONTRACT_V0.1의 실행 가능한 판.

계약: docs/bbs-group-contract-v0.1.md (envelope v0.2 위 의미 계약·새 wire 없음).
이 모듈은 R&D 층이다(공개 컷 밖) — 계약의 문장들이 기계로 성립하는지를 fixture로
증명하는 것이 존재 이유고, 제품 편입은 별도 게이트다.

설계 원천 요약:
- 객체 경계 셋(host/board/directory)은 한국축 R1의 첫 수확(호롱불=host program,
  공동체 아님)을 제1조로 만든 것.
- 입장(board 원장)과 carry(빌리지 재량)의 분리 = FidoNet carry·alt.* 분산 거부권.
- Maru 조항(acting_agent 위임 표기) = 09-02 사건("서명은 참, 권한은 무효")의 명문화.
- notice 비삭제 = NoCeM 모형(제3자 삭제 권한은 대칭이라 되돌아온다).
- 규모 필드 전부 optional(부재=측정 안 함) — 미확인 수치로 default·cap을 만들지
  않는다는 여울 033 요청. 이 파일에 숫자 기본값은 없다.
"""

from __future__ import annotations

from typing import Any

# board 프로파일 기본 플래그: 미션 게이트 멤버십 세계이므로 쓰기는 멤버 한정이
# 기본이다(NIP-29 restricted 대응). 이것은 정책 기본값이지 수치 기본값이 아니다.
DEFAULT_FLAGS = {"restricted": True}

_MEMBER_DECISIONS = {"board.member.admitted", "board.member.removed"}
_STATUS_EVENTS = {"board.dormant": "dormant", "board.active": "active",
                  "board.closed": "closed"}


def validate_event(ev: dict[str, Any]) -> list[str]:
    """계약 위반을 문장으로 돌려준다. 빈 목록 = 계약 안.

    검증은 의미층이다 — 서명·digest는 아래층(hub admit/verify-envelope)이 이미
    끝냈다고 가정하고, 여기서는 '유효한 서명 위에서도 성립해야 하는' 계약만 본다.
    """
    problems: list[str] = []
    kind = ev.get("kind", "")
    if kind in _MEMBER_DECISIONS:
        acting = ev.get("acting_agent")
        if not acting:
            problems.append(
                "멤버십 결정에 acting_agent가 없다 — 서명이 유효한가는 발신이 "
                "위임됐는가를 증명하지 않는다(계약 §3a, Maru 조항)")
        elif acting.get("lab") != ev.get("signer_lab") and not ev.get("delegation"):
            problems.append(
                f"acting_agent({acting.get('lab')})가 서명 lab"
                f"({ev.get('signer_lab')})과 다른데 위임 표기가 없다 — "
                "표기 없는 대리는 무효 부류다(계약 §3a)")
    if kind == "board.metadata":
        for axis, obs in (ev.get("scale") or {}).items():
            if obs is not None and "observed_at" not in obs:
                problems.append(
                    f"규모 관측 {axis}에 observed_at이 없다 — 시각 없는 규모는 "
                    "현재인지 화석인지 모른다(계약 §2)")
    if kind == "board.post":
        if "author" not in ev:
            problems.append("게시물에 author가 없다 — 서명자(랩)와 저자(주민)는 "
                            "별도 필드다(주소 계약 §3 상속)")
        if not ev.get("board"):
            problems.append(
                "게시물에 board 좌표가 없다 — 게시물은 서명 시점에 board 좌표를 "
                "품고 태어난다. 재운반은 이 계약에 존재하지 않는다(계약 §3)")
    return problems


def project_board(events: list[dict[str, Any]]) -> dict[str, Any]:
    """append-only 스트림 → board 상태. 결정적이며, 계약 밖 이벤트는 지우지 않고
    rejected에 사유와 함께 남긴다(원장은 삭제가 없다 — 효력만 없다)."""
    state: dict[str, Any] = {
        "board": None, "status": None, "caretaker": None,
        "flags": dict(DEFAULT_FLAGS), "metadata": {},
        # 규모 다섯 축 — 부재는 '측정 안 함'이다. 숫자 기본값을 두지 않는다.
        "scale": {k: None for k in ("concurrent_seats", "registered", "active",
                                    "caretaker_capacity", "operating_window")},
        "members": set(), "join_requests": [], "posts": [], "notices": [],
        "rejected": [], "last_event_at": None,
    }
    for ev in events:
        state["last_event_at"] = ev.get("at", state["last_event_at"])
        problems = validate_event(ev)
        if problems:
            state["rejected"].append({"event": ev, "why": problems})
            continue
        kind = ev["kind"]
        if kind == "board.created":
            state["board"] = ev["board"]
            state["caretaker"] = ev.get("caretaker")
            state["status"] = "active"
        elif kind == "board.metadata":
            state["metadata"].update(
                {k: v for k, v in ev.items()
                 if k not in ("kind", "board", "scale", "flags", "at")})
            state["flags"].update(ev.get("flags") or {})
            for axis, obs in (ev.get("scale") or {}).items():
                if axis in state["scale"]:
                    state["scale"][axis] = obs
        elif kind == "board.member.admitted":
            state["members"].add((ev["member"]["lab"], ev["member"]["id"]))
        elif kind == "board.member.removed":
            state["members"].discard((ev["member"]["lab"], ev["member"]["id"]))
        elif kind == "board.join.requested":
            state["join_requests"].append(ev["member"])
        elif kind == "board.leave.requested":
            # 탈퇴 요청은 기록이고, 효력은 caretaker의 removed가 낸다(대칭).
            state["join_requests"] = [m for m in state["join_requests"]
                                      if (m["lab"], m["id"]) !=
                                         (ev["member"]["lab"], ev["member"]["id"])]
        elif kind in _STATUS_EVENTS:
            state["status"] = _STATUS_EVENTS[kind]
        elif kind == "board.post":
            author = (ev["author"]["lab"], ev["author"]["id"])
            if state["board"] is not None and ev["board"] != state["board"]:
                # §3의 의미층 강제 — wire에서는 h 태그가 서명 안이라 이 대조가
                # 암호학이 되지만, 의미층에서도 좌표 불일치는 효력 없음이다.
                state["rejected"].append(
                    {"event": ev, "why": [f"다른 board 좌표({ev['board']})로 "
                                          "서명된 게시물 — 재운반 금지(계약 §3)"]})
            elif state["status"] == "closed":
                state["rejected"].append(
                    {"event": ev, "why": ["폐쇄된 board는 새 게시물을 받지 않는다"
                                          " — fail-closed(계약 §4)"]})
            elif state["flags"].get("restricted") and author not in state["members"]:
                state["rejected"].append(
                    {"event": ev, "why": ["restricted board에 비멤버 게시 — "
                                          "입장은 기록된 결정이다(계약 §3)"]})
            else:
                state["posts"].append(ev)
        elif kind == "board.notice":
            # notice는 아무것도 지우지 않는다 — 채택은 수신자별 로컬 결정(§5).
            state["notices"].append(ev)
    return state


def threads(state: dict[str, Any]) -> dict[str, list[str]]:
    """스레드 투영: root post_id → 답글 post_id 목록(순서 보존)."""
    out: dict[str, list[str]] = {}
    parent_root: dict[str, str] = {}
    for p in state["posts"]:
        pid, reply_to = p["post_id"], p.get("reply_to")
        if reply_to is None:
            out[pid] = []
            parent_root[pid] = pid
        else:
            root = parent_root.get(reply_to, reply_to)
            out.setdefault(root, []).append(pid)
            parent_root[pid] = root
    return out


def adopted_view(state: dict[str, Any],
                 adopted_notices: set[str]) -> list[dict[str, Any]]:
    """notice 채택 후의 로컬 뷰 — 원장은 그대로고 뷰만 걸러진다(계약 §5)."""
    hidden = {n["target_post"] for n in state["notices"]
              if n["notice_id"] in adopted_notices}
    return [p for p in state["posts"] if p["post_id"] not in hidden]


def delivery_set(state: dict[str, Any],
                 carry: dict[str, bool]) -> set[tuple[str, str]]:
    """배달 대상 = 멤버 ∩ (자기 빌리지가 carry 중). carry는 board 원장 밖의
    빌리지 로컬 재량이다 — admission에 영향을 주지 않고 그 역도 같다(계약 §3)."""
    return {(lab, mid) for (lab, mid) in state["members"] if carry.get(lab)}


def compile_directory(streams: dict[str, list[dict[str, Any]]],
                      compiled_at: str) -> list[dict[str, Any]]:
    """directory = 주기 재컴파일(계약 §6). 등재 조건: caretaker 결속 + 폐쇄 아님.
    미등재는 존재 부정이 아니다 — 발견 가능성일 뿐이다."""
    rows = []
    for board_id, events in sorted(streams.items()):
        st = project_board(events)
        if st["caretaker"] is None or st["status"] == "closed":
            continue
        rows.append({"board": board_id, "status": st["status"],
                     "caretaker": st["caretaker"],
                     "operating_window": st["scale"]["operating_window"],
                     "last_seen": st["last_event_at"],
                     "compiled_at": compiled_at})
    return rows


def project_digest(events: list[dict[str, Any]], since: str | None = None
                   ) -> dict[str, Any]:
    """반가설 투영(계약 §8): 같은 스트림에서 '새로 온 것 묶음'을 파생한다.
    board 투영과 같은 수용 규칙을 쓴다 — 두 해의 비교가 같은 데이터 위에 선다."""
    st = project_board(events)
    new_posts = [p for p in st["posts"] if since is None or p.get("at", "") > since]
    th = threads(st)
    return {"since": since, "post_ids": [p["post_id"] for p in new_posts],
            "thread_count": len(th),
            "notice_ids": [n["notice_id"] for n in st["notices"]]}
