"""주민·마을 전화번호부 참조 기계 v0 — PROFILE_DIRECTORY_CONTRACT_V0.1의 실행판.

BBS 참조 기계(bbs.py)의 자매. 같은 원칙: append-only 스트림 → 결정적 투영,
계약 밖 이벤트는 지우지 않고 rejected에 사유와 함께.

- 최소 공개는 화이트리스트가 강제한다(§3) — 기억·원본이 실릴 필드 자체가 없다.
- 자기 소개 원칙(§2): author=subject. 남이 남의 프로필을 못 세운다.
- Maru 조항 상속: subject의 랩≠서명 랩인데 위임 표기가 없으면 fail-closed.
- directory 행에는 활동·가용성 필드가 없다(§4) — 프로필 원장 이벤트의
  마지막 관측(profile_event_last_seen)만 기록한다(여울 042 편집 메모 반영).
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

PROFILE_FIELDS = {"display_name", "kind", "village", "bio", "interests",
                  "languages", "roles", "contact", "links",
                  # v0.2(나루 084 §2): 기판 전이 관측 카운트 — preserve 전이는
                  # 주체를 바꾸지 않는다. epoch가 아니라 이 필드가 그 사실의 자리.
                  "substrate_transitions"}
SUBJECT_KINDS = {"creature", "village", "lab"}
# v0.2(여울 037 §2): last_seen이 활동처럼 읽히는 것을 이름으로 막는다 —
# 원천은 profile 원장 이벤트의 관측시각뿐이다.
_DIRECTORY_ROW_KEYS = ("subject", "profile", "vouch", "subject_claimed",
                       "announced_at", "profile_event_last_seen", "compiled_at")


def _coord(s: dict[str, Any]) -> tuple[str, str, int]:
    """주소 계약 좌표 — epoch가 다르면 다른 주체다(조용한 합침 금지)."""
    return (s["lab"], s["id"], s.get("epoch", 1))


def _delegated_voice_ok(ev: dict[str, Any]) -> bool:
    """v0.2: author≠subject의 유일한 합법 경로 — 위임 발화.

    acting_agent(말하는 손)와 delegation(위임 근거 — 마을 결정 원장 경로 등)이
    둘 다 있어야 한다. 쓰임: 은퇴 주민의 철회(나루 084 §3, Moss 사례)·집합
    주체(village/lab)의 프로필을 caretaker가 내는 경우(라이브 첫 거부 사례)."""
    return bool(ev.get("acting_agent")) and bool(ev.get("delegation"))


def validate_profile_event(ev: dict[str, Any]) -> list[str]:
    problems: list[str] = []
    kind = ev.get("kind", "")
    subject = ev.get("subject")
    if not subject:
        return ["subject가 없다 — 전화번호부의 행은 주체 좌표 위에 선다(계약 §1)"]
    if kind in ("profile.announced", "profile.updated", "profile.withdrawn"):
        author = ev.get("author")
        if (not author or _coord(author) != _coord(subject)) \
                and not _delegated_voice_ok(ev):
            problems.append(
                "author≠subject인데 위임 발화 표기(acting_agent+delegation)가 "
                "없다 — 소개·철회는 주체의 발화이거나, 위임 근거가 기록된 "
                "대리 발화여야 한다(계약 §2, v0.2)")
    if kind in ("profile.announced", "profile.updated"):
        profile = ev.get("profile") or {}
        extra = set(profile) - PROFILE_FIELDS
        if extra:
            problems.append(
                f"화이트리스트 밖 필드 {sorted(extra)} — 공개 선택된 최소만 "
                "싣는다. 원본은 빌리지에 남는다(계약 §3)")
        if profile.get("kind") not in SUBJECT_KINDS:
            problems.append("profile.kind는 creature|village|lab 중 하나여야 "
                            "한다(계약 §1)")
        if subject["lab"] != ev.get("signer_lab") and not ev.get("delegation"):
            problems.append(
                f"subject의 랩({subject['lab']})≠서명 랩({ev.get('signer_lab')})"
                "인데 위임 표기가 없다 — Maru 조항 상속(BBS 계약 §4a)")
    return problems


def project_profiles(events: list[dict[str, Any]],
                     lab_pubkeys: dict[str, str] | None = None,
                     was_valid_fn=None) -> dict[str, Any]:
    """스트림 → 주체별 현재 프로필. updated는 대체, withdrawn은 대칭으로 내린다.

    lab_pubkeys를 주면 발화 체인(voice 블록)을 등급 판정한다(ORG-ID-D1):
    verified → 행에 표기 / 체인 없음·검증 불가 → 현행(claimed) / 깨진 체인 →
    이벤트 거부(위조 신호). 주지 않으면 전부 claimed — 검증 불가는 결함이 아니다."""
    try:
        import sys as _sys
        _sys.path.insert(0, str(Path(__file__).resolve().parents[1]
                              / "identity-v0"))
        import voice as _voice
    except ImportError:                                    # pragma: no cover
        _voice = None
    rows: dict[tuple[str, str, int], dict[str, Any]] = {}
    withdrawn: set[tuple[str, str, int]] = set()
    rejected: list[dict[str, Any]] = []
    for ev in events:
        problems = validate_profile_event(ev)
        if problems:
            rejected.append({"event": ev, "why": problems})
            continue
        evidence = None
        if _voice is not None and ev.get("voice") is not None:
            # r3(Orin 030 §4): 체인의 상태를 접지 않고 보존한다 —
            # unverifiable을 claimed로 접으면 시도가 사라진다.
            g = _voice.grade_event(ev, lab_pubkeys, was_valid_fn=was_valid_fn)
            if g["grade"] == "rejected":
                rejected.append({"event": ev,
                                 "why": [f"발화 체인 거부: {w}" for w in g["why"]]})
                continue
            evidence = g["grade"]          # "verified" | "unverifiable"
        coord = _coord(ev["subject"])
        kind = ev["kind"]
        if kind == "profile.announced" or kind == "profile.updated":
            prior = rows.get(coord)
            rows[coord] = {
                "subject": ev["subject"], "profile": ev["profile"],
                "vouch": ev.get("vouch"),
                "announced_at": prior["announced_at"] if prior else ev.get("at"),
                "last_seen": ev.get("at"),
                "voice_evidence": evidence,
            }
            withdrawn.discard(coord)
        elif kind == "profile.withdrawn":
            withdrawn.add(coord)
    return {"rows": rows, "withdrawn": withdrawn, "rejected": rejected}


def compile_people_directory(events: list[dict[str, Any]], compiled_at: str,
                             lab_pubkeys: dict[str, str] | None = None,
                             was_valid_fn=None) -> list[dict[str, Any]]:
    """전화번호부 컴파일(§4) — 주기 재컴파일이 신선도를 강제한다(BBS §7 상속).

    행 스키마는 고정 키 집합이다: 활동·가용성 주장 필드는 **존재하지 않는다** —
    등재는 발견 가능성이지 존재·활동·응답 의무가 아니다(주소 계약 §1의 기계화)."""
    st = project_profiles(events, lab_pubkeys, was_valid_fn)
    out = []
    for coord in sorted(st["rows"]):
        if coord in st["withdrawn"]:
            continue
        r = st["rows"][coord]
        row = {"subject": r["subject"], "profile": r["profile"],
               "vouch": r["vouch"],
               # v0.2(여울 037 §3): author=subject는 payload 불변식이지
               # 암호 증명이 아니다 — claimed만 말한다. verified 필드는
               # ORG-ID-D1의 발화 체인이 선 행에**만** 존재한다(부재≠False —
               # 부재는 "체인 없음/검증 불가"다).
               "subject_claimed": True,
               "announced_at": r["announced_at"],
               "profile_event_last_seen": r["last_seen"],
               "compiled_at": compiled_at}
        if r.get("voice_evidence") == "verified":
            row["subject_authority_verified"] = True
        if r.get("voice_evidence") is not None:
            # 상태 보존(Orin 030 §4): 체인이 시도된 행은 그 상태를 말한다 —
            # 부재=시도 없음 / "unverifiable"=시도했으나 미완 / "verified"=성립.
            row["voice_evidence"] = r["voice_evidence"]
        out.append(row)
    for row in out:
        base = {k for k in row
                if k not in ("subject_authority_verified", "voice_evidence")}
        assert base == set(_DIRECTORY_ROW_KEYS)
    return out


def public_projection(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """v0.2(여울 037 §4): 문명 관측면(전망대 등) 투영 — **contact는 항상
    제거된다.** 1978 수확 판례의 기계화: 공개면에 연락 좌표가 실리는 경로
    자체를 없앤다. fail-closed — 산출물에 contact가 남으면 예외다."""
    out = []
    for r in rows:
        p = {k: v for k, v in r["profile"].items() if k != "contact"}
        out.append({"subject": r["subject"], "profile": p,
                    "announced_at": r["announced_at"],
                    "profile_event_last_seen": r["profile_event_last_seen"]})
    for r in out:
        if "contact" in r["profile"]:
            raise AssertionError("public projection에 contact가 남았다 — "
                                 "수확 판례 위반(계약 §5)")
    return out
