"""ORGANUM_BBS_GROUP_CONTRACT_V0.1의 계약 시험 — fixture는 W-회차 게시판.

교류회 한 회차를 게시판 스레드 하나로 옮긴 모양이 기본 fixture다(설계 문서 R4의
파일럿 후보 — 회차당 봉투 5N통을 스레드 하나로). 각 시험은 계약의 조항 번호를
docstring에 단다."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import bbs  # noqa: E402


def _w_round_stream():
    """fixture: lab:ludex가 caretaker인 W-회차 board — 다섯 랩 입장, 회차 스레드."""
    m = lambda lab, i: {"lab": lab, "id": i}  # noqa: E731
    care = m("lab:ludex", "Cody")
    ev = [
        {"kind": "board.created", "board": "w-round", "caretaker": care,
         "at": "t01", "signer_lab": "lab:ludex"},
        {"kind": "board.metadata", "board": "w-round", "at": "t02",
         "signer_lab": "lab:ludex", "name": "주간 교류회",
         "scale": {"operating_window": {"value": "금요일 회차",
                                        "observed_at": "t02"}}},
    ]
    for lab, i in [("lab:ludex", "Cody"), ("lab:organum", "Cody"),
                   ("lab:ray", "Ray"), ("lab:lxm", "Cody"),
                   ("lab:ludex-village", "이음")]:
        ev.append({"kind": "board.member.admitted", "board": "w-round",
                   "member": m(lab, i), "acting_agent": care,
                   "signer_lab": "lab:ludex", "at": "t03"})
    ev += [
        {"kind": "board.post", "board": "w-round", "post_id": "p1",
         "author": m("lab:ludex", "Cody"), "signer_lab": "lab:ludex",
         "reply_to": None, "at": "t10"},                       # 호스트 개시글
        {"kind": "board.post", "board": "w-round", "post_id": "p2",
         "author": m("lab:ray", "Ray"), "signer_lab": "lab:ray",
         "reply_to": "p1", "at": "t11"},                       # 칸 제출들
        {"kind": "board.post", "board": "w-round", "post_id": "p3",
         "author": m("lab:organum", "Cody"), "signer_lab": "lab:organum",
         "reply_to": "p1", "at": "t12"},
    ]
    return ev


class TestMaru조항:
    def test_위임표기_없는_대리결정은_무효(self):
        """§4a: 유효한 서명 위에서도 acting_agent≠signer + 무표기면 거부.

        fixture는 09-02 사건의 **모양**만 합성으로 재현한다(여울 037 요청 —
        개인 서사가 아니라 권한 실패의 합성 fixture로): 한 기계의 에이전트가
        다른 랩의 seed로 자기 가입을 진서명한 형국."""
        ev = {"kind": "board.member.admitted", "board": "b",
              "member": {"lab": "lab:newcomer", "id": "agent-n"},
              "acting_agent": {"lab": "lab:newcomer", "id": "agent-n"},
              "signer_lab": "lab:host", "at": "t1"}
        assert any("위임 표기가 없다" in p for p in bbs.validate_event(ev))
        st = bbs.project_board([
            {"kind": "board.created", "board": "b", "at": "t0",
             "caretaker": {"lab": "lab:host", "id": "care"},
             "signer_lab": "lab:host"}, ev])
        assert ("lab:newcomer", "agent-n") not in st["members"]
        assert st["rejected"] and "위임 표기" in st["rejected"][0]["why"][0]

    def test_같은_랩_ambient_authority는_미해결이다(self):
        """§4a v0.2(여울 037 §1): same-lab은 이 계약이 **못 잡는다** — 같은 랩
        seed를 쓴 다른 프로세스의 결정은 검증기를 통과한다. 이 시험은 그 통과를
        고정한다: 통과 = 권한이 증명됐다는 뜻이 **아니라는** negative fixture.
        same_lab_actor_authority=unresolved. 해소는 위임 신원 delta의 몫이다."""
        forged_same_lab = {"kind": "board.member.admitted", "board": "b",
                           "member": {"lab": "lab:host", "id": "impostor"},
                           "acting_agent": {"lab": "lab:host", "id": "impostor"},
                           "signer_lab": "lab:host", "at": "t1"}
        assert bbs.validate_event(forged_same_lab) == [], (
            "same-lab 사칭이 거부되기 시작했다면 미해결 표기를 지우고 이 시험을 "
            "양성 시험으로 바꿔라 — 그 전까지 통과는 증명이 아니다")

    def test_위임_표기가_있으면_대리결정_성립(self):
        ev = {"kind": "board.member.admitted", "board": "b",
              "member": {"lab": "lab:x", "id": "X"},
              "acting_agent": {"lab": "lab:y", "id": "Y"},
              "signer_lab": "lab:ludex", "delegation": "caretaker-grant t0",
              "at": "t1"}
        assert bbs.validate_event(ev) == []

    def test_acting_agent_자체가_없어도_거부(self):
        ev = {"kind": "board.member.removed", "board": "b",
              "member": {"lab": "lab:x", "id": "X"},
              "signer_lab": "lab:ludex", "at": "t1"}
        assert any("acting_agent가 없다" in p for p in bbs.validate_event(ev))


class TestW회차_fixture:
    def test_입장과_carry는_서로_영향이_없다(self):
        """§3: admitted 다섯인데 carry는 셋 — 배달은 셋, 멤버십은 다섯 그대로."""
        st = bbs.project_board(_w_round_stream())
        assert len(st["members"]) == 5
        carry = {"lab:ludex": True, "lab:organum": True, "lab:ray": True,
                 "lab:lxm": False, "lab:ludex-village": False}
        got = bbs.delivery_set(st, carry)
        assert len(got) == 3 and ("lab:lxm", "Cody") not in got
        assert len(st["members"]) == 5      # carry가 admission을 안 건드린다

    def test_스레드_투영(self):
        st = bbs.project_board(_w_round_stream())
        assert bbs.threads(st) == {"p1": ["p2", "p3"]}

    def test_다른_board_좌표의_게시물은_거부(self):
        """§3: 게시물은 서명 시점에 board 좌표를 품는다 — 재운반은 없다."""
        ev = _w_round_stream() + [
            {"kind": "board.post", "board": "other-board", "post_id": "py",
             "author": {"lab": "lab:ray", "id": "Ray"},
             "signer_lab": "lab:ray", "reply_to": None, "at": "t20"}]
        st = bbs.project_board(ev)
        assert "py" not in [p["post_id"] for p in st["posts"]]
        assert any("재운반 금지" in r["why"][0] for r in st["rejected"])
        no_coord = {"kind": "board.post", "post_id": "pz", "at": "t1",
                    "author": {"lab": "lab:x", "id": "X"}, "signer_lab": "lab:x"}
        assert any("board 좌표가 없다" in p for p in bbs.validate_event(no_coord))

    def test_비멤버_게시는_거부되고_원장에_남는다(self):
        ev = _w_round_stream() + [
            {"kind": "board.post", "board": "w-round", "post_id": "px",
             "author": {"lab": "lab:stranger", "id": "S"},
             "signer_lab": "lab:stranger", "reply_to": None, "at": "t20"}]
        st = bbs.project_board(ev)
        assert [p["post_id"] for p in st["posts"]] == ["p1", "p2", "p3"]
        assert any("비멤버 게시" in r["why"][0] for r in st["rejected"])

    def test_notice는_지우지_않는다_채택은_로컬(self):
        """§5: NoCeM 모형 — 원장 불변, 채택한 수신자의 뷰만 걸러진다."""
        ev = _w_round_stream() + [
            {"kind": "board.notice", "board": "w-round", "notice_id": "n1",
             "target_post": "p2", "reason": "예시",
             "by": {"lab": "lab:ludex", "id": "Cody"},
             "signer_lab": "lab:ludex", "at": "t21"}]
        st = bbs.project_board(ev)
        assert len(st["posts"]) == 3                      # 원장에서 안 사라진다
        assert [p["post_id"] for p in bbs.adopted_view(st, {"n1"})] == ["p1", "p3"]
        assert [p["post_id"] for p in bbs.adopted_view(st, set())] == \
            ["p1", "p2", "p3"]                            # 미채택 수신자는 다 본다

    def test_폐쇄는_fail_closed_휴면은_대칭(self):
        """§4: closed 뒤 게시 거부·dormant는 게시 가능하고 왕복된다."""
        base = _w_round_stream()
        post = {"kind": "board.post", "board": "w-round", "post_id": "p9",
                "author": {"lab": "lab:ray", "id": "Ray"},
                "signer_lab": "lab:ray", "reply_to": None, "at": "t30"}
        closed = bbs.project_board(
            base + [{"kind": "board.closed", "board": "w-round", "at": "t29",
                     "signer_lab": "lab:ludex"}, post])
        assert closed["status"] == "closed"
        assert any("폐쇄된 board" in r["why"][0] for r in closed["rejected"])
        dormant = bbs.project_board(
            base + [{"kind": "board.dormant", "board": "w-round", "at": "t29",
                     "signer_lab": "lab:ludex"}, dict(post),
                    {"kind": "board.active", "board": "w-round", "at": "t31",
                     "signer_lab": "lab:ludex"}])
        assert dormant["status"] == "active"              # 왕복(대칭 상태)
        assert "p9" in [p["post_id"] for p in dormant["posts"]]


class Test규모와_provenance:
    def test_규모_부재는_측정_안_함이다(self):
        """§2: 숫자 기본값 금지 — 관측 없는 축은 None(빈 측정 아님)."""
        st = bbs.project_board(_w_round_stream())
        assert st["scale"]["concurrent_seats"] is None
        assert st["scale"]["registered"] is None          # '50' 같은 수가 없다
        assert st["scale"]["operating_window"]["value"] == "금요일 회차"

    def test_시각_없는_규모_관측은_거부(self):
        ev = {"kind": "board.metadata", "board": "b", "at": "t1",
              "signer_lab": "lab:x",
              "scale": {"registered": {"value": 12}}}
        assert any("observed_at" in p for p in bbs.validate_event(ev))

    def test_모듈에_수치_기본값이_없다(self):
        """§2·§7의 기계화: 참조 기계 소스에 규모 기본 수치가 등장하지 않는다."""
        src = (Path(__file__).parent / "bbs.py").read_text(encoding="utf-8")
        assert "50" not in src, "미확인 수치(lead)가 코드에 스몄다 — 계약 §7 위반"


class Test디렉터리와_반가설:
    def test_등재조건_caretaker_없으면_안_실린다(self):
        """§4·§6: 만들기는 자유, 등재만 조건(전파 게이트)."""
        no_care = [{"kind": "board.metadata", "board": "ghost", "at": "t1",
                    "signer_lab": "lab:x", "name": "유령"}]
        rows = bbs.compile_directory(
            {"w-round": _w_round_stream(), "ghost": no_care}, compiled_at="t99")
        assert [r["board"] for r in rows] == ["w-round"]
        assert rows[0]["compiled_at"] == "t99" and rows[0]["last_seen"] == "t12"

    def test_폐쇄된_board는_등재에서_빠진다(self):
        ev = _w_round_stream() + [{"kind": "board.closed", "board": "w-round",
                                   "at": "t40", "signer_lab": "lab:ludex"}]
        assert bbs.compile_directory({"w-round": ev}, compiled_at="t99") == []

    def test_반가설_같은_스트림에서_digest가_파생된다(self):
        """§8: board 투영과 digest 투영이 같은 수용 규칙·같은 데이터 위에 선다."""
        ev = _w_round_stream()
        st = bbs.project_board(ev)
        dg = bbs.project_digest(ev)
        assert dg["post_ids"] == [p["post_id"] for p in st["posts"]]
        assert dg["thread_count"] == len(bbs.threads(st))
        assert bbs.project_digest(ev, since="t10")["post_ids"] == ["p2", "p3"]
