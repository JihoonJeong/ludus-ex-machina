"""board ↔ 봉투 결합 — 계약(ORG-BBS-R3-001/002)을 실제 transport에 올리는 층.

핵심 성질: **참여자에게 새 설치가 없다.** board는 drop 채널 규약
(`<board>/from-<lab>`)+JSON body 규약이라, 출하된 organum-hub(0.4.17)의
message→export→push만으로 어느 랩이든 오늘 게시할 수 있다(FidoNet 모양 —
노드는 표준 메일러, 코디네이터가 컴파일). 이 모듈은 **호스트 도구**다:
pull → 검증(출하된 verify-envelope 재사용) → JSON 파싱 → 계약 투영.

§3 성립 확인: board 좌표는 JSON body 안에 있고, body의 sha256이 envelope
payload에 결속되며 그 envelope가 서명된다 — 좌표는 서명 아래 있다.

순서 규약(v0): 투영 순서는 (at, lab, n) 정렬 — 문마다 append-only이고 문 사이
병합은 결정적이어야 한다. at의 시계 품질은 파일럿에서 실측한다.
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).parent))
import bbs  # noqa: E402

_SRC = Path(__file__).resolve().parents[2] / "src"
CLI = [sys.executable, "-m", "organum.hub_cli"]
_ENV = {**os.environ, "PYTHONPATH": str(_SRC)}
MEDIA = "application/json"


def event_body_bytes(event: dict[str, Any]) -> bytes:
    """의미 이벤트 → 정렬 JSON bytes. digest가 서명에 결속되는 그 bytes다."""
    return json.dumps(event, ensure_ascii=False, sort_keys=True,
                      separators=(",", ":")).encode("utf-8")


def _run(args: list[str], cwd: Path) -> Any:
    # 서브프로세스 상한은 클라이언트 자기 예산(300s)+워밍 위에 있어야 한다 —
    # 120으로 뒀다가 D2 라이브 첫 콜드스타트(200s대)를 우리가 잘랐다(09-02 실측).
    # "천장이 분포 안에 있으면 그 계기는 길이를 못 잰다"의 wire판.
    r = subprocess.run(CLI + args, cwd=cwd, env=_ENV, capture_output=True,
                       text=True, timeout=700)
    if r.returncode != 0:
        raise RuntimeError(f"CLI 실패 {args[:2]}: {r.stderr.strip()[:200]}")
    out = r.stdout.strip()
    return json.loads(out) if out.startswith("{") else out


def send_board_event(lab_home: Path, key_name: str, signer: str,
                     event: dict[str, Any], *, board: str,
                     to_lab: str, to_id: str, url_base: str,
                     token_file: Path) -> dict[str, Any]:
    """참여자 흐름 — 출하된 CLI 루프 그대로: message → export → push.

    body 파일명이 곧 locator다. 채널은 `<board>/from-<발신 lab의 bare name>`."""
    body = lab_home / f"{board}-{event.get('post_id') or event['kind']}.json"
    body.write_bytes(event_body_bytes(event))
    msg = _run(["message", "--dir", "hub", "--key", f"{key_name}.seed",
                "--signer", signer, "--key-id", "k1", "--epoch", "1",
                "--to-lab", to_lab, "--to-id", to_id, "--to-epoch", "1",
                "--body-file", body.name, "--media-type", MEDIA], lab_home)
    exp = _run(["export", "--dir", "hub", "--out", f"out-{board}",
                "--event-id", msg["event_id"], "--body", body.name], lab_home)
    sender = signer.split(":", 1)[1]
    return _run(["push", "--url", f"{url_base}/v0/{board}/from-{sender}",
                 "--quad", f"out-{board}/{exp['nnn']}",
                 "--token-file", str(token_file), "--no-warmup"], lab_home)


def collect_board(url_base: str, board: str, senders: list[str],
                  dest_root: Path, token_file: Path, cwd: Path) -> None:
    """호스트 흐름 1 — 문마다 pull(출하된 CLI)."""
    for s in senders:
        _run(["pull", "--url", f"{url_base}/v0/{board}/from-{s}",
              "--dest", str(dest_root / f"from-{s}"),
              "--token-file", str(token_file), "--no-warmup"], cwd)


def load_board_events(dest_root: Path, board: str, hub_dir: Path,
                      cwd: Path) -> tuple[list[dict], list[dict]]:
    """호스트 흐름 2 — quad마다 verify-envelope(출하된 검증기)로 서명·digest를
    확인하고, JSON body를 의미 이벤트로 파싱한다. 실패는 지우지 않고 problems로."""
    events: list[tuple] = []
    problems: list[dict] = []
    for door in sorted(dest_root.glob("from-*")):
        lab = door.name[len("from-"):]
        for env_p in sorted(door.glob("*-envelope.json")):
            n = env_p.name.split("-", 1)[0]
            sig_p = door / f"{n}-sig.txt"
            body_p = next((p for p in door.glob(f"{n}-*")
                           if p not in (env_p, sig_p)), None)
            if body_p is None:
                problems.append({"door": door.name, "n": n,
                                 "why": "body 없음(미완성 quad)"})
                continue
            v = _run(["verify-envelope", "--envelope", str(env_p),
                      "--sig-file", str(sig_p), "--body", str(body_p),
                      "--dir", str(hub_dir)], cwd)
            if not (v.get("valid_signature") and v.get("body_sha256_match")):
                problems.append({"door": door.name, "n": n, "why": v})
                continue
            try:
                ev = json.loads(body_p.read_text(encoding="utf-8"))
            except ValueError:
                problems.append({"door": door.name, "n": n,
                                 "why": "body가 JSON이 아님"})
                continue
            ev.setdefault("signer_lab", f"lab:{lab}")
            events.append((ev.get("at", ""), lab, int(n), ev))
    ordered = [e for _, _, _, e in sorted(events, key=lambda t: t[:3])]
    return ordered, problems


def read_board(url_base: str, board: str, senders: list[str], workdir: Path,
               token_file: Path, hub_dir: Path) -> dict[str, Any]:
    """호스트 파이프라인 전체: 수거 → 검증 → 투영. 반환에 threads 포함."""
    dest = workdir / f"board-{board}"
    collect_board(url_base, board, senders, dest, token_file, workdir)
    events, problems = load_board_events(dest, board, hub_dir, workdir)
    state = bbs.project_board(events)
    state["threads"] = bbs.threads(state)
    state["transport_problems"] = problems
    return state
