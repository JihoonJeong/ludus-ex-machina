"""PROFILE_DIRECTORY_CONTRACT_V0.1의 계약 시험 — fixture는 연합 전화번호부.

각 시험은 계약 조항 번호를 docstring에 단다."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import profiles  # noqa: E402


def _sub(lab, i, epoch=1):
    return {"lab": lab, "id": i, "epoch": epoch}


def _announce(lab, i, at, village=None, signer=None, **profile_extra):
    profile = {"kind": "creature", "display_name": i,
               "contact": {"lab_id": lab, "to_id": i, "to_epoch": 1}}
    profile.update(profile_extra)
    if village:
        profile["village"] = village
    return {"kind": "profile.announced", "subject": _sub(lab, i),
            "author": _sub(lab, i), "signer_lab": signer or lab,
            "profile": profile, "at": at}


def _fixture():
    """나루 크리처 둘 + 여울 주민 하나 + 마을 프로필 하나."""
    village = {"kind": "profile.announced",
               "subject": _sub("lab:ludex-village", "여울"),
               "author": _sub("lab:ludex-village", "여울"),
               "signer_lab": "lab:ludex-village",
               "profile": {"kind": "village", "display_name": "여울",
                           "bio": "맥스튜디오 마을"},
               "vouch": {"lab": "lab:ludex-village", "id": "이음"}, "at": "t01"}
    return [
        village,
        _announce("lab:ludex", "Aria", "t02", village="나루",
                  interests=["서사", "판정문"]),
        _announce("lab:ludex", "Echo", "t03", village="나루"),
        _announce("lab:ludex-village", "Canto", "t04", village="여울",
                  interests=["음악"]),
    ]


class Test자기소개_원칙:
    def test_남이_남의_프로필을_못_세운다(self):
        """§2: author≠subject + 위임 무표기 → 거부."""
        ev = {"kind": "profile.announced", "subject": _sub("lab:ludex", "Aria"),
              "author": _sub("lab:organum", "Cody"), "signer_lab": "lab:organum",
              "profile": {"kind": "creature", "display_name": "Aria"}, "at": "t1"}
        assert any("author≠subject" in p
                   for p in profiles.validate_profile_event(ev))

    def test_위임_발화_집합주체와_은퇴주민(self):
        """§2 v0.2: author≠subject의 합법 경로 = acting_agent+delegation.
        라이브 첫 거부(마을 프로필을 caretaker가 냄)와 은퇴 주민 철회(나루 084
        §3)의 두 모양을 같은 기계가 받는다."""
        village = {"kind": "profile.announced",
                   "subject": _sub("lab:ray", "ray-village"),
                   "author": _sub("lab:ray", "Ray"), "signer_lab": "lab:ray",
                   "acting_agent": _sub("lab:ray", "Ray"),
                   "delegation": "village decision drafts/decisions/015.md",
                   "profile": {"kind": "village", "display_name": "Ray 마을"},
                   "at": "t1"}
        assert profiles.validate_profile_event(village) == []
        retired = {"kind": "profile.withdrawn",
                   "subject": _sub("lab:x", "Moss"),
                   "author": _sub("lab:x", "care"), "signer_lab": "lab:x",
                   "acting_agent": _sub("lab:x", "care"),
                   "delegation": "village/decisions/013-retirement.md",
                   "at": "t2"}
        assert profiles.validate_profile_event(retired) == []
        no_deleg = dict(retired)
        no_deleg.pop("delegation")
        assert any("위임 발화 표기" in p
                   for p in profiles.validate_profile_event(no_deleg))

    def test_마루조항_상속_외부_서명은_위임_표기_필수(self):
        """BBS §4a 상속: subject 랩≠서명 랩 + 무표기 → 거부, 표기 시 성립."""
        ev = _announce("lab:ludex", "Aria", "t1", signer="lab:organum")
        assert any("위임 표기가 없다" in p
                   for p in profiles.validate_profile_event(ev))
        ev["delegation"] = "relay-consent t0"
        assert profiles.validate_profile_event(ev) == []


class Test최소공개:
    def test_화이트리스트_밖_필드는_거부(self):
        """§3: 기억·원본이 실릴 필드 자체가 없다 — 모양이 경계다."""
        ev = _announce("lab:ludex", "Aria", "t1", memory_dump="...")
        why = profiles.validate_profile_event(ev)
        assert any("화이트리스트 밖" in p and "memory_dump" in p for p in why)

    def test_kind_없는_프로필은_거부(self):
        ev = _announce("lab:ludex", "Aria", "t1")
        ev["profile"].pop("kind")
        assert any("creature|village|lab" in p
                   for p in profiles.validate_profile_event(ev))


class Test전화번호부:
    def test_컴파일_네_행과_freshness(self):
        """§4: compiled_at·last_seen 병기(BBS §7 상속)."""
        rows = profiles.compile_people_directory(_fixture(), compiled_at="t99")
        assert len(rows) == 4
        aria = next(r for r in rows if r["subject"]["id"] == "Aria")
        assert aria["profile_event_last_seen"] == "t02" and aria["compiled_at"] == "t99"
        assert aria["profile"]["village"] == "나루"

    def test_행에_활동_가용성_필드가_없다(self):
        """§4: 등재≠존재·활동·응답 — 스키마 수준의 기계화(주소 계약 §1)."""
        rows = profiles.compile_people_directory(_fixture(), compiled_at="t99")
        for row in rows:
            assert set(row) == {"subject", "profile", "vouch", "subject_claimed",
                                "announced_at", "profile_event_last_seen",
                                "compiled_at"}
            assert "available" not in row and "active" not in row
            assert "last_seen" not in row      # v0.2: 원천이 이름에 있어야 한다

    def test_updated는_대체하고_announced_at은_보존(self):
        ev = _fixture() + [
            {"kind": "profile.updated", "subject": _sub("lab:ludex", "Aria"),
             "author": _sub("lab:ludex", "Aria"), "signer_lab": "lab:ludex",
             "profile": {"kind": "creature", "display_name": "Aria",
                         "bio": "5.6에서도 같은 존재"}, "at": "t10"}]
        rows = profiles.compile_people_directory(ev, compiled_at="t99")
        aria = next(r for r in rows if r["subject"]["id"] == "Aria")
        assert aria["profile"]["bio"] == "5.6에서도 같은 존재"
        assert aria["announced_at"] == "t02" and aria["profile_event_last_seen"] == "t10"

    def test_withdrawn은_대칭으로_내리고_재공고로_돌아온다(self):
        """§2: 스스로 내림 — 원장은 남고 directory에서만 빠진다."""
        ev = _fixture() + [
            {"kind": "profile.withdrawn", "subject": _sub("lab:ludex", "Echo"),
             "author": _sub("lab:ludex", "Echo"), "signer_lab": "lab:ludex",
             "at": "t11"}]
        rows = profiles.compile_people_directory(ev, compiled_at="t99")
        assert "Echo" not in [r["subject"]["id"] for r in rows]
        back = ev + [_announce("lab:ludex", "Echo", "t12", village="나루")]
        rows2 = profiles.compile_people_directory(back, compiled_at="t99")
        assert "Echo" in [r["subject"]["id"] for r in rows2]

    def test_epoch가_다르면_다른_주체다(self):
        """§1: 같은 이름의 조용한 합침 금지(주소 계약 상속)."""
        ev = _fixture() + [
            {"kind": "profile.announced",
             "subject": _sub("lab:ludex", "Aria", epoch=2),
             "author": _sub("lab:ludex", "Aria", epoch=2),
             "signer_lab": "lab:ludex",
             "profile": {"kind": "creature", "display_name": "Aria(2)"},
             "at": "t20"}]
        rows = profiles.compile_people_directory(ev, compiled_at="t99")
        arias = [r for r in rows if r["subject"]["id"] == "Aria"]
        assert len(arias) == 2      # epoch 1과 2는 별도 행이다


class TestV02추가:
    def test_public_projection은_contact를_항상_벗긴다(self):
        """§5 v0.2(여울 037 §4): 전망대 투영에 연락 좌표가 실리는 경로 자체가
        없다 — fail-closed."""
        rows = profiles.compile_people_directory(_fixture(), compiled_at="t99")
        assert any("contact" in r["profile"] for r in rows)   # 원본엔 있다
        pub = profiles.public_projection(rows)
        assert all("contact" not in r["profile"] for r in pub)
        assert all("vouch" not in r and "subject_claimed" not in r for r in pub)

    def test_기판_전이_preserve는_주체를_바꾸지_않는다(self):
        """§1 v0.2(나루 084 §2): 재브레인 op=preserve → subject·epoch 불변,
        profile.updated + substrate_transitions 관측만 는다. 행은 하나다."""
        ev = _fixture() + [
            {"kind": "profile.updated", "subject": _sub("lab:ludex", "Aria"),
             "author": _sub("lab:ludex", "Aria"), "signer_lab": "lab:ludex",
             "profile": {"kind": "creature", "display_name": "Aria",
                         "substrate_transitions": 1,
                         "bio": "5.6에서도 같은 존재"}, "at": "t10"}]
        rows = profiles.compile_people_directory(ev, compiled_at="t99")
        arias = [r for r in rows if r["subject"]["id"] == "Aria"]
        assert len(arias) == 1                       # 갈라지지 않는다
        assert arias[0]["profile"]["substrate_transitions"] == 1
        assert arias[0]["announced_at"] == "t02"     # 역사도 이어진다

    def test_contact_없는_프로필도_유효하다(self):
        """§3 v0.2(여울 037 §4): contact는 optional — 없어도 등재된다."""
        ev = {"kind": "profile.announced", "subject": _sub("lab:x", "Shy"),
              "author": _sub("lab:x", "Shy"), "signer_lab": "lab:x",
              "profile": {"kind": "creature", "display_name": "Shy"}, "at": "t1"}
        assert profiles.validate_profile_event(ev) == []


class TestVoice등급_통합:
    def test_verified_행은_체인이_선_행에만_있다(self):
        """ORG-ID-D1 통합: 발화 체인이 선 행에만 subject_authority_verified가
        존재한다 — 부재는 False가 아니라 '체인 없음/검증 불가'다."""
        sys.path.insert(0, str(Path(__file__).parent.parent / "identity-v0"))
        import voice
        lab_seed = bytes(range(1, 33)); v_seed = bytes(range(33, 65))
        lab_pub = voice.sp.public_key(lab_seed).hex()
        vpub = voice.mint_voice(v_seed)
        subj = {"lab": "lab:organum", "id": "Cody", "epoch": 1}
        att = voice.make_attestation(lab_seed, "lab:organum", subj, vpub,
                                     hub_event_id="ab" * 32,
                                     hub_accepted_seq=200, at="t1")
        ev = {"kind": "profile.announced", "subject": subj, "author": subj,
              "signer_lab": "lab:organum",
              "profile": {"kind": "creature", "display_name": "Cody"},
              "at": "t2"}
        signed = voice.attach_voice(ev, v_seed, att)
        stream = _fixture() + [signed]
        rows = profiles.compile_people_directory(
            stream, compiled_at="t99", lab_pubkeys={"lab:organum": lab_pub},
            was_valid_fn=lambda p, s: True)
        cody = next(r for r in rows if r["subject"]["id"] == "Cody")
        assert cody["subject_authority_verified"] is True
        for r in rows:
            if r["subject"]["id"] != "Cody":
                assert "subject_authority_verified" not in r   # 부재≠False
        # r2: was_valid_fn 없이는 같은 체인도 unverifiable — verified 미발행,
        # r3: 단 그 시도는 상태로 보존된다(접지 않는다 — Orin 030 §4)
        rows2 = profiles.compile_people_directory(
            stream, compiled_at="t99", lab_pubkeys={"lab:organum": lab_pub})
        cody2 = next(r for r in rows2 if r["subject"]["id"] == "Cody")
        assert "subject_authority_verified" not in cody2
        assert cody2["voice_evidence"] == "unverifiable"
        aria = next(r for r in rows2 if r["subject"]["id"] == "Aria")
        assert "voice_evidence" not in aria        # 시도 없음=필드 부재

    def test_깨진_체인은_행이_아니라_거부다(self):
        sys.path.insert(0, str(Path(__file__).parent.parent / "identity-v0"))
        import voice
        lab_seed = bytes(range(1, 33)); v_seed = bytes(range(33, 65))
        lab_pub = voice.sp.public_key(lab_seed).hex()
        vpub = voice.mint_voice(v_seed)
        subj = {"lab": "lab:organum", "id": "Cody", "epoch": 1}
        att = voice.make_attestation(lab_seed, "lab:organum", subj, vpub,
                                     hub_event_id="ab" * 32,
                                     hub_accepted_seq=200, at="t1")
        ev = {"kind": "profile.announced", "subject": subj, "author": subj,
              "signer_lab": "lab:organum",
              "profile": {"kind": "creature", "display_name": "Cody"},
              "at": "t2"}
        signed = voice.attach_voice(ev, v_seed, att)
        signed["profile"]["bio"] = "서명 뒤에 끼워넣은 문장"   # 변조
        st = profiles.project_profiles([signed],
                                       lab_pubkeys={"lab:organum": lab_pub},
                                       was_valid_fn=lambda p, s: True)
        assert st["rows"] == {} and st["rejected"]
        assert "발화 체인 거부" in st["rejected"][0]["why"][0]
