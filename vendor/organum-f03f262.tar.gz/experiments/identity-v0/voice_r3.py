"""발화 키 r3 — 정식 admission 결속: receipt·포함 증명·구간 판정 (Orin 030).

r2와의 차이가 이 파일의 존재 이유다:

- **자기참조 회피**: 선언(declaration)에는 좌표가 없다 — event_id·accepted_seq는
  admission 뒤에만 존재하고, receipt/proof가 밖에서 결속한다.
  valid_from_seq는 저장값이 아니라 **유도값**(accepted_seq+1)이다.
- **두 검증 모드**(Orin §2): stateful=신뢰·동기화된 원장에서 좌표로 원문 대조 /
  stateless=proof bundle(봉투+서명+receipt+포함 증명+앵커)로 원장 없이. 좌표만
  있고 원장도 proof도 없으면 독립 검증이 아니다.
- **발화 자체의 admission 좌표**: 발화도 admitted되어 좌표를 갖는다 — 발화가
  [결속 유효 시작, 철회) 구간 안인지의 **구간 판정**이 backdated 발화를 배제한다.
- **VoiceRegistry**: attested/revoked의 구간 투영. checked_through_seq는 호출자
  임의값이 아니라 registry가 실제 소화한 원장 checkpoint에서 유도된다.
- 진실 원천은 전부 기존 hub 기계다: HubIndex.admit의 receipt v2(content_sha256이
  봉투 원문을 결속)·TransparencyLog 포함 증명·verify_relay_receipt. 새 암호 0.
"""

from __future__ import annotations

import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

_SRC = Path(__file__).resolve().parents[2] / "src"
sys.path.insert(0, str(_SRC))
from organum import hub_envelope as he  # noqa: E402
from organum import hub_log as hl  # noqa: E402
from organum import schnorr_pure as sp  # noqa: E402

sys.path.insert(0, str(Path(__file__).parent))
from voice import DOMAIN, mint_voice, sign_speech  # noqa: E402,F401

ATTEST_KIND = "voice.attested"
REVOKE_KIND = "voice.revoked"
_FORBIDDEN_IN_DECLARATION = {"hub", "event_id", "accepted_seq", "valid_from_seq",
                             "tree_size", "root", "receipt"}


def _canon(obj: dict) -> bytes:
    return json.dumps(obj, ensure_ascii=False, sort_keys=True,
                      separators=(",", ":")).encode("utf-8")


def _now_z() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _coord(s: dict[str, Any]) -> tuple:
    return (s.get("lab"), s.get("id"), s.get("epoch", 1))


# ── 선언 (좌표 없음 — 자기참조 회피) ─────────────────────────────────────────

def make_declaration(kind: str, lab: str, subject: dict[str, Any],
                     voice_pubkey: str, at: str | None = None) -> dict[str, Any]:
    assert kind in (ATTEST_KIND, REVOKE_KIND)
    return {"kind": kind, "lab": lab, "subject": subject,
            "voice_pubkey": voice_pubkey, "at": at or _now_z()}


def declaration_problems(decl: Any) -> list[str]:
    if not isinstance(decl, dict):
        return ["선언이 객체가 아니다"]
    p = []
    bad = _FORBIDDEN_IN_DECLARATION & set(decl)
    if bad:
        p.append(f"선언에 좌표류 필드 {sorted(bad)} — 좌표는 admission 뒤에만 "
                 "존재한다. payload에는 선언만 담는다(Orin 030 §3)")
    if decl.get("kind") not in (ATTEST_KIND, REVOKE_KIND):
        p.append("선언 kind가 voice.attested|voice.revoked가 아니다")
    if not isinstance(decl.get("subject"), dict):
        p.append("선언에 subject가 없다")
    return p


# ── admission — 봉투·receipt·proof 번들 ─────────────────────────────────────

def _message_envelope(cfg: dict, signer: dict, body_bytes: bytes,
                      locator: str) -> dict:
    digest = hashlib.sha256(body_bytes).hexdigest()
    payload = {"target": cfg["target"], "body_locator": locator,
               "body_sha256": digest, "body_media_type": "application/json"}
    subject = {"type": "message", "id": "message:" + digest[:24]}
    idem = he.canonical_sha({"kind": "message.posted", "subject": subject,
                             "payload": payload})[:32]
    return {"envelope_schema": he.ENVELOPE_SCHEMA, "event_kind": "message.posted",
            "signer": signer, "subject": subject,
            "provenance": {"lab": signer["id"], "machine": cfg["machine"],
                           "platform": sys.platform,
                           "adapter": "voice-r3/0.1", "cli_version": None,
                           "capture": None},
            "idempotency_key": idem, "created_at": _now_z(), "payload": payload}


def _bundle_from(hub, raw: bytes, sig_hex: str, receipt: dict,
                 body_bytes: bytes) -> dict[str, Any]:
    seq, size = receipt["body"]["accepted_seq"], receipt["body"]["tree_size"]
    # proof.path 원소는 hex 문자열로 — 번들이 완전히 JSON 직렬화 가능해야
    # self-contained라 부를 수 있다. verify_bundle이 decode+32byte 강제.
    path = [h.hex() for h in hub.log.inclusion_proof(seq - 1, size)]
    return {"body": body_bytes.decode("utf-8"), "envelope_raw": raw.hex(),
            "sig": sig_hex, "receipt": receipt,
            "proof": {"index": seq - 1, "size": size, "path": path}}


def admit_with_bundle(hub, lab_seed: bytes, cfg: dict, signer: dict,
                      body_bytes: bytes, locator: str) -> dict[str, Any]:
    """본문(선언 또는 발화)을 hub에 admit하고 proof bundle을 만든다.

    bundle = {body, envelope_raw, sig, receipt, proof{index,size}} —
    stateless 검증의 전 재료. receipt가 없으면(hub에 영수증 키 없음) 번들은
    성립하지 않는다 — 그 사실을 숨기지 않는다.

    **idem 단락(B1 계약)**: 같은 (signer, kind, idem key)의 재전송은 서명·재생성
    없이 최초 결과로 수렴한다 — idem key는 created_at을 제외하므로, 이 단락이
    없으면 시계 초를 넘긴 재전송이 '같은 idem·다른 bytes'로 충돌한다(r3 시험이
    이 결함을 유령으로 잡았다). 프로덕션 CLI가 저장된 quad를 재푸시하는 것의
    등가물: 여기서는 원장에 남은 원 봉투를 재직렬화해 같은 bytes로 수렴시킨다."""
    env = _message_envelope(cfg, signer, body_bytes, locator)
    idem = env["idempotency_key"]
    prior = hub.idem_prior(signer["id"], "message.posted", idem)
    if prior is not None:
        rec = hub._by_id[prior["event_id"]]
        raw0 = he.canonical_bytes(rec["envelope"])
        sig0 = sp.sign(hashlib.sha256(raw0).digest(), lab_seed)
        if prior.get("receipt") is None:
            raise RuntimeError("prior에 receipt 없음")
        return _bundle_from(hub, raw0, sig0.hex(), prior["receipt"], body_bytes)
    raw = he.canonical_bytes(env)
    sig = sp.sign(hashlib.sha256(raw).digest(), lab_seed)
    r = hub.admit(raw, sig.hex(), sp.public_key(lab_seed).hex())
    if not r.get("admitted"):
        raise RuntimeError(f"admission 실패: {r}")
    if r.get("receipt") is None:
        raise RuntimeError("receipt 없음 — 이 hub는 영수증 키가 없다. "
                           "proof bundle은 성립하지 않는다")
    return _bundle_from(hub, raw, sig.hex(), r["receipt"], body_bytes)


# ── stateless 검증 — proof bundle ───────────────────────────────────────────

def _is_hex(s: Any, n: int | None = None) -> bool:
    if not isinstance(s, str):
        return False
    if n is not None and len(s) != n * 2:
        return False
    try:
        bytes.fromhex(s)
        return len(s) % 2 == 0
    except ValueError:
        return False


def verify_bundle(bundle: Any, anchor: Any) -> dict[str, Any]:
    """bundle을 앵커만으로 검증한다(원장 무접촉). **전체 fail-closed**(Orin 032
    반례 3): 공개 입력의 어떤 모양도 예외로 새지 않고 rejected/unverifiable로
    수렴한다 — container·field·hex·int 타입을 먼저 검증한다.

    anchor = {"lab_pubkeys": {lab_id: hex64}, "receipt_pubkey": hex64,
              "source_domain": str}. 반환 {"ok","seq","why","body","signer_id"}."""
    def bad(*w):
        return {"ok": False, "why": list(w), "seq": None, "signer_id": None}
    if not isinstance(bundle, dict) or not isinstance(anchor, dict):
        return bad("bundle/anchor가 객체가 아니다")
    if not _is_hex(anchor.get("receipt_pubkey"), 32) \
            or not isinstance(anchor.get("lab_pubkeys"), dict):
        return bad("anchor 모양이 아니다(receipt_pubkey hex64·lab_pubkeys dict)")
    if not (_is_hex(bundle.get("envelope_raw")) and _is_hex(bundle.get("sig"), 64)
            and isinstance(bundle.get("body"), str)
            and isinstance(bundle.get("receipt"), dict)
            and isinstance(bundle.get("proof"), dict)):
        return bad("bundle 모양이 아니다")
    raw = bytes.fromhex(bundle["envelope_raw"])
    try:
        env = json.loads(raw)
    except ValueError:
        return bad("envelope_raw가 JSON이 아니다")
    if not isinstance(env, dict) or not isinstance(env.get("signer"), dict) \
            or not isinstance(env.get("payload"), dict):
        return bad("봉투가 예상 객체 구조가 아니다")
    proof = bundle["proof"]
    if not (isinstance(proof.get("index"), int) and isinstance(proof.get("size"),
            int) and isinstance(proof.get("path"), list)):
        return bad("proof 모양이 아니다(index·size int·path list)")
    # proof.path 각 원소도 32byte hex여야 한다(Orin 033 반례 B): container만
    # 보고 원소 타입을 안 보면 str 원소가 verify_inclusion에서 예외로 샌다.
    if not all(_is_hex(h, 32) for h in proof["path"]):
        return bad("proof.path 원소가 32byte hex가 아니다")
    proof_path = [bytes.fromhex(h) for h in proof["path"]]
    sig = bytes.fromhex(bundle["sig"])
    body_bytes = bundle["body"].encode("utf-8")
    lab = env["signer"].get("id")
    pub = anchor["lab_pubkeys"].get(lab)
    if pub is None or not _is_hex(pub, 32):
        return {"ok": False, "unanchored": True, "seq": None, "signer_id": lab,
                "why": [f"{lab}의 pubkey가 앵커에 없다(또는 형식 오류) — 검증 불가"]}
    why: list[str] = []
    if not sp.verify(sig, hashlib.sha256(raw).digest(), bytes.fromhex(pub)):
        why.append("봉투 서명이 깨졌다")
    if env["payload"].get("body_sha256") != hashlib.sha256(body_bytes).hexdigest():
        why.append("본문 digest가 봉투와 어긋난다")
    if not he.verify_relay_receipt(bundle["receipt"],
            bytes.fromhex(anchor["receipt_pubkey"]),
            expected_source_domain=anchor.get("source_domain")):
        return {"ok": False, "seq": None, "signer_id": lab,
                "why": why + ["receipt 검증 실패(서명·body contract·source_domain)"]}
    rb = bundle["receipt"]["body"]
    if rb.get("content_sha256") != hashlib.sha256(raw).hexdigest():
        why.append("receipt의 content_sha256이 봉투 원문과 어긋난다")
    if proof["size"] != rb["tree_size"]:
        why.append("proof.size ≠ receipt.tree_size")
    if proof["index"] != rb["accepted_seq"] - 1:
        why.append("proof.index ≠ accepted_seq-1")
    if not why and not hl.verify_inclusion(raw, proof["index"], proof["size"],
                                           proof_path,
                                           bytes.fromhex(rb["root"])):
        why.append("포함 증명이 receipt의 root에 서지 않는다")
    if why:
        return {"ok": False, "why": why, "seq": None, "signer_id": lab}
    return {"ok": True, "why": [], "seq": rb["accepted_seq"],
            "body": body_bytes, "signer_id": lab}


# ── stateful 검증 — 신뢰 원장 대조 ──────────────────────────────────────────

def verify_stateful(coords: dict[str, Any], expected_raw_hex: str,
                    trusted_ledger: list[bytes]) -> dict[str, Any]:
    """검증자가 신뢰·동기화한 원장을 이미 가진 경우 — 좌표로 원문을 조회·대조.

    trusted_ledger = seq 순 원문 봉투 목록(events.jsonl 재생의 대역 — index=
    seq-1). self-contained가 아니다(로컬 신뢰 원장 상태에 의존) — 이름이 그
    사실을 말하게 한다(Orin 030 §2A)."""
    seq = coords.get("accepted_seq")
    if not (isinstance(seq, int) and 1 <= seq <= len(trusted_ledger)):
        return {"ok": False, "why": [f"원장에 seq {seq} 없음"]}
    if trusted_ledger[seq - 1] != bytes.fromhex(expected_raw_hex):
        return {"ok": False, "why": ["원장의 원문과 제시된 봉투가 다르다"]}
    return {"ok": True, "why": [], "seq": seq}


# ── VoiceRegistry — 구간 투영·checkpoint 유도 ───────────────────────────────

class VoiceRegistry:
    """attested/revoked 선언의 구간 투영.

    **gap-free sync**(Orin 032 반례 2): `checked_through_seq`는 관측한 최대값이
    아니라 **연속으로 소화한 좌표의 상한**이다. 원장의 모든 사건을 seq 순서대로
    먹여야 하며(voice와 무관한 것은 `ingest_event(seq, None)`), 좌표가 건너뛰면
    checkpoint가 그 구멍 앞에서 멈춘다 — 높은 좌표 하나로 중간 철회를 건너뛸 수
    없다. 단순 max는 철회 한 건을 놓친 채 verified를 말하게 했다(그 반례가 이
    구조를 낳았다).

    입력은 naked body가 아니라 **검증된 bundle의 결과**여야 한다(반례 1·2의
    공통 처방): 호출자가 (declaration, seq)를 임의로 짜 넣지 못하도록
    `ingest_verified`가 verify_bundle 결과에서 seq와 signer를 함께 유도한다."""

    def __init__(self):
        self._intervals: dict[tuple, list[dict]] = {}
        self.checked_through_seq = 0
        self._head: tuple[int, bytes] | None = None   # 마지막 신뢰 (tree_size, root)

    def attach_consistency(self, bundle: dict, log) -> dict:
        """직전 신뢰 head → 이번 bundle의 head로의 consistency proof를 붙인다.

        consumer 측 계산이다(head-상대) — 번들 생성 시점이 아니라 소화 시점에
        자기 신뢰 head에 대해 만든다. path는 hex(직렬화 가능). old_size==0이면
        proof 불요(첫 head)."""
        rb = bundle["receipt"]["body"]
        new_size = rb["tree_size"]
        old_size = self._head[0] if self._head is not None else 0
        if old_size == 0 or old_size == new_size:
            return dict(bundle, consistency=[])
        path = [h.hex() for h in log.consistency_proof(old_size, new_size)]
        return dict(bundle, consistency=path)

    def ingest_verified(self, bundle: Any, anchor: Any) -> list[str]:
        """원장 좌표 하나를 **검증된 bundle에서 유도**해 소화한다(Orin 033 반례 A).

        호출자가 (seq, declaration|None)을 주장하지 않는다 — seq는 receipt에서,
        선언 여부는 **검증된 봉투 본문의 파싱**에서 나온다. voice와 무관한
        사건이라는 판정도 파서가 내린다(호출자가 None을 주장할 수 없다).
        연속(=checkpoint+1)이 아니면 거부하고 checkpoint를 안 올린다.

        **tree-head consistency**(Orin 034 fork splice): seq 연속만으로는 서로
        다른 fork의 좌표를 이어 붙일 수 있다 — inclusion proof는 "이 root에
        있다"만 말하지 두 root가 한 append-only 역사인지는 말하지 않는다. 그래서
        직전 tree head에서 이번 tree head로의 Merkle consistency를 강제하고,
        같은 tree_size에 다른 root가 오면 equivocation으로 거부한다. 번들에
        `consistency`(직전 head→이번 head proof, path hex)가 실려 있어야 한다."""
        v = verify_bundle(bundle, anchor)
        if not v.get("ok"):
            return [f"미검증 record는 소화하지 않는다: {v.get('why')}"]
        seq, signer_id = v["seq"], v["signer_id"]
        if seq != self.checked_through_seq + 1:
            return [f"비연속 좌표: {seq}, 기대 "
                    f"{self.checked_through_seq + 1} — 구멍을 건너뛸 수 없다"]
        rb = bundle["receipt"]["body"]
        new_size, new_root = rb["tree_size"], bytes.fromhex(rb["root"])
        if rb["accepted_seq"] > new_size:
            return [f"accepted_seq({rb['accepted_seq']})>tree_size({new_size})"]
        if self._head is not None:
            old_size, old_root = self._head
            if new_size == old_size and new_root != old_root:
                return [f"equivocation: tree_size {old_size}에 다른 root — "
                        "같은 receipt key의 두 역사(fork)를 구분할 수 없다"]
            cproof = bundle.get("consistency")
            if not isinstance(cproof, list) or not all(_is_hex(h, 32)
                                                       for h in cproof):
                return ["consistency proof 없음/형식오류 — fork splice를 배제할 "
                        "수 없다(Orin 034)"]
            if not hl.verify_consistency(old_size, old_root, new_size, new_root,
                                         [bytes.fromhex(h) for h in cproof]):
                return [f"consistency 실패: tree head {old_size}→{new_size}가 "
                        "한 append-only 역사가 아니다(fork splice)"]
        # 선언 여부는 검증된 본문에서 유도 — 유효한 voice 선언이고 서명 랩이
        # 선언 lab과 같을 때만 적용, 그 외는 전부 non-voice(None)로 투영.
        decl = None
        try:
            cand = json.loads(v["body"])
            if isinstance(cand, dict) and cand.get("kind") in (
                    ATTEST_KIND, REVOKE_KIND) and not declaration_problems(cand) \
                    and signer_id == cand.get("lab"):
                decl = cand
        except (ValueError, TypeError):
            decl = None
        if decl is not None:
            key = (_coord(decl["subject"]), decl["voice_pubkey"])
            rows = self._intervals.setdefault(key, [])
            if decl["kind"] == ATTEST_KIND:
                rows.append({"valid_from": seq + 1, "revoked_at": None})
            else:
                for row in rows:
                    if row["revoked_at"] is None:
                        row["revoked_at"] = seq
        self._head = (new_size, new_root)     # 신뢰 tree head 전진 고정
        self.checked_through_seq = seq
        return []

    def valid_at(self, subject: dict, voice_pubkey: str, at_seq: int) -> bool:
        for row in self._intervals.get((_coord(subject), voice_pubkey), []):
            if row["valid_from"] <= at_seq and \
                    (row["revoked_at"] is None or at_seq < row["revoked_at"]):
                return True
        return False


# ── 등급 판정 r3 ────────────────────────────────────────────────────────────

def grade_r3(speech_bytes: bytes, author: dict[str, Any],
             voice_sig: str | None, attestation_bundle: Any,
             speech_bundle: Any, anchor: dict[str, Any] | None,
             registry: VoiceRegistry | None) -> dict[str, Any]:
    """4상태 + 구간 판정.

    verified의 성립 = attestation bundle 검증 + 발화 서명 + 발화 bundle 검증 +
    **발화 좌표가 [valid_from, revoke) 구간 안**(registry) — checked_through는
    registry에서 유도. revocation 부재는 stateless로 증명 불가하므로 registry
    없이는 unverifiable이다(정직 표기)."""
    if voice_sig is None and attestation_bundle is None:
        return {"grade": "claimed", "why": ["체인 없음"]}
    if voice_sig is None or attestation_bundle is None or speech_bundle is None:
        return {"grade": "rejected",
                "why": ["체인 반쪽 — 서명·보증 번들·발화 번들은 함께 온다"]}
    if anchor is None:
        return {"grade": "unverifiable", "why": ["앵커 없음 — 검증 불가"]}
    av = verify_bundle(attestation_bundle, anchor)
    if av.get("unanchored"):
        return {"grade": "unverifiable", "why": av["why"]}
    if not av["ok"]:
        return {"grade": "rejected",
                "why": [f"보증 번들: {w}" for w in av["why"]]}
    try:
        decl = json.loads(av["body"])
    except ValueError:
        return {"grade": "rejected", "why": ["보증 본문이 JSON이 아니다"]}
    dp = declaration_problems(decl)
    if dp:
        return {"grade": "rejected", "why": dp}
    if decl["kind"] != ATTEST_KIND:
        return {"grade": "rejected", "why": ["보증 선언이 attested가 아니다"]}
    if _coord(decl["subject"]) != _coord(author):
        return {"grade": "rejected", "why": ["보증의 subject≠발화의 author"]}
    # exact authority binding(Orin 032 반례 1): 보증을 실제 서명한 랩
    # (envelope.signer.id)이 선언 lab·author lab과 셋 다 같아야 한다 —
    # 신뢰 목록의 다른 랩이 남의 크리처 voice 권한을 만들 수 없다.
    if not (av["signer_id"] == decl.get("lab") == author.get("lab")):
        return {"grade": "rejected",
                "why": [f"권한 교차: 보증 서명 랩({av['signer_id']})·선언 lab"
                        f"({decl.get('lab')})·author lab({author.get('lab')})이 "
                        "셋 다 같지 않다"]}
    vpub = decl.get("voice_pubkey", "")
    try:
        sig_ok = sp.verify(bytes.fromhex(voice_sig),
                           hashlib.sha256(DOMAIN + speech_bytes).digest(),
                           bytes.fromhex(vpub))
    except (ValueError, TypeError):
        sig_ok = False
    if not sig_ok:
        return {"grade": "rejected", "why": ["발화 서명이 보증된 키에 유효하지 "
                                             "않다(도메인 표지 포함)"]}
    sv = verify_bundle(speech_bundle, anchor)
    if not sv["ok"]:
        return {"grade": "rejected" if not sv.get("unanchored")
                else "unverifiable",
                "why": [f"발화 번들: {w}" for w in sv["why"]]}
    # 발화 admission도 author lab의 서명에 결속(Orin 032 반례 1 후반): 제3자가
    # 옛 voice 서명을 나중 좌표에 재게시해 authority 있는 새 발화로 만들지 못한다.
    if sv["signer_id"] != author.get("lab"):
        return {"grade": "rejected",
                "why": [f"발화 서명 랩({sv['signer_id']})≠author lab"
                        f"({author.get('lab')}) — 제3자 재게시"]}
    att_seq, speech_seq = av["seq"], sv["seq"]
    valid_from = att_seq + 1
    if registry is None:
        return {"grade": "unverifiable",
                "why": ["registry 없음 — revocation 부재는 stateless로 증명할 "
                        "수 없다"]}
    if registry.checked_through_seq < speech_seq:
        return {"grade": "unverifiable",
                "why": [f"registry checkpoint({registry.checked_through_seq})가 "
                        f"발화 좌표({speech_seq})에 못 미친다"]}
    if speech_seq < valid_from:
        return {"grade": "rejected",
                "why": [f"발화 좌표({speech_seq})가 결속 유효 시작"
                        f"({valid_from}) 앞이다 — backdated"]}
    if not registry.valid_at(decl["subject"], vpub, speech_seq):
        return {"grade": "rejected",
                "why": [f"발화 좌표({speech_seq})에서 결속이 유효하지 않다"
                        "(철회 이후이거나 미결속)"]}
    return {"grade": "verified", "why": [],
            "valid_from_seq": valid_from, "verified_at_seq": att_seq,
            "speech_seq": speech_seq,
            "checked_through_seq": registry.checked_through_seq}
