"""발화 키(voice key) 참조 기계 v0-r2 — ORG-ID-D1 (docs/voice-key-delta-v0.md).

r2 = Orin 029 게이트 크리틱 폐쇄판. 바뀐 것:

- **4상태**: claimed(체인 없음) / unverifiable(체인 있음·신뢰근 또는 좌표 술어
  미확보 — 시도했음이 숨지 않는다) / rejected(체인 깨짐·malformed) / verified.
- **verified의 크기 축소**: 전 체인 성립 + attestation의 Hub 좌표(event_id·
  accepted_seq, valid_from=accepted_seq+1 파생) + 호출자가 준 `was_valid_fn`으로
  랩 키의 at-seq 유효성까지 섰을 때만. 결과에 `verified_at_seq`·
  `checked_through_seq` 병기 — 철회 이후의 현재성을 사본이 보증한다고 말하지
  않는다.
- **malformed는 전부 rejected로 수렴** — 공개 입력이 예외로 소비자를 중단시키지
  않는다(hex·shape·kind·lab 대조 전부).
- **도메인 표지**: 발화 서명은 `organum-voice/v0` 표지를 접두한다(교차 프로토콜
  재사용 방지). D2의 표지 없는 구 서명은 이 판에서 rejected — 재발화 대상.
- **mint_voice는 비밀을 돌려주지 않는다** — seed custody는 호출자 경계의 것.

새 암호 0: BIP-340(schnorr_pure)·canonical bytes 재사용.
승격 경로는 여전히 존재하지 않는다.
"""

from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path
from typing import Any, Callable

_SRC = Path(__file__).resolve().parents[2] / "src"
sys.path.insert(0, str(_SRC))
from organum import schnorr_pure as sp  # noqa: E402

DOMAIN = b"organum-voice/v0\n"
ATTEST_KIND = "voice.attested"


def _canon(obj: dict) -> bytes:
    return json.dumps(obj, ensure_ascii=False, sort_keys=True,
                      separators=(",", ":")).encode("utf-8")


def _digest(b: bytes) -> bytes:
    return hashlib.sha256(b).digest()


def _hex_bytes(s: Any, n: int) -> bytes | None:
    """길이 n바이트의 hex 문자열만 bytes로 — 그 외 전부 None(예외 없음)."""
    if not isinstance(s, str) or len(s) != n * 2:
        return None
    try:
        return bytes.fromhex(s)
    except ValueError:
        return None


def _coord(s: dict[str, Any]) -> tuple:
    return (s.get("lab"), s.get("id"), s.get("epoch", 1))


def mint_voice(seed: bytes) -> str:
    """발화 키의 pubkey hex만 돌려준다 — 비밀 seed는 호출자 custody 경계가
    소유하며, 직렬화 가능한 반환값에 다시 담지 않는다(Orin 029 §6)."""
    return sp.public_key(seed).hex()


def make_attestation(lab_seed: bytes, lab: str, subject: dict[str, Any],
                     voice_pubkey: str, *, hub_event_id: str,
                     hub_accepted_seq: int, at: str) -> dict[str, Any]:
    """결속 보증 — **Hub admitted 좌표가 필수다**(Orin 029). valid_from_seq는
    호출자 입력이 아니라 admitted seq에서 파생된다(소급 금지의 좌표).

    사용 순서: 보증 본문을 Hub에 admit(message) → 그 event_id·accepted_seq로
    이 인라인 사본을 만든다. 좌표 불일치는 검증기가 rejected로 잡는다."""
    body = {"kind": ATTEST_KIND, "lab": lab, "subject": subject,
            "voice_pubkey": voice_pubkey,
            "hub": {"event_id": hub_event_id,
                    "accepted_seq": int(hub_accepted_seq)},
            "valid_from_seq": int(hub_accepted_seq) + 1, "at": at}
    sig = sp.sign(_digest(_canon(body)), lab_seed)
    return {"body": body, "lab_sig": sig.hex()}


def sign_speech(voice_seed: bytes, speech_bytes: bytes) -> str:
    """발화 서명 — 도메인 표지를 접두해 다른 프로토콜의 서명과 섞이지 않는다."""
    return sp.sign(_digest(DOMAIN + speech_bytes), voice_seed).hex()


def _att_shape_problems(att: Any, author: dict[str, Any]) -> list[str]:
    """attestation의 모양 검사 — 전부 rejected 사유다(예외 아님)."""
    p: list[str] = []
    if not isinstance(att, dict):
        return ["attestation이 객체가 아니다"]
    body = att.get("body")
    if not isinstance(body, dict):
        return ["attestation.body가 객체가 아니다"]
    if body.get("kind") != ATTEST_KIND:
        p.append(f"attestation kind가 {ATTEST_KIND}가 아니다"
                 f"({body.get('kind')!r}) — 다른 종류의 봉투로 보증을 흉내낼 수 없다")
    if body.get("lab") != author.get("lab"):
        p.append(f"보증 발행 lab({body.get('lab')})≠author의 lab"
                 f"({author.get('lab')}) — 남의 랩 보증으로 말할 수 없다")
    subj = body.get("subject")
    if not isinstance(subj, dict) or _coord(subj) != _coord(author):
        p.append("보증의 subject≠발화의 author — 남의 보증으로 말할 수 없다")
    hub = body.get("hub")
    vfs = body.get("valid_from_seq")
    if not (isinstance(hub, dict)
            and _hex_bytes(hub.get("event_id"), 32) is not None
            and isinstance(hub.get("accepted_seq"), int)
            and hub["accepted_seq"] >= 0):
        p.append("Hub 좌표(event_id hex64·accepted_seq≥0)가 없다 — 좌표 없는 "
                 "보증은 소급 금지를 증명할 수 없다")
    elif not (isinstance(vfs, int) and vfs == hub["accepted_seq"] + 1):
        p.append(f"valid_from_seq({vfs!r})≠accepted_seq+1 — 유효 시점은 "
                 "admitted 좌표에서 파생돼야 한다")
    if _hex_bytes(att.get("lab_sig"), 64) is None:
        p.append("lab_sig가 hex128이 아니다")
    if _hex_bytes(body.get("voice_pubkey"), 32) is None:
        p.append("voice_pubkey가 hex64가 아니다")
    return p


def grade_speech(speech_bytes: bytes, author: dict[str, Any],
                 voice_sig: str | None, attestation: dict[str, Any] | None,
                 lab_pubkey: str | None, *,
                 was_valid_fn: Callable[[str, int], bool] | None = None,
                 checked_through_seq: int | None = None) -> dict[str, Any]:
    """등급 판정 — 4상태(Orin 029).

    claimed      체인 없음(관측 불가 — 현행 세계)
    unverifiable 체인 있음, 그러나 신뢰근(lab_pubkey) 또는 좌표 술어
                 (was_valid_fn) 미확보 — 시도가 있었음을 숨기지 않는다
    rejected     체인이 있는데 깨짐·malformed(위조 신호 — 예외로 새지 않는다)
    verified     전 체인 + Hub 좌표 + at-seq 키 유효까지 성립
    """
    if voice_sig is None and attestation is None:
        return {"grade": "claimed", "why": ["체인 없음 — 관측 불가(현행 세계)"]}
    if voice_sig is None or attestation is None:
        return {"grade": "rejected",
                "why": ["체인 반쪽 — 서명과 보증은 함께 온다"]}
    shape = _att_shape_problems(attestation, author if isinstance(author, dict)
                                else {})
    if _hex_bytes(voice_sig, 64) is None:
        shape.append("voice_sig가 hex128이 아니다")
    if shape:
        return {"grade": "rejected", "why": shape}
    body = attestation["body"]
    if lab_pubkey is None or _hex_bytes(lab_pubkey, 32) is None:
        return {"grade": "unverifiable",
                "why": ["체인은 있으나 신뢰근(랩 pubkey) 미확보 — 검증을 "
                        "시도했고 완료하지 못했다"]}
    why: list[str] = []
    if not sp.verify(bytes.fromhex(attestation["lab_sig"]),
                     _digest(_canon(body)), bytes.fromhex(lab_pubkey)):
        why.append("보증의 랩 서명이 깨졌다")
    if not sp.verify(bytes.fromhex(voice_sig), _digest(DOMAIN + speech_bytes),
                     bytes.fromhex(body["voice_pubkey"])):
        why.append("발화 서명이 보증된 발화 키에 유효하지 않다(도메인 표지 포함)")
    if why:
        return {"grade": "rejected", "why": why}
    at_seq = body["hub"]["accepted_seq"]
    if was_valid_fn is None:
        return {"grade": "unverifiable",
                "why": ["서명은 성립했으나 랩 키의 at-seq 유효성 술어"
                        "(was_valid)가 없다 — verified를 말하지 않는다"]}
    if not was_valid_fn(lab_pubkey, at_seq):
        return {"grade": "rejected",
                "why": [f"랩 키가 seq {at_seq}에서 유효하지 않았다"]}
    return {"grade": "verified", "why": [],
            "valid_from_seq": body["valid_from_seq"],
            "verified_at_seq": at_seq,
            "checked_through_seq": checked_through_seq}


# ── 이벤트 결합 ──────────────────────────────────────────────────────────────

def speech_bytes_of(event: dict[str, Any]) -> bytes:
    return _canon({k: v for k, v in event.items() if k != "voice"})


def attach_voice(event: dict[str, Any], voice_seed: bytes,
                 attestation: dict[str, Any]) -> dict[str, Any]:
    out = dict(event)
    out["voice"] = {"sig": sign_speech(voice_seed, speech_bytes_of(event)),
                    "attestation": attestation}
    return out


def grade_event(event: dict[str, Any], lab_pubkeys: dict[str, str] | None, *,
                was_valid_fn: Callable[[str, int], bool] | None = None,
                checked_through_seq: int | None = None) -> dict[str, Any]:
    author = event.get("author") or event.get("subject") or {}
    vb = event.get("voice")
    if vb is None:
        return {"grade": "claimed", "why": ["체인 없음"]}
    if not isinstance(vb, dict):
        return {"grade": "rejected", "why": ["voice 블록이 객체가 아니다"]}
    pub = (lab_pubkeys or {}).get(author.get("lab", ""))
    return grade_speech(speech_bytes_of(event), author, vb.get("sig"),
                        vb.get("attestation"), pub,
                        was_valid_fn=was_valid_fn,
                        checked_through_seq=checked_through_seq)
