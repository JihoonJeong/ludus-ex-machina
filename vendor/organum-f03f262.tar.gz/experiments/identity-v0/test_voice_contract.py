"""발화 키 delta r2 계약 시험 — 4상태·Hub 좌표·반례 배터리(Orin 029)."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import voice  # noqa: E402

LAB_SEED = bytes(range(1, 33))
VOICE_SEED = bytes(range(33, 65))
OTHER_SEED = bytes(range(65, 97))
LAB_PUB = voice.sp.public_key(LAB_SEED).hex()
CODY = {"lab": "lab:organum", "id": "Cody", "epoch": 1}
SPEECH = "광장 첫 verified 발화 리허설".encode()
EID = "ab" * 32
WAS_VALID = lambda pub, seq: pub == LAB_PUB and seq >= 0  # noqa: E731


def _att(**over):
    kw = dict(hub_event_id=EID, hub_accepted_seq=202, at="t1")
    kw.update(over)
    vpub = voice.mint_voice(VOICE_SEED)
    return voice.make_attestation(LAB_SEED, "lab:organum", CODY, vpub, **kw)


def _grade(speech=SPEECH, author=CODY, sig=None, att=None, pub=LAB_PUB,
           fn=WAS_VALID, through=250):
    if att is None:
        att = _att()
    if sig is None:
        sig = voice.sign_speech(VOICE_SEED, speech if speech != SPEECH else SPEECH)
    return voice.grade_speech(speech, author, sig, att, pub,
                              was_valid_fn=fn, checked_through_seq=through)


class Test4상태:
    def test_체인_없음은_claimed(self):
        g = voice.grade_speech(SPEECH, CODY, None, None, LAB_PUB,
                               was_valid_fn=WAS_VALID)
        assert g["grade"] == "claimed"

    def test_전체인_성립은_verified_좌표_병기(self):
        g = _grade()
        assert g["grade"] == "verified"
        assert g["valid_from_seq"] == 203 and g["verified_at_seq"] == 202
        assert g["checked_through_seq"] == 250   # 현재성 주장은 여기까지만

    def test_신뢰근_미확보는_unverifiable(self):
        """체인 있음+랩 키 모름 = claimed가 아니라 unverifiable —
        시도했음이 숨지 않는다(Orin §3)."""
        assert _grade(pub=None)["grade"] == "unverifiable"

    def test_was_valid_없으면_unverifiable(self):
        """서명이 다 서도 at-seq 술어 없이는 verified를 말하지 않는다."""
        g = _grade(fn=None)
        assert g["grade"] == "unverifiable"
        assert any("was_valid" in w for w in g["why"])

    def test_was_valid_false는_rejected(self):
        assert _grade(fn=lambda p, s: False)["grade"] == "rejected"

    def test_승격_경로가_없다(self):
        assert not [n for n in dir(voice) if "promote" in n or "upgrade" in n]


class TestOrin_반례배터리:
    """029의 최소 반례 다섯 — 전부 rejected로 수렴해야 한다(예외 금지)."""

    def test_wrong_kind은_rejected(self):
        att = _att()
        att["body"]["kind"] = "artifact.attested"
        g = _grade(att=att)
        assert g["grade"] == "rejected" and any("kind" in w for w in g["why"])

    def test_wrong_attestation_lab은_rejected(self):
        att = voice.make_attestation(LAB_SEED, "lab:other", CODY,
                                     voice.mint_voice(VOICE_SEED),
                                     hub_event_id=EID, hub_accepted_seq=202,
                                     at="t1")
        g = _grade(att=att)
        assert g["grade"] == "rejected" and any("남의 랩 보증" in w
                                                for w in g["why"])

    def test_음수_seq는_rejected(self):
        att = _att()
        att["body"]["hub"]["accepted_seq"] = -1
        att["body"]["valid_from_seq"] = 0
        assert _grade(att=att)["grade"] == "rejected"

    def test_malformed_hex는_예외가_아니라_rejected(self):
        att = _att()
        att["lab_sig"] = "not-hex"
        assert _grade(att=att)["grade"] == "rejected"
        assert _grade(sig="zz" * 64)["grade"] == "rejected"
        assert voice.grade_speech(SPEECH, CODY, "짧다", _att(), LAB_PUB,
                                  was_valid_fn=WAS_VALID)["grade"] == "rejected"

    def test_좌표_없는_보증은_rejected(self):
        att = _att()
        del att["body"]["hub"]
        g = _grade(att=att)
        assert g["grade"] == "rejected" and any("좌표" in w for w in g["why"])

    def test_valid_from이_좌표에서_파생되지_않으면_rejected(self):
        att = _att()
        att["body"]["valid_from_seq"] = 999      # 호출자 임의 입력 금지
        assert _grade(att=att)["grade"] == "rejected"


class Test체인:
    def test_본문_변조는_rejected(self):
        sig = voice.sign_speech(VOICE_SEED, SPEECH)
        g = voice.grade_speech(SPEECH + b"!", CODY, sig, _att(), LAB_PUB,
                               was_valid_fn=WAS_VALID)
        assert g["grade"] == "rejected"

    def test_도메인_표지_없는_구서명은_rejected(self):
        """D2의 표지 없는 서명은 r2에서 무효 — 재발화 대상(정직 강등 아님,
        프로토콜 경계)."""
        import hashlib
        old = voice.sp.sign(hashlib.sha256(SPEECH).digest(), VOICE_SEED).hex()
        assert voice.grade_speech(SPEECH, CODY, old, _att(), LAB_PUB,
                                  was_valid_fn=WAS_VALID)["grade"] == "rejected"

    def test_남의_보증으로_말할_수_없다(self):
        impostor = {"lab": "lab:organum", "id": "Impostor", "epoch": 1}
        g = voice.grade_speech(SPEECH, impostor,
                               voice.sign_speech(VOICE_SEED, SPEECH),
                               _att(), LAB_PUB, was_valid_fn=WAS_VALID)
        assert g["grade"] == "rejected"

    def test_위조_보증은_rejected(self):
        fake = voice.make_attestation(OTHER_SEED, "lab:organum", CODY,
                                      voice.mint_voice(VOICE_SEED),
                                      hub_event_id=EID, hub_accepted_seq=202,
                                      at="t1")
        g = _grade(att=fake)
        assert g["grade"] == "rejected" and any("랩 서명" in w for w in g["why"])

    def test_epoch가_다르면_남이다(self):
        g = voice.grade_speech(SPEECH, dict(CODY, epoch=2),
                               voice.sign_speech(VOICE_SEED, SPEECH),
                               _att(), LAB_PUB, was_valid_fn=WAS_VALID)
        assert g["grade"] == "rejected"


class TestCustody:
    def test_mint는_비밀을_돌려주지_않는다(self):
        """Orin §6: 직렬화 가능한 반환값에 seed 사본을 만들지 않는다."""
        out = voice.mint_voice(VOICE_SEED)
        assert isinstance(out, str) and len(out) == 64
        assert VOICE_SEED.hex() not in out
