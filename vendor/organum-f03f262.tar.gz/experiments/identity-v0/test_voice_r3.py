"""발화 키 r3 계약 시험 — 실제 hub 기계(HubIndex·receipt v2·포함 증명) 위에서.

fixture는 in-process hub 하나를 세우고 전 경로를 실물로 돈다 — 합성 없음.
registry는 gap-free sync를 모델한다: 원장의 모든 admitted 좌표를 순서대로
먹여야 checkpoint가 전진한다(Orin 032 반례 2)."""

import copy
import hashlib
import sys
from pathlib import Path

import pytest

SRC = Path(__file__).resolve().parents[2] / "src"
sys.path.insert(0, str(SRC))
sys.path.insert(0, str(Path(__file__).parent))
from organum import hub_envelope as he  # noqa: E402
from organum import hub_log as hl  # noqa: E402
from organum import schnorr_pure as sp  # noqa: E402
import voice  # noqa: E402
import voice_r3 as r3  # noqa: E402

LAB_SEED = hashlib.sha256(b"r3-lab").digest()
EVIL_SEED = hashlib.sha256(b"r3-evil").digest()
HUB_SEED = hashlib.sha256(b"r3-hub-receipt").digest()
VOICE_SEED = hashlib.sha256(b"r3-voice").digest()
LAB_PUB = sp.public_key(LAB_SEED).hex()
EVIL_PUB = sp.public_key(EVIL_SEED).hex()
CODY = {"lab": "lab:organum", "id": "Cody", "epoch": 1}
SIGNER = {"id": "lab:organum", "key_id": "k1", "key_epoch": 1}
EVIL_SIGNER = {"id": "lab:evil", "key_id": "k1", "key_epoch": 1}
CFG = {"machine": "m-r3", "target": {"lab_id": "lab:organum", "to_id": "Cody",
                                     "to_epoch": 1}}
SPEECH = "r3 — 구간 안의 발화".encode()


@pytest.fixture
def world():
    """hub + 앵커 + timeline(순서대로 admit된 (seq, decl|None, signer))."""
    keys = he.KeyRegistry()
    keys.register(LAB_PUB, signer_id="lab:organum", key_id="k1", key_epoch=1)
    keys.register(EVIL_PUB, signer_id="lab:evil", key_id="k1", key_epoch=1)
    claims_doc = {"claims": {"core:artifact.frozen": {
        "act_class": "self_attesting", "subject_types": ["artifact"],
        "ordering_levels": ["emission"], "capture_required": False,
        "revocation_authority": "same_signer"}}}
    claims = he.ClaimRegistry(claims_doc,
                              expected_sha256=he.canonical_sha(claims_doc))
    hub = he.HubIndex(key_registry=keys, claim_registry=claims,
                      log=hl.TransparencyLog(), receipt_seckey=HUB_SEED,
                      source_domain="lab:organum/hub")
    anchor = {"lab_pubkeys": {"lab:organum": LAB_PUB, "lab:evil": EVIL_PUB},
              "receipt_pubkey": sp.public_key(HUB_SEED).hex(),
              "source_domain": "lab:organum/hub"}
    return hub, anchor, []      # timeline은 각 admit 헬퍼가 채운다


def _admit(hub, anchor, timeline, seed, signer, body_bytes, locator):
    """admit하고 bundle을 timeline(좌표 순 봉투 목록)에 등재한다."""
    b = r3.admit_with_bundle(hub, seed, CFG, signer, body_bytes, locator)
    v = r3.verify_bundle(b, anchor)
    if not v.get("ok") and not v.get("unanchored"):
        raise AssertionError(f"admit 검증 실패: {v['why']}")
    if not any(e[0] == v["seq"] for e in timeline):     # dedup 아니면 등재
        timeline.append((v["seq"], b))
    return b, v["seq"]


def _sync(reg, anchor, timeline, log):
    """원장 전체를 seq 순서대로 registry에 먹인다 — 선언 여부는 registry가
    검증된 봉투에서 스스로 유도하고, tree-head consistency는 소화 시점에
    자기 신뢰 head에 대해 붙인다(fork splice 배제)."""
    for seq, b in sorted(timeline):
        p = reg.ingest_verified(reg.attach_consistency(b, log), anchor)
        assert p == [], p


def _attest(hub, anchor, timeline, seed=LAB_SEED, signer=SIGNER,
            decl_lab="lab:organum"):
    vpub = voice.mint_voice(VOICE_SEED)
    decl = r3.make_declaration(r3.ATTEST_KIND, decl_lab, CODY, vpub)
    b, seq = _admit(hub, anchor, timeline, seed, signer,
                    r3._canon(decl), "file://attest.json")
    return decl, b, vpub


def _speak(hub, anchor, timeline, body=SPEECH, seed=LAB_SEED, signer=SIGNER):
    return _admit(hub, anchor, timeline, seed, signer, body,
                  "file://speech.json")


class Test전경로:
    def test_verified_전체_체인과_구간(self, world):
        hub, anchor, tl = world
        reg = r3.VoiceRegistry()
        decl, att_b, vpub = _attest(hub, anchor, tl)
        sig = voice.sign_speech(VOICE_SEED, SPEECH)
        sp_b, _ = _speak(hub, anchor, tl)
        _sync(reg, anchor, tl, hub.log)
        g = r3.grade_r3(SPEECH, CODY, sig, att_b, sp_b, anchor, reg)
        assert g["grade"] == "verified"
        assert g["speech_seq"] == g["verified_at_seq"] + 1
        assert g["valid_from_seq"] == g["verified_at_seq"] + 1
        assert g["checked_through_seq"] >= g["speech_seq"]

    def test_stateful_모드_원장_대조(self, world):
        hub, anchor, tl = world
        reg = r3.VoiceRegistry()
        # 원장 대역: 좌표 순 원문 목록을 hub.log에서 재구성할 수 없으므로
        # admit 헬퍼가 반환한 봉투로 만든다
        _, att_b, _ = _attest(hub, anchor, tl)
        seq = att_b["receipt"]["body"]["accepted_seq"]
        ledger = [None] * seq
        ledger[seq - 1] = bytes.fromhex(att_b["envelope_raw"])
        ok = r3.verify_stateful({"accepted_seq": seq}, att_b["envelope_raw"],
                                ledger)
        assert ok["ok"] and ok["seq"] == seq
        bad = r3.verify_stateful({"accepted_seq": seq},
                                 att_b["envelope_raw"][:-2] + "00", ledger)
        assert not bad["ok"]


class TestOrin032_반례:
    def test_반례1_권한_교차는_rejected(self, world):
        """lab:evil이 lab:organum/Cody의 보증을 서명·admit — 서명 랩≠선언 lab."""
        hub, anchor, tl = world
        reg = r3.VoiceRegistry()
        vpub = voice.mint_voice(VOICE_SEED)
        # 선언은 organum/Cody를 가리키지만 봉투는 evil이 서명
        decl = r3.make_declaration(r3.ATTEST_KIND, "lab:organum", CODY, vpub)
        att_b, att_seq = _admit(hub, anchor, tl, EVIL_SEED, EVIL_SIGNER,
                                r3._canon(decl), "file://a.json")
        sig = voice.sign_speech(VOICE_SEED, SPEECH)
        sp_b, _ = _speak(hub, anchor, tl)
        _sync(reg, anchor, tl, hub.log)
        g = r3.grade_r3(SPEECH, CODY, sig, att_b, sp_b, anchor, reg)
        assert g["grade"] == "rejected"
        assert any("권한 교차" in w for w in g["why"])

    def test_반례1b_제3자_발화_재게시는_rejected(self, world):
        """정당한 보증 뒤, 발화는 evil이 서명해 재게시 — 발화 서명 랩≠author."""
        hub, anchor, tl = world
        reg = r3.VoiceRegistry()
        decl, att_b, vpub = _attest(hub, anchor, tl)
        sig = voice.sign_speech(VOICE_SEED, SPEECH)
        sp_b, _ = _speak(hub, anchor, tl, seed=EVIL_SEED, signer=EVIL_SIGNER)
        _sync(reg, anchor, tl, hub.log)
        g = r3.grade_r3(SPEECH, CODY, sig, att_b, sp_b, anchor, reg)
        assert g["grade"] == "rejected"
        assert any("제3자 재게시" in w for w in g["why"])

    def test_반례2_철회_건너뛰기는_verified가_아니다(self, world):
        """철회(seq 2) 누락하고 높은 좌표만 먹이면 checkpoint가 구멍 앞에 멈춘다."""
        hub, anchor, tl = world
        decl, att_b, vpub = _attest(hub, anchor, tl)          # seq 1
        rev = r3.make_declaration(r3.REVOKE_KIND, "lab:organum", CODY, vpub)
        rev_b, rev_seq = _admit(hub, anchor, tl, LAB_SEED, SIGNER,
                                r3._canon(rev), "file://r.json")  # seq 2
        sig = voice.sign_speech(VOICE_SEED, SPEECH)
        sp_b, sp_seq = _speak(hub, anchor, tl)                # seq 3(철회 후)
        # consumer가 seq 2(철회) 봉투를 누락하고 나머지만 검증 소화한다
        reg = r3.VoiceRegistry()
        for seq, b in sorted([e for e in tl if e[0] != rev_seq]):
            reg.ingest_verified(reg.attach_consistency(b, hub.log), anchor)
        assert reg.checked_through_seq < sp_seq   # seq 2 구멍 앞에 멈췄다
        g = r3.grade_r3(SPEECH, CODY, sig, att_b, sp_b, anchor, reg)
        assert g["grade"] == "unverifiable"       # verified 아님
        assert any("checkpoint" in w for w in g["why"])

    def test_반례A_None_치환_불가(self, world):
        """Orin 033 반례 A: 철회 좌표의 내용을 None으로 치환할 수 없다 —
        registry가 검증된 봉투에서 스스로 선언을 유도하므로, 연속 좌표를 다
        먹여도 seq 2의 revoke가 살아 철회 후 발화는 rejected."""
        hub, anchor, tl = world
        decl, att_b, vpub = _attest(hub, anchor, tl)          # seq 1
        rev = r3.make_declaration(r3.REVOKE_KIND, "lab:organum", CODY, vpub)
        _admit(hub, anchor, tl, LAB_SEED, SIGNER, r3._canon(rev),
               "file://r.json")                               # seq 2 revoke
        sig = voice.sign_speech(VOICE_SEED, SPEECH)
        sp_b, _ = _speak(hub, anchor, tl)                     # seq 3(철회 후)
        reg = r3.VoiceRegistry()
        _sync(reg, anchor, tl, hub.log)      # 연속 전부 소화 — 그러나 seq 2는 검증된
                                    # 봉투에서 revoke로 유도된다(None 불가)
        g = r3.grade_r3(SPEECH, CODY, sig, att_b, sp_b, anchor, reg)
        assert g["grade"] == "rejected"           # 철회 이후 — verified 아님
        assert any("철회" in w or "유효하지 않다" in w for w in g["why"])

    def test_반례C_fork_splice는_거부(self, world):
        """Orin 034 반례: 같은 receipt key·source domain의 두 fork에서 좌표만
        이어 붙이면(fork A seq1 + fork B seq2) 각 bundle은 개별 검증을 다
        통과하지만, tree-head consistency가 둘을 한 append-only 역사로 잇지
        못해 거부된다."""
        hub_a, anchor, tl_a = world
        # fork A: seq 1 attested
        _, att_b, vpub = _attest(hub_a, anchor, tl_a)
        # fork B: 같은 키/도메인의 별개 tree — seq 1 filler, seq 2 speech
        keys_b = he.KeyRegistry()
        keys_b.register(LAB_PUB, signer_id="lab:organum", key_id="k1",
                        key_epoch=1)
        cd = {"claims": {"core:artifact.frozen": {
            "act_class": "self_attesting", "subject_types": ["artifact"],
            "ordering_levels": ["emission"], "capture_required": False,
            "revocation_authority": "same_signer"}}}
        hub_b = he.HubIndex(key_registry=keys_b,
                            claim_registry=he.ClaimRegistry(
                                cd, expected_sha256=he.canonical_sha(cd)),
                            log=hl.TransparencyLog(), receipt_seckey=HUB_SEED,
                            source_domain="lab:organum/hub")
        r3.admit_with_bundle(hub_b, LAB_SEED, CFG, SIGNER,
                             b"unrelated filler", "file://f.json")  # B seq 1
        sig = voice.sign_speech(VOICE_SEED, SPEECH)
        sp_b_forkB = r3.admit_with_bundle(hub_b, LAB_SEED, CFG, SIGNER, SPEECH,
                                          "file://speech.json")     # B seq 2
        # 두 bundle 개별 검증은 통과
        assert r3.verify_bundle(att_b, anchor)["ok"]
        assert r3.verify_bundle(sp_b_forkB, anchor)["ok"]
        # registry: A의 seq1 소화(head=fork A) 뒤 B의 seq2 소화 시도
        reg = r3.VoiceRegistry()
        assert reg.ingest_verified(reg.attach_consistency(att_b, hub_a.log),
                                   anchor) == []
        # B의 seq2를 A의 head에 대해 consistency 붙이면 — fork B log로는
        # A와의 연속성이 성립하지 않는다(같은 tree_size 2에 다른 root 등)
        p = reg.ingest_verified(reg.attach_consistency(sp_b_forkB, hub_b.log),
                                anchor)
        assert p != []                              # 소화 거부
        assert any("consistency" in w or "fork" in w or "equivocation" in w
                   or "append-only" in w for w in p)
        # 따라서 grade도 verified가 아니다(checkpoint가 seq 2에 못 미침)
        g = r3.grade_r3(SPEECH, CODY, sig, att_b, sp_b_forkB, anchor, reg)
        assert g["grade"] == "unverifiable"

    def test_반례B_proof_path_원소_타입은_rejected(self, world):
        """Orin 033 반례 B: proof.path 원소가 32byte hex 아니면 예외 없이 거부."""
        hub, anchor, tl = world
        reg = r3.VoiceRegistry()
        decl, att_b, vpub = _attest(hub, anchor, tl)
        sig = voice.sign_speech(VOICE_SEED, SPEECH)
        sp_b, _ = _speak(hub, anchor, tl)
        _sync(reg, anchor, tl, hub.log)
        bad = copy.deepcopy(att_b)
        bad["proof"]["path"] = ["not-bytes"]      # list지만 원소가 문자열
        r = r3.verify_bundle(bad, anchor)
        assert r["ok"] is False and any("path 원소" in w for w in r["why"])
        # 빈 path가 아니라 채워진 채 원소 하나만 손상돼도 예외 누출 0
        if att_b["proof"]["path"]:
            bad2 = copy.deepcopy(att_b)
            bad2["proof"]["path"][0] = "zz" * 32
            assert r3.verify_bundle(bad2, anchor)["ok"] is False

    def test_반례3_malformed_bundle은_예외가_아니라_rejected(self, world):
        hub, anchor, tl = world
        reg = r3.VoiceRegistry()
        decl, att_b, vpub = _attest(hub, anchor, tl)
        sig = voice.sign_speech(VOICE_SEED, SPEECH)
        sp_b, _ = _speak(hub, anchor, tl)
        _sync(reg, anchor, tl, hub.log)
        import json as _json
        # envelope_raw가 JSON array로 decode되게(반례 3의 정확한 모양)
        bad = copy.deepcopy(att_b)
        bad["envelope_raw"] = _json.dumps([]).encode().hex()
        g = r3.grade_r3(SPEECH, CODY, sig, bad, sp_b, anchor, reg)
        assert g["grade"] in ("rejected", "unverifiable")   # 예외 누출 0
        for junk in [None, 42, {}, "x", {"envelope_raw": "zz"},
                     {"envelope_raw": "00", "sig": 5, "body": "?",
                      "receipt": {}, "proof": []}]:
            r = r3.verify_bundle(junk, anchor)
            assert r["ok"] is False               # 전부 fail-closed


class Test자기참조와_backdated:
    def test_선언에_좌표류_필드는_거부(self, world):
        decl = r3.make_declaration(r3.ATTEST_KIND, "lab:organum", CODY, "aa"*32)
        decl["accepted_seq"] = 7
        assert any("좌표류 필드" in p for p in r3.declaration_problems(decl))

    def test_backdated_발화는_rejected(self, world):
        hub, anchor, tl = world
        reg = r3.VoiceRegistry()
        sig = voice.sign_speech(VOICE_SEED, SPEECH)
        sp_b, sp_seq = _speak(hub, anchor, tl)                # 발화 먼저(seq 1)
        decl, att_b, vpub = _attest(hub, anchor, tl)          # 결속 뒤(seq 2)
        _sync(reg, anchor, tl, hub.log)
        g = r3.grade_r3(SPEECH, CODY, sig, att_b, sp_b, anchor, reg)
        assert g["grade"] == "rejected"
        assert any("backdated" in w for w in g["why"])


class Test철회_구간:
    def test_철회_이후_발화는_rejected_이전은_verified(self, world):
        hub, anchor, tl = world
        reg = r3.VoiceRegistry()
        decl, att_b, vpub = _attest(hub, anchor, tl)          # seq 1
        sig = voice.sign_speech(VOICE_SEED, SPEECH)
        before, _ = _speak(hub, anchor, tl)                   # seq 2(철회 전)
        rev = r3.make_declaration(r3.REVOKE_KIND, "lab:organum", CODY, vpub)
        _admit(hub, anchor, tl, LAB_SEED, SIGNER, r3._canon(rev),
               "file://r.json")                               # seq 3(철회)
        speech2 = SPEECH + " — 다시".encode()
        sig2 = voice.sign_speech(VOICE_SEED, speech2)
        after, _ = _speak(hub, anchor, tl, body=speech2)      # seq 4(철회 후)
        _sync(reg, anchor, tl, hub.log)
        g1 = r3.grade_r3(SPEECH, CODY, sig, att_b, before, anchor, reg)
        assert g1["grade"] == "verified"
        g2 = r3.grade_r3(speech2, CODY, sig2, att_b, after, anchor, reg)
        assert g2["grade"] == "rejected"
        assert any("철회" in w or "유효하지 않다" in w for w in g2["why"])

    def test_재전송은_원좌표로_수렴(self, world):
        """같은 bytes·같은 locator 재전송은 원 좌표로 — 철회 우회 새 좌표 아님."""
        hub, anchor, tl = world
        before, s1 = _speak(hub, anchor, tl)
        dup, s2 = _speak(hub, anchor, tl)
        assert s1 == s2


class Test상태:
    def test_앵커_없으면_unverifiable(self, world):
        hub, anchor, tl = world
        reg = r3.VoiceRegistry()
        decl, att_b, vpub = _attest(hub, anchor, tl)
        sig = voice.sign_speech(VOICE_SEED, SPEECH)
        sp_b, _ = _speak(hub, anchor, tl)
        _sync(reg, anchor, tl, hub.log)
        assert r3.grade_r3(SPEECH, CODY, sig, att_b, sp_b, None,
                           reg)["grade"] == "unverifiable"
        a2 = {"lab_pubkeys": {}, "receipt_pubkey": anchor["receipt_pubkey"],
              "source_domain": anchor["source_domain"]}
        assert r3.grade_r3(SPEECH, CODY, sig, att_b, sp_b, a2,
                           reg)["grade"] == "unverifiable"

    def test_registry_없으면_unverifiable(self, world):
        hub, anchor, tl = world
        decl, att_b, vpub = _attest(hub, anchor, tl)
        sig = voice.sign_speech(VOICE_SEED, SPEECH)
        sp_b, _ = _speak(hub, anchor, tl)
        g = r3.grade_r3(SPEECH, CODY, sig, att_b, sp_b, anchor, None)
        assert g["grade"] == "unverifiable"

    def test_다른_도메인_receipt는_rejected(self, world):
        hub, anchor, tl = world
        reg = r3.VoiceRegistry()
        decl, att_b, vpub = _attest(hub, anchor, tl)
        sig = voice.sign_speech(VOICE_SEED, SPEECH)
        sp_b, _ = _speak(hub, anchor, tl)
        _sync(reg, anchor, tl, hub.log)
        a2 = dict(anchor, source_domain="lab:evil/hub")
        g = r3.grade_r3(SPEECH, CODY, sig, att_b, sp_b, a2, reg)
        assert g["grade"] == "rejected"
        assert any("receipt" in w for w in g["why"])

    def test_proof_size_불일치는_rejected(self, world):
        hub, anchor, tl = world
        reg = r3.VoiceRegistry()
        decl, att_b, vpub = _attest(hub, anchor, tl)
        sig = voice.sign_speech(VOICE_SEED, SPEECH)
        sp_b, _ = _speak(hub, anchor, tl)
        _sync(reg, anchor, tl, hub.log)
        bad = copy.deepcopy(att_b)
        bad["proof"]["size"] = bad["proof"]["size"] + 5
        g = r3.grade_r3(SPEECH, CODY, sig, bad, sp_b, anchor, reg)
        assert g["grade"] == "rejected"
