#!/usr/bin/env python3
"""dev(private JihoonJeong/organum) → public cut(ludex-lab/organum) 수출.

공개 모델 = ludex와 같은 public-cut: dev repo는 private 유지, 공개는 화이트리스트
경로만 큐레이션해 cut repo로 복사한다. PyPI 배포(단일 패키지 organum)는 **cut에서
빌드**한다 — dev 내부(실험·핸드오프·저널·상태)는 절대 공개면에 닿지 않는다.

기본 dry-run(무엇이 복사될지 출력만). `--apply`로 실제 복사. **git add/commit/push는
하지 않는다** — 공개면 반영은 사람이 cut repo에서 diff를 보고 결정한다.

    python3 scripts/export-public-cut.py            # dry-run
    python3 scripts/export-public-cut.py --apply    # 복사 실행
"""

import argparse
import shutil
import sys
from pathlib import Path

DEV = Path(__file__).resolve().parent.parent
DEFAULT_CUT = Path.home() / "Projects" / "ludex-lab-organum"

# 공개되는 것 전부가 이 목록에서 나온다 — 여기 없는 경로는 공개면에 닿지 않는다.
# (src, dst) 리맵 주의: cut의 docs/는 GitHub Pages 사이트 루트라 문서는 manual/로 보낸다.
WHITELIST = [
    ("src/organum/", "src/organum/"),
    ("tests/", "tests/"),
    ("skills/", "skills/"),        # 번들 skill — invariant 테스트(Inv8)가 자기 provision 검사
    ("pyproject.toml", "pyproject.toml"),
    ("LICENSE", "LICENSE"),
    # 줄바꿈 정규화 차단 — 공개면에도 반드시 간다(Ray 038: 공개 레포에 이게 없어
    # 벤더링 벡터가 CRLF→LF로 정규화되면 content SHA pin이 깨진다. dev에서만 막고
    # cut에 안 실으면 그 사고는 소비자 쪽에서만 터진다 — 가장 나쁜 모양이다).
    (".gitattributes", ".gitattributes"),
    ("docs/quickstart-inspector.md", "manual/quickstart-inspector.md"),
    ("docs/quickstart-inspector.en.md", "manual/quickstart-inspector.en.md"),
    ("docs/quickstart-observe.md", "manual/quickstart-observe.md"),
    ("docs/quickstart-observe.en.md", "manual/quickstart-observe.en.md"),
    ("docs/case-study-inspector-duel.md", "manual/case-study-inspector-duel.md"),
    ("docs/case-study-inspector-duel.en.md", "manual/case-study-inspector-duel.en.md"),
    ("docs/case-study-inspector-duel.json", "manual/case-study-inspector-duel.json"),
    ("docs/quickstart-hub.md", "manual/quickstart-hub.md"),
    ("docs/quickstart-hub.en.md", "manual/quickstart-hub.en.md"),
    # organum bbs 0.5.0 계약 둘(의미층·wire 무변) — 제품 승격분(A). 발화 키
    # verified·experiments/는 whitelist 밖이라 공개면에 안 닿는다(경계 유지).
    ("docs/bbs-group-contract-v0.1.md", "manual/bbs-group-contract-v0.1.md"),
    ("docs/profile-directory-contract-v0.1.md",
     "manual/profile-directory-contract-v0.1.md"),
    # ("docs/quickstart-code.md", "manual/quickstart-code.md"),
    # ("docs/quickstart-code.en.md", "manual/quickstart-code.en.md"),
    #   ↑ **Orin ACK(봉투 035) 대기 중 — 판정이 서면 이 두 줄의 주석을 푼다.**
    #   왜 whitelist에서 빼는가: 대기가 "매 릴리스마다 손으로 git add를 골라내기"로
    #   유지되고 있었고, 0.4.12·0.4.13·0.4.14 세 번 연속 그렇게 했다. 언젠가
    #   `git add -A`를 치는 날 ACK 없이 공개면에 나간다 — 규율이 메우고 있는 자리는
    #   한 번의 착각으로 무너진다는 것이 이번 주 우리가 남에게 한 말이다.
    #   Orin 018이 배포 slice의 선행조건으로 **Ray의 clean-room smoke**를 걸어 뒀으므로
    #   ACK가 늦는 것은 지연이 아니라 순서다. 그동안 대기를 기억이 아니라 여기에 둔다.
]
EXCLUDE_NAMES = {"__pycache__", ".DS_Store"}


def _iter_files(p: Path):
    if p.is_file():
        yield p
        return
    for f in sorted(p.rglob("*")):
        if f.is_file() and not (set(f.parts) & EXCLUDE_NAMES):
            yield f


def _vacuity_gate() -> int:
    """공허 단언 스캔 — 지적이 있으면 컷을 멈춘다.

    W35 교류회에서 세 집이 같은 주에 「같은 사본을 자기와 비교하는 검사」를
    각자 사건으로 만났고, 우리 칸 3이 "체계적으로 찾는 방법이 없다"였다.
    Ludex가 부분해(1단계 치환→AST 동일=공허)를 보냈다(우리 seq 129). 시험
    스위트에 넣으면 컷 트리에서 영구 skip이 되므로(scripts/는 공개면 밖),
    **출하 경로에** 건다 — 모든 공개는 이 스크립트를 지나므로 매 컷마다 밟힌다.
    하한 스캐너다: 지적 0이 "공허 없음"이 아니라 "1단계 치환으로는 없음"이다."""
    import subprocess
    scanner = DEV / "scripts" / "find_self_comparisons.py"
    r = subprocess.run([sys.executable, str(scanner),
                        str(DEV / "src"), str(DEV / "tests")],
                       capture_output=True, text=True)
    if r.returncode != 0:
        print("export: 공허 단언 지적 — 컷 중단:", file=sys.stderr)
        print(r.stdout, file=sys.stderr)
        return 1
    print(f"  vacuity gate: {r.stdout.splitlines()[-1]}")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--cut", default=str(DEFAULT_CUT), help=f"cut repo 경로 (기본 {DEFAULT_CUT})")
    ap.add_argument("--apply", action="store_true", help="실제 복사 (기본은 dry-run)")
    args = ap.parse_args()
    cut = Path(args.cut).expanduser()
    if not (cut / ".git").is_dir():
        print(f"export: cut repo가 아님: {cut}", file=sys.stderr)
        return 1
    if _vacuity_gate() != 0:
        return 1
    n = 0
    for src_entry, dst_entry in WHITELIST:
        src = DEV / src_entry
        if not src.exists():
            print(f"  ! 없음(건너뜀): {src_entry}", file=sys.stderr)
            continue
        for f in _iter_files(src):
            rel = f.relative_to(DEV / src_entry) if src.is_dir() else None
            dst = (cut / dst_entry / rel) if rel is not None else (cut / dst_entry)
            print(f"  {f.relative_to(DEV)} → {dst.relative_to(cut)}")
            if args.apply:
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(f, dst)
            n += 1
    mode = "복사됨" if args.apply else "복사 예정 (dry-run — 실행은 --apply)"
    print(f"export: {n}개 파일 {mode} → {cut}")
    if args.apply:
        print("다음: cut repo에서 `git diff` 검토 → 사람이 commit/push (스크립트는 안 함)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
