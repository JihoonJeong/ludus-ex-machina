#!/usr/bin/env python3
"""공허한 단언 찾기 — 같은 사본을 자기와 비교하는 자리.

Organum 교류회 1회차 칸 3 (2026-08-28)에 대한 부분해:

    "try/except 삼킴은 문법으로 잡힌다. 그런데 자기 비교는 문법이 아니라
     의미다 — `a == b`가 공허한지는 `a`와 `b`가 같은 원천에서 왔는지를
     알아야 판정되고, 그건 호출 그래프를 거슬러야 나온다."

그들 사례: `organum/__init__.py`에 `__version__ = version("organum")`이 있고,
시험이 `assertEqual(organum.__version__, version("organum"))`이었다. 두 항이
**같은 표현**인데 이름이 달라 보였다. 그 시험은 두 달간 초록이었고, 이웃의
환경 보고가 우연히 드러냈다.

**부분해**: 자기 비교는 의미론이지만 **한 번 치환하면 문법이 된다.**

    1. 각 모듈에서 `이름 → 정의 표현식` 지도를 만든다 (모듈 최상단 대입만).
    2. 비교 단언의 양변에서 그 이름들을 정의로 치환한다 (1단계만).
    3. 치환 뒤 두 변의 AST가 같으면 그 단언은 공허하다.

한 단계만 도는 이유는 그 이상이 호출 그래프이기 때문이다. **1단계에서 잡히는
것이 실제로 일어난 사고의 모양**이라는 것이 Organum 사례의 증언이다.

한계는 정직하게 적는다 — 이것은 **하한**이다. 원천이 함수 반환값을 거쳐 오거나
모듈이 갈리면 못 잡는다. 잡은 것은 진짜이고, 못 잡은 것에 대해서는 아무 말도
하지 않는다.

    python3 tools/find_self_comparisons.py tests/ ludex/
"""

from __future__ import annotations

import ast
import sys
from pathlib import Path

EQUALITY_METHODS = {"assertEqual", "assertIs", "assertNotEqual", "assertIsNot"}


def module_definitions(tree: ast.Module) -> dict[str, ast.expr]:
    """모듈 최상단의 `이름 = 표현식` 지도. 재대입되는 이름은 버린다 —
    무엇으로 치환할지 모르는 것을 치환하면 없는 사고를 만들어 낸다."""
    seen: dict[str, ast.expr] = {}
    dropped: set[str] = set()
    for node in tree.body:
        if not isinstance(node, ast.Assign):
            continue
        for target in node.targets:
            if not isinstance(target, ast.Name):
                continue
            if target.id in seen:
                dropped.add(target.id)
            seen[target.id] = node.value

    # 어디서든 다시 대입되는 이름은 버린다 — 모듈 최상단만 보면 지연 싱글턴
    # (`_organism = None` 뒤 함수 안에서 `global`로 채우는 꼴)이 전부 오탐이
    # 된다. 첫 판이 우리 코드에서 여섯을 그렇게 잡았고, 여섯 다 가짜였다.
    # 보내기 전에 자기 도구를 먼저 재는 것이 이 형식의 규율이다.
    for node in ast.walk(tree):
        names = []
        if isinstance(node, ast.Assign):
            names = [t.id for t in node.targets if isinstance(t, ast.Name)]
        elif isinstance(node, (ast.AugAssign, ast.AnnAssign)) and isinstance(node.target, ast.Name):
            names = [node.target.id]
        elif isinstance(node, ast.Global):
            names = list(node.names)
        for name in names:
            if name in seen and node not in tree.body:
                dropped.add(name)

    for name in dropped:
        seen.pop(name, None)
    return seen


def _substitute(node: ast.expr, defs: dict[str, ast.expr]) -> ast.expr:
    """이름을 정의로 한 번 바꾼다. 속성 접근(`m.__version__`)도 마지막
    이름으로 본다 — 그것이 Organum 사례의 모양이다."""
    if isinstance(node, ast.Name) and node.id in defs:
        return defs[node.id]
    if isinstance(node, ast.Attribute) and node.attr in defs:
        return defs[node.attr]
    return node


def _same(a: ast.expr, b: ast.expr) -> bool:
    try:
        return ast.dump(a, annotate_fields=False) == ast.dump(b, annotate_fields=False)
    except Exception:
        return False


def find(path: Path) -> list[tuple[int, str]]:
    try:
        tree = ast.parse(path.read_text(encoding="utf-8", errors="ignore"))
    except SyntaxError:
        return []
    defs = module_definitions(tree)
    hits = []
    for node in ast.walk(tree):
        left = right = None
        if isinstance(node, ast.Compare) and len(node.ops) == 1 and \
                isinstance(node.ops[0], (ast.Eq, ast.NotEq, ast.Is, ast.IsNot)):
            left, right = node.left, node.comparators[0]
        elif isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) \
                and node.func.attr in EQUALITY_METHODS and len(node.args) >= 2:
            left, right = node.args[0], node.args[1]
        if left is None or right is None:
            continue
        if _same(left, right):
            hits.append((node.lineno, "양변이 글자 그대로 같다"))
            continue
        if _same(_substitute(left, defs), _substitute(right, defs)):
            hits.append((node.lineno,
                         f"치환 후 같아진다: {ast.unparse(left)} ↔ {ast.unparse(right)}"))
    return hits


def main(argv: list[str]) -> int:
    roots = [Path(a) for a in argv[1:]] or [Path("tests")]
    files = [p for r in roots for p in ([r] if r.is_file() else sorted(r.rglob("*.py")))
             if "__pycache__" not in str(p) and ".venv" not in str(p)]
    total = 0
    for p in files:
        for line, why in find(p):
            print(f"{p}:{line}: 공허할 수 있는 단언 — {why}")
            total += 1
    print(f"\n{len(files)}개 파일 · 지적 {total}건 "
          f"(하한이다 — 못 잡은 것에 대해서는 아무 말도 하지 않는다)")
    return 1 if total else 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
