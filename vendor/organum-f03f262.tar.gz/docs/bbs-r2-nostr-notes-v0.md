# BBS R2 노트 v0 — NIP-29 세부·Buzz 커스텀 kind 지형 실측

작성: Organum Cody · 2026-08-30 · 상태: R2 완료(스펙 raw + block/buzz 저장소 직접 열람)
선행: `bbs-history-notes-v0.md`(R1) · 조사 원문 별도 보관, 주장마다 출처 확인됨.

## 1. NIP-29의 뼈대 — 프로파일이 밟을 자리

- **그룹 = id + 그 id에 규칙을 집행하는 relay.** 스펙 원문이 그렇게 정의한다.
  그룹 생성 절차는 스펙에 없고(9007이 있을 뿐), 접근 규칙 집행은 전적으로 relay
  정책 — **집행 프로토콜 자체(NIP-42 쓰는지 등)는 스펙 밖이다.** managed/unmanaged
  구분은 현행 master에서 사라졌다.
- **관리 이벤트**: 9000 put-user(재발행=역할 갱신)·9001 remove-user(9022 수신 시
  relay 자동 발행)·9002 edit-metadata·9005 delete-event·9007/9008 create/delete-
  group·9009 create-invite·9010 update-pin-list·**9021 join-request/9022
  leave-request**(사용자 발신). 9003·9004·9006·9011–9020은 예약 공백.
- **메타데이터(relay 마스터키 서명, addressable)**: 39000 group metadata(플래그
  포함)·39001 admins·39002 members(존재 보장 없음·부분 목록 가능)·39003 roles
  (**역할의 권한 의미는 스펙 밖** — relay 정책)·39005 pinned events.
- **플래그**: `private`(멤버만 읽기)·`restricted`(멤버만 쓰기)·`hidden`(메타데이터
  숨김)·`closed`(join request 무시, 초대 코드 예외). 초대: 9009로 code 생성 →
  naddr에 실어 공유 → 9021에 code 태그.
- **timeline references**: 사용자 이벤트에 `previous` 태그(최근 이벤트 id 앞
  8hex, 권장 3+) — relay가 자기 DB에 없는 참조를 거부해 **포크된 그룹으로의
  맥락 밖 재전파를 차단**. 서명 안에 들어간다.

## 2. 우리 봉투 모델에 걸리는 제약 — R3의 제1 설계 사실

**`h` 태그(그룹 좌표)는 서명 대상 태그다. 이미 서명된 봉투를 나중에 게시판에
"싣기"는 불가능하다** — 서명 시점에 게시판 좌표를 알아야 한다. `previous`도 서명
안이라, 그걸 집행하는 relay에선 최근 이벤트를 먼저 읽고 서명해야 한다. 또 Buzz는
NIP-42 인증 필수 + **저자 pubkey=인증 pubkey 강제**라 제3자 대리 게시가 막힌다 —
봉투 발신 키 자체가 접속 멤버여야 한다.

→ R3 결론 후보: **게시판 글은 기존 봉투의 재운반이 아니라 새 서명 행위다.**
"이메일 봉투를 게시판에 전재"가 아니라 "게시판 좌표를 품고 태어나는 게시물".
이메일(hub)과 게시판(bbs)은 같은 키·같은 신원 위의 **다른 발화 형식**이 된다.

## 3. Buzz 실측 — 표준과의 이탈 대장

- **커스텀 kind**: kind 9(스트림 채팅, `h` 필수)·9030–9033(NIP-43 relay 멤버십
  관리 — 그룹이 아니라 relay 층)·**9040–9044(moderation: ban/unban/timeout/
  untimeout/resolve-report — Buzz 독자)**·13534(relay 서명 멤버 명부 스냅샷,
  NIP-70 protected)·8000/8001(멤버 증감 델타)·20001/20002(ephemeral 프레즌스·
  타이핑)·40002–40008(메시지 v2·수정·핀·북마크·예약 등 — 표준 클라이언트 렌더
  불가)·44100/44101(멤버 증감 알림, 수신자 p-gated).
- **표준 이탈 주의점**: 39005/39006을 THREAD_SUMMARY/WINDOW_BOUNDS 오버레이로
  써서 **표준 39005(pinned events)와 번호 충돌**. 9009는 저장만 되고 no-op,
  9010 미구현 흔적. 39003 roles는 방출 안 함. `previous` 집행 흔적 없음.
- **"표준 클라이언트가 그대로 붙나"**: 문서상 "가능(NIP-29+42)"이나 검증은 자체
  테스트 클라이언트와 nak뿐 — **anecdotal이라고 스스로 표기.** 우리 프로파일은
  vanilla NIP-29 기준으로 잡고, Buzz 이탈점은 이 대장으로 관리한다.
- **self-host**: Apache 2.0, Rust, Docker Compose(Postgres 17·Redis 7·MinIO).
  운용 판단은 LxM 몫이며 JJ의 상주 Docker 회피 방침·Render free 티어 제약이
  변수 — R3에서 "우리 drop 위 최소 구현 vs Buzz 채택"의 비교표가 필요하다.

## 4. NIP-OA/NIP-AA — 위임 신원의 기성 관례가 있었다

Buzz의 agent 신원 모델(Block 제안 NIP, 아직 표준 병합 아님):

- 에이전트는 **자기 keypair**를 갖는다. owner 결속은 이벤트의 `auth` 태그 하나 —
  owner 키가 `nostr:agent-auth:<agent-pubkey>:<conditions>`에 서명(conditions는
  kind·created_at 절만). **저자는 끝까지 agent 키**(owner로 치환·병합 금지).
- 인증(NIP-AA): relay가 NIP-42 challenge → agent가 AUTH 이벤트에 `auth` 태그 동봉
  → relay는 owner가 활성 멤버인지 확인 후 **virtual membership** 부여. **owner
  멤버십이 철회되면 agent 접속도 다음부터 자동 차단.** agent 키 유출≠owner 키 유출.

우리 현재 모델(크리처 무키·랩 서명 대필+author 표기)과의 대조가 **R3의 결정
항목**이다: 두 모델 다 "크리처가 랩 키를 안 갖는다"는 지키지만, NIP-OA는 크리처
발화의 저자성이 암호학적으로 서고(자기 키), 우리는 랩 provenance가 서는 대신
저자성이 본문 표기다. 게시판(1:N 상시 발화)에서는 저자성 요구가 이메일보다 높다
— 주소 계약 §3("랩 서명=운반 증명, 대필 아님")의 게시판판이 NIP-OA 모양일 수
있다. 단 표준 미병합·Buzz 전용이라는 지위는 정직하게 대장에 남긴다.

## 5. R3 설계 입력 추가분 (R1의 6개에 이어)

7. **게시물=서명 시점에 게시판 좌표 내장**(h in-signature) — 봉투 재운반 아님,
   같은 신원의 다른 발화 형식.
8. **위임 신원 결정 항목**: 무키+랩 서명(현행) vs NIP-OA형(크리처 개별 키+owner
   attestation) — 게시판의 저자성 요구 기준으로 R3에서 비교·판정. 판정 전 구현 금지.
9. **vanilla NIP-29 기준 프로파일 + Buzz 이탈 대장 병행** — Buzz 낙관은 문서상
   주장으로만 취급.
10. **backend 비교표**(R3 산출물에 포함): 우리 drop 위 최소 게시판 구현 vs Buzz
    self-host 채택 — 운용 비용·집행 위치·이탈 대장·LxM 의견.

## 6. 미확인

NIP-29 private 그룹의 읽기 차단 프로토콜(스펙 침묵·relay 재량) · Buzz의 미등록
kind 수용 정책(코드 미확인) · Chachi/0xchat 실접속(anecdotal) · Buzz의 previous/
9010 처리 부재의 의도 여부.
