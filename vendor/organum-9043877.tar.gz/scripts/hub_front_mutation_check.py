"""0.9.0 변이 검사 — MCP 창구(`hub_front.py`)와 그것을 받치는 드롭 서버의 변경 셋.

판정 한 곳을 일부러 망가뜨린 사본을 임시 디렉터리에 만들고 시험을 돌린다. 모든 변이가
**시험 실패**로 끝나야 한다. 수집 오류는 잡힘이 아니다.

    python3 scripts/hub_front_mutation_check.py

종료코드 0 = 기준선 통과 + 모든 변이가 시험 실패로 잡힘.
"""
import os, pathlib, shutil, subprocess, sys, tempfile
ROOT = pathlib.Path(__file__).resolve().parents[1]
F, D = "src/organum/hub_front.py", "src/organum/hub_drop.py"
T = "tests/test_hub_front.py"
M = [
 ("baseline", F, "", ""),
 # ── 누가, 무엇을 ──
 ("우편함이 없는 호출자를 통과", F, "        if grant is None:\n            return 403,", "        if False:\n            return 403,"),
 ("목록에서 받는 이를 안 봄", F, '                    if env is None or env["to"] != grant.recipient:\n                        continue', "                    if env is None:\n                        continue"),
 ("한 통 받기에서 받는 이를 안 봄", F, '            if env is None or env["to"] != grant.recipient:\n                # 남의', "            if env is None:\n                # 남의"),
 ("목록이 우편함 밖의 문을 엶", F, "        if door is not None and door not in grant.doors:", "        if False:"),
 ("한 통 받기가 우편함 밖의 문을 엶", F, "        if door not in grant.doors:", "        if False:"),
 ("커서로 문을 넓힘", F, "                if d in doors and isinstance(n, str)", "                if isinstance(n, str)"),
 ("문에 패턴을 받음", F, "        if not doors or not all(isinstance(d, str) and _DOOR_RE.match(d) for d in doors):", "        if not doors:"),
 # ── HTTP 한 겹 ──
 ("GET을 받음", F, '        if method.upper() != "POST":', "        if False:"),
 ("Origin을 안 봄", F, "        if origin is not None and self._origins is not None and origin not in self._origins:", "        if False:"),
 ("요청 크기 한도 없음", F, "        if len(body) > REQUEST_MAX_BYTES:", "        if False:"),
 ("한 요청에 여러 메시지를 받음", F, "        if not isinstance(message, dict):\n            return self._http(400,", "        if False:\n            return self._http(400,"),
 ("알림에 답함", F, '        if "id" not in message:\n            return 202, None', '        if "id" not in message:\n            return 200, {"jsonrpc": "2.0"}'),
 ("id의 모양을 안 봄", F, "        if isinstance(id_, bool) or not isinstance(id_, (str, int)):\n            return 400,", "        if False:\n            return 400,"),
 # ── 두 시대 ──
 ("모르는 modern 판을 받음", F, "        if version not in MODERN_VERSIONS:", "        if False:"),
 ("머리와 본문의 어긋남을 통과", F, "            if problem:\n                return 400,", "            if False:\n                return 400,"),
 ("Mcp-Name이 달라도 통과", F, '            if name != params.get("name"):', "            if False:"),
 ("Mcp-Method가 달라도 통과", F, '        if headers.get("mcp-method") != method:', "        if False:"),
 ("클라이언트 능력 칸 없이 통과", F, '        if method != "server/discover" and not isinstance(meta.get(META_CLIENT_CAPABILITIES), dict):', "        if False:"),
 ("modern의 모르는 메서드에 404가 아님", F, '            return 404, self._error(id_, ERR_METHOD_NOT_FOUND, f"Method not found: {method}")', '            return 200, self._error(id_, ERR_METHOD_NOT_FOUND, f"Method not found: {method}")'),
 ("modern 결과에 resultType 없음", F, '                    "result": {**result, "resultType": "complete",', '                    "result": {**result,'),
 ("머리가 modern인데 본문에 판이 없어도 legacy로", F, "        if header_version in MODERN_VERSIONS:\n            return 400,", "        if False:\n            return 400,"),
 ("legacy가 모르는 판을 그대로 답함", F, '"protocolVersion": asked if asked in LEGACY_VERSIONS else LEGACY_VERSIONS[0],', '"protocolVersion": asked,'),
 ("legacy의 모르는 판 머리를 통과", F, "        if method != \"initialize\" and header_version is not None \\\n                and header_version not in LEGACY_VERSIONS:", "        if False:"),
 ("modern을 꺼도 modern으로 답함", F, "        if not self._modern_on:\n            return self._legacy(", "        if False:\n            return self._legacy("),
 ("legacy의 모르는 메서드를 판 머리로 먼저 막음", F, '        if method not in ("initialize", "ping", "tools/list", "tools/call"):', "        if False:"),
 ("읽기 전용 표시를 뺌", F, '    read_only = {"readOnlyHint": True,', '    read_only = {"readOnlyHint": False,'),
 # ── 바이트와 한도 ──
 ("도구의 답에 크기 한도 없음", F, "            if not fits(result):", "            if False:"),
 ("한도를 보내는 바이트가 아니라 도구의 글로 잼(Orin 057)", F, '            return len(_dump(wrap(result)).encode("utf-8")) <= self._response_max', '            return len(result["content"][0]["text"].encode("utf-8")) <= self._response_max'),
 ("한도가 한 바이트 좁음", F, '            return len(_dump(wrap(result)).encode("utf-8")) <= self._response_max', '            return len(_dump(wrap(result)).encode("utf-8")) < self._response_max'),
 ("줄였다면서 본문을 그대로 둠", F, '        out = {**out, "status": "too_large", "body": None, "body_encoding": None,', '        out = {**out, "status": "too_large",'),
 ("줄인 답이 들어가는지 다시 안 잼", F, "                    if fits(result):\n                        break", "                    if True:\n                        break"),
 ("봉투를 빼는 차례가 없음", F, '        out = {**out, "envelope": None, "sig": None}\n        out.pop("envelope_base64", None)\n        yield out', "        return"),
 ("넘쳐서 못 보낸 편지를 내줬다고 적음", F, 'result, status, kept = failed(_TOO_LARGE[name]), "too_large", False', 'result, status, kept = failed(_TOO_LARGE[name]), "too_large", True'),
 ("마지막 문이 없음", F, "        if len(raw) <= self._response_max:\n            return status, out, raw", "        if True:\n            return status, out, raw"),
 ("마지막 문이 큰 id를 그대로 되돌림", F, "        for echoed in (id_, None):", "        for echoed in (id_,):"),
 ("한도의 바닥이 없음", F, "        if self._response_max < RESPONSE_MIN_BYTES:", "        if False:"),
 ("봉투의 긴 칸을 그대로 실음", F, "    return value if isinstance(value, str) and len(value) <= FIELD_MAX_CHARS else None", "    return value if isinstance(value, str) else None"),
 ("목록이 본문의 긴 이름을 그대로 실음", F, '                                    "body_name": _short(entry.get("body_name")),', '                                    "body_name": entry.get("body_name"),'),
 ("한 통 받기가 본문의 긴 이름을 그대로 실음", F, '               "body_name": _short(q.get("body_name")), "notice": NOTICE}', '               "body_name": q.get("body_name"), "notice": NOTICE}'),
 ("어긋난 봉투의 알림을 개수에 안 셈", F, "                    if len(letters) + len(problems) >= limit or self._left(deadline) <= 0:", "                    if len(letters) >= limit or self._left(deadline) <= 0:"),
 ("보낸 이를 확인된 것처럼 실음(목록)", F, '                                    "sender": {"claimed": env["from"], "verified": False},', '                                    "sender": {"claimed": env["from"], "verified": True},'),
 ("보낸 이를 확인된 것처럼 실음(한 통)", F, '               "sender": {"claimed": env["from"], "verified": False}, "signature_checked": False,', '               "sender": {"claimed": env["from"], "verified": True}, "signature_checked": False,'),
 ("다 못 본 것을 다 봤다고 답함", F, '"letters": letters, "more": more, "complete": not more,', '"letters": letters, "more": more, "complete": True,'),
 ("본문과 봉투의 지문을 안 견줌", F, 'body_matches_envelope=_sha(body) == env["body_sha256"])', "body_matches_envelope=True)"),
 ("UTF-8이 아닌 본문을 글로 바꿔 냄", F, '                text = body.decode("utf-8")', '                text = body.decode("utf-8", "replace")'),
 ("base64 청을 무시", F, '        if encoding == "text":\n            try:\n                text = body', '        if True:\n            try:\n                text = body'),
 ("색인과 다른 봉투를 그대로 냄", F, '                    if entry.get("envelope_sha256") not in (None, _sha(raw)):', "                    if False:"),
 ("받은 편지라는 알림을 뺌", F, '"cursor": _encode_cursor(positions), "examined": examined, "notice": NOTICE}', '"cursor": _encode_cursor(positions), "examined": examined, "notice": ""}'),
 # ── 본문은 받는 이를 확인한 뒤에만 · 감사 ──
 ("받는 이를 보기 전에 편지를 통째로 가져옴", F, "            raw = self._reader.envelope(door, n, timeout=self._left(deadline))\n            trail", '            raw = self._reader.letter(door, n, timeout=self._left(deadline))["envelope"]\n            trail'),
 ("두 번 읽는 사이에 달라진 편지를 내줌", F, '        if q["envelope"] != raw:', "        if False:"),
 ("봉투를 묶어 읽지 않음", F, "            if many is not None:", "            if False:"),
 ("드롭에서 봉투를 본문과 함께 받음", F, 'body = self._get(f"{door}?since={since}&limit={int(limit)}&bodies=0", timeout)', 'body = self._get(f"{door}?since={since}&limit={int(limit)}", timeout)'),
 ("본문이 딸려 온 봉투를 그대로 받음", F, '                if "body_b64" in q:', "                if False:"),
 ("감사를 적지 못해도 내줌", F, '                return failed("the mail front could not record this read; nothing was returned")', "                pass"),
 ("감사를 부르지 않음", F, '        if self._audit is not None and trail["fetched"]:', "        if False:"),
 ("내주지 않은 편지를 내줬다고 적음", F, '            if not kept:\n                trail["delivered"] = []', '            if False:\n                trail["delivered"] = []'),
 ("묶어 가져온 봉투를 감사에 안 적음", F, '                trail["fetched"].extend([door, k] for k in got)', "                pass"),
 ("하나씩 가져온 봉투를 감사에 안 적음", F, '        trail["fetched"].append([door, n])\n        return raw', "        return raw"),
 ("한 통 받기가 가져온 봉투를 감사에 안 적음", F, '            trail["fetched"].append([door, n])\n            trail["examined"]', '            trail["examined"]'),
 ("연 봉투를 감사에 안 적음(목록)", F, '                    trail["examined"].append([d, n])', "                    pass"),
 # ── 커서와 시간 ──
 ("커서가 본 데까지 가지 않음", F, "                    positions[d] = n                      # 내 앞이 아닌 편지도 지나간다", "                    pass"),
 ("처음에 문을 통째로 훑음", F, "        if position is None and len(entries) > self._lookback:", "        if False:"),
 ("개수 한도를 안 지킴", F, "                    if len(letters) + len(problems) >= limit or self._left(deadline) <= 0:", "                    if self._left(deadline) <= 0:"),
 ("시간의 예산을 안 지킴", F, "                    if len(letters) + len(problems) >= limit or self._left(deadline) <= 0:", "                    if len(letters) + len(problems) >= limit:"),
 ("색인의 다음 쪽을 안 읽음", F, '            if not page.get("more") or not got:\n                break', "            if True:\n                break"),
 ("아직인 읽는 길을 실패로 답함", F, '            raise NotReady(30, "the drop did not answer in time") from None', '            raise ReaderError("the drop did not answer in time") from None'),
 ("빈 번호 뒤의 편지를 그 번호로 내줌", F, '        if not isinstance(quads, list) or not quads or quads[0].get("n") != n:', "        if not isinstance(quads, list) or not quads:"),
 ("색인이 없는 드롭을 모르고 지나감", F, '        if not isinstance(body.get("index"), list):', "        if False:"),
 # ── 드롭 서버 ──
 ("읽기만 줄이 상태 칸에 씀", D, '        if entry.state_slot() != "write":', "        if False:"),
 ("쓰기 범위 없는 줄을 쓰는 줄로 봄", D, '        return "write" if (self.legacy or self.write) else "read"', '        return "write"'),
 ("id 없는 줄·폐기 줄에 칸을 줌", D, '        if self.revoked or not self.explicit_id:\n            return "none"', '        if False:\n            return "none"'),
 ("limit을 무시", D, "        quads = [b for n in fresh[:page] if (b := _quad_files(dirp, n, with_bodies))]", "        quads = [b for n in fresh[:PAGE_SIZE] if (b := _quad_files(dirp, n, with_bodies))]"),
 ("본문 없이 받기를 청해도 본문을 실음", D, "        quads = [b for n in fresh[:page] if (b := _quad_files(dirp, n, with_bodies))]", "        quads = [b for n in fresh[:page] if (b := _quad_files(dirp, n, True))]"),
 ("bodies의 값을 안 봄", D, '            if q["bodies"] not in ("0", "1"):', "            if False:"),
 ("본문 없이 읽은 것을 감사 줄에 안 남김", D, "                    bodies=None if with_bodies else False)", "                    bodies=None)"),
 ("limit의 범위를 안 봄", D, "            if not (lim.isdigit() and len(lim) <= 3 and 1 <= int(lim) <= PAGE_SIZE):", "            if not lim.isdigit():"),
 ("more를 쪽의 크기로 안 셈", D, '        self._send(200, {"quads": quads, "more": len(fresh) > page})', '        self._send(200, {"quads": quads, "more": len(fresh) > PAGE_SIZE})'),
 ("감사 줄에 표지의 답을 안 남김", D, 'meta=q.get("meta") == "1" or None, mirrored=mirrored)', 'meta=q.get("meta") == "1" or None)'),
]
env = dict(os.environ)
bad = 0
tmp = tempfile.mkdtemp(prefix="frontmut-")
for name, target, a, b in M:
    d = pathlib.Path(tmp) / "w"
    shutil.rmtree(d, ignore_errors=True)
    (d / "tests").mkdir(parents=True)
    shutil.copytree(ROOT / "src", d / "src", ignore=shutil.ignore_patterns("__pycache__", "*.egg-info"))
    shutil.copy(ROOT / T, d / "tests/")
    f = d / target
    src = f.read_text(encoding="utf-8")
    if a and src.count(a) != 1:
        print(f"ANCHOR MISSING({src.count(a)}): {name}"); bad += 1; continue
    if a:
        f.write_text(src.replace(a, b), encoding="utf-8")
    r = subprocess.run([sys.executable, "-m", "pytest", str(d / "tests"), "-q", "-p", "no:cacheprovider", "-x"],
                       capture_output=True, text=True, env=env, cwd=d)
    tail = [l for l in r.stdout.splitlines() if " passed" in l or " failed" in l or " error" in l]
    summ = tail[-1] if tail else "NO SUMMARY"
    coll = "error" in summ and "failed" not in summ and "passed" not in summ
    if not a:
        v = "BASELINE-OK" if r.returncode == 0 else "BASELINE-FAIL"; bad += r.returncode != 0
    else:
        v = "COLLECTION-ERROR" if coll else ("CAUGHT" if r.returncode else "MISSED"); bad += v != "CAUGHT"
    print(f"{v:16} {name} :: {summ}")
shutil.rmtree(tmp, ignore_errors=True)
sys.exit(1 if bad else 0)
