#!/usr/bin/env python3
"""dev(private JihoonJeong/organum) → public cut(ludex-lab/organum) 수출.

공개 모델 = ludex와 같은 public-cut: dev repo는 private 유지, 공개는 화이트리스트
경로만 큐레이션해 cut repo로 복사한다. PyPI 배포(단일 패키지 organum)는 **cut에서
빌드**한다 — dev 내부(실험·핸드오프·저널·상태)는 절대 공개면에 닿지 않는다.

기본 dry-run(무엇이 복사될지 출력만). `--apply`로 실제 복사. **git add/commit/push는
하지 않는다** — 공개면 반영은 사람이 cut repo에서 diff를 보고 결정한다.

    python3 scripts/export-public-cut.py            # dry-run
    python3 scripts/export-public-cut.py --apply    # 복사 실행
"""

import argparse
import shutil
import sys
from pathlib import Path

DEV = Path(__file__).resolve().parent.parent
DEFAULT_CUT = Path.home() / "Projects" / "ludex-lab-organum"

# 공개되는 것 전부가 이 목록에서 나온다 — 여기 없는 경로는 공개면에 닿지 않는다.
# (src, dst) 리맵 주의: cut의 docs/는 GitHub Pages 사이트 루트라 문서는 manual/로 보낸다.
WHITELIST = [
    ("src/organum/", "src/organum/"),
    ("tests/", "tests/"),
    ("skills/", "skills/"),        # 번들 skill — invariant 테스트(Inv8)가 자기 provision 검사
    ("pyproject.toml", "pyproject.toml"),
    ("LICENSE", "LICENSE"),
    ("docs/quickstart-inspector.md", "manual/quickstart-inspector.md"),
    ("docs/quickstart-inspector.en.md", "manual/quickstart-inspector.en.md"),
    ("docs/quickstart-observe.md", "manual/quickstart-observe.md"),
    ("docs/quickstart-observe.en.md", "manual/quickstart-observe.en.md"),
    ("docs/case-study-inspector-duel.md", "manual/case-study-inspector-duel.md"),
    ("docs/case-study-inspector-duel.en.md", "manual/case-study-inspector-duel.en.md"),
    ("docs/case-study-inspector-duel.json", "manual/case-study-inspector-duel.json"),
    ("docs/quickstart-hub.md", "manual/quickstart-hub.md"),
    ("docs/quickstart-hub.en.md", "manual/quickstart-hub.en.md"),
]
EXCLUDE_NAMES = {"__pycache__", ".DS_Store"}


def _iter_files(p: Path):
    if p.is_file():
        yield p
        return
    for f in sorted(p.rglob("*")):
        if f.is_file() and not (set(f.parts) & EXCLUDE_NAMES):
            yield f


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--cut", default=str(DEFAULT_CUT), help=f"cut repo 경로 (기본 {DEFAULT_CUT})")
    ap.add_argument("--apply", action="store_true", help="실제 복사 (기본은 dry-run)")
    args = ap.parse_args()
    cut = Path(args.cut).expanduser()
    if not (cut / ".git").is_dir():
        print(f"export: cut repo가 아님: {cut}", file=sys.stderr)
        return 1
    n = 0
    for src_entry, dst_entry in WHITELIST:
        src = DEV / src_entry
        if not src.exists():
            print(f"  ! 없음(건너뜀): {src_entry}", file=sys.stderr)
            continue
        for f in _iter_files(src):
            rel = f.relative_to(DEV / src_entry) if src.is_dir() else None
            dst = (cut / dst_entry / rel) if rel is not None else (cut / dst_entry)
            print(f"  {f.relative_to(DEV)} → {dst.relative_to(cut)}")
            if args.apply:
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(f, dst)
            n += 1
    mode = "복사됨" if args.apply else "복사 예정 (dry-run — 실행은 --apply)"
    print(f"export: {n}개 파일 {mode} → {cut}")
    if args.apply:
        print("다음: cut repo에서 `git diff` 검토 → 사람이 commit/push (스크립트는 안 함)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
