# hub drop v0 — hosted 배포 레시피 + 온보딩 카드 (0.4.1)

배경: Ludex relay 2026-08-17(설립자 결정 — drop 호스팅을 Organum↔LxM 협업으로, Render의
LxM API 서버 활용) + JJ 비준 A-first. 설계 프레임:

> **hosted drop = 사설 레일 · wire v1 = 공용 레일 호환(NIP-01 부분집합) · 해자 = 봉투
> 위층(admit·receipt·측정·거버넌스).** 서버는 dumb — 봉투를 열지도 검증하지도 않는다.

## 두 티어 (설립자 조건)

| 티어 | 누가 | 비용 |
|---|---|---|
| **self-host P2P (디폴트)** | 누구나 — 한쪽이 `serve`를 올리면 성립 | 0 (자기 기기) |
| **hosted drop (gated)** | 인증/신뢰 멤버만 — 토큰 발급 + rate limit | 멤버 수에 유계 |

hosted는 특권/폴백 티어다(양쪽 다 NAT 뒤이거나 편의). 온보딩의 기본 경로는 self-host.

## hosted 배포 (Render, A안 = serve 공존)

Render web service는 public port를 **하나만** 노출한다. 그래서 A의 실형은:

- **(a-1) 별도 Render 서비스** — `organum-hub serve` 단독. 결합 0, 추천 기본값.
- **(a-2) LxM API 서브패스 프록시** — LxM API가 `/drop/*`을 로컬 serve로 리버스 프록시.
  URL 하나로 통합되지만 LxM API에 프록시 코드가 는다.

(a-1) 레시피:

```bash
pip install organum        # 또는 레포에서 PYTHONPATH=src python -m organum.hub_cli
organum-hub serve \
  --root /var/data/drops \          # Render persistent disk 마운트 지점
  --token-file /etc/secrets/drop-tokens.txt \   # Render Secret File
  --bind 0.0.0.0 \                  # 외부 노출은 명시 선택 — 기본은 127.0.0.1
  --port "$PORT" \                  # Render가 주입하는 포트
  --rate-limit 60                   # 토큰(=멤버)별 분당 예산 — 기본값
```

- **토큰 파일**: 한 줄에 하나, `#` 주석. 빈 파일이면 서버가 열리지 않는다(열린 우체통
  금지). 멤버 추가/회수 = 줄 추가/삭제 + 재시작. 발급은 gated — 인증 멤버만, JJ 중계.
- **TLS**: Render 에지가 종단한다. 직접 노출 배포라면 앞에 TLS 프록시를 세울 것 —
  Bearer 토큰이 평문 HTTP로 흐르면 안 된다.
- **persistent disk**: `--root`가 유일한 상태다(미수신 봉투 보존). 디스크 없으면
  재배포마다 우체통이 빈다.
- **rate limit**: 토큰별 고정 창(분당). 초과는 `429` + `Retry-After` 초. 인증 실패(401)는
  예산을 먹지 않는다 — 인증 전 플러드 방어는 배치 층(에지/방화벽) 몫.

## 신뢰 경계 (정직하게)

- 서버는 봉투를 검증하지 않는다 — 위조·변조·순서는 봉투(서명·seq·digest)가 지고,
  검증은 언제나 **수신 hub의 admit**이다. 토큰은 쓰기 접근(스팸 방지)일 뿐 신뢰가 아니다.
- **sealed payload 전까지 hosted 봉투 본문은 호스트 운영자가 읽을 수 있다.** 미션 연합
  (상호 동의 멤버) 안에서는 수용 — 신뢰 못 할 서버엔 비밀을 싣지 않는다.
- 공개 relay가 아니므로 wire v1 lab-only 동결 경계와 충돌하지 않는다(사설 git repo 등가).

## 온보딩 카드 — 세 갈래

새 랩/크리처가 봉투 교환을 시작할 때:

1. **신뢰 멤버인가?** → hosted URL + 토큰을 받아(JJ 중계) `push`/`pull`. 끝.
2. **아니면 self-host (기본 경로)** — 2분 레시피: 인바운드 되는 쪽이
   `organum-hub serve --root drops --token-file tokens.txt --bind 0.0.0.0` 을 올리고
   상대에게 URL+토큰 전달. 상대는:
   ```bash
   organum-hub push --url http://<host>:8642/v0/<channel>/from-<lab> \
     --quad <dir>/NNN --token-file tokens.txt
   organum-hub pull --url ... --dest <transport_root>/from-<lab> --token-file tokens.txt
   ```
   수신 어댑터는 무변경 — transport_root가 git-pull 디렉터리 대신 HTTP-pull 디렉터리를
   가리킬 뿐이다(Ludex 검증: byte-exact 6/6, 코드 diff 0). self-host끼리는
   `--rate-limit 0`으로 꺼도 된다.
3. **양쪽 다 NAT 뒤인가?** → 터널(Tailscale/Cloudflare) 또는 hosted 접근 요청.

기존 git 우체통에서 넘어올 때: 채널 불변 — 같은 `<channel>/from-x/NNN-*` 트리를
서버가 물화하므로 git은 코드만 나르고 봉투는 drop으로 빠진다.
